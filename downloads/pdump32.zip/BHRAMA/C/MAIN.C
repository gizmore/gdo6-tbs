/* 
 * Bhrama Client-Server Interface 0.3
 * (c)1999 CindyG
 *
 * main.c : test application for bhrama c interface
 */

#define WIN32_LEAN_AND_MEAN
#define STRICT
#include <windows.h>
#include <commdlg.h>
#include "bhrama.h"

void main(void)
{
	STARTUPINFO			sinfo;
	PROCESS_INFORMATION	pinfo;
	OPENFILENAME		ofn;
	CHAR				filename[260];

	/* Get the target filename */
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize  = sizeof(ofn);
	ofn.lpstrFilter  = "Executable Files (*.exe)\0*.exe\0All Files (*.*)\0*.*\0";
	ofn.nFilterIndex = 1;
	ofn.lpstrFile    = filename;
	ofn.nMaxFile     = sizeof(filename);
	ofn.lpstrTitle   = "Select protected file to open";
	ofn.Flags        = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_NONETWORKBUTTON;
	if (0 == GetOpenFileName(&ofn)) {
		return;
	}

	/* Create the process */
	ZeroMemory(&sinfo, sizeof(sinfo));
	sinfo.cb = sizeof(sinfo);
	if (0 == CreateProcess(NULL, filename, NULL, NULL, FALSE, CREATE_SUSPENDED | NORMAL_PRIORITY_CLASS, NULL, NULL, &sinfo, &pinfo)) {
		MessageBox(NULL, "Failed to create process", "Error", MB_ICONERROR | MB_OK);
		return;
	}

	/* Wait for user verification */
	MessageBox(NULL, "Select 'AutoFix PE' in the Bhrama Server.\nPress OK to dump.", "Dump", MB_OK);
		
	/* Dump the process */
	if (TRUE == bhrama_dump(pinfo.dwProcessId, 0, 0, BHRAMA_IMPORT_USE, BHRAMA_OPT_DEFAULT)) {
		/* todo: switch to ProcDump save dialog */
		MessageBox(NULL, "Dump successful.", "Joy", MB_OK | MB_ICONINFORMATION);
	} else {
		MessageBox(NULL, "Dump failed. Check if Bhrama Server is running.", "Error", MB_OK | MB_ICONERROR);
	}

	/* Terminate the process */
	TerminateProcess(pinfo.hProcess, -28);
}

