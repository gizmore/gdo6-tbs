<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//*****************  PARSER: PRINTNEWS  *******************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}

$this->load("printnews,newslink");

$res=$this->first("SELECT a.*,b.username,b.email,c.name AS catname FROM ".PRE."_news AS a LEFT JOIN ".PRE."_user AS b USING(userid) LEFT JOIN ".PRE."_newscat AS c ON a.catid=c.id WHERE ( a.id='".$_REQUEST['id']."' AND ( ( a.pubtime AND a.pubtime<='".time()."' ) AND ( a.endtime='0' OR a.endtime>'".time()."' ) ) ) LIMIT 1");
	if ( !$res['id'] ) exit; //Verf�gbarkeits-Check

$input['%SEITENNAME%']=$this->replace($this->set['title']);
$input['%WEBSITE%']=$this->set['http'];
$input['%NEWSLINK%']=$this->set['http'].$this->set['newspage'].'?id='.$_REQUEST['id'].$this->iif($this->set['newsparams'],"&".$this->set['newsparams']);


	//DATUM
	if ( $_REQUEST['preview'] ) $date=getdate($res['time']);
	else $date=getdate($res['pubtime']);
	
	if ( $this->set['leadingzero'] ) $zform=2;
	else $zform=1;

$input['%JAHR%']=$date['year'];
$input['%MONAT%']=sprintf("%0".$zform.".d",$date['mon']);
$input['%TAG%']=sprintf("%0".$zform.".d",$date['mday']);
$input['%WOCHENTAG%']=$this->gerday($date['wday']);
$input['%KALENDERMONAT%']=$this->germon($date['mon']);
$input['%STUNDEN%']=sprintf("%02.d",$date['hours']);
$input['%MINUTEN%']=sprintf("%02.d",$date['minutes']);
$input['%SEKUNDEN%']=sprintf("%02.d",$date['seconds']);

$input['%TITEL%']=$this->textcodes($this->replace($res['topic'],1));
$input['%UNTERTITEL%']=$this->textcodes($this->replace($res['subtopic'],1));

	//USER
	if ( !$res['userid'] ) {
	$input['%USER%']=$this->replace($res['ext_user']);
	$input['%MAIL%']="mailto:".$res['ext_mail'];
	}
	else {
	$input['%USER%']=$this->replace($res['username']);
		if ( $res['email'] ) $input['%MAIL%']=$res['email'];
		else $input['%MAIL%']="-";
	}

$input['%KATEGORIE%']=$this->replace($res['catname']);

//TEXT
$thetext=eregi_replace("\[mehr\]","",$res['text']);

	if ( $this->set['usehtml'] && eregi("[html]",$thetext) && eregi("[/html]",$thetext) ) {
	$input['%TEXT%']=$this->codes($this->replace(preg_replace("/\[html\](.*?)\[\/html\]/sie", "\$this->htmlcodecache('\\1')",$thetext)),$this->set['useimg']);
		if ( is_array($this->htmlcode) ) foreach($this->htmlcode AS $key => $value) $input['%TEXT%']=str_replace("%HTMLCODE#".$key."%",$value,$input['%TEXT%']);
	}
	else $input['%TEXT%']=$this->codes($this->replace($thetext),$this->set['useimg']);


//LINKS
	for($i=1;$i<=3;++$i) {
		if ( $res['link'.$i] ) {
		$links=explode("|",$res['link'.$i]);
		$lins['%TITEL%']=$this->replace($links[0]);
		$lins['%LINK%']='<a href="'.$links[2].'"'.$this->iif($links[3]=="blank",' target="_blank"').'>'.$this->replace($links[1]).'</a>';
		$input['%LINKS%'].=strtr($this->file['newslink'],$lins);
		unset($links,$lins);
		}
	}
	if ( !$input['%LINKS%'] ) $input['%LINKS%']="";


//OUTPUT
echo strtr($this->file['printnews'],$input);
	
?>