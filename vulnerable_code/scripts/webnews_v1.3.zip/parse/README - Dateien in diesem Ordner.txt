Alle Dateien in diesem Ordner sind NICHT zum Includen in die Website bestimmt!
==============================================================================

Es handelt sich hierbei um Module, die eigenst�ndig nicht ausgef�hrt werden k�nnen!
Wie Sie das WEB//NEWS Script richtig in Ihre Website einbinden erfahren sie in der Readme.