<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//****************  KOMMENTAR HINZUF�GEN  *****************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}

list($lptime)=$this->first("SELECT time FROM ".PRE."_comment WHERE ip='".$_SERVER['REMOTE_ADDR']."' ORDER BY time DESC LIMIT 1");
list($blockip)=$this->first("SELECT string FROM ".PRE."_block WHERE ( type='ip' AND string='".$_SERVER['REMOTE_ADDR']."' AND endtime>='".time()."' ) LIMIT 1");
list($blockname)=$this->first("SELECT string FROM ".PRE."_block WHERE ( type='name' AND string='".addslashes($_POST['name'])."' AND endtime>='".time()."' ) LIMIT 1");

if ( 
!$_POST['name']
 || !$_POST['text']
 || ( $this->set['cf1']['useit'] && $this->set['cf1']['required'] && !$_POST['feld1'] )
 || ( $this->set['cf2']['useit'] && $this->set['cf2']['required'] && !$_POST['feld2'] )
 || ( $this->set['cf3']['useit'] && $this->set['cf3']['required'] && !$_POST['feld3'] )
 || ( $this->set['cf4']['useit'] && $this->set['cf4']['required'] && !$_POST['feld4'] )
 || ( $this->set['cf5']['useit'] && $this->set['cf5']['required'] && !$_POST['feld5'] )
) echo $this->message(0);
elseif ( $blockip || $blockname ) $this->message(1);
elseif ( ($lptime+$this->set['spamprot']*60)>time() ) $this->message(2,array("%DAUER%"=>(($lptime+$this->set['spamprot']*60)-time())));
elseif ( strlen($_POST['text'])>$this->set['maxcomchars'] ) $this->message(3,array("%ZEICHEN%"=>strlen($_POST['text']),"%ZEICHEN_MAX%"=>$this->set['maxcomchars']));
elseif ( $this->set['noshouting'] && preg_match("/\!\!\!\!|\?\?\?\?/is",$_POST['text']) ) $this->message(4);
else {
$this->query("INSERT INTO ".PRE."_comment (newsid,name,feld1,feld2,feld3,feld4,feld5,text,time,ip) VALUES ('".$_REQUEST['id']."','".addslashes($_POST['name'])."','".addslashes($_POST['feld1'])."','".addslashes($_POST['feld2'])."','".addslashes($_POST['feld3'])."','".addslashes($_POST['feld4'])."','".addslashes($_POST['feld5'])."','".addslashes($_POST['text'])."','".time()."','".$_SERVER['REMOTE_ADDR']."')");
	if ( $type=="archiv" ) $presite="arch";
	else $presite="news";
$link=$this->set[$presite.'page'].'?id='.$_REQUEST['id'].$this->iif($this->set[$presite.'params'],"&".$this->set[$presite.'params']);

echo $this->message(5,array("%LINK%"=>$link)).'<meta http-equiv="refresh" content="4; URL='.$link.'">';
}

?>