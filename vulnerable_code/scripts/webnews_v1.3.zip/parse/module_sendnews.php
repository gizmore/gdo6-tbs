<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//******************  PARSER: SENDNEWS  *******************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}

$this->load("sendnewsform");

$this->query("SELECT id,name FROM ".PRE."_newscat ORDER BY name ASC");
	while($res=$this->fetch()) $input['%KATS%'].='<option value="'.$res['id'].'">'.$this->replace($res['name']).'</option>';
$this->free();

$this->cache[]='<form action="'.$this->set['sendnpage'].$this->iif($this->set['sendnparams'],'?'.$this->set['sendnparams']).'" method="post">'.$this->iif($input,@strtr($this->file['sendnewsform'],$input),$this->file['sendnewsform']).'<input type="hidden" name="sendnews" value="1"></form>';
$this->out();

?>