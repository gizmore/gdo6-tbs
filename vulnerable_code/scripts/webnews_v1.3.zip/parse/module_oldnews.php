<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//******************  PARSER: OLDNEWS  ********************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}

$this->load("oldnewsentry");
$this->query("SELECT a.id,a.topic,a.subtopic,a.pubtime,a.ext_user,a.ext_mail,b.userid,b.username,b.email FROM ".PRE."_news AS a LEFT JOIN ".PRE."_user AS b USING(userid) WHERE ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) ORDER BY pin DESC, pubtime DESC LIMIT ".$this->set['maxnews'].",".$this->set['oldnewscount']);
	while($res=$this->fetch()) {
		if ( $this->set['leadingzero'] ) $zform=2;
		else $zform=1;
	$date=getdate($res['pubtime']);
	$input['%JAHR%']=$date['year'];
	$input['%MONAT%']=sprintf("%0".$zform.".d",$date['mon']);
	$input['%TAG%']=sprintf("%0".$zform.".d",$date['mday']);
	$input['%WOCHENTAG%']=$this->gerday($date['wday']);
	$input['%KALENDERMONAT%']=$this->germon($date['mon']);
	$input['%STUNDEN%']=sprintf("%02.d",$date['hours']);
	$input['%MINUTEN%']=sprintf("%02.d",$date['minutes']);
	$input['%SEKUNDEN%']=sprintf("%02.d",$date['seconds']);
	
		if ( !$res['userid'] ) {
		$input['%USER%']=$this->replace($res['ext_user']);
		$input['%MAIL%']="mailto:".$res['ext_mail'];
		}
		else {
		$input['%USER%']=$this->replace($res['username']);
			if ( $res['email'] ) $input['%MAIL%']="mailto:".$res['email'];
			else $input['%MAIL%']="#";
		}
	
		if ( $this->set['oldnewsmlen'] && strlen($res['topic'])>$this->set['oldnewsmlen'] ) $input['%TITEL%']=$this->textcodes($this->replace(substr($res['topic'],0,$this->set['oldnewsmlen']-3)."..."));
		else $input['%TITEL%']=$this->textcodes($this->replace($res['topic']));
	$input['%UNTERTITEL%']=$this->textcodes($this->replace($res['subtopic']));

		if ( $this->set['oldnewsltype']==2 ) $input['%LINK%']=$input['%LINK%']=$this->set['archpage']."?id=".$res['id'].$this->iif($this->set['archparams'],'&'.$this->set['archparams']);
		else $input['%LINK%']=$this->set['archpage']."?month=".$date['mon'].",".$date['year'].$this->iif($this->set['archparams'],'&'.$this->set['archparams']).'#wn'.$res['id'];
	
	$this->cache[]=strtr($this->file['oldnewsentry'],$input);
	unset($input,$date);
	}
$this->out();

?>