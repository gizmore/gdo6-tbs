<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//*******************  PARSER: SEARCH  ********************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}

	if ( !$_POST['item'] ) $this->message(7);
	else {
	$this->load("searchres,searchresheader");
	
	$pp=explode(" ",$_POST['item']);
	$marking=implode("+",$pp);
		
		//Search in Category
		if ( $_POST['catid'] ) $catid=" AND catid='".$_POST['catid']."'";
		
		//Make Query
		if ( $_POST['searchin']=="title" ) foreach ( $pp AS $find ) $wherecache[]=" ( topic LIKE '%".addslashes($find)."%' OR subtopic LIKE '%".addslashes($find)."%' ) ";
		elseif ( $_POST['searchin']=="text" ) foreach ( $pp AS $find ) $wherecache[]=" ( text LIKE '%".addslashes($find)."%' ) ";
		else foreach ( $pp AS $find ) $wherecache[]=" ( topic LIKE '%".addslashes($find)."%' OR subtopic LIKE '%".addslashes($find)."%' OR text LIKE '%".addslashes($find)."%' ) ";
	
		//Get LINK
		if ( $_POST['link']=="or" ) $link="OR";
		else $link="AND";
		
		if ( is_array($wherecache) ) $where=implode($link,$wherecache);
		unset($wherecache);
	
	
	$this->query("SELECT * FROM ".PRE."_news WHERE ( ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) $catid ".$this->iif($where,"AND ( ".$where." ) ")." ) ORDER BY pubtime DESC");
		if ( $this->checkres() ) {
			while($res=$this->fetch()) {
			$date=getdate($res['pubtime']);
				if ( intval($date['year'].sprintf("%02.d",$date['mon']))!=$stamp ) {
				$input['%MONAT%']=$this->germon($date['mon']);
				$input['%JAHR%']=$date['year'];
				$this->cache[]=strtr($this->file['searchresheader'],$input);
				unset($input);
				}
		
			$input['%TITLE%']=$this->replace($res['topic']);
			$input['%LINK%']=$this->set['searchpage'].'?id='.$res['id'].'&mark='.$marking.$this->iif($this->set['searchparams'],"&".$this->set['searchparams']);
			$this->cache[]=strtr($this->file['searchres'],$input);
			unset($input);
			
			$stamp=intval($date['year'].sprintf("%02.d",$date['mon']));
			}
		}
		else $this->cache[]="Zu diesen Begriffen wurden keine Meldungen gefunden!";
	$this->free();
	$this->out();
	}

?>