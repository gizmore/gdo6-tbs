<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//*******************  NEWS EMPFEHLEN  ********************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}

if ( $_POST['send']==1 ) {
	if ( !$_POST['s-name'] || !$_POST['s-mail'] || !$_POST['e-name'] || !$_POST['e-mail'] || !$_POST['betreff'] || !$_POST['text'] ) $this->message(0);
	else {
	$headers .= "To: ".$_POST['e-name']." <".$_POST['e-mail'].">\r\n";
	$headers .= "From: ".$_POST['s-name']." <".$_POST['s-mail'].">\r\n";
	@mail($_POST['e-email'],$_POST['betreff'],$_POST['text'],$headers);
		if ( $type=="news" ) $link=$this->set['newspage'].'?id='.$_REQUEST['stof'].$this->iif($this->set['newsparams'],"&".$this->set['newsparams']);
		elseif ( $type=="archiv" ) $link=$this->set['archpage'].'?id='.$_REQUEST['stof'].$this->iif($this->set['archparams'],"&".$this->set['archparams']);
	echo $this->message(8,array("%LINK%"=>$link)).'<meta http-equiv="refresh" content="4; URL='.$link.'">';
	}
}
else {
$this->load("sendtofriendform");

$res=$this->first("SELECT topic FROM ".PRE."_news WHERE id='".$_REQUEST['stof']."' LIMIT 1");

	if ( $type=="news" ) {
	$link1=$this->set['http'].$this->set['newspage'].'?id='.$_REQUEST['stof'].$this->iif($this->set['newsparams'],"&".$this->set['newsparams']);
	$link2=$this->set['newspage'].'?stof='.$_REQUEST['stof'].$this->iif($this->set['newsparams'],"&".$this->set['newsparams']);
	}
	elseif ( $type=="archiv" ) {
	$link1=$this->set['http'].$this->set['newspage'].'?id='.$_REQUEST['stof'].$this->iif($this->set['newsparams'],"&".$this->set['newsparams']);
	$link2=$this->set['archpage'].'?stof='.$_REQUEST['stof'].$this->iif($this->set['archparams'],"&".$this->set['archparams']);
	}

$input['%BETREFF%']=htmlspecialchars($res['topic']);
$input['%TEXT%']=htmlspecialchars("Hallo,\nich habe hier eine Seite gefunden, die dich interessieren k�nnte:\n\n".$link1);

echo '<form action="'.$link2.'" method="post">'.strtr($this->file['sendtofriendform'],$input).'<input type="hidden" name="send" value="1"></form>';
}

?>