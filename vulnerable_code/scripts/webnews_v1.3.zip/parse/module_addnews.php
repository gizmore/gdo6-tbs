<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//*******************  NEWS EINSENDEN  ********************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}

if ( !$_POST['name'] || !$_POST['mail'] || ( $this->set['usekats'] && !$_POST['catid'] ) || !$_POST['topic'] || !$_POST['text'] ) echo $this->message(0);
else {
	if ( $this->set['usekats'] ) $_POST['catid']=1;
$this->query("INSERT INTO ".PRE."_news ( catid, ext_user, ext_mail, topic, text, time ) VALUES ('".$_POST['catid']."','".addslashes($_POST['name'])."','".addslashes($_POST['mail'])."','".addslashes($_POST['topic'])."','".addslashes($_POST['text'])."','".time()."')");

$this->message(6);
}

?>