<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//*******************  PARSER: ARCHIV  ********************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}


//Letzter aktiver Eintrag
list($lasttime)=$this->first("SELECT pubtime FROM ".PRE."_news WHERE ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) ORDER BY pubtime DESC LIMIT ".($this->set['maxnews']-1).",".$this->set['maxnews']);
	
$this->load("archiveheader,archiveentry");
$this->query("SELECT pubtime FROM ".PRE."_news WHERE ( ".$this->iif(!$this->set['archallnews'],"pubtime<'".$lasttime."' AND")." ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) ) ORDER BY pubtime ASC");
	while($res=$this->fetch()) {
	$date=getdate($res['pubtime']);
		if ( intval($date['year'].sprintf("%02.d",$date['mon']))>$laststamp ) {
			if ( $date['year']!=$lastyear ) {
			$input['%JAHR%']=$date['year'];
			$this->cache[]=strtr($this->file['archiveheader'],$input);
			unset($input);
			}
	
		$input['%MONAT%']=$this->germon($date['mon']);
		$input['%LINK%']=$this->set['archpage']."?month=".$date['mon'].",".$date['year'].$this->iif($this->set['archparams'],"&".$this->set['archparams']);
		$this->cache[]=strtr($this->file['archiveentry'],$input);
		unset($input);
		}
	$laststamp=intval($date['year'].sprintf("%02.d",$date['mon']));
	$lastyear=$date['year'];
	}
	
	//Searchfield
	if ( $type=="archiv" && $this->set['searchfarch'] && !$one && !$_REQUEST['month'] ) {
	$input['%KATS%']='<option value="">Alle</option>';
		if ( $this->set['usekats'] ) {
		$this->query("SELECT id,name FROM ".PRE."_newscat");
			while($res=$this->fetch()) $input['%KATS%'].='<option value="'.$res['id'].'">'.$this->replace($res['name']).'</option>';
		$this->free();
		}
	
	$this->load("searchfield");
	$this->cache[]='<form action="'.$this->set['searchpage'].$this->iif($this->set['searchparams'],'?'.$this->set['searchparams']).'" method="post">'.@strtr($this->file["searchfield"],$input).'<input type="hidden" name="do" value="search"></form>';
	}
$this->out();

?>