<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//********************  PARSER: NEWS  *********************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}

	//Newskats
	if ( $this->set['usekats'] ) {
	$this->query("SELECT id,icon,name FROM ".PRE."_newscat");
		while($res=$this->fetch()) { 
			if ( $res['icon'] ) $newscat[$res['id']]['icon']='<img src="'.$res['icon'].'" alt="'.$this->replace($res['name']).'" border="0">';
		$newscat[$res['id']]['name']=$this->replace($res['name']);
		}
	$this->free();
	}
	
//Letzter aktiver Eintrag
list($lasttime)=$this->first("SELECT pubtime FROM ".PRE."_news WHERE ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) ORDER BY pin DESC, pubtime DESC LIMIT ".($this->set['maxnews']-1).",".$this->set['maxnews']);


	//MySQL generieren + TMPLs laden
	if ( $_REQUEST['preview'] ) {
	$where=" a.id='".$_REQUEST['id']."'"; //Preview
	$one=true;
	$this->load("newsdetailentry,dateheader,newslink,relatednews");
	}
	elseif ( $_REQUEST['id'] ) { //Ein Eintrag: News/Archiv
	$where="( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) AND a.id='".$_REQUEST['id']."'";
	$one=true;
	$this->load("newsdetailentry,dateheader,newslink,relatednews");
	$this->query("UPDATE ".PRE."_news SET counter=counter+1 WHERE id='".$_REQUEST['id']."' LIMIT 1");
	}
	elseif ( $_REQUEST['month'] ) { //Archiv: Month
	$req=explode(",",$_REQUEST['month']);
	//$where="( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) AND ( (pubtime>='".(mktime(0,0,0,intval($req[0]),1,intval($req[1])))."' AND pubtime<'".(mktime(0,0,0,(intval($req[0])+1),1,intval($req[1])))."') ".$this->iif(!$this->set['archallnews'],"AND pubtime<'".$lasttime."'")." )";
	$where="( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) AND ( pubtime BETWEEN '".(mktime(0,0,0,intval($req[0]),1,intval($req[1])))."' AND '".(mktime(0,0,-1,(intval($req[0])+1),1,intval($req[1])))."' ".$this->iif(!$this->set['archallnews'],"AND pubtime<'".$lasttime."'")." )";
	$this->load("newsentry,dateheader,newslink");
	}
	elseif ( $_REQUEST['cat'] ) {
	$where="( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) AND a.catid='".$_REQUEST['cat']."'";
	$this->load("newsentry,dateheader,newslink");
	}
	else {
	$where="( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) )";
	$this->load("newsentry,dateheader,newslink");
	}


//Seitenzahlen
if ( $type=="archiv" ) $limit="";
elseif ( $type=="news" && !$one && $this->set['browsenews'] ) {	
list($newscount)=$this->first("SELECT count(id) FROM ".PRE."_news WHERE ( ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) ".$this->iif($_REQUEST['cat']," AND catid='".$_REQUEST['cat']."' ")." )");
$newspages=ceil($newscount/$this->set['maxnews']);
	//Check Pagevar
	$_REQUEST['page']=intval($_REQUEST['page']);
	if ( !$_REQUEST['page'] ) $_REQUEST['page']=1;
	elseif ( $_REQUEST['page']<1 || $_REQUEST['page']>$newspages ) $_REQUEST['page']=1;

$limit="LIMIT ".(($_REQUEST['page']-1)*$this->set['maxnews']).",".$this->set['maxnews'];
}
else $limit="LIMIT ".$this->set['maxnews'];

	
$query=$this->query("SELECT a.*,b.username,b.email FROM ".PRE."_news AS a LEFT JOIN ".PRE."_user AS b USING(userid) ".$this->iif($where,'WHERE ( '.$where.' )')." ORDER BY ".$this->iif($type!="archiv","pin DESC, ")." pubtime DESC ".$limit);
	while($res=$this->fetch($query)) {
	$input['%NEWSID%']="wn".$res['id'];
		if ( !$res['userid'] ) {
		$input['%USER%']=$this->replace($res['ext_user']);
		$input['%MAIL%']="mailto:".$res['ext_mail'];
		}
		else {
		$input['%USER%']=$this->replace($res['username']);
			if ( $res['email'] ) $input['%MAIL%']="mailto:".$res['email'];
			else $input['%MAIL%']="#";
		}
	$input['%TITEL%']=$this->textcodes($this->replace($res['topic'],1));
	$input['%UNTERTITEL%']=$this->textcodes($this->replace($res['subtopic'],1));
	
	/*if ( $this->set['usekats'] && $newscat[$res['catid']] )*/ //v1.2
	$input['%ICON%']=$newscat[$res['catid']]['icon'];
		
		//Text parsen
		if ( $_REQUEST['id'] ) $thetext=eregi_replace("\[mehr\]","",$res['text']);
		else {
			if ( eregi("\[mehr\]",$res['text']) ) {
			$txtparts=explode("[MEHR]",eregi_replace("\[mehr\]","[MEHR]",$res['text']));
			$thetext=$txtparts[0];
			unset($txtparts);
			$addmehr=true;
			}
			else $thetext=$res['text'];
		}
		
		if ( $this->set['usehtml'] && eregi("[html]",$thetext) && eregi("[/html]",$thetext) ) {
		$input['%TEXT%']=$this->codes($this->replace(preg_replace("/\[html\](.*?)\[\/html\]/sie", "\$this->htmlcodecache('\\1')",$thetext)),$this->set['useimg']);
			if ( is_array($this->htmlcode) ) foreach($this->htmlcode AS $key => $value) $input['%TEXT%']=str_replace("%HTMLCODE#".$key."%",$value,$input['%TEXT%']);
		}
		else $input['%TEXT%']=$this->codes($this->replace($thetext),$this->set['useimg']);
		
		//Generiere Einzel-Link
		if ( $type=="news" ) $showonelink=$this->set['newspage'].'?id='.$res['id'].$this->iif($this->set['newsparams'],"&".$this->set['newsparams']);
		elseif ( $type=="archiv" ) $showonelink=$this->set['archpage'].'?id='.$res['id'].$this->iif($this->set['archparams'],"&".$this->set['archparams']);
		if ( $addmehr ) {
		$input['%TEXT%'].=' ... <a href="'.$showonelink.'">'.$this->set['mehrtext'].'</a>';
		unset($addmehr);
		}
		$input['%DETAILLINK%']=$showonelink;


		//Search-Markup
		if ( $_REQUEST['mark'] ) {
		$input['%TITEL%']=$this->mark($input['%TITEL%']);
		$input['%UNTERTITEL%']=$this->mark($input['%UNTERTITEL%']);
		$input['%TEXT%']=$this->mark($input['%TEXT%']);
		}
		
		
		//Kategorie-Link
		if ( $this->set['usekats'] ) {
		$input['%KATEGORIE%']=$newscat[$res['catid']]['name'];
			if ( $type=="archiv" ) $input['%KATLINK%']=$this->set['archpage'].'?cat='.$res['catid'].$this->iif($this->set['archparams'],"&".$this->set['archparams']);
      else $input['%KATLINK%']=$this->set['newspage'].'?cat='.$res['catid'].$this->iif($this->set['newsparams'],"&".$this->set['newsparams']);
		}
		
		
		//Datum/Zeit
		if ( $_REQUEST['preview'] ) $date=getdate($res['time']);
		else $date=getdate($res['pubtime']);
		
		if ( $this->set['leadingzero'] ) $zform=2;
		else $zform=1;
		
		if ( $this->set['bigdate'] ) {
		$input_h['%JAHR%']=$date['year'];
		$input_h['%MONAT%']=sprintf("%0".$zform.".d",$date['mon']);
		$input_h['%TAG%']=sprintf("%0".$zform.".d",$date['mday']);
		$input_h['%WOCHENTAG%']=$this->gerday($date['wday']);
		$input_h['%KALENDERMONAT%']=$this->germon($date['mon']);
		$input['%STUNDEN%']=sprintf("%02.d",$date['hours']);
		$input['%MINUTEN%']=sprintf("%02.d",$date['minutes']);
		$input['%SEKUNDEN%']=sprintf("%02.d",$date['seconds']);
		$stamp=$input_h['%TAG%']."/".$input_h['%MONAT%']."/".$input_h['%JAHR%'];
		unset($date);
		}
		else {
		$input['%JAHR%']=$date['year'];
		$input['%MONAT%']=sprintf("%0".$zform.".d",$date['mon']);
		$input['%TAG%']=sprintf("%0".$zform.".d",$date['mday']);
		$input['%WOCHENTAG%']=$this->gerday($date['wday']);
		$input['%KALENDERMONAT%']=$this->germon($date['mon']);
		$input['%STUNDEN%']=sprintf("%02.d",$date['hours']);
		$input['%MINUTEN%']=sprintf("%02.d",$date['minutes']);
		$input['%SEKUNDEN%']=sprintf("%02.d",$date['seconds']);
		unset($date);
		}
	
		//Links
		for($i=1;$i<=3;++$i) {
			if ( $res['link'.$i] ) {
			$links=explode("|",$res['link'.$i]);
			$lins['%TITEL%']=$this->replace($links[0]);
			$lins['%LINK%']='<a href="'.$links[2].'"'.$this->iif($links[3]=="blank",' target="_blank"').'>'.$this->replace($links[1]).'</a>';
			$input['%LINKS%'].=strtr($this->file['newslink'],$lins);
			unset($links,$lins);
			}
		}
		if ( !$input['%LINKS%'] ) $input['%LINKS%']="";
		
		
		//Druckversion & einem Freund senden
		$input['%DRUCKLINK%']=$this->set['location']."/print.php?id=".$res['id'];
			if ( $type=="news" ) $input['%EMPFEHLENLINK%']=$this->set['newspage'].'?stof='.$res['id'].$this->iif($this->set['newsparams'],"&".$this->set['newsparams']);
			elseif ( $type=="archiv" ) $input['%EMPFEHLENLINK%']=$this->set['archpage'].'?stof='.$res['id'].$this->iif($this->set['archparams'],"&".$this->set['archparams']);
		
		
		//�hnliche Meldungen
		if ( $this->set['relatednews'] && $one ) {
		$query2=$this->query("SELECT id,topic FROM ".PRE."_news WHERE ( catid='".$res['catid']."' AND ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) ) ORDER BY pin DESC, pubtime DESC LIMIT ".($this->set['relnewscount']+1));
			//Showtype
			if ( $type=="news" ) $prestr="news";
			elseif ( $type=="archiv" ) $prestr="arch";
			elseif ( $type=="search" ) $prestr="search";
			
			while($ri<$this->set['relnewscount'] && !$stop ) {
			$res2=$this->fetch($query2);
				if ( !$res2['id'] ) $stop=true;
				elseif ( $res2['id']!=$res['id'] ) {
				$input['%MEHRNEWS%'].=str_replace("%LINK%",'<a href="'.$this->set[$prestr.'page'].'?id='.$res2['id'].$this->iif($this->set[$prestr.'params'],"&".$this->set[$prestr.'params']).'">'.$this->textcodes($this->replace($res2['topic'])).'</a>',$this->file['relatednews']);
				++$ri;
				}
			}
		unset($ri);
		$this->free($query2);
			if ( !$input['%MEHRNEWS%'] ) $input['%MEHRNEWS%']="";
		}
		
		//Kommentarlink
		if ( $this->set['usecoms'] ) {
			if ( $res['allowcoms'] ) {
			list($count,$trash)=$this->first("SELECT count(id) FROM ".PRE."_comment WHERE newsid='".$res['id']."' LIMIT 1");
				if ( ( $type=="archiv" || $type=="news" ) ) $input['%KOMMENTARE%']='<a href="'.$showonelink.'">'.$count.' Kommentar'.$this->iif($count!=1,"e").'</a>';
				else $input['%KOMMENTARE%']=$count.' Kommentar'.$this->iif($count!=1,"e");
			}
			else $input['%KOMMENTARE%']="Kommentare deaktiviert";
		}
		
		//Bigdate
		if ( $this->set['bigdate'] ) {
			if ( $laststamp!=$stamp ) $this->cache[]=strtr($this->file['dateheader'],$input_h);
		$laststamp=$stamp;
		}
	
	//Parse
	$this->cache[]=strtr($this->iif(isset($this->file['newsentry']),$this->file['newsentry'],$this->file['newsdetailentry']),$input);
	unset($input,$input_h);
	
		
	
		//Kommentare
		if ( $one && $this->set['usecoms'] && $type!="search" && $res['allowcoms'] ) {
		$this->load("commententry,commentform");
			if ( $type=="archiv" ) $presite="arch";
			else $presite="news";
			
			if ( $this->set['comformpos']!=2 ) $this->set['comformpos']=1;
			
			//Com-Form
			if ( ( $this->set['allowarchcoms']==1 || $res['pubtime']>=$lasttime ) && $this->set['comformpos']==1 ) $this->cache[]='<form action="'.$this->set[$presite.'page'].$this->iif($this->set[$presite.'params'],'?'.$this->set[$presite.'params']).'" method="post">'.$this->file['commentform'].'<input type="hidden" name="id" value="'.$res['id'].'"><input type="hidden" name="addcom" value="1"></form>';
		
		$this->query("SELECT * FROM ".PRE."_comment WHERE newsid='".$res['id']."' ORDER BY time DESC");
			while($cres=$this->fetch()) {
			$input['%NAME%']=$this->replace($cres['name']);
			$input['%TEXT%']=$this->codes($this->replace($this->badwords($cres['text'])),$this->set['allowimg'],1);
				for ( $i=1; $i<=5; $i++ ) {
					if ( $this->set['cf'.$i]['useit'] ) {
						if ( $cres['feld'.$i] ) $input['%FELD'.$i.'%']=str_replace("%INHALT%",$cres['feld'.$i],$this->set['cf'.$i]['output']);
						else $input['%FELD'.$i.'%']=$this->set['cf'.$i]['else'];
					}
				}   
			
			$date=getdate($cres['time']);
			$input['%JAHR%']=$date['year'];
			$input['%MONAT%']=sprintf("%0".$zform.".d",$date['mon']);
			$input['%TAG%']=sprintf("%0".$zform.".d",$date['mday']);
			$input['%WOCHENTAG%']=$this->gerday($date['wday']);
			$input['%KALENDERMONAT%']=$this->germon($date['mon']);
			$input['%STUNDEN%']=sprintf("%02.d",$date['hours']);
			$input['%MINUTEN%']=sprintf("%02.d",$date['minutes']);
			$input['%SEKUNDEN%']=sprintf("%02.d",$date['seconds']);
		
			$this->cache[]=strtr($this->file['commententry'],$input);
			unset($input,$date);
			}
		$this->free();
			
			//Com-Form
			if ( ( $this->set['allowarchcoms']==1 || $res['pubtime']>=$lasttime ) && $this->set['comformpos']==2 ) $this->cache[]='<form action="'.$this->set[$presite.'page'].$this->iif($this->set[$presite.'params'],'?'.$this->set[$presite.'params']).'" method="post">'.$this->file['commentform'].'<input type="hidden" name="id" value="'.$res['id'].'"><input type="hidden" name="addcom" value="1"></form>';
		}       
	}
	$this->free();//End News & Comments
	
	
	
	//Seitenzahlen
	if ( $type=="news" && !$one && $this->set['browsenews'] ) {
	unset($input);
	$this->load("newspages");
		
		//Seitenzahlen
		if ( $this->set['cutpages'] ) {
			for ( $pi=1; $pi<=$newspages; $pi++ ) {
				if ( $pi>=($_REQUEST['page']-$this->set['cutpages']) && $pi<=($_REQUEST['page']+$this->set['cutpages']) ) {
					if ( !$input['%SEITEN%'] && $pi>1 ) $input['%SEITEN%'].=' ...';
					if ( $_REQUEST['page']==$pi ) $input['%SEITEN%'].=" ".str_replace("%ZAHL%",$pi,$this->set['selpage']);
					else $input['%SEITEN%'].=' <a href="'.$this->set['newspage'].'?page='.$pi.$this->iif($_REQUEST['cat'],"&cat=".$_REQUEST['cat']).$this->iif($this->set['newsparams'],"&".$this->set['newsparams']).'">'.$pi.'</a>';
				$last=$pi;
				}
			}
			if ( $last<$newspages ) $input['%SEITEN%'].=' ...';
		}
		else {
			for ( $pi=1; $pi<=$newspages; $pi++ ) {
				if ( $_REQUEST['page']==$pi ) $input['%SEITEN%'].=" ".str_replace("%ZAHL%",$pi,$this->set['selpage']);
				else $input['%SEITEN%'].=' <a href="'.$this->set['newspage'].'?page='.$pi.$this->iif($this->set['newsparams'],"&".$this->set['newsparams']).'">'.$pi.'</a>';
			}
		}
	
	$input['%SEITENZAHL%']=$newspages;
	$this->cache[]=strtr($this->file['newspages'],$input);
	unset($i,$pagestr,$last);
	} //End Seitenzahlen
	
	
	
	if ( $type=="news" && !$one ) {
		//Make Catlist
		if ( $this->set['listcats'] || $this->set['searchfnews'] ) {
		$input['%KATS%']='<option value="0">Alle</option>';
		$input2['%KATS%']='<option value="0">Alle</option>';
		
		$this->query("SELECT id,name FROM ".PRE."_newscat ORDER BY name ASC");
			while($res=$this->fetch()) {
				if ( $res['id']==$_REQUEST['cat'] ) $input['%KATS%'].='<option value="'.$res['id'].'" selected>'.$this->replace($res['name']).'</option>';
				else $input['%KATS%'].='<option value="'.$res['id'].'">'.$this->replace($res['name']).'</option>';
			$input2['%KATS%'].='<option value="'.$res['id'].'">'.$this->replace($res['name']).'</option>';
			}
		$this->free();
		}
	
		//Kategorie-Liste
		if ( $this->set['listcats'] && $this->set['usekats'] ) {
		$this->load("choosecat");
		$this->cache[]='<form action="'.$this->set['newspage'].$this->iif($this->set['newsparams'],'?'.$this->set['newsparams']).'" method="post">'.@strtr($this->file["choosecat"],$input).'</form>';
		}
	
		//Searchfield
		if ( $this->set['searchfnews'] ) {
		$this->load("searchfield");
		$this->cache[]='<form action="'.$this->set['searchpage'].$this->iif($this->set['searchparams'],'?'.$this->set['searchparams']).'" method="post">'.@strtr($this->file["searchfield"],$input2).'<input type="hidden" name="do" value="search"></form>';
		}
	unset($input);
	unset($input2);
	}

/************* DON'T REMOVE THIS COPYRIGHT MESSAGE! *************/
//Mit dem Entfernen der Copyright-Message wird Ihre WEB//NEWS Lizenz ung�ltig!
	if ( !$_REQUEST['id'] && $type=="news" ) $this->cache[]='<center><font size="1" face="Verdana">WEB//NEWS Newsmanagement - &copy; by <a href="http://www.stylemotion.de" target="_blank">Stylemotion.de</a></font></center>';
/************* DON'T REMOVE THIS COPYRIGHT MESSAGE! *************/
$this->out();

?>