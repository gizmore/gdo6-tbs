<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



//*********************************************************
//******************  PARSER: LASTNEWS  *******************
//*********************************************************

	//Sicherheitsabfrage
	if ( !is_object($this) ) {
	echo"FEHLER: Das Script wurde falsch eingebunden! Alle Dateien aus dem Ordner &quot;parse&quot; sind NICHT zum includen bestimmt. Lesen Sie die Readme um WEB//NEWS richtig einzubinden.";
	return;
	}
	
//Letzter aktiver Eintrag
list($lasttime)=$this->first("SELECT pubtime FROM ".PRE."_news WHERE ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ) ORDER BY pin DESC, pubtime DESC LIMIT ".($this->set['maxnews']-1).",".$this->set['maxnews']);

$this->load("lastnewsentry");
$this->query("SELECT a.id,a.topic,a.subtopic,a.pubtime,a.ext_user,a.ext_mail,b.userid,b.username,b.email FROM ".PRE."_news AS a LEFT JOIN ".PRE."_user AS b USING(userid) WHERE ( ( pubtime AND pubtime<='".time()."' ) AND ( endtime='0' OR endtime>'".time()."' ) ".$this->iif($_REQUEST['lastnewscat']," AND ( a.catid='".$_REQUEST['lastnewscat']."' )")." ) ORDER BY pin DESC, pubtime DESC LIMIT ".$this->set['lastnewscount']);
	while($res=$this->fetch()) {
		if ( $this->set['leadingzero'] ) $zform=2;
		else $zform=1;
	$date=getdate($res['pubtime']);
	$input['%JAHR%']=$date['year'];
	$input['%MONAT%']=sprintf("%0".$zform.".d",$date['mon']);
	$input['%TAG%']=sprintf("%0".$zform.".d",$date['mday']);
	$input['%WOCHENTAG%']=$this->gerday($date['wday']);
	$input['%KALENDERMONAT%']=$this->germon($date['mon']);
	$input['%STUNDEN%']=sprintf("%02.d",$date['hours']);
	$input['%MINUTEN%']=sprintf("%02.d",$date['minutes']);
	$input['%SEKUNDEN%']=sprintf("%02.d",$date['seconds']);
	
	if ( !$res['userid'] ) {
	$input['%USER%']=$this->replace($res['ext_user']);
	$input['%MAIL%']="mailto:".$res['ext_mail'];
	}
	else {
	$input['%USER%']=$this->replace($res['username']);
		if ( $res['email'] ) $input['%MAIL%']="mailto:".$res['email'];
		else $input['%MAIL%']="#";
	}
	
		if ( $this->set['lastnewsmlen'] && strlen($res['topic'])>$this->set['lastnewsmlen'] ) $input['%TITEL%']=$this->textcodes($this->replace(substr($res['topic'],0,$this->set['lastnewsmlen']-3)."..."));
		else $input['%TITEL%']=$this->textcodes($this->replace($res['topic']));
   $input['%UNTERTITEL%']=$this->textcodes($this->replace($res['subtopic']));

		if ( $res['pubtime']>=$lasttime ) {
			if ( $this->set['lastnewsltype']==2 ) $input['%LINK%']=$this->set['newspage'].'?id='.$res['id'].$this->iif($this->set['newsparams'],'&'.$this->set['newsparams']);
			else $input['%LINK%']=$this->set['newspage'].$this->iif($this->set['newsparams'],'?'.$this->set['newsparams']).'#wn'.$res['id'];
		}
		else {
			if ( $this->set['lastnewsltype']==2 ) $input['%LINK%']=$input['%LINK%']=$this->set['archpage']."?id=".$res['id'].$this->iif($this->set['archparams'],'&'.$this->set['archparams']);
			else $input['%LINK%']=$this->set['archpage']."?month=".$date['mon'].",".$date['year'].$this->iif($this->set['archparams'],'&'.$this->set['archparams']).'#wn'.$res['id'];
		}
	
	$this->cache[]=strtr($this->file['lastnewsentry'],$input);
	unset($input,$date);
	}
$this->out();

?>