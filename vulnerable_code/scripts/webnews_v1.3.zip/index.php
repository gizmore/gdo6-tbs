<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2003                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



$DIR=dirname(__file__);
require($DIR."/modules/startup.php");

	if ( file_exists("install.php") ) message("delinstall");

	/*** LOAD ACTION ***/
	if ( file_exists("actions/".$_REQUEST['action'].".php") ) {
		if ( has_right($_REQUEST['action']) ) include("actions/".$_REQUEST['action'].".php");
		else message("noright");
	}
	else message("invalid_action");
	
/*** DEFINE DESIGN-VARS ***/
$set['style']['design_pagetitle']=$set['title'];
$set['style']['design_title']=$_ACTIONS[$_REQUEST['action']]['caption'];
$set['style']['design_pagelink']='<a href="'.$set['pagelink'].'" target="_blank">Zur Website</a>';

	if ( $_USER['userid'] ) {
	$set['style']['design_actlink']='<a href="index.php?action=logout">Ausloggen</a>';
	$set['style']['design_navi']="";
		foreach ( $_ACTIONS AS $key => $value ) {
			if ( ( $_RIGHTS[$key]==1 || $_RIGHTS['global']==1 ) && $value['cat']!="none" && $value['visible']==1 ) {
				if ( $lastnav!=$value['navid'] ) unset($lastcat);
				if ( $lastcat!=$value['cat'] ) $set['style']['design_navi#'.$value['navid']].='<br><img src="design/navi_'.$value['cat'].'.gif" alt="" border="0"><br>';
				if ( $_REQUEST['action']==$key ) $set['style']['design_navi#'.$value['navid']].='&nbsp;&nbsp;<img src="design/dot_sel.gif" alt="" border="0"> <a href="index.php?action='.$key.'">'.replace($value['navi']).'</a><br>';
				else $set['style']['design_navi#'.$value['navid']].='&nbsp;&nbsp;<img src="design/dot.gif" alt="" border="0"> <a href="index.php?action='.$key.'">'.replace($value['navi']).'</a><br>';
			$lastcat=$value['cat'];
			$lastnav=$value['navid'];
			}
		}
	}
	else {
	$set['style']['design_actlink']='<a href="index.php">Einloggen</a>';
	$set['style']['design_navi#1']='<table width="100%" cellpadding="5" cellspacing="0" border="0"><tr><td class="navi"><b>Willkommen bei WEB//NEWS!</b><br>Um in den Adminbereich zu gelangen m&uuml;ssen Sie sich zuerst einloggen.</td></tr></table>';
	$set['style']['design_navi#2']="";
	}

/*** OUTPUT ***/
$db->close($set);
$tmpl->out($set['style']);

?>