<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
list($count,$trash)=$db->first("SELECT count(id) FROM ".PRE."_news WHERE catid='".$_POST['id']."' LIMIT 1");
	if ( !$count ) {
	$db->query("DELETE FROM ".PRE."_newscat WHERE id='".$_POST['id']."' LIMIT 1");
	message("cat_del_ok","index.php?action=cat.show");
	logit("Kategorie ID #".$_POST['id']." gel�scht");
	}
	else die("this category is still in use!");
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
$ins['id']=$_REQUEST['id'];
message("cat_del",0,$ins);
}

?>