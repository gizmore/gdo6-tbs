<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_REQUEST['clean']=="yes" ) {
	if ( $_POST['do']==1 ) {
	$db->query("DELETE FROM ".PRE."_log");
	message("user_log_clean_ok","index.php?action=user.log");
	logit("Protokoll geleert");
	}
	else message("user_log_clean");
}
else {
$tmpl->load("user_log");
logit("Protokoll eingesehen");

$query=$db->query("SELECT * FROM ".PRE."_log");
	while($res=$db->fetch()) {
		for ( $i=1; $i<=(3-strlen($res['userid'])); ++$i ) $add.="&nbsp;";
	$input['log'].=$res['time']."&nbsp;&nbsp;&nbsp;UserID #".$res['userid'].$add."&nbsp;&nbsp;".$res['action']."\n";
	unset($add);
	}
$db->free();

$input['log'].=date("d-m-Y H:i:s")." &gt;&gt;&gt; LOG ENDE";

$tmpl->cache[]=$tmpl->parse($tmpl->file['user_log'],$input);
}

?>