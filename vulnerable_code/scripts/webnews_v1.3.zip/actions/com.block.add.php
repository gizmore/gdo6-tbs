<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################

if ( $_POST['do'] ) {
$block['name']=array();
$block['ip']=array();
$query=$db->query("SELECT type,string FROM ".PRE."_block WHERE endtime>='".time()."'");
	if ( $db->checkres($query) ) {
		while($res=$db->fetch($query)) {
		$block[$res['type']][]=$res['string'];
		}
	}
$db->free($query);
unset($db->result,$res,$query);

	if ( !intval($_POST['days']) ) $_POST['days']=1;
	if ( $_POST['blockip'] || $_POST['blockname'] ) list($thename,$theip)=$db->first("SELECT name,ip FROM ".PRE."_comment WHERE id='".$_REQUEST['id']."' LIMIT 1");
	if ( $_POST['blockip'] && !in_array($theip,$block['ip']) ) {
	$db->query("INSERT INTO ".PRE."_block (type,string,endtime) VALUES ('ip','".$theip."','".(time()+intval($_POST['days'])*24*3600)."')");
	logit("IP ".$theip." gesperrt");
	}
	if ( $_POST['blockname'] && !in_array($thename,$block['name']) ) {
	$db->query("INSERT INTO ".PRE."_block (type,string,endtime) VALUES ('name','".$thename."','".(time()+intval($_POST['days'])*24*3600)."')");
	logit("Nickname ".$thename." gesperrt");
	}

//Alte Sperren l�schen
$db->query("DELETE FROM ".PRE."_block WHERE endtime<'".time()."'");
message("com_block_ok","index.php?action=com.show&newsid=".$_POST['newsid']);
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
	if ( !$_REQUEST['newsid'] ) die("no newsid specified!");
$ins['id']=$_REQUEST['id'];
$ins['newsid']=$_REQUEST['newsid'];
message("com_block",0,$ins);
}

?>