<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( ($_POST['pw1'] || $_POST['pw2']) && $_POST['pw1']!=$_POST['pw2'] ) message("user_add_pwfail");
	else {
	$db->query("UPDATE ".PRE."_user SET email='".$_POST['mail']."'".iif ( (($_POST['pw1'] || $_POST['pw2']) && $_POST['pw1']==$_POST['pw2']), ",password='".md5($_POST['pw1'])."'" )." WHERE ( userid='".$_USER['userid']."' )");
		if ( ($_POST['pw1'] || $_POST['pw2']) && $_POST['pw1']==$_POST['pw2'] ) {
		setcookie("wn_userid",$_USER['userid'],time()+30*24*3600);
		setcookie("wn_userpw",md5($_POST['pw1']),time()+30*24*3600);
		message("pers_profile_pwok","index.php");
		logit("Benutzerprofil bearbeitet");
		}
		else message("pers_profile_ok","index.php");
	}
}
else {
$tmpl->load("pers_profile");
$input['userid']=$_USER['userid'];
$input['username']=htmlspecialchars($_USER['username']);
$input['email']=htmlspecialchars($_USER['email']);
$tmpl->cache[]=$tmpl->parse($tmpl->file['pers_profile'],$input);
}

?>