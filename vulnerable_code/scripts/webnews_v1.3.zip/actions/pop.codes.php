<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



/*** MODULES LOAD ***/
require("../modules/config.inc.php");
require("../modules/template.php");
$tmpl = new template;

$tmpl->load("pop_codes","../");
$tmpl->cache[]=$tmpl->file['pop_codes'];

$set['style']['design_pagetitle']=$set['title'];

/*** OUTPUT ***/
$tmpl->out($set['style'],1);

?>
