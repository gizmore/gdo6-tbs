<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( !$_REQUEST['id'] ) die("no id specified!");

if ( $_POST['do']==1 ) {
	if ( $_POST['pub']==1 ) $thepubtime=time();
	else $thepubtime=mktime($_POST['pubtime']['hours'],$_POST['pubtime']['mins'],$_POST['pubtime']['secs'],$_POST['pubtime']['month'],$_POST['pubtime']['day'],$_POST['pubtime']['year']);
	
	function checkvalues($key) {
		if ( $_POST[$key]['day']=="" ) return false;
		if ( $_POST[$key]['month']=="" ) return false;
		if ( $_POST[$key]['year']=="" ) return false;
		if ( $_POST[$key]['hours']=="" ) return false;
		if ( $_POST[$key]['mins']=="" ) return false;
		if ( $_POST[$key]['secs']=="" ) return false;
	return true;
	}
	
	if ( is_array($_POST['endtime']) && checkvalues("endtime") ) $theendtime=mktime($_POST['endtime']['hours'],$_POST['endtime']['mins'],$_POST['endtime']['secs'],$_POST['endtime']['month'],$_POST['endtime']['day'],$_POST['endtime']['year']);
	else $theendtime=0;
	
	if ( $theendtime<=$thepubtime ) $theendtime=0;

$db->query("UPDATE ".PRE."_news SET pubtime='".$thepubtime."',endtime='".$theendtime."' WHERE ( id='".$_POST['id']."'".iif(has_spright("news.pub")!=1," AND userid='".$_USER['userid']."'")." ) LIMIT 1");
message("news_pub_ok","index.php?action=news.show");
logit("Artikel ID #".$_REQUEST['id']." ver�ffentlicht");
}
else {
	function dropdown($start,$to,$name,$value,$se=0) {
		if ( $value==-1 ) $out.='<option value="" selected></option>';
		if ( $se ) $out.='<option value=""></option>';
		for ( $i=$start; $i<=$to; $i++ ) $out.='<option value="'.$i.'"'.iif( $value!=-1 && $i==$value," selected").'>'.sprintf("%02.d",$i).'</option>';
		if ( substr($name,0,7)=="pubtime" ) return '<select name="'.$name.'" onchange="checkit();">'.$out.'</select>';
		else return '<select name="'.$name.'">'.$out.'</select>';
	}

list($input['%title%'])=$db->first("SELECT topic FROM ".PRE."_news WHERE id='".$_REQUEST['id']."' LIMIT 1");
$input['%id%']=$_REQUEST['id'];

$pubdate=getdate();
$input['%pubtime%']=dropdown(1,31,"pubtime[day]",$pubdate['mday']).".".dropdown(1,12,"pubtime[month]",$pubdate['mon']).".".dropdown(2000,2010,"pubtime[year]",$pubdate['year'])." - ".dropdown(0,23,"pubtime[hours]",$pubdate['hours']).":".dropdown(0,59,"pubtime[mins]",$pubdate['minutes']).":".dropdown(0,59,"pubtime[secs]",$pubdate['seconds'])." Uhr";;

$input['%endtime%']=dropdown(1,31,"endtime[day]",-1).".".dropdown(1,12,"endtime[month]",-1).".".dropdown(2000,2010,"endtime[year]",-1)." - ".dropdown(0,23,"endtime[hours]",-1).":".dropdown(0,59,"endtime[mins]",-1).":".dropdown(0,59,"endtime[secs]",-1)." Uhr";

$tmpl->cache[]=strtr($tmpl->get("news_pub"),$input);
}


?>