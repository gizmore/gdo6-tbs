<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['name'] /*|| !$_POST['icon']*/ ) message("back"); //Version 1.1
	else {
	$res=$db->first("SELECT id FROM ".PRE."_newscat WHERE ( name='".addslashes($_POST['name'])."' AND id!='".$_POST['id']."' ) LIMIT 1");
		if ( $res['id'] ) message("cat_add_inuse");
		else {
		$db->query("UPDATE ".PRE."_newscat SET name='".addslashes($_POST['name'])."',icon='".addslashes($_POST['icon'])."' WHERE id='".$_POST['id']."'");
		message("cat_edit_ok","index.php?action=cat.show");
		logit("Kategorie ID #".$_POST['id']." bearbeitet");
		}
	}
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");

$tmpl->load("cat_edit");
$res=$db->first("SELECT * FROM ".PRE."_newscat WHERE id='".$_REQUEST['id']."'");
$input['id']=$_REQUEST['id'];
$input['name']=htmlspecialchars($res['name']);
$input['icon']=htmlspecialchars($res['icon']);
$tmpl->cache[]=$tmpl->parse($tmpl->file['cat_edit'],$input);
}

?>