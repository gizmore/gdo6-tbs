<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['name'] /*|| !$_POST['icon']*/ ) message("back"); //Version 1.1
	else {
	$res=$db->first("SELECT id FROM ".PRE."_newscat WHERE name='".addslashes($_POST['name'])."' LIMIT 1");
		if ( $res['id'] ) message("cat_add_inuse");
		else {
		$db->query("INSERT INTO ".PRE."_newscat (name,icon) VALUES ('".addslashes($_POST['name'])."','".addslashes($_POST['icon'])."')");
		message("cat_add_ok","index.php?action=cat.show");
		logit("Kategorie ID #".$db->insert_id()." erstellt");
		}
	}
}
else {
$tmpl->load("cat_add");
$tmpl->cache[]=$tmpl->parse($tmpl->file['cat_add'],$input);
}

?>