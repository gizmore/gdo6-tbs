<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( !$_GET['id'] ) die("no id specified!");

$db->query("UPDATE ".PRE."_news SET pubtime='0',endtime='0' WHERE ( id='".$_GET['id']."'".iif(has_spright("news.unpub")!=1," AND userid='".$_USER['userid']."'")." ) LIMIT 1");
message("news_unpub_ok","index.php?action=news.show");
logit("Artikel ID #".$_GET['id']." wiederrufen");

?>