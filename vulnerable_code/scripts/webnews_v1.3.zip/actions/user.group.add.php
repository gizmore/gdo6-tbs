<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['groupname'] || ( !$_POST['rights'] && !$_POST['allrights'] ) ) message("back");
	else {
	$db->query("SELECT groupid FROM ".PRE."_group WHERE groupname='".addslashes($_POST['groupname'])."' LIMIT 1");
		if ( $db->checkres() ) message("group_add_inuse");
		else {
			//R String
			if ( $_POST['allrights'] ) $rgs="global";
			else {
				foreach( $_POST['rights'] AS $action => $value ) if ( $value ) $c[]=$action;
			$rgs=implode("|",$c);
			unset($c);
			}
		
			//SPR String
			if ( is_array($_POST['sprights']) )	{
				foreach( $_POST['sprights'] AS $action => $value ) if ( $value ) $c[]=$action;
			$spr=implode("|",$c);
			unset($c);
			}
		
		$db->query("INSERT INTO ".PRE."_group (groupname,grouprights,groupsprights) VALUES('".addslashes($_POST['groupname'])."','$rgs','$spr')");
		message("group_add_ok","index.php?action=user.group.show");
		logit("Benutzergruppe ID #".$db->insert_id()." erstellt");
		}
	}
}
else {
$tmpl->load("user_group,user_group_e0,user_group_e1,user_group_cat");

$query=$db->query("SELECT action,caption,cat,catname,extra,extra_descr FROM ".PRE."_actions WHERE cat!='none' ORDER BY cat ASC, ord ASC");
	while($res=$db->fetch()) {
	++$i;
		if ( $res['cat']!=$lastactcat ) {
		$ins['title']=replace($res['catname']);
		$input['content'].=$tmpl->parse($tmpl->file['user_group_cat'],$ins);
		unset($ins);
		$i=1;
		}
	
	$ins['action']=replace($res['caption']." (".$res['action'].")");
	$ins['rights']='<input type="checkbox" name="rights['.$res['action'].']" value="1">';
		if ( $res['extra'] ) $ins['sprights']='<input type="checkbox" name="sprights['.$res['action'].']" value="1">';
		else $ins['sprights']="&nbsp;";
		if ( $res['extra_descr'] ) $ins['info']='<a href="javascript:openwin(\''.$res['action'].'\');"><img src="design/info.gif" alt="Mehr Informationen" title="Mehr Informationen" border="0"></a>';
		else $ins['info']="&nbsp;";
	
	$input['content'].=$tmpl->parse($tmpl->file['user_group_e'.$i%2],$ins);
	$lastactcat=$res['cat'];
	}
$db->free();

$input['groupname']="";
$input['checked']="";
$input['submit']="Benutzergruppe erstellen";
$input['groupid']="0";
$input['action']="user.group.add";

$tmpl->cache[]=$tmpl->parse($tmpl->file['user_group'],$input);
}

?>