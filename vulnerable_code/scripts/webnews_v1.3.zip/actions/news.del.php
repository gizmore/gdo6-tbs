<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
$db->query("DELETE FROM ".PRE."_news WHERE ( id='".$_POST['id']."'".iif(has_spright("news.del")!=1," AND userid='".$_USER['userid']."'")." ) LIMIT 1");
message("news_del_ok","index.php?action=news.show");
logit("Artikel ID #".$_POST['id']." gel�scht");
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
$ins['id']=$_REQUEST['id'];
message("news_del",0,$ins);
}

?>