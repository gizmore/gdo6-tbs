<?php
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



$tmpl->load("index");

$input['username']=replace($_USER['username'],1);
	if ( $_USER['email'] ) $input['useremail']=replace($_USER['email'],1);
	else $input['useremail']='-';
$input['usergroup']=replace($_USER['groupname'],1);
$input['useractive']=makedate($_USER['lastonline']);

list($input['c_news'],$trash)=$db->first("SELECT count(id) FROM ".PRE."_news");
list($input['c_own'],$trash)=$db->first("SELECT count(id) FROM ".PRE."_news WHERE userid='".$_USER['userid']."'");
list($input['c_cats'],$trash)=$db->first("SELECT count(id) FROM ".PRE."_newscat");
list($input['c_coms'],$trash)=$db->first("SELECT count(id) FROM ".PRE."_comment");
list($input['c_users'],$trash)=$db->first("SELECT count(userid) FROM ".PRE."_user");
list($input['c_groups'],$trash)=$db->first("SELECT count(groupid) FROM ".PRE."_group");

$tmpl->cache[]=$tmpl->parse($tmpl->file['index'],$input);

?>