<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( $_POST['id']!=$_USER['userid'] ) {
	$db->query("DELETE FROM ".PRE."_user WHERE userid='".$_POST['id']."' LIMIT 1");
	message("user_del_ok","index.php?action=user.show");
	logit("Benutzer ID #".$_POST['id']." gel�scht");
	}
	else die("can not delete yourself!");
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
$ins['id']=$_REQUEST['id'];
message("user_del",0,$ins);
}

?>