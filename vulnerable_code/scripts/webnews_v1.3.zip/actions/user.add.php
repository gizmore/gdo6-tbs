<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['username'] || !$_POST['pw1'] || !$_POST['pw2'] || !$_POST['groupid'] ) message("back");
	elseif ( $_POST['pw1']!=$_POST['pw2'] ) message("user_add_pwfail");
	else {
	$res=$db->first("SELECT userid FROM ".PRE."_user WHERE username='".addslashes($_POST['username'])."' LIMIT 1");
		if ( $res['userid'] ) message("user_add_uninuse");
		else {
		$db->query("INSERT INTO ".PRE."_user (username,password,groupid,email,active,lastonline,lastonline_temp) VALUES ('".addslashes($_POST['username'])."','".md5($_POST['pw1'])."','".$_POST['groupid']."','".$_POST['mail']."','".$_POST['active']."','".time()."','".time()."')");
			if ( $_POST['sendmail'] && $_POST['mail'] ) mail($_POST['mail'],"WEB//NEWS Account","WEB//NEWS Account f�r ".$set['title']."\n========================================================\n\n".$_USER['username']." hat einen Benutzeraccount f�r dich erstellt. Hier deine Benutzerdaten:\nBenutzername:  ".$_POST['username']."\nPasswort:      ".$_POST['pw1'],"From:".$_USER['email']);
		message("user_add_ok","index.php?action=user.show");
		logit("Benutzer ID #".$db->insert_id()." erstellt");
		}
	}
}
else {
$tmpl->load("user_add");
$input['groups']='<option value=""></option>';
$db->query("SELECT groupid,groupname FROM ".PRE."_group ORDER BY groupname ASC");
	while ( $res=$db->fetch()) $input['groups'].='<option value="'.$res['groupid'].'">'.replace($res['groupname']).'</option>';
$db->free();
$tmpl->cache[]=$tmpl->parse($tmpl->file['user_add'],$input);
}

?>