<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



$tmpl->load("user_profile");

$res=$db->first("SELECT * FROM ".PRE."_user LEFT JOIN ".PRE."_group USING (groupid) WHERE userid='".$_GET['id']."' LIMIT 1");
$input['username']=replace($res['username']);
$input['userid']=$res['userid'];
$input['groupname']=replace($res['groupname']);
	if ( $res['email'] ) $input['email']='<a href="mailto:'.$res['email'].'">'.$res['email'].'</a>';
	else $input['email']='-';
$input['lastactive']=makedate($res['lastonline_temp']);

$tmpl->cache[]=$tmpl->parse($tmpl->file['user_profile'],$input);

logit("Benutzerprofil ID #".$_GET['id']." angesehen");

?>