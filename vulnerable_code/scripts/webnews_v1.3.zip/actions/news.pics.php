<?php
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################


$DIR=dirname(__file__)."/..";
require("../modules/startup.php");
	
	//Message Function -> Version 1.1
	function pmessage($msgid,$link=0,$input=-1) {
	global $tmpl;
	$tmpl->load("msg_pheader,msg_pfooter,msg_".$msgid,"../");
		if ( $link ) $message=$tmpl->file["msg_".$msgid].'<font><br><br>&raquo; <a href="'.$link.'">Klicken Sie hier, wenn Ihr Browser keine automatische Weiterleitung unterst&uuml;tzt oder Sie nicht l&auml;nger warten wollen.</a> &laquo;</font><meta http-equiv="refresh" content="4; URL='.$link.'">';
		else $message=$tmpl->file["msg_".$msgid];
		if ( is_array($input) ) $message=$tmpl->parse($message,$input);
	$tmpl->cache[]=$tmpl->file['msg_pheader'].$message.$tmpl->file['msg_pfooter'];
	}

	
//**********************************************************************
//************************** START SCRIPT ******************************
//**********************************************************************

if ( has_right("news.pics") ) {

	//************ Create Folder ************
	if ( $_POST['crfolder']==1 ) {
		if ( !ctype_alnum($_REQUEST['fname']) ) pmessage("pics_crf_wname");
		elseif ( is_dir($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['fname']) ) pmessage("pics_crf_exists");
		else {
		mkdir($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['fname'],0777);
		pmessage("pics_crf_ok","news.pics.php");
		logit("Bilderordner &quot;".$_REQUEST['fname']."&quot; erstellt");
		}
	}
	
	
	//************ Delete Folder ************
	elseif ( $_REQUEST['delfolder'] ) {
		if ( has_spright("news.pics") ) {
			if ( $_POST['do']==1 ) {
			$fcount=0;
			$handle=@opendir($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['delfolder']);
				if ( $handle ) { while ($file = readdir ($handle)) if ( $file!="." && $file!=".." ) ++$fcount; }
			@closedir($handle);
			
				if ( $fcount!=0 ) die("Der ausgew�hlte Ordner enth�lt noch Dateien!");
				else {
				@rmdir($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['delfolder']);
				pmessage("pics_delf_ok","news.pics.php");
				logit("Bilderordner &quot;".$_REQUEST['delfolder']."&quot; gel�scht");
				}
			}
			else {
			$input['fname']=$_REQUEST['delfolder'];
			pmessage("pics_delf",0,$input);
			}
		}
	}
	
	
	//************ Rename ************
	elseif ( $_REQUEST['rename'] ) {
		if ( has_spright("news.pics") ) {
			if ( $_POST['do']==1 ) {
			$p=explode(".",$_POST['rename']);
			$newfile=$_POST['newname'].'.'.array_pop($p);
				if ( !$_POST['newname'] ) pmessage("back");
				elseif ( file_exists($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$newfile) ) pmessage("pics_rename_exists");
				elseif ( @rename($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$_POST['rename'],$_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$newfile) ) {
				pmessage("pics_rename_ok","news.pics.php?f=".$_POST['f']);
				logit("Bild &quot;".$_REQUEST['rename']."&quot; in &quot;".$newfile."&quot; umbenannt");
				}
				else pmessage("pics_rename_fail");
			}
			else {
			$input['fname']=$_REQUEST['f'];
			$input['rename']=$_REQUEST['rename'];
			$p=explode(".",$_REQUEST['rename']);
			$input['type']=array_pop($p);
			pmessage("pics_rename",0,$input);
			}
		}
		else die("Sie haben keine Berechtigung diese Aktion auszuf&uuml;hren!");
	}
	
	
	//************ Move ************
	elseif ( $_REQUEST['move'] ) {
		if ( has_spright("news.pics") ) {
			if ( $_POST['do']==1 ) {
				if ( file_exists($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['tof'].'/'.$_POST['move']) ) pmessage("pics_move_exists");
				elseif ( @copy($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['fromf'].'/'.$_POST['move'],$_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['tof'].'/'.$_POST['move']) ) {
				@unlink($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['fromf'].'/'.$_POST['move']);
				pmessage("pics_move_ok","news.pics.php?f=".$_POST['tof']);
				logit("Bild &quot;".$_REQUEST['move']."&quot; von &quot;".$_POST['fromf']."&quot; nach &quot;".$_POST['tof']."&quot; verschoben");
				}
				else die("Datei konnte nicht verschoben werden, �berpr�fen Sie ihre CHMOD Einstellungen (CHMOD 777 ben�tigt)!");
			}
			else {
			$handle=@opendir($_SERVER['DOCUMENT_ROOT'].$set['picfolder']);
				if ( $handle ) while ($file=readdir ($handle)) if ( $file!="." && $file!=".." ) $folderlist[]=$file;
			@closedir($handle);
			@sort($folderlist);
				if ( is_array($folderlist) ) foreach($folderlist AS $folder) if ( $folder!=$_REQUEST['f'] ) $input['folders'].='<option value="'.$folder.'">'.$folder.'</option>';
			
			$input['move']=$_REQUEST['move'];
			$input['fname']=$_REQUEST['f'];
			pmessage("pics_move",0,$input);
			}
		}
		else die("Sie haben keine Berechtigung diese Aktion auszuf&uuml;hren!");
	}
	
	
	//************ Copy ************
	elseif ( $_REQUEST['fcopy'] ) {
		if ( has_spright("news.pics") ) {
			if ( $_POST['do']==1 ) {
			$p=explode(".",$_POST['fcopy']);
			$newfile=$_POST['newname'].'.'.array_pop($p);
				if ( !$_POST['newname'] ) pmessage("back");
				elseif ( file_exists($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['tof'].'/'.$newfile) ) pmessage("pics_copy_exists");
				elseif ( @copy($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['fromf'].'/'.$_POST['fcopy'],$_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['tof'].'/'.$newfile) ) {
				pmessage("pics_copy_ok","news.pics.php?f=".$_POST['tof']);
				logit("Bild &quot;".$_REQUEST['fcopy']."&quot; von &quot;".$_POST['fromf']."&quot; als &quot;".$newfile."&quot; nach &quot;".$_POST['tof']."&quot; kopiert");
				}
				else die("Datei konnte nicht verschoben werden, �berpr�fen Sie ihre CHMOD Einstellungen (CHMOD 777 ben�tigt)!");
			}
			else {
			$handle=@opendir($_SERVER['DOCUMENT_ROOT'].$set['picfolder']);
				if ( $handle ) while ($file=readdir ($handle)) if ( $file!="." && $file!=".." ) $folderlist[]=$file;
			@closedir($handle);
			@sort($folderlist);
				if ( is_array($folderlist) ) foreach($folderlist AS $folder) if ( $folder!=$_REQUEST['f'] ) $input['folders'].='<option value="'.$folder.'">'.$folder.'</option>';
			
			$input['fcopy']=$_REQUEST['fcopy'];
			$input['fname']=$_REQUEST['f'];
			$p=explode(".",$_REQUEST['fcopy']);
			$input['type']=array_pop($p);
			$input['newname']=implode(".",$p);
			pmessage("pics_copy",0,$input);
			}
		}
		else die("Sie haben keine Berechtigung diese Aktion auszuf&uuml;hren!");
	}
	
	
	//************ Delete File ************
	elseif ( $_REQUEST['delete'] ) {
		if ( has_spright("news.pics") ) {
			if ( $_REQUEST['do']==1 ) {
			@unlink($_SERVER['DOCUMENT_ROOT'].$set['picfolder']."/".$_POST['f']."/".$_REQUEST['delete']);
			pmessage("pics_del_ok","news.pics.php?f=".$_POST['f']);
			logit("Bild &quot;".$_REQUEST['delete']."&quot; gel�scht");
			}
			else {
			$input['delete']=$_REQUEST['delete'];
			$input['fname']=$_REQUEST['f'];
			pmessage("pics_del",0,$input);
			}
		}
		else die("Sie haben keine Berechtigung diese Aktion auszuf&uuml;hren!");
	}
	
	
	//************ Create Thumbnail ************
	elseif ( $_REQUEST['thumb'] ) {
		if ( $_REQUEST['do']==1 ) {
		$p=explode(".",$_POST['thumb']);
		$ftype='.'.array_pop($p);
		$newfile=$_POST['newname'].$ftype;
			if ( !$_POST['newname'] ) pmessage("back");
			elseif ( file_exists($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$newfile) ) pmessage("pics_copy_exists");
			elseif ( ( $_POST['rtype']=="w" && intval($_POST['neww'])==0 ) || ( $_POST['rtype']=="h" && intval($_POST['newh'])==0 ) ) pmessage("pics_copy_wrongval");
			else {
			$size=@getimagesize($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['f'].'/'.$_REQUEST['thumb']);
			$scale=$size[0]/$size[1];
			
				//Get new size
				if ( $_POST['rtype']=="w" ) {
				$new[0]=intval($_POST['neww']);
				$new[1]=round((intval($_POST['neww']))/$scale);
				}
				elseif ( $_POST['rtype']=="h" ) {
				$new[0]=round((intval($_POST['newh']))*$scale);
				$new[1]=intval($_POST['newh']);
				}
				
				
				//Gif-File
				if ( $size[2]==1 ) { 
				$source=@imagecreatefromgif($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$_POST['thumb']); 
				$dst=@imagecreatetruecolor($new[0],$new[1]); 
					if ( $_POST['useaa'] ) @imagecopyresampled( $dst, $source, 0, 0, 0, 0, $new[0], $new[1], $size[0], $size[1] ) || die("Aktion fehlgeschlagen! Wahrscheinlich wird Antialiasing in dieser Version nicht unterst�tzt.");
					else @imagecopyresized( $dst, $source, 0, 0, 0, 0, $new[0], $new[1], $size[0], $size[1] );
				@imagegif($dst,$_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$newfile);
				@imagedestroy($dst);
				}
				//Jpg-File
				elseif ( $size[2]==2 ) {
				$source=@imagecreatefromjpeg($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$_POST['thumb']); 
				$dst=@imagecreatetruecolor($new[0],$new[1]); 
					if ( $_POST['useaa'] ) @imagecopyresampled( $dst, $source, 0, 0, 0, 0, $new[0], $new[1], $size[0], $size[1] ) || die("Aktion fehlgeschlagen! Wahrscheinlich wird Antialiasing in dieser Version nicht unterst�tzt.");
					else @imagecopyresized( $dst, $source, 0, 0, 0, 0, $new[0], $new[1], $size[0], $size[1] ); 
				@imagejpeg($dst,$_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$newfile);
				@imagedestroy($dst);
				}
				//Png-Bild
				elseif ( $size[2]==3 ) {
				$source=@imagecreatefrompng($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$_POST['thumb']); 
				$dst=@imagecreatetruecolor($new[0],$new[1]); 
					if ( $_POST['useaa'] ) @imagecopyresampled( $dst, $source, 0, 0, 0, 0, $new[0], $new[1], $size[0], $size[1] ) || die("Aktion fehlgeschlagen! Wahrscheinlich wird Antialiasing in dieser Version nicht unterst�tzt.");
					else @imagecopyresized( $dst, $source, 0, 0, 0, 0, $new[0], $new[1], $size[0], $size[1] );
				@imagepng($dst,$_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$newfile);
				@imagedestroy($dst);
				}
			
				if ( file_exists($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_POST['f'].'/'.$newfile) ) {
				pmessage("pics_thumb_ok","news.pics.php?f=".$_POST['f']);
				logit("Thumbnail &quot;".$newfile."&quot; im Ordner &quot;".$_POST['f']."&quot; erstellt");
				}
				else die("Aktion fehlgeschlagen! Wahrscheinlich ist ihre PHP- bzw. GD Library-Version nicht kompatibel.");
			}
		}
		else {
		$input['thumb']=$_REQUEST['thumb'];
		$input['fname']=$_REQUEST['f'];
		$size=@getimagesize($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['f'].'/'.$_REQUEST['thumb']);
		$input['width']=$size[0];
		$input['height']=$size[1];
		$p=explode(".",$_REQUEST['thumb']);
		$input['type']=array_pop($p);
		$input['newname']=implode(".",$p).$set['smallpic'];
		pmessage("pics_thumb",0,$input);
		}
	}
	
	
	//************ Upload File ************
	elseif ( $_REQUEST['upload'] ) {
		if ( file_exists($_SERVER['DOCUMENT_ROOT'].$set['picfolder']."/".$_POST['f']."/".$_FILES['bild']['name']) ) pmessage("pics_exists");
		elseif ( is_uploaded_file($_FILES['bild']['tmp_name']) ) {
		$filetypes=array("gif","jpg","jpe","jpeg","png","GIF","JPG","JPE","JPEG","PNG");
		$p=explode(".",$_FILES['bild']['name']); $type=array_pop($p);
		
			if ( !in_array($type,$filetypes) ) pmessage("pics_nopic");
			else {
				if ( @move_uploaded_file($_FILES['bild']['tmp_name'],$_SERVER['DOCUMENT_ROOT'].$set['picfolder']."/".$_POST['f']."/".$_FILES['bild']['name']) ) {
				@chmod($file,0775);
				pmessage("pics_upload_ok","news.pics.php?f=".$_POST['f']);
				logit("Bild &quot;".$_FILES['bild']['name']."&quot; in den Ordner &quot;".$_POST['f']."&quot; hochgeladen");
				}
				else die("Datei konnte nicht hochgeladen werden, �berpr�fen Sie ihre CHMOD Einstellungen (CHMOD 777 ben�tigt)!");
			}
		}
	}
	
	
	//************ List Pictures ************
	elseif ( $_REQUEST['f'] ) {
		if ( !$_REQUEST['p'] ) $_REQUEST['p']=0;
	$tmpl->load("news_pics,news_pics_listp,news_pics_func2,news_pics_e0,news_pics_e1,news_pics_none,news_pics_space_e0,news_pics_space_e1","../");
	$input['colspan']="4";
	
	//Make TMPL
	$ins['content']=$tmpl->file['news_pics_listp'];
	$ptmpl=$tmpl->parse($tmpl->file['news_pics'],$ins);
	unset($ins);
	
	$handle=@opendir($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['f']);
		if ( $handle ) {
			while ($file=readdir ($handle)) if ( $file!="." && $file!=".." ) $bildlist[]=$file;
		}
		else die("Unterfordner /".$_REQUEST['f']." des Bilderordners ".$set['picfolder']." nicht gefunden oder keine Leserechte, �berpr&uuml;fen Sie ihre CHMOD Einstellungen (CHMOD 777 ben�tigt)!");
	@closedir($handle);
	@sort($bildlist);
	
		if ( is_array($bildlist) ) {
			foreach($bildlist AS $file) {
			$size=@getimagesize($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['f'].'/'.$file);
				if ( is_array($size) ) {
				++$i;
					if ( ($i-1)>=$_REQUEST['p'] && ($i-1)<($_REQUEST['p']+(ceil($set['epp']/4)*4)) ) {
					
					$datasize=filesize($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$_REQUEST['f'].'/'.$file);
						if ( $datasize>1048576 ) $dsize=round($datasize/(1024*1024)).'MB';
						elseif ( $datasize>1024 )  $dsize=round($datasize/(1024)).'KB';
						else  $dsize=$datasize.'Byte';
						
					$ins['size']=$size[0].'x'.$size[1].', '.$dsize;
					
						//Resize Picture
						if ( $size[0]>120 && $size[0]>$size[1] ) {
						$fr=$size[1]/$size[0];
						$size[0]=120;
						$size[1]=ceil(120*$fr);
						}
						elseif ( $size[1]>120 ) {
						$fr=$size[0]/$size[1];
						$size[0]=ceil(120*$fr);
						$size[1]=120;
						}
					
						if ( strlen($file)>20 ) $ins['name']=substr($file,0,7)."[...]".substr($file,-7);
						else $ins['name']=$file;
					$ins['image']='<a href="'.$set['picfolder']."/".$_REQUEST['f']."/".$file.'" target="_blank"><img src="'.$set['picfolder']."/".$_REQUEST['f']."/".$file.'" width="'.$size[0].'" height="'.$size[1].'" alt="'.$file.'" title="'.$file.'" border="0" style="border:1px dashed #000000;margin:3px;"></a>';

						if ( has_spright("news.pics") ) $ins['options']='<a href="news.pics.php?f='.$_REQUEST['f'].'&rename='.$file.'"><img src="../design/rename.gif" alt="Umbenennen" title="Umbenennen" border="0" align="absmiddle"></a>&nbsp;&nbsp;<a href="news.pics.php?f='.$_REQUEST['f'].'&move='.$file.'"><img src="../design/move.gif" alt="Verschieben" title="Verschieben" border="0" align="absmiddle"></a>&nbsp;&nbsp;<a href="news.pics.php?f='.$_REQUEST['f'].'&fcopy='.$file.'"><img src="../design/copy.gif" alt="Kopieren" title="Kopieren" border="0" align="absmiddle"></a>&nbsp;&nbsp;<a href="news.pics.php?f='.$_REQUEST['f'].'&delete='.$file.'"><img src="../design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0" align="absmiddle"></a>';
					$ins['options'].='&nbsp;&nbsp;<a href="news.pics.php?f='.$_REQUEST['f'].'&thumb='.$file.'"><img src="../design/resize.gif" alt="Vorschaubild erstellen (Thumbnail)" title="Vorschaubild erstellen (Thumbnail)" border="0" align="absmiddle"></a>';
					
						if ( $set['useimg'] ) {
						$ins['insert']='<a href="javascript:wnimg(\''.$set['picfolder']."/".$_REQUEST['f']."/".$file.'\');">Als [IMG] einf&uuml;gen</a><br>';
					
						$pa=explode(".",$file);
						$ftype='.'.array_pop($pa);
						$filename=implode(".",$pa);
						$tfile=$filename.$set['smallpic'].$ftype;
							if ( substr($filename,(-1*strlen($set['smallpic'])))==$set['smallpic'] ) $mfile=substr($filename,0,(-1*strlen($set['smallpic']))).$ftype;
							
							if ( in_array($tfile,$bildlist) ) $ins['insert'].='<a href="javascript:wnpopup(\''.$set['picfolder']."/".$_REQUEST['f']."/".$file.'\',\''.$set['picfolder']."/".$_REQUEST['f']."/".$tfile.'\');">Mit Thumbnail einf&uuml;gen</a><br>';
							elseif ( $mfile && in_array($mfile,$bildlist) ) $ins['insert'].='<a href="javascript:thumbtag(\''.$set['picfolder']."/".$_REQUEST['f']."/".$mfile.'\',\''.$set['picfolder']."/".$_REQUEST['f']."/".$file.'\');">Mit Original einf&uuml;gen</a><br>';
						unset($p,$ftype,$filename,$tfile,$mfile);
						}
						else $ins['insert']="";
					
						if ( $i%4==1 ) $input['content'].="<tr>";
					$input['content'].=$tmpl->parse($tmpl->file['news_pics_e'.$i%2],$ins);
					unset($ins);
						if ( $i%4==0 ) $input['content'].="</tr>";
					}
					elseif ( ($i-1)>=($_REQUEST['p']+(ceil($set['epp']/4)*4)) ) $stop=1;
				}
				else echo"Bildgr��e konnte nicht ausgelesen werden!";
			unset($size);
			}
			
			//L�ckenf�ller
			while($i%4!=0 && !$stop ) {
			++$i;
			$input['content'].=$tmpl->file['news_pics_space_e'.$i%2];
				if ( $i%4==0 ) $input['content'].="</tr>";
			}
		}
		else $input['content']=$tmpl->file['news_pics_none'];
	
	$input['pathmore']=' &raquo; <a href="news.pics.php?f='.$_REQUEST['f'].'">'.$_REQUEST['f'].'</a>';
	$input['pages']=pages("news.pics.php?f=".$_REQUEST['f'],count($bildlist),$_REQUEST['p'],1);	
	$input['function']=$tmpl->file['news_pics_func2'];
	$input['fname']=$_REQUEST['f'];
	$tmpl->cache[]=$tmpl->parse($ptmpl,$input);
	}
	
	
	//************ Ordner w�hlen ************
	else {
	$tmpl->load("news_pics,news_pics_listf,news_pics_func1,news_picsf_e0,news_picsf_e1,news_pics_fnone","../");
	$input['colspan']="3";
	
	//Make TMPL
	$ins['content']=$tmpl->file['news_pics_listf'];
	$ptmpl=$tmpl->parse($tmpl->file['news_pics'],$ins);
	unset($ins);
	
		function countfiles($file) {
		global $set;
		$fcount=0;
		$handle=@opendir($_SERVER['DOCUMENT_ROOT'].$set['picfolder'].'/'.$file);
			if ( $handle ) { while ($file = readdir ($handle)) if ( $file!="." && $file!=".." ) ++$fcount; }
		@closedir($handle);
		return $fcount;
		}
	
	$handle=@opendir($_SERVER['DOCUMENT_ROOT'].$set['picfolder']);
		if ( $handle ) {
			while ($file=readdir($handle)) if ( $file!="." && $file!=".." ) $folderlist[]=$file;
		}
		else die("Bilderordner ".$set['picfolder']." nicht gefunden oder keine Leserechte, �berpr�fen Sie ihre CHMOD Einstellungen (CHMOD 777 ben�tigt)!");
	@closedir($handle);
	@sort($folderlist);
	
		if ( is_array($folderlist) ) {
			foreach($folderlist AS $file) {
			++$i;
			$ins['fname']=$file;
			$ins['count']=countfiles($file);
				if ( has_spright("news.pics") && !$ins['count'] ) $ins['options']='<a href="news.pics.php?delfolder='.$file.'"><img src="../design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0" align="absmiddle"></a>';
				else $ins['options']="&nbsp;";
			
			$input['content'].=$tmpl->parse($tmpl->file['news_picsf_e'.$i%2],$ins);
			}
		}
		else $input['content']=$tmpl->file['news_pics_fnone'];
	
	$input['pathmore']="";
	$input['function']=$tmpl->file['news_pics_func1'];
	$tmpl->cache[]=$tmpl->parse($ptmpl,$input);
	}

}
else die("Sie haben keine Berechtigung diese Aktion auszuf�hren!");

$set['style']['design_pagetitle']=$set['title'];
	
/*** OUTPUT ***/
$tmpl->out($set['style'],1);
?>