<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



	if ( has_right("com.show") ) $tmpl->cache[]='<p>&raquo; <a href="index.php?action=com.show">Kommentare zeigen</a><br><font>Zeige die Kommentare zu den einzelnen Newsartikel an.</font></p>';

$tmpl->load("com_block_show,com_block_show_e0,com_block_show_e1,com_block_show_none,com_block_show_spacer");

$orderdef['string']['col']="string";
$orderdef['string']['sort']="ASC";
$orderdef['string']['name']="Name/IP";
$orderdef['time']['col']="endtime";
$orderdef['time']['sort']="ASC";
$orderdef['time']['name']="Ende";
$orderdef['default']="string";

$db->query("SELECT * FROM ".PRE."_block WHERE endtime>='".time()."' ORDER BY type ASC, ".getorder($orderdef));
	if ( $db->checkres() ) {
		while($res=$db->fetch()) {
			if ( $lasttype && $lasttype!=$res['type'] ) $input['content'].=$tmpl->file['com_block_show_spacer'];
		++$i;
		$ins['string']=iif($res['type']=="name","Name: ","IP: ").replace($res['string']);
		$ins['endtime']=makedate($res['endtime']);
			if ( has_right("com.block.del") ) $ins['options'].='<a href="index.php?action=com.block.del&id='.$res['id'].'"><img src="design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0"></a> ';
			if ( !$ins['options'] ) $ins['options']="&nbsp;";
		$input['content'].=$tmpl->parse($tmpl->file['com_block_show_e'.$i%2],$ins);
		unset($ins);
		$lasttype=$res['type'];
		}
	}
	else $input['content']=$tmpl->file['com_block_show_none'];
$db->free();

$input['orderstring']=orderstr($orderdef,"index.php?action=com.block.show");
$tmpl->cache[]=$tmpl->parse($tmpl->file['com_block_show'],$input);

?>