<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



	if ( has_right("user.group.add") ) $tmpl->cache[]='<p>&raquo; <a href="index.php?action=user.group.add">Benutzergruppe erstellen</a><br><font>Hier k&ouml;nnen Sie neue Benutzergruppen anlegen um die Rechtevergabe zu individualisieren.</font></p>';

$tmpl->load("user_group_show,user_group_show_e0,user_group_show_e1");

$query=$db->query("SELECT groupid,groupname FROM ".PRE."_group ORDER BY groupname ASC");
	while($res=$db->fetch($query)) {
	++$i;
	$ins['name']=replace($res['groupname']);
	list($ins['count'],$trash)=$db->first("SELECT count(groupid) FROM ".PRE."_user WHERE groupid='".$res['groupid']."'");
		if ( has_right("user.group.edit") ) $ins['options']='<a href="index.php?action=user.group.edit&id='.$res['groupid'].'"><img src="design/edit.gif" alt="Bearbeiten" title="Bearbeiten" border="0"></a> ';
		if ( has_right("user.group.del") && !$ins['count'] ) $ins['options'].='<a href="index.php?action=user.group.del&id='.$res['groupid'].'"><img src="design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0"></a> ';
		if ( !$ins['options'] ) $ins['options']="&nbsp;";
	$input['content'].=$tmpl->parse($tmpl->file['user_group_show_e'.$i%2],$ins);
	unset($ins);
	}
$db->free($query);

$tmpl->cache[]=$tmpl->parse($tmpl->file['user_group_show'],$input);

?>