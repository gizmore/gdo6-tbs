<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['id'] || !$_POST['newsid'] || !$_POST['name'] || !$_POST['text'] ) message("back");
	else {
	$time=mktime($_POST['time']['hours'],$_POST['time']['mins'],$_POST['time']['secs'],$_POST['time']['month'],$_POST['time']['day'],$_POST['time']['year']);
	$db->query("UPDATE ".PRE."_comment SET name='".addslashes($_POST['name'])."',email='".addslashes($_POST['mail'])."',text='".addslashes($_POST['text'])."',time='".$time."' WHERE ( id='".$_POST['id']."' AND newsid='".$_POST['newsid']."' ) LIMIT 1");
	message("com_edit_ok","index.php?action=com.show&newsid=".$_POST['newsid']);
	logit("Kommentar ID #".$_POST['id']." bearbeitet");
	}
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
	if ( !$_REQUEST['newsid'] ) die("no newsid specified!");

$tmpl->load("com_edit");
$res=$db->first("SELECT * FROM ".PRE."_comment WHERE ( id='".$_REQUEST['id']."' AND newsid='".$_REQUEST['newsid']."')");

	function dropdown($start,$to,$name,$value) {
		for ( $i=$start; $i<=$to; $i++ ) $out.='<option value="'.$i.'"'.iif($i==$value," selected").'>'.sprintf("%02.d",$i).'</option>';
	return '<select name="'.$name.'">'.$out.'</select>';
	}
	
$input['id']=$_REQUEST['id'];
$input['newsid']=$_REQUEST['newsid'];
$input['name']=htmlspecialchars($res['name']);
$input['email']=htmlspecialchars($res['email']);
$input['text']=htmlspecialchars($res['text']);
$input['tagstatus']=tagstatus_com();

$date=getdate($res['time']);
$input['date']=dropdown(1,31,"time[day]",$date['mday']).".".dropdown(1,12,"time[month]",$date['mon']).".".dropdown(2000,2010,"time[year]",$date['year'])." - ".dropdown(0,23,"time[hours]",$date['hours']).":".dropdown(0,59,"time[mins]",$date['minutes']).":".dropdown(0,59,"time[secs]",$date['seconds'])." Uhr";

$tmpl->cache[]=$tmpl->parse($tmpl->file['com_edit'],$input);
}

?>