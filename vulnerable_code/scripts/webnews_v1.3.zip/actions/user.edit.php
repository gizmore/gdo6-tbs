<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['userid'] || !$_POST['username'] || !$_POST['groupid'] ) message("back");
	elseif ( ($_POST['pw1'] || $_POST['pw2']) && $_POST['pw1']!=$_POST['pw2'] ) message("user_add_pwfail");
	else {
	$res=$db->first("SELECT userid FROM ".PRE."_user WHERE ( username='".addslashes($_POST['username'])."' AND userid!='".$_POST['userid']."' ) LIMIT 1");
		if ( $res['userid'] ) message("user_add_uninuse");
		else {
		$db->query("UPDATE ".PRE."_user SET username='".addslashes($_POST['username'])."'".iif ( (($_POST['pw1'] || $_POST['pw2']) && $_POST['pw1']==$_POST['pw2']), ",password='".md5($_POST['pw1'])."'" ).",groupid='".$_POST['groupid']."',email='".$_POST['mail']."',active='".$_POST['active']."' WHERE ( userid='".$_POST['userid']."' AND userid!='".$_USER['userid']."' )");
		message("user_edit_ok","index.php?action=user.show");
		logit("Benutzer ID #".$_POST['userid']." bearbeitet");
		}
	}
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");

$tmpl->load("user_edit");
$res=$db->first("SELECT userid,username,email,active,groupid FROM ".PRE."_user WHERE userid='".$_REQUEST['id']."'");
$input['userid']=$res['userid'];
$input['username']=htmlspecialchars($res['username']);
$input['email']=htmlspecialchars($res['email']);
$input['active']='<input type="radio" name="active" value="1"'.iif($res['active']==1,' checked').'> aktiv&nbsp;&nbsp;<input type="radio" name="active" value="0"'.iif($res['active']==0,' checked').'> inaktiv';

$db->query("SELECT groupid,groupname FROM ".PRE."_group ORDER BY groupname ASC");
	while ( $res2=$db->fetch()) $input['groups'].='<option value="'.$res2['groupid'].'"'.iif( $res['groupid']==$res2['groupid']," selected" ).'>'.replace($res2['groupname']).'</option>';
$db->free();

$tmpl->cache[]=$tmpl->parse($tmpl->file['user_edit'],$input);
}

?>