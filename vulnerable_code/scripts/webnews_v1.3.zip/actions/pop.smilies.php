<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



/*** MODULES LOAD ***/
require("../modules/config.inc.php");
require("../modules/functions.php");
require("../modules/template.php");

$tmpl = new template;
$tmpl->load("pop_smilies,pop_smilies_e0,pop_smilies_e1","../");
	foreach ( $set['smilies'] AS $file => $code ) {
	++$i;
	$ins['code']=replace($code);
	$ins['smilie']='<img src="../parse/smilies/'.$file.'.gif" alt="" border="0" onclick="smilie(\''.$code.'\');">';
	$input['content'].=$tmpl->parse($tmpl->file['pop_smilies_e'.$i%2],$ins);
	unset($ins);
	}
$tmpl->cache[]=$tmpl->parse($tmpl->file['pop_smilies'],$input);

$set['style']['design_pagetitle']=$set['title'];

/*** OUTPUT ***/
$tmpl->out($set['style'],1);

?>
