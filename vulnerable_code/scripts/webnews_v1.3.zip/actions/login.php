<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



$tmpl->load("login");

if ( !$_POST['logintime'] || intval($_POST['logintime'])==0 ) $_POST['logintime']=30;

if ( $_POST['name'] && $_POST['pw'] ) {
$res=$db->first("SELECT userid,username,active FROM ".PRE."_user WHERE (username='".addslashes($_POST['name'])."' AND password='".md5($_POST['pw'])."') LIMIT 1");
	if ( !$res['userid'] ) message("login_fail","index.php");
	elseif ( !$res['active'] ) message("user_inactive","index.php");
	else {
		if ( $res['username']==$_POST['name'] ) {
		setcookie("wn_userid",$res['userid'],time()+$_POST['logintime']*24*3600);
		setcookie("wn_userpw",md5($_POST['pw']),time()+$_POST['logintime']*24*3600);
		message("login_ok","index.php");
		logit("&gt;&gt;&gt;&gt;&gt;&gt; LOGIN &gt;&gt;&gt;&gt;&gt;&gt;",$res['userid']);
		}
		else message("login_fail","index.php");
	}
}
else $tmpl->cache[]=$tmpl->file['login'];

?>