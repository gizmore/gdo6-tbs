<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



	if ( !$_REQUEST['id'] ) die("no id set!");

/*** MODULES LOAD ***/
require("../modules/config.inc.php");
require("../modules/functions.php");
require("../modules/database.php");
require("../modules/template.php");

$tmpl = new template;
$db = new database;
$db->connect($set);
define("PRE",$set['table']);

$tmpl->load("user_group_info","../","../");

$res=$db->first("SELECT extra_descr FROM ".PRE."_actions WHERE action='".$_REQUEST['id']."'");
$input['info']=replace($res['extra_descr']);
$tmpl->cache[]=$tmpl->parse($tmpl->file['user_group_info'],$input);

$set['style']['design_pagetitle']=$set['title'];

/*** OUTPUT ***/
$db->close($set);
$tmpl->out($set['style'],1);

?>
