<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $set['usekats'] ) {
	if ( has_right("cat.add") ) $tmpl->cache[]='<p>&raquo; <a href="index.php?action=cat.add">Kategorie erstellen</a><br><font>Hiermit k&ouml;nnen Sie weitere Newskategorien erstellen.</font></p>';

$tmpl->load("cat_show,cat_show_e0,cat_show_e1,cat_show_none");
$query=$db->query("SELECT * FROM ".PRE."_newscat ORDER BY name ASC");
	if ( $db->checkres() ) {
		while($res=$db->fetch($query)) {
		++$i;
		$ins['name']=replace($res['name']);
		list($ins['count'],$trash)=$db->first("SELECT count(id) FROM ".PRE."_news WHERE catid='".$res['id']."'");	
		
			if ( has_right("cat.edit") ) $ins['options'].='<a href="index.php?action=cat.edit&id='.$res['id'].'"><img src="design/edit.gif" alt="Bearbeiten" title="Bearbeiten" border="0"></a> ';
			if ( has_right("cat.del") && !$ins['count'] ) $ins['options'].='<a href="index.php?action=cat.del&id='.$res['id'].'"><img src="design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0"></a>';
			if ( has_right("cat.clean") && $ins['count'] ) $ins['options'].='<a href="index.php?action=cat.clean&id='.$res['id'].'"><img src="design/clean.gif" alt="R&auml;umen und L&ouml;schen" title="R&auml;umen und L&ouml;schen" border="0"></a>';
			if ( !$ins['options'] ) $ins['options']="&nbsp;";
			
		$input['content'].=$tmpl->parse($tmpl->file['cat_show_e'.$i%2],$ins);
		unset($ins);
		}
	}
	else $input['content']=$tmpl->file['cat_show_none'];
$db->free();
$tmpl->cache[]=$tmpl->parse($tmpl->file['cat_show'],$input);
}
else message("cat_off");

?>