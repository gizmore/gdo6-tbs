<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['topic'] || !$_POST['text'] || ( $set['usekats'] && !$_POST['catid'] ) ) message("back");
	else {
	$now=time();
		if ( !$set['usekats'] ) $_POST['catid']=1;
		for ( $i=0; $i<=3 ; ++$i ) if ( $_POST['link'.$i]['title'] && $_POST['link'.$i]['text'] && $_POST['link'.$i]['link'] ) $links[$i]=$_POST['link'.$i]['title']."|".$_POST['link'.$i]['text']."|".$_POST['link'.$i]['link']."|".$_POST['link'.$i]['target'];
		
		//Import-Modus
		if ( has_right("news.pub") && $set['importmode'] ) {
		$pubtime=mktime($_POST['pubtime']['hours'],$_POST['pubtime']['mins'],$_POST['pubtime']['secs'],$_POST['pubtime']['month'],$_POST['pubtime']['day'],$_POST['pubtime']['year']);
		}
		
		if ( !$_POST['allowcoms'] ) $_POST['allowcoms']=0;
		
	$db->query("INSERT INTO ".PRE."_news (catid,userid,topic,subtopic,text,link1,link2,link3,time,pubtime,pin,allowcoms) VALUES ('".$_POST['catid']."','".$_USER['userid']."','".addslashes($_POST['topic'])."','".addslashes($_POST['subtopic'])."','".addslashes($_POST['text'])."','".addslashes($links[1])."','".addslashes($links[2])."','".addslashes($links[3])."','".$now."','".$pubtime."','".$_POST['pin']."','".$_POST['allowcoms']."')");
	
	$id=$db->insert_id();
		if ( $_POST['pubnow'] ) message("news_addpub_ok","index.php?action=news.pub&id=".$id);
		else message("news_add_ok","index.php?action=news.show");
	logit("Artikel ID #".$id." erstellt");
	}
}
else {
	if ( has_right("news.pics") ) $tmpl->cache[]='<p>&raquo; <a href="javascript:bmanager();">Bildmanager</a><br><font>Mit diesem Tool lassen sich eigene Bilder hochladen und verwalten.</font></p>';
$tmpl->load("news_add");

	if ( is_array($set['e_fonts']) ) foreach ( $set['e_fonts'] AS $val ) $input['font'].='<option value="'.$val.'">'.$val.'</option>';
	if ( is_array($set['e_sizes']) ) foreach ( $set['e_sizes'] AS $val ) $input['size'].='<option value="'.$val.'">'.$val.'</option>';
	if ( is_array($set['e_colors']) ) foreach ( $set['e_colors'] AS $name => $val ) $input['color'].='<option value="'.$val.'" style="background:'.$val.';">'.$name.'</option>';
	if ( !$input['font'] ) $input['font']="";
	if ( !$input['size'] ) $input['size']="";
	if ( !$input['color'] ) $input['color']="";
	
	if ( $_COOKIE['wncmode']==1 ) {
	$input['m0check']='';
	$input['m1check']='checked';
	}
	else {
	$input['m0check']='checked';
	$input['m1check']='';
	}
	
	//Ver�ffentlichung + Import-Modus
	function dropdown($start,$to,$name,$value) {
		if ( $value=="none" ) $out.='<option value="" selected></option>';
		for ( $i=$start; $i<=$to; $i++ ) $out.='<option value="'.$i.'"'.iif($value!="none" && $i==$value," selected").'>'.sprintf("%02.d",$i).'</option>';
	return '<select name="'.$name.'">'.$out.'</select>';
	}
	
	if ( has_right("news.pub") ) {
		if ( $set['importmode'] ) {
		$thedate=getdate();
		$insert=dropdown(1,31,"pubtime[day]",$thedate['mday']).".".dropdown(1,12,"pubtime[month]",$thedate['mon']).".".dropdown(2000,2010,"pubtime[year]",$thedate['year'])." - ".dropdown(0,23,"pubtime[hours]",$thedate['hours']).":".dropdown(0,59,"pubtime[mins]",$thedate['minutes']).":".dropdown(0,59,"pubtime[secs]",$thedate['seconds'])." Uhr";
		$input['publish']=str_replace("%import%",$insert,$tmpl->get("news_add_import"));
		}
		else $input['publish']=$tmpl->get("news_add_pub");
	}
	else $input['publish']="";
	
$input['username']=replace($_USER['username']);
$input['userid']=$_USER['userid'];
	if ( $set['usetcode'] ) $input['topictagstatus']="AN";
	else $input['topictagstatus']="AUS";
$input['tagstatus']=tagstatus();
	
	if ( $set['usekats'] ) {
	$db->query("SELECT id,name FROM ".PRE."_newscat ORDER BY name ASC");
		while($res=$db->fetch()) $input['newscat'].='<option value="'.$res['id'].'">'.replace($res['name']).'</option>';
	$db->free();
		if ( $input['newscat'] ) $input['newscat']='<select name="catid"><option value=""></option>'.$input['newscat'].'</select>'; 
		else message("news_nocat");
	}
	else $input['newscat']="deaktiviert<br><font>(Bei &Auml;nderung dieser Option werden die Newsmeldungen automatisch der zuerst erstellten Kategorie zugewie&szlig;en.)</font>";
	
	if ( $set['usecoms'] ) $input['allowcoms']='<input type="checkbox" name="allowcoms" value="1" checked> Kommentare erlauben';
	else $input['allowcoms']='Kommentarfunktion deaktiviert';
	
	if ( $input['newscat'] ) $tmpl->cache[]=$tmpl->parse($tmpl->file['news_add'],$input);
}

?>