<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



setcookie("wn_userid",0,time()-10000);
setcookie("wn_userpw",0,time()-10000);
	if ( $_REQUEST['auto']==1 ) {
	message("logout_auto","index.php");
	logit("&lt;&lt;&lt;&lt;&lt;&lt; LOGOUT (AUTO) &lt;&lt;&lt;&lt;&lt;&lt;");
	}
	elseif ( $_REQUEST['auto']==2 ) {
	message("user_inactive","index.php");
	logit("&lt;&lt;&lt;&lt;&lt;&lt; LOGOUT (INAKTIV) &lt;&lt;&lt;&lt;&lt;&lt;");
	}
	else {
	message("logout","index.php");
	logit("&lt;&lt;&lt;&lt;&lt;&lt; LOGOUT &lt;&lt;&lt;&lt;&lt;&lt;");
	}
?>
