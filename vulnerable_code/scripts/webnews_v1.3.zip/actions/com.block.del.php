<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
list($type,$string)=$db->first("SELECT type,string FROM ".PRE."_block WHERE id='".$_POST['id']."' LIMIT 1");
$db->query("DELETE FROM ".PRE."_block WHERE id='".$_POST['id']."' LIMIT 1");
message("com_block_del_ok","index.php?action=com.block.show");
	if ( $type=="name" ) logit("Nickname ".$string." entsperrt");
	elseif ( $type=="ip" ) logit("IP ".$string." entsperrt");
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
$ins['id']=$_REQUEST['id'];
message("com_block_del",0,$ins);
}

?>