<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################


/************ ADD ENTRY ************/
if ( $_POST['add']==1 ) {
	if ( !$_POST['name'] || !$_POST['url'] ) message("back");
	else {
		if ( substr($_POST['url'],0,4)=="www." ) $_POST['url']="http://".$_POST['url'];
	$db->query("INSERT INTO ".PRE."_source VALUES ('0','".addslashes($_POST['name'])."','".addslashes($_POST['url'])."','".addslashes($_POST['text'])."')");
	message("news_source_add_ok","index.php?action=news.source");
	logit("Quelle ID #".$db->insert_id()." hinzugef�gt");
	}
}


/************ DEL ENTRY ************/
elseif ( $_REQUEST['del'] ) {
	if ( has_spright("news.source") ) {
		if ( $_POST['do']==1 ) {
		$db->query("DELETE FROM ".PRE."_source WHERE id='".$_POST['del']."' LIMIT 1");
		message("news_source_del_ok","index.php?action=news.source");
		}
		else {
		$input['del']=$_GET['del'];
		message("news_source_del",0,$input);
		}
	}
	else die("Sie haben keine Berechtigung diese Aktion auszuf&uuml;hren!");
}


/************ EDIT ENTRY ************/
elseif ( $_REQUEST['edit'] ) {
	if ( has_spright("news.source") ) {
		if ( $_POST['do']==1 ) {
			if ( !$_POST['edit'] || !$_POST['name'] || !$_POST['url'] ) message("back");
			else {
				if ( substr($_POST['url'],0,4)=="www." ) $_POST['url']="http://".$_POST['url'];
			$db->query("UPDATE ".PRE."_source SET name='".addslashes($_POST['name'])."',url='".addslashes($_POST['url'])."',text='".addslashes($_POST['text'])."' WHERE id='".$_REQUEST['edit']."' LIMIT 1");
			message("news_source_edit_ok","index.php?action=news.source");
			logit("Quelle ID #".$_REQUEST['edit']." bearbeitet");
			}
		}
		else {
		$tmpl->load("news_source_edit");
		$res=$db->first("SELECT * FROM ".PRE."_source WHERE id='".$_REQUEST['edit']."' LIMIT 1");
		$input['edit']=$_REQUEST['edit'];
		$input['name']=htmlspecialchars($res['name']);
		$input['url']=htmlspecialchars($res['url']);
		$input['text']=htmlspecialchars($res['text']);
		$tmpl->cache[]=$tmpl->parse($tmpl->file['news_source_edit'],$input);
		}
	}
	else die("Sie haben keine Berechtigung diese Aktion auszuf&uuml;hren!");
}


/************ SHOW ************/
else {
$tmpl->load("news_source,news_source_e0,news_source_e1,news_source_none");

$query=$db->query("SELECT * FROM ".PRE."_source ORDER BY name ASC");
	while($res=$db->fetch()) {
	++$i;
	$ins['link']='<a href="'.$res['url'].'" target="_blank">'.$res['name'].'</a>';
	$ins['text']=replace($res['text']);
		if ( $res['text'] ) $ins['text']=replace($res['text']);
		else $ins['text']="&nbsp;";
		if ( has_spright("news.source") ) $ins['options']='<a href="index.php?action=news.source&edit='.$res['id'].'"><img src="design/edit.gif" alt="Bearbeiten" title="Bearbeiten" border="0"></a> <a href="index.php?action=news.source&del='.$res['id'].'"><img src="design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0"></a>';
		if ( !$ins['options'] ) $ins['options']="&nbsp;";
	$input['links'].=$tmpl->parse($tmpl->file['news_source_e'.$i%2],$ins);
	}
$db->free();

	if ( !$input['links'] ) $input['links'].=$tmpl->file['news_source_none'];

$tmpl->cache[]=$tmpl->parse($tmpl->file['news_source'],$input);
}

?>