<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['groupid'] || !$_POST['groupname'] || ( !$_POST['rights'] && !$_POST['allrights'] ) ) message("back");
	else {
	//Check groupname
	list($name,$trash)=$db->first("SELECT groupname FROM ".PRE."_group WHERE groupid='".$_POST['groupid']."' LIMIT 1");
	if ( $name!=$_POST['groupname'] ) $db->query("SELECT groupid FROM ".PRE."_group WHERE groupname='".addslashes($_POST['groupname'])."' LIMIT 1");
	
		if ( $db->checkres() ) message("group_add_inuse");
		else {
			//R String
			if ( $_POST['allrights'] ) $rgs="global";
			else {
				foreach( $_POST['rights'] AS $action => $value ) if ( $value ) $cc[]=$action;
			$rgs=@implode("|",$cc);
			
			}
		
			//SPR String
			if ( is_array($_POST['sprights']) && $rgs!="global" )	{
				foreach( $_POST['sprights'] AS $action => $value ) if ( $value && @in_array($action,$cc) ) $c[]=$action;
			$spr=@implode("|",$c);
			unset($c);
			}
		unset($cc);
		
		$db->query("UPDATE ".PRE."_group SET groupname='".addslashes($_POST['groupname'])."',grouprights='$rgs',groupsprights='$spr' WHERE groupid='".$_POST['groupid']."' LIMIT 1");
		message("group_edit_ok","index.php?action=user.group.show");
		logit("Benutzergruppe ID #".$_POST['groupid']." bearbeitet");
		}
	}
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");

$res=$db->first("SELECT * FROM ".PRE."_group WHERE groupid='".$_REQUEST['id']."'");
$input['groupname']=htmlspecialchars($res['groupname']);
	if ( $res['grouprights']=="global" ) $input['checked']="checked";
	else $input['checked']="";
$input['groupid']=$res['groupid'];

$grights=array();
$gsprights=array();
	if ( $res['grouprights'] && $res['grouprights']!="global" ) $grights=explode("|",$res['grouprights']);
	if ( $res['groupsprights'] ) $gsprights=explode("|",$res['groupsprights']);

$tmpl->load("user_group,user_group_e0,user_group_e1,user_group_cat");
$query=$db->query("SELECT action,caption,cat,catname,extra,extra_descr FROM ".PRE."_actions WHERE cat!='none' ORDER BY cat ASC, ord ASC");
	while($res=$db->fetch()) {
	++$i;
		if ( $res['cat']!=$lastactcat ) {
		$ins['title']=replace($res['catname']);
		$input['content'].=$tmpl->parse($tmpl->file['user_group_cat'],$ins);
		unset($ins);
		$i=1;
		}
	
	$ins['action']=replace($res['caption']." (".$res['action'].")");
	$ins['rights']='<input type="checkbox" name="rights['.$res['action'].']" value="1"'.iif(in_array($res['action'],$grights), " checked").'>';
		if ( $res['extra'] ) $ins['sprights']='<input type="checkbox" name="sprights['.$res['action'].']" value="1"'.iif(in_array($res['action'],$gsprights), " checked" ).'>';
		else $ins['sprights']="&nbsp;";
		if ( $res['extra_descr'] ) $ins['info']='<a href="javascript:openwin(\''.$res['action'].'\');"><img src="design/info.gif" alt="Mehr Informationen" alt="Mehr Informationen" border="0"></a>';
		else $ins['info']="&nbsp;";
	
	$input['content'].=$tmpl->parse($tmpl->file['user_group_e'.$i%2],$ins);
	$lastactcat=$res['cat'];
	}
$db->free();

$input['submit']="Aktualisieren";
$input['action']="user.group.edit";

$tmpl->cache[]=$tmpl->parse($tmpl->file['user_group'],$input);
}

?>