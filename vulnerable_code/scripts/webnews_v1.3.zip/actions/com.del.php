<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
$db->query("DELETE FROM ".PRE."_comment WHERE ( id='".$_POST['id']."' AND newsid='".$_POST['newsid']."' ) LIMIT 1");
message("com_del_ok","index.php?action=com.show&newsid=".$_POST['newsid']);
logit("Kommentar ID #".$_POST['id']." gel�scht");
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
	if ( !$_REQUEST['newsid'] ) die("no newsid specified!");
$ins['id']=$_REQUEST['id'];
$ins['newsid']=$_REQUEST['newsid'];
message("com_del",0,$ins);
}

?>