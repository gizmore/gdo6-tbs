<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( has_right("user.add") ) $tmpl->cache[]='<p>&raquo; <a href="index.php?action=user.add">Benutzer hinzuf&uuml;gen</a><br><font>F&uuml;gen Sie dem WEB//NEWS System weitere Benutzer hinzu.</font></p>';

$tmpl->load("user_show,user_show_e0,user_show_e1");

$orderdef['user']['col']="username";
$orderdef['user']['sort']="ASC";
$orderdef['user']['name']="Benutzer";
$orderdef['group']['col']="groupname";
$orderdef['group']['sort']="ASC";
$orderdef['group']['name']="Benutzergruppe";
$orderdef['default']="user";

$query=$db->query("SELECT userid,username,groupname,active FROM ".PRE."_user LEFT JOIN ".PRE."_group USING (groupid) ORDER BY ".getorder($orderdef));
	while($res=$db->fetch()) {
	++$i;
	$ins['username']=replace($res['username']);
	$ins['usergroup']=replace($res['groupname']);
	
		if ( $res['active'] ) $ins['active']='<img src="design/active.gif" alt="Aktiv" title="Aktiv" border="0">';
		else $ins['active']='<img src="design/inactive.gif" alt="Inaktiv" title="Inaktiv" border="0">';	
	
		if ( has_right("user.edit") && $res['userid']!=$_USER['userid'] ) $ins['options'].='<a href="index.php?action=user.edit&id='.$res['userid'].'"><img src="design/edit.gif" alt="Bearbeiten" title="Bearbeiten" border="0"></a> ';
		if ( has_right("user.del") && $res['userid']!=$_USER['userid'] ) $ins['options'].='<a href="index.php?action=user.del&id='.$res['userid'].'"><img src="design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0"></a> ';
		if ( has_right("user.profile") && $res['userid']!=$_USER['userid'] ) $ins['options'].='<a href="index.php?action=user.profile&id='.$res['userid'].'"><img src="design/profile.gif" alt="Profil ansehen" title="Profil ansehen" border="0"></a>';
		if ( !$ins['options'] ) $ins['options']="&nbsp;";
		
	$input['content'].=$tmpl->parse($tmpl->file['user_show_e'.$i%2],$ins);
	unset($ins);
	}
$db->free();

$input['orderstring']=orderstr($orderdef,"index.php?action=user.show");
$tmpl->cache[]=$tmpl->parse($tmpl->file['user_show'],$input);

?>