<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $set['usecoms'] ) {

	if ( has_right("com.block.show") ) $tmpl->cache[]='<p>&raquo; <a href="index.php?action=com.block.show">Kommentar-Sperren zeigen</a><br><font>Hier k&ouml;nnen Sie sich alle gesperrten Nicknames und IPs anzeigen lassen.</font></p>';

	if ( $_REQUEST['newsid'] ) {
		if ( !$_REQUEST['newsid'] ) die("no newsid specified!");
	$orderdef['user']['col']="name";
	$orderdef['user']['sort']="ASC";
	$orderdef['user']['name']="Name";
	$orderdef['time']['col']="time";
	$orderdef['time']['sort']="DESC";
	$orderdef['time']['name']="Datum";
	$orderdef['default']="time";
	
	$block['name']=array();
	$block['ip']=array();
	$query=$db->query("SELECT type,string FROM ".PRE."_block WHERE endtime>='".time()."'");
		if ( $db->checkres($query) ) {
			while($res=$db->fetch($query)) {
			$block[$res['type']][]=$res['string'];
			}
		}
	$db->free($query);
	unset($db->result,$res,$query);
	
		if ( !$_REQUEST['p'] ) $_REQUEST['p']=0;
	$res=$db->first("SELECT count(id) FROM ".PRE."_comment WHERE newsid='".$_REQUEST['newsid']."'"); $count=$res[0];
	$input['pages']=pages("index.php?action=com.show&newsid=".$_REQUEST['newsid'],$count,$_REQUEST['p']);
	
	$tmpl->load("com_cshow,com_cshow_e0,com_cshow_e1");
	$query=$db->query("SELECT id,name,text,time,ip FROM ".PRE."_comment WHERE newsid='".$_REQUEST['newsid']."' ORDER BY ".getorder($orderdef)." LIMIT ".$_REQUEST['p'].",".$set['epp']);
		if ( $db->checkres($query) ) {
			while($res=$db->fetch($query)) {
			++$i;
			$ins['name']=replace($res['name']);
				if ( strlen($res['text'])>45 ) $ins['text']=replace(substr($res['text'],0,42)."...");
				else $ins['text']=replace($res['text']);
			$ins['date']=makedate($res['time'],1);
				if ( has_right("com.edit") ) $ins['options'].='<a href="index.php?action=com.edit&id='.$res['id'].'&newsid='.$_REQUEST['newsid'].'"><img src="design/edit.gif" alt="Bearbeiten" title="Bearbeiten" border="0"></a> ';
				if ( has_right("com.del") ) $ins['options'].='<a href="index.php?action=com.del&id='.$res['id'].'&newsid='.$_REQUEST['newsid'].'"><img src="design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0"></a> ';
			$ins['options'].='<img src="design/ip.gif" alt="IP: '.$res['ip'].'" title="IP: '.$res['ip'].'" border="0"> ';
				if ( !in_array($res['name'],$block['name']) || !in_array($res['ip'],$block['ip']) ) $ins['options'].='<a href="index.php?action=com.block.add&id='.$res['id'].'&newsid='.$_REQUEST['newsid'].'"><img src="design/blockip.gif" alt="Sperren" title="Sperren" border="0"></a>';
			$input['content'].=$tmpl->parse($tmpl->file['com_cshow_e'.$i%2],$ins); 
			unset($ins);
			}
		}
		else $input['content']="";
	$db->free();
	
	$input['orderstring']=orderstr($orderdef,"index.php?action=com.show&newsid=".$_REQUEST['newsid']."&p=".$_REQUEST['p']);
	$tmpl->cache[]=$tmpl->parse($tmpl->file['com_cshow'],$input);
	$tmpl->cache[]='&raquo; <a href="index.php?action=com.show">Zur&uuml;ck zur Newsebene</a>';
	}
	
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	
	else {
	$orderdef['thema']['col']="topic";
	$orderdef['thema']['sort']="ASC";
	$orderdef['thema']['name']="Thema";
	$orderdef['date']['col']="time";
	$orderdef['date']['sort']="DESC";
	$orderdef['date']['name']="Erstelldatum";
	$orderdef['pubdate']['col']="pubtime";
	$orderdef['pubdate']['sort']="DESC";
	$orderdef['pubdate']['name']="Ver�ffentlichung";
	$orderdef['default']="pubdate";
	
		if ( !$_REQUEST['p'] ) $_REQUEST['p']=0;
	$res=$db->first("SELECT count(id) FROM ".PRE."_news"); $count=$res[0];
	$input['pages']=pages("index.php?action=com.show",$count,$_REQUEST['p']);
	
	$tmpl->load("com_show,com_show_e0,com_show_e1,com_show_none");
	$query=$db->query("SELECT id,topic FROM ".PRE."_news ORDER BY ".getorder($orderdef)." LIMIT ".$_REQUEST['p'].",".($_REQUEST['p']+$set['epp']));
		if ( $db->checkres($query) ) {
			while($res=$db->fetch($query)) {
			++$i;
				if ( strlen($res['topic'])<=40 ) $ins['topic']=replace($res['topic']);
				else $ins['topic']=replace(substr($res['topic'],0,37)."...");
			list($ins['count'],$trash)=$db->first("SELECT count(id) FROM ".PRE."_comment WHERE newsid='".$res['id']."'");
				if ( $ins['count'] ) $ins['options'].='<a href="index.php?action=com.show&newsid='.$res['id'].'"><img src="design/open.gif" alt="Kommentare zeigen" title="Kommentare zeigen" border="0"></a> ';
				if ( !$ins['options'] ) $ins['options']="&nbsp;";
			$input['content'].=$tmpl->parse($tmpl->file['com_show_e'.$i%2],$ins); 
			unset($ins);
			}
		}
		else $input['content']=$tmpl->file['com_show_none'];
	$db->free();

	$input['orderstring']=orderstr($orderdef,"index.php?action=com.show&p=".$_REQUEST['p']);
	$tmpl->cache[]=$tmpl->parse($tmpl->file['com_show'],$input);
	}
}
else message("com_off");

?>