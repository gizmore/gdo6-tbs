<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['id'] || !$_POST['topic'] || !$_POST['text'] || ( $set['usekats'] && !$_POST['catid'] ) ) message("back");
	else {
		if ( !$set['usekats'] ) $_POST['catid']=1;
		for ( $i=0; $i<=3 ; ++$i ) if ( $_POST['link'.$i]['title'] && $_POST['link'.$i]['text'] && $_POST['link'.$i]['link'] ) $links[$i]=$_POST['link'.$i]['title']."|".$_POST['link'.$i]['text']."|".$_POST['link'.$i]['link']."|".$_POST['link'.$i]['target'];
		
		function checkvalues($key) {
			if ( $_POST[$key]['day']=="" ) return false;
			if ( $_POST[$key]['month']=="" ) return false;
			if ( $_POST[$key]['year']=="" ) return false;
			if ( $_POST[$key]['hours']=="" ) return false;
			if ( $_POST[$key]['mins']=="" ) return false;
			if ( $_POST[$key]['secs']=="" ) return false;
		return true;
		}
		
		if ( is_array($_POST['pubtime']) && checkvalues("pubtime") ) $thepubtime=mktime($_POST['pubtime']['hours'],$_POST['pubtime']['mins'],$_POST['pubtime']['secs'],$_POST['pubtime']['month'],$_POST['pubtime']['day'],$_POST['pubtime']['year']);
		else $thepubtime=0;
		
		if ( is_array($_POST['endtime']) && checkvalues("endtime") ) $theendtime=mktime($_POST['endtime']['hours'],$_POST['endtime']['mins'],$_POST['endtime']['secs'],$_POST['endtime']['month'],$_POST['endtime']['day'],$_POST['endtime']['year']);
		else $theendtime=0;
		
		if ( $theendtime<=$thepubtime ) $theendtime=0;
		
		if ( !$_POST['allowcoms'] ) $_POST['allowcoms']=0;
		
	$db->query("UPDATE ".PRE."_news SET catid='".$_POST['catid']."',topic='".addslashes($_POST['topic'])."',subtopic='".addslashes($_POST['subtopic'])."',text='".addslashes($_POST['text'])."',link1='".addslashes($links[1])."',link2='".addslashes($links[2])."',link3='".addslashes($links[3])."',pubtime='".$thepubtime."',endtime='".$theendtime."',pin='".$_POST['pin']."',allowcoms='".$_POST['allowcoms']."' WHERE ( id='".$_POST['id']."'".iif(has_spright("news.edit")!=1," AND userid='".$_USER['userid']."'").") LIMIT 1");
	message("news_edit_ok","index.php?action=news.show");
	logit("Artikel ID #".$_POST['id']." bearbeitet");
	}
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
	
	if ( has_right("news.pics") ) $tmpl->cache[]='<p>&raquo; <a href="javascript:bmanager();">Bildmanager</a><br><font>Mit diesem Tool lassen sich eigene Bilder hochladen und verwalten.</font></p>';
	
$tmpl->load("news_edit");

	if ( is_array($set['e_fonts']) ) foreach ( $set['e_fonts'] AS $val ) $input['font'].='<option value="'.$val.'">'.$val.'</option>';
	if ( is_array($set['e_sizes']) ) foreach ( $set['e_sizes'] AS $val ) $input['size'].='<option value="'.$val.'">'.$val.'</option>';
	if ( is_array($set['e_colors']) ) foreach ( $set['e_colors'] AS $name => $val ) $input['color'].='<option value="'.$val.'" style="background:'.$val.';">'.$name.'</option>';
	if ( !$input['font'] ) $input['font']="";
	if ( !$input['size'] ) $input['size']="";
	if ( !$input['color'] ) $input['color']="";

	if ( $_COOKIE['wncmode']==1 ) {
	$input['m0check']='';
	$input['m1check']='checked';
	}
	else {
	$input['m0check']='checked';
	$input['m1check']='';
	}
	
$res=$db->first("SELECT a.*,b.username FROM ".PRE."_news AS a LEFT JOIN ".PRE."_user AS b USING(userid) WHERE id='".$_REQUEST['id']."' LIMIT 1");

	if ( $set['usekats'] ) {
	$db->query("SELECT id,name FROM ".PRE."_newscat ORDER BY name ASC");
		while($res2=$db->fetch()) $input['newscat'].='<option value="'.$res2['id'].'"'.iif($res['catid']==$res2['id']," selected").'>'.replace($res2['name']).'</option>';
	$db->free();
		if ( $input['newscat'] ) $input['newscat']='<select name="catid">'.$input['newscat'].'</select>'; 
		else { message("news_nocat"); $stop=1; }
	}
	else $input['newscat']="deaktiviert<br><font>(Bei &Auml;nderung dieser Option werden die Newsmeldungen automatisch der zuerst erstellten Kategorie zugewie&szlig;en.)</font>";
	
	if ( !$stop ) {
		function dropdown($start,$to,$name,$value,$se=0) {
			if ( $value==-1 ) $out.='<option value="" selected></option>';
			if ( $se ) $out.='<option value=""></option>';
			for ( $i=$start; $i<=$to; $i++ ) $out.='<option value="'.$i.'"'.iif( $value!=-1 && $i==$value," selected").'>'.sprintf("%02.d",$i).'</option>';
		return '<select name="'.$name.'">'.$out.'</select>';
		}
	
	$input['id']=$_REQUEST['id'];
		if ( !$res['userid'] ) $input['username']="<i>Gast: ".replace($res['ext_user'])."</i>";
		else $input['username']=replace($res['username']);
	$input['userid']=$res['userid'];
	$input['date']=makedate($res['time']);
	$input['topic']=htmlspecialchars($res['topic']);
	$input['subtopic']=htmlspecialchars($res['subtopic']);
	$input['text']=htmlspecialchars($res['text']);
		if ( $set['usetcode'] ) $input['topictagstatus']="AN";
		else $input['topictagstatus']="AUS";
	$input['tagstatus']=tagstatus();
		
		if ( $res['pubtime'] ) {
		$pubdate=getdate($res['pubtime']);
		$ins['%pubtime%']=dropdown(1,31,"pubtime[day]",$pubdate['mday']).".".dropdown(1,12,"pubtime[month]",$pubdate['mon']).".".dropdown(2000,2010,"pubtime[year]",$pubdate['year'])." - ".dropdown(0,23,"pubtime[hours]",$pubdate['hours']).":".dropdown(0,59,"pubtime[mins]",$pubdate['minutes']).":".dropdown(0,59,"pubtime[secs]",$pubdate['seconds'])." Uhr";
			if ( $res['endtime'] ) {
			$enddate=getdate($res['endtime']);
			$ins['%endtime%']=dropdown(1,31,"endtime[day]",$enddate['mday'],1).".".dropdown(1,12,"endtime[month]",$enddate['mon'],1).".".dropdown(2000,2010,"endtime[year]",$enddate['year'],1)." - ".dropdown(0,23,"endtime[hours]",$enddate['hours'],1).":".dropdown(0,59,"endtime[mins]",$enddate['minutes'],1).":".dropdown(0,59,"endtime[secs]",$enddate['seconds'],1)." Uhr";
			}
			else $ins['%endtime%']=dropdown(1,31,"endtime[day]",-1).".".dropdown(1,12,"endtime[month]",-1).".".dropdown(2000,2010,"endtime[year]",-1)." - ".dropdown(0,23,"endtime[hours]",-1).":".dropdown(0,59,"endtime[mins]",-1).":".dropdown(0,59,"endtime[secs]",-1)." Uhr";
		$input['publish']=strtr($tmpl->get("news_edit_pub"),$ins);
		unset($ins);
		}
		else $input['publish']="";
		
		if ( $res['pin'] ) $input['pin']='<input type="checkbox" name="pin" value="1" checked> Artikel wird immer vor allen anderen gezeigt';
		else $input['pin']='<input type="checkbox" name="pin" value="1"> Artikel wird immer vor allen anderen gezeigt';
		
		for ( $i=0; $i<=3 ; ++$i ) {
		$temp=explode("|",$res['link'.$i]);
			if ( $temp[0] ) $input['link'.$i.'_title']=htmlspecialchars($temp[0]);
			else $input['link'.$i.'_title']="Link";
		$input['link'.$i.'_text']=htmlspecialchars($temp[1]);
		$input['link'.$i.'_link']=htmlspecialchars($temp[2]);
			if ( $temp[3]=="blank" ) $input['link'.$i.'_checked']=' checked';
			elseif ( isset($temp[3]) && !$temp[3] ) $input['link'.$i.'_checked']='';
			else $input['link'.$i.'_checked']=' checked';
		unset($temp);
		}
	}
	
	if ( $set['usecoms'] ) {
		if ( $res['allowcoms'] ) $input['allowcoms']='<input type="checkbox" name="allowcoms" value="1" checked> Kommentare erlauben';
		else $input['allowcoms']='<input type="checkbox" name="allowcoms" value="1"> Kommentare erlauben';
	}
	else $input['allowcoms']='Kommentarfunktion deaktiviert';

$tmpl->cache[]=$tmpl->parse($tmpl->file['news_edit'],$input);
}

?>