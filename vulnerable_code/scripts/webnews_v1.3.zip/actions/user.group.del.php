<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
list($count,$trash)=$db->first("SELECT count(userid) FROM ".PRE."_user WHERE groupid='".$_POST['id']."' LIMIT 1");
	if ( !$count ) {
	$db->query("DELETE FROM ".PRE."_group WHERE groupid='".$_POST['id']."' LIMIT 1");
	message("group_del_ok","index.php?action=user.group.show");
	logit("Benutzergruppe ID #".$_POST['id']." gel�scht");
	}
	else die("this group is still in use!");
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");
$ins['id']=$_REQUEST['id'];
message("group_del",0,$ins);
}

?>