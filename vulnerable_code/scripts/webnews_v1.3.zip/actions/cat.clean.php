<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



if ( $_POST['do'] ) {
	if ( !$_POST['id'] || !$_POST['tocat'] ) message("back");
	else {
	$db->query("UPDATE ".PRE."_news SET catid='".$_POST['tocat']."' WHERE catid='".$_POST['id']."'");
		if ( $_POST['delcat'] ) {
		$db->query("DELETE FROM ".PRE."_newscat WHERE id='".$_POST['id']."' LIMIT 1");
		message("cat_clean_del_ok","index.php?action=cat.show");
		logit("Kategorie ID #".$_POST['id']." ger�umt");
		logit("Kategorie ID #".$_POST['id']." gel�scht");
		}
		else {
		message("cat_clean_ok","index.php?action=cat.show");
		logit("Kategorie ID #".$_POST['id']." ger�umt");
		}
	}
}
else {
	if ( !$_REQUEST['id'] ) die("no id specified!");

$db->query("SELECT id,name FROM ".PRE."_newscat ORDER BY name ASC");
	while ( $res=$db->fetch() ) if ( $_REQUEST['id']!=$res['id'] ) $input['cats'].='<option value="'.$res['id'].'">'.$res['name'].'</option>';
$db->free();
$input['id']=$_REQUEST['id'];
message("cat_clean",0,$input);
}

?>