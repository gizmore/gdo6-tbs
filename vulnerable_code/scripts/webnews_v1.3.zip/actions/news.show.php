<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



$tmpl->load("news_show,news_show_e0,news_show_e1,news_show_none,news_show_space");
	if ( has_right("news.add") ) $tmpl->cache[]='<p>&raquo; <a href="index.php?action=news.add">News schreiben</a><br><font>Schreiben Sie einen neuen Newsartikel.</font></p>';

$orderdef['thema']['col']="topic";
$orderdef['thema']['sort']="ASC";
$orderdef['thema']['name']="Thema";
$orderdef['user']['col']="username";
$orderdef['user']['sort']="ASC";
$orderdef['user']['name']="Autor";
$orderdef['date']['col']="time";
$orderdef['date']['sort']="DESC";
$orderdef['date']['name']="Erstelldatum";
$orderdef['pubdate']['col']="pubtime";
$orderdef['pubdate']['sort']="DESC";
$orderdef['pubdate']['name']="Ver�ffentlichung";
$orderdef['default']="date";

	if ( !$_REQUEST['p'] ) $_REQUEST['p']=0;
	if ( !$_REQUEST['cat'] ) $_REQUEST['cat']="all";
	if ( !$_REQUEST['self'] ) $_REQUEST['self']=0;

	if ( !has_spright("news.show") ) {
	$special="a.userid='".$_USER['userid']."'";
	$input['special']="&nbsp;";
	}
	else {
		if ( $_REQUEST['self']==1 ) { 
		$special="a.userid='".$_USER['userid']."'";
		$input['special']='&raquo; <a href="index.php?action=news.show&cat='.$_REQUEST['cat'].'">Alle zeigen</a>';
		}
		else $input['special']='&raquo; <a href="index.php?action=news.show&self=1&cat='.$_REQUEST['cat'].'">Nur eigene zeigen</a>';
	}
	
	if ( $set['usekats'] ) {
	$db->query("SELECT id,name FROM ".PRE."_newscat ORDER BY name ASC");
		while($res=$db->fetch()) {
		$newscat[$res['id']]=$res['name'];
		$catsel.='<option value="'.$res['id'].'"'.iif($res['id']==$_REQUEST['cat']," selected").'>'.$res['name'].'</option>'; //Cat Select
		}
	$db->free();
	
	//String: Cat Select
	$input['choosecat']='Nur diese Kategorie: <select name="cat" onchange="if(this.options[this.selectedIndex].value.length!=0) window.location=(\'index.php?action=news.show&cat=\'+this.options[this.selectedIndex].value);"><option value="all">Alle</option>'.$catsel.'</select> <input type="submit" value="Los!" class="button">';
	
		//Cat Select: MySQL Query
		if ( $_REQUEST['cat'] && $_REQUEST['cat']!="all" ) $special.=iif($special," AND ")."catid='".$_REQUEST['cat']."'";
	}
	else $input['choosecat']="";

	if ( $special ) $special="WHERE ( ".$special." )";
	
//Pages
$res=$db->first("SELECT count(id) FROM ".PRE."_news AS a ".$special);
$count=$res[0];
$input['pages']=pages("index.php?action=news.show&self=".$_REQUEST['self']."&cat=".$_REQUEST['cat']."&order=".$_REQUEST['order']."&type=".$_REQUEST['type'],$count,$_REQUEST['p']);

$query=$db->query("SELECT id,catid,topic,a.userid,username,ext_user,pubtime,endtime,counter,pin FROM ".PRE."_news AS a LEFT JOIN ".PRE."_user USING(userid) ".$special." ORDER BY pin DESC, ".getorder($orderdef)." LIMIT ".$_REQUEST['p'].",".$set['epp']);
	if ( $db->checkres() ) {
		while($res=$db->fetch()) {
		++$i;
		
			if ( $pin && !$res['pin'] ) $input['content'].=$tmpl->file['news_show_space'];
		
			if ( $res['endtime'] && $res['endtime']<time() ) $ins['pubcolor']="autounpub";
			elseif ( $res['pubtime']>time() ) $ins['pubcolor']="autopub";
			elseif ( $res['pubtime'] && $res['pubtime']<=time() ) $ins['pubcolor']="published";
			else $ins['pubcolor']="notpublished";
			
			if ( strlen($res['topic'])<=40 ) $ins['topic']=replace($res['topic']);
			else $ins['topic']=replace(substr($res['topic'],0,37)."...");
			
			if ( !$res['userid'] ) $ins['username']="<i>Gast: ".replace($res['ext_user'])."</i>";
			else $ins['username']=replace($res['username']);
			
			if ( $set['usekats'] ) $ins['catname']=$newscat[$res['catid']];
			else $ins['catname']="-";
			
			if ( $res['pubtime'] ) $ins['date']=makedate($res['pubtime'],1);
			else $ins['date']="-";
			
			if ( ($_USER['userid']==$res['userid'] && has_right("news.edit")) || ($_USER['userid']!=$res['userid'] && has_spright("news.edit")) ) $ins['options'].='<a href="index.php?action=news.edit&id='.$res['id'].'"><img src="design/edit.gif" alt="Bearbeiten" title="Bearbeiten" border="0"></a> ';
			if ( ($_USER['userid']==$res['userid'] && has_right("news.del")) || ($_USER['userid']!=$res['userid'] && has_spright("news.del")) ) $ins['options'].='<a href="index.php?action=news.del&id='.$res['id'].'"><img src="design/del.gif" alt="L&ouml;schen" title="L&ouml;schen" border="0"></a> ';
			if ( !$res['pubtime'] && ( ( $_USER['userid']==$res['userid'] && has_right("news.pub") ) || ( $_USER['userid']!=$res['userid'] && has_spright("news.pub") ) ) ) $ins['options'].='<a href="index.php?action=news.pub&id='.$res['id'].'"><img src="design/pub.gif" alt="Ver&ouml;ffentlichen" title="Ver&ouml;ffentlichen" border="0"></a> ';
			if ( $res['pubtime'] && ( ( $_USER['userid']==$res['userid'] && has_right("news.unpub") ) || ( $_USER['userid']!=$res['userid'] && has_spright("news.unpub") ) ) ) $ins['options'].='<a href="index.php?action=news.unpub&id='.$res['id'].'"><img src="design/unpub.gif" alt="Wiederrufen" title="Wiederrufen" border="0"></a> ';
		$ins['options'].='<img src="design/hits.gif" alt="Hits: '.$res['counter'].'" title="Hits: '.$res['counter'].'" border="0">';
			
			if ( !$res['pubtime'] ) $ins['preview']=' <a href="'.$set['newspage']."?id=".$res['id']."&preview=yes".iif($set['newsparams'],"&".$set['newsparams']).'" target="_blank"><img src="design/preview.gif" alt="Vorschau" title="Vorschau" border="0" align="absmiddle"></a>';
			else $ins['preview']=' <a href="'.$set['newspage']."?id=".$res['id'].iif($set['newsparams'],"&".$set['newsparams']).'" target="_blank"><img src="design/jump.gif" alt="Artikel zeigen" title="Artikel zeigen" border="0" align="absmiddle"></a>';
		
		$input['content'].=$tmpl->parse($tmpl->file['news_show_e'.$i%2],$ins); 
		unset($ins);
		$pin=$res['pin'];
		}
	}
	else $input['content']=$tmpl->file['news_show_none'];
$db->free();

$input['orderstring']=orderstr($orderdef,"index.php?action=news.show&p=".$_REQUEST['p']."&self=".$_REQUEST['self']);
$tmpl->cache[]=$tmpl->parse($tmpl->file['news_show'],$input);

?>