<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################

//Unset Basic Vars
unset($_RIGHTS,$_USER);


/*** MODULES LOAD ***/
require($DIR."/modules/config.inc.php");
require($DIR."/modules/functions.php");
require($DIR."/modules/database.php");
require($DIR."/modules/template.php");


/*** STARTUP ***/
if (get_magic_quotes_gpc()) {
	if(is_array($_REQUEST)) $_REQUEST=strpsl($_REQUEST);
	if(is_array($_POST)) $_POST=strpsl($_POST);
	if(is_array($_GET)) $_GET=strpsl($_GET);
	if(is_array($_COOKIE)) $_COOKIE=strpsl($_COOKIE);
}
@set_magic_quotes_runtime(0);
$_RIGHTS['login']=1;
$_RIGHTS['logout']=1;
	if ( !$_COOKIE['wn_userid'] ) $_REQUEST['action']="login";
	elseif ( empty($_REQUEST['action']) ) $_REQUEST['action']="index";

$tmpl = new template;
$db = new database;
$db->connect($set);
define("PRE",$set['table']);
$db->query("UPDATE ".PRE."_user SET lastonline=lastonline_temp WHERE (lastonline_temp+600)<".time()); //Update Lastonline

//Actions
$query=$db->query("SELECT * FROM ".PRE."_actions ORDER BY navid ASC, ord ASC"); 
	while($res=$db->fetch()) foreach($res AS $key => $dat) if ( $key!="action" ) $_ACTIONS[$res['action']][$key]=$dat;
	
	/*** USERINFO ***/
	if ( $_COOKIE['wn_userid'] ) {
	$_USER=$db->first("SELECT * FROM ".PRE."_user LEFT JOIN ".PRE."_group USING (groupid) WHERE ( userid='".$_COOKIE['wn_userid']."' AND password='".$_COOKIE['wn_userpw']."' ) LIMIT 1");
		if ( !$_USER['userid'] && $_REQUEST['action']!="logout" ) { header("location:index.php?action=logout&auto=1"); exit; }
		elseif ( !$_USER['active'] && $_REQUEST['action']!="logout" ) { header("location:index.php?action=logout&auto=2"); exit; }
	$rights=explode("|",$_USER['grouprights']);
		foreach ( $rights AS $dat ) $_RIGHTS[$dat]=1;
	$_RIGHTS['index']=1;
	
	$sprights=explode("|",$_USER['groupsprights']);
		foreach ( $sprights AS $dat ) $_SPRIGHTS[$dat]=1;
	
	$db->query("UPDATE ".PRE."_user SET lastonline_temp='".time()."' WHERE userid='".$_USER['userid']."'"); //Useronline Temp
	$_USER['lastonline_temp']=time();
	}

?>