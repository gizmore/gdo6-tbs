<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



class template {
var $file    = array();
var $cache   = array();
var $message = "";
var $output  = "";
var $dname   = array();

	/*** Templates laden ***/
	function load($string,$dirpush="") {
	global $set;
	$files=explode(",",$string);
		foreach ( $files AS $file ) {
		$filecache=@file($dirpush."design/templates/".$file.".html",1);
			if ( is_array($filecache) ) {
			$this->file[$file]=implode("",$filecache);
			unset($filecache);
			}
			else echo "Template ".$file.".html wurde nicht gefunden!<br>";
		}
	}
	
	/*** Templates holen ***/
	function get($file,$dirpush="") {
	global $set;
	$filecache=@file($dirpush."design/templates/".$file.".html",1);
		if ( is_array($filecache) ) {
		$this->file[$file]=implode("",$filecache);
		return $this->file[$file];
		}
		else echo "Template ".$file.".html wurde nicht gefunden!<br>";
	}
	
	/*** Parsen ***/
	function parse($file,$input) {
		if ( is_array($input) ) foreach( $input AS $search => $data ) $file=str_replace("%".$search."%",$data,$file);
	return $file;
	}
	
	/*** Print ***/
	function out($style_vars,$block=0) {
		if ( !$block ) {
			if ( !empty($this->message) ) {
			$this->load("msg_header,msg_footer");
			$this->dname[0]="msg_header"; $this->dname[1]="msg_footer";
			unset($this->cache); $this->cache[]=$this->message;
			}
			else {
			ksort($this->cache);
			$this->load("header,footer");
			$this->dname[0]="header"; $this->dname[1]="footer";
			}
		}
	
	//Output zusammensetzten
	$this->output=$this->file[$this->dname[0]];
		foreach ( $this->cache AS $data ) $this->output.=$data;	
	$this->output.=$this->file[$this->dname[1]];
	
	//Standardvariablen einparsen + echo
	echo $this->parse($this->output,$style_vars);
	}
}

?>