<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



function replace ($text,$blocker=-1) {
$text=htmlentities($text);
	if ( $blocker==-1 ) $text=nl2br($text);
return $text;
}

function has_right($action) {
global $_RIGHTS;
	if ( $_RIGHTS[$action]==1 ) return true;
	if ( $_RIGHTS['global']==1 ) return true;
return false;
}

function has_spright($action) {
global $_SPRIGHTS,$_RIGHTS;
	if ( $_SPRIGHTS[$action]==1 ) return true;
	if ( $_RIGHTS['global']==1 ) return true;
return false;
}

function strpsl(&$array) {
reset($array);
	foreach($array AS $key => $val) {
		if(is_string($val)) $array[$key]=trim(stripslashes($val));
		elseif(is_array($val)) $array[$key]=strpsl($val);
	}
return $array;
}

function message($msgid,$link=0,$input=-1) {
global $tmpl;
$tmpl->load("msg_".$msgid);
	if ( $link ) $tmpl->message=$tmpl->file["msg_".$msgid].'<font><br><br>&raquo; <a href="'.$link.'">Klicken Sie hier, wenn Ihr Browser keine automatische Weiterleitung unterst&uuml;tzt oder Sie nicht l&auml;nger warten wollen.</a> &laquo;</font><meta http-equiv="refresh" content="4; URL='.$link.'">';
	else $tmpl->message=$tmpl->file["msg_".$msgid];
	if ( is_array($input) ) $tmpl->message=$tmpl->parse($tmpl->message,$input);
}

function makedate($time,$br=0) {
static $today;
static $yesterday;
static $tomorrow;

	if ( !$today ) $today=date("j/n/Y");
	if ( !$yesterday ) $yesterday=date("j/n/Y",time()-24*3600);
	if ( !$tomorrow ) $tomorrow=date("j/n/Y",time()+24*3600);

$date=getdate($time);
$thisday=$date['mday']."/".$date['mon']."/".$date['year'];

  if ( $today==$thisday ) return "<b>Heute</b>, ".iif($br,"<br>").sprintf ("%02.d", $date['hours']).":".sprintf ("%02.d", $date['minutes'])." Uhr";
	elseif ( $yesterday==$this ) return "<b>Gestern</b>, ".iif($br,"<br>").sprintf ("%02.d", $date['hours']).":".sprintf ("%02.d", $date['minutes'])." Uhr";
	elseif ( $tomorrow==$this ) return "<b>Morgen</b>, ".iif($br,"<br>").sprintf ("%02.d", $date['hours']).":".sprintf ("%02.d", $date['minutes'])." Uhr";
  else return sprintf ("%02.d", $date['mday']).".".sprintf ("%02.d", $date['mon']).".".sprintf ("%02.d", $date['year']).", ".iif($br,"<br>").sprintf ("%02.d", $date['hours']).":".sprintf ("%02.d", $date['minutes'])." Uhr";
}

function pages($link,$count,$on=0,$four=0) {
global $set;
	if ( $four ) $epp=ceil($set['epp']/4)*4;
	else $epp=$set['epp'];
	
	if ( $count ) {
	$pages=ceil($count/$epp);
	$out="Seiten($pages):";
		for($i=1;$i<=$pages;$i++) {
			if ( (($i-1)*$epp)==$on ) $out.=' ['.$i.']';
			else $out.=' <a href="'.$link.'&p='.(($i-1)*$epp).'">'.$i.'</a>';
		}
	}
	else $out="Seiten(0):";
return $out;
}

function getorder($info) {
global $_REQUEST;
	if ( !$info['default'] ) echo"WARNING! No default sortcol set!";
	
	$col=$info[$_REQUEST['order']]['col'];
		if ( !$col ) { 
		$col=$info[$info['default']]['col'];
		$_REQUEST['order']=$info['default'];
		}
		
		if ( $_REQUEST['type']!="ASC" && $_REQUEST['type']!="DESC" ) $_REQUEST['type']=$info[$_REQUEST['order']]['sort'];
return $col." ".$_REQUEST['type'];
}

function orderstr($info,$link) {
global $_REQUEST;
	foreach ( $info AS $key => $sort ) {
		if ( $key!="default" ) {
			if ( $_REQUEST['order']==$key ) {
				if ( $_REQUEST['type']=="ASC" ) $out[]='<a href="'.$link.'&order='.$key.'&type=DESC">'.replace($sort['name']).' <img src="design/asc.gif" alt="ASC" border="0" align="absmiddle"></a>';
				else $out[]='<a href="'.$link.'&order='.$key.'&type=ASC">'.replace($sort['name']).' <img src="design/desc.gif" alt="DESC" border="0" align="absmiddle"></a>';
			}
			else $out[]='<a href="'.$link.'&order='.$key.'&type='.$sort['sort'].'">'.replace($sort['name']).'</a>';
		}
	}
	
	if ( is_array($out) ) $ex=implode(" | ",$out);
return $ex;
}

function iif($arg,$string,$elsestring="") {
	if ( $arg ) return $string;
	else return $elsestring;
}

function tagstatus() {
global $set;
$out='<u>Tag-Status:</u><br>HTML ist AUS<br><a href="javascript:popup(\'pop.smilies\');">Smilies</a> sind '.iif($set['usesmilies'],"AN","AUS").'<br><a href="javascript:popup(\'pop.codes\');">WN-Codes</a> sind '.iif($set['usecode'],"AN","AUS").'<br>[HTML]-Code ist '.iif($set['usehtml'],"AN","AUS").'<br>[IMG]-Code ist '.iif($set['useimg'],"AN","AUS");
return $out;
}

function tagstatus_com() {
global $set;
$out='<u>Tag-Status:</u><br>HTML ist AUS<br><a href="javascript:popup(\'pop.smilies\');">Smilies</a> sind '.iif($set['allowsmilies'],"AN","AUS").'<br><a href="javascript:popup(\'pop.codes\');">Standard Codes</a> sind '.iif($set['allowcode'],"AN","AUS").'<br>[IMG]-Code ist '.iif($set['allowimg'],"AN","AUS");
return $out;
}

function logit($text,$userid=0) {
global $db,$_USER;
	if ( $userid && !$_USER['userid'] ) $_USER['userid']=$userid;
$date=getdate(time());
$db->query("INSERT INTO ".PRE."_log VALUES ('".sprintf("%02.d",$date['mday'])."-".sprintf("%02.d",$date['mon'])."-".$date['year']." ".sprintf("%02.d",$date['hours']).":".sprintf("%02.d",$date['minutes']).":".sprintf("%02.d",$date['seconds'])."','".$_USER['userid']."','".$text."')");
}
?>