//###########################################################
//##                                                       ##
//##            WEB//NEWS Newsmanagement Script            ##
//##                (c) Copyright 2002-2004                ##
//##                  by Christian Scheb                   ##
//##                                                       ##
//###########################################################


//Define Tag-Cache
var thetags=new Array();


//**************************** GENERAL FUNCTIONS ****************************

function countarray() {
var count=0;
	for (i=0; i<thetags.length; i++ ) {
		if ( thetags[i]==null || thetags[i]=="" && thetags[i]=="undefined" ) {
		return i;
		}
	}
return thetags.length;
}

//Tag anf�gen
function addtag(thetag) {
thetags[countarray()]=thetag;
}

//Ist ein Tag bereits ge�ffnet?
function tagexists(tag) {
var found=false;
	for (i=0; i<thetags.length; i++ ) {
		if ( thetags[i]==tag ) {
		found=true;
		}
	}
return found;
}

//Tag schlie�en
function closetag() {
	if ( countarray()!=0 ) {
	var count=countarray();
	document.form.text.value+="[/"+thetags[(count-1)]+"]";
	delete thetags[(count-1)];
	document.form.text.focus();
	}
	else sendmsg('Keine offenen Tags vorhanden');
}

//Alle Tags schlie�en
function closeall() {
var count=countarray();
	if ( count!=0 ) {
		for ( i=1; i<=count; i++ ) {
		document.form.text.value+="[/"+thetags[(count-i)]+"]";
		delete thetags[(count-i)];
		}
	document.form.text.focus();
	}
	else sendmsg('Keine offenen Tags vorhanden');
}

function normalmode() {
//Checks normal Mode
	if ( document.form.mode[0].checked ) return true;
	else return false;
}

//Nachricht ausgeben
function sendmsg(text) {
document.form.msgbox.value='� '+text+' �';
}

//Modus speichern
function savemode(mode) {
document.cookie="wncmode="+mode+"; path=/; expires=Thu, 1 Jan 2015 00:00:00 GMT;";
	if ( mode==0 ) sendmsg('Normaler Modus');
	else sendmsg('Erweiterter Modus');
}


//**************************** TAG-FUNCTIONS ****************************

//Format Font
function wnformat(thetype,thevalue) {
	if ( normalmode()==true ) {
		if ( thevalue!=0 && thevalue!="" ) {
		thetext=prompt("Gib bitte den Text ein, der mit "+thetype+" formatiert werden soll");
			if ( thetext!=null && thetext!="" ) {
			document.form.text.value+="["+thetype+"="+thevalue+"]"+thetext+"[/"+thetype+"] ";
			}
		}
		
	document.form.usefont.selectedIndex = 0;
	document.form.usesize.selectedIndex = 0;
	document.form.usecolor.selectedIndex = 0;
	document.form.text.focus();
	}
	else {
		if ( tagexists(thetype)==false ) {
		document.form.text.value+="["+thetype+"="+thevalue+"]";
		addtag(thetype);
		
		document.form.usefont.selectedIndex = 0;
		document.form.usesize.selectedIndex = 0;
		document.form.usecolor.selectedIndex = 0;
		document.form.text.focus();
		}
	}
}


//Simple WN-Codes
function wncode(thecode,prptext) {
	if ( normalmode()==true ) {
	gettext=prompt("Bitte gib den Text ein, der formatiert werden soll:\n["+thecode+"]...[/"+thecode+"]",prptext);
		if ( gettext!=null && gettext!="" ) {
		document.form.text.value+="["+thecode+"]"+gettext+"[/"+thecode+"] ";
		}
	document.form.text.focus();
	}
	else {
		if ( tagexists(thecode)==false ) {
		document.form.text.value+="["+thecode+"]";
		addtag(thecode);
		document.form.text.focus();
		}
		else sendmsg('Der ['+thecode+']-Tag ist bereits ge�ffnet');
	}
}


//Links
function wnlink(thetype) {
thetext=prompt("Gib den Text an der verlinkt werden soll","");
	if ( thetype=="MAIL" ) {
	prp_msg="Gib bitte die vollst�ndige eMail-Adresse an";
	prp_text="";
	}
	else {
	prp_msg="Gib bitte die vollst�ndige URL an";
	prp_text="http://";
	}
	
theurl = prompt(prp_msg,prp_text);
	if ( theurl!=null && theurl!="" ) {
		if ( thetext!=null && thetext!="" ) {
		document.form.text.value+="["+thetype+"="+theurl+"]"+thetext+"[/"+thetype+"] ";
		}
		else {
		document.form.text.value+="["+thetype+"]"+theurl+"[/"+thetype+"] ";
		}
	}
document.form.text.focus();
}


//Picture
function wnimg() {
	if ( normalmode()==true ) {
	gettext=prompt("Bitte gib entweder die URL oder den relativen Pfad der Zieldatei (Bild) an","");
	getalign=prompt("Bitte gib die Ausrichtung des Bilds an (left, center, right) oder klicke auf \"Abbrechen\" um keine Ausrichtung anzugeben","");
		if ( gettext!=null && gettext!="" ) {
			if ( getalign!=null && getalign!="" ) {
			document.form.text.value+="[IMG="+getalign+"]"+gettext+"[/IMG] ";
			}
			else {
			document.form.text.value+="[IMG]"+gettext+"[/IMG] ";
			}
		}
	document.form.text.focus();
	}
	else {
		if ( tagexists('IMG')==false ) {
		document.form.text.value+="[IMG]";
		addtag('IMG');
		document.form.text.focus();
		}
		else sendmsg('Der [IMG]-Tag ist bereits ge�ffnet');
	}
}


//Popup-Picture
function wnpopup() {
thethumb=prompt("Bitte gib entweder die URL oder den relativen Pfad der Zieldatei (Thumbnail) an","");
thepic = prompt("Bitte gib entweder die URL oder den relativen Pfad der Zieldatei (Popup-Bild) an","");
	if ( thethumb!=null && thethumb!="" ) {
		if ( thepic!=null && thepic!="" ) {
		document.form.text.value+="[POPUP="+thepic+"]"+thethumb+"[/POPUP] ";
		}
	}
document.form.text.focus();
}


//Make List
function wnlist(listtype) {
	if ( listtype=="a" || listtype=="1" ) {
	liststart="[list="+listtype+"]\n";
	listend="[/list] ";
	}
	else {
	liststart="[list]\n";
	listend="[/list] ";
	}

list="";
theentry = "bla";
	
	while ( theentry != "" && theentry != null ) {
	theentry = prompt("Gib ein Element der Liste an\nKlicke auf \"Abbrechen\" um die Liste fertigzustellen!", "");
		if ( theentry!="" && theentry!=null ) {
		list+="[*]"+theentry+"\n";
		}
	}

	if ( list!="" ) {
	document.form.text.value+=liststart+list+listend;
	document.form.text.focus();
	}

//Clear Vars
liststart="";
listend="";
list="";
}


//Open HTML-Area
function openhtml() {
	if ( normalmode()==true ) {
	document.form.text.value+="\n[HTML]\n<!-- Ihr HTML-Code -->\n[/HTML]";
	document.form.text.focus();
	}
	else {
		if ( tagexists('HTML')==false ) {
		document.form.text.value+="\n[HTML]\n";
		addtag('HTML');
		document.form.text.focus();
		}
		else sendmsg('Der [HTML]-Tag ist bereits ge�ffnet');
	}
}


//Mehr
function wnmehr() {
document.form.text.value+="[MEHR]";
document.form.text.focus();
}