//###########################################################
//##                                                       ##
//##            WEB//NEWS Newsmanagement Script            ##
//##                (c) Copyright 2002-2004                ##
//##                  by Christian Scheb                   ##
//##                                                       ##
//###########################################################


//**************************** TAG-FUNCTIONS ****************************

//Picture
function wnimg(gettext) {
getalign=prompt("Bitte gib die Ausrichtung des Bilds an (left, center, right) oder klicke auf \"Abbrechen\" um keine Ausrichtung anzugeben","");
	if ( gettext!=null && gettext!="" ) {
		if ( getalign!=null && getalign!="" ) {
		opener.document.form.text.value+="[IMG="+getalign+"]"+gettext+"[/IMG] ";
		}
		else {
		opener.document.form.text.value+="[IMG]"+gettext+"[/IMG] ";
		}
	}
opener.document.form.text.focus();
}


//Popup-Picture
function wnpopup(thepic,thethumb) {
	if ( thethumb!=null && thethumb!="" ) {
		if ( thepic!=null && thepic!="" ) {
		opener.document.form.text.value+="[POPUP="+thepic+"]"+thethumb+"[/POPUP] ";
		}
	}
opener.document.form.text.focus();
}