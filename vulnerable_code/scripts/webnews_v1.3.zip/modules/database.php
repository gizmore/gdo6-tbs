<?php 
###########################################################
##                                                       ##
##            WEB//NEWS Newsmanagement Script            ##
##                (c) Copyright 2002-2004                ##
##                  by Christian Scheb                   ##
##                                                       ##
###########################################################



class database {

//Datenbankkonfiguration
var $conn     = 0;
var $result   = 0;
var $fetched  = array();
	
	//Verbindung herstellen
	function connect($set) {
	define("CONN",@mysql_connect($set['server'], $set['user'], $set['password']));
		if ( !CONN ) die("Konnte keine Verbindung zur Datenbank herstellen!");
		if ( !@mysql_select_db($set['database'], CONN) ) die("Konnte die Datenbank ".$set['database']." nicht ausw&auml;hlen!");
	}
	
	//Datenbankanfrage
	function query($query) {
	$this->result=@mysql_query($query,CONN);
		if ( !$this->result ) $this->error("MySQL-Error: ".mysql_error()."<br>Anfrage: ".$query);
		return $this->result;
	}
	
	//Datenbankanfrage (nur die erste Reihe)
	function first($query,$type=MYSQL_BOTH) {
	$this->result=@mysql_query($query,CONN);
		if ( !$this->result ) {
		$this->error("MySQL-Error: ".mysql_error()."<br>Anfrage: ".$query);
		return array();
		}
		
	$this->fetched=@mysql_fetch_array($this->result,$type);
	$this->free();
	return $this->fetched;
	}
	
	//Array holen
	function fetch($result=-1,$type=MYSQL_BOTH) {
		if ( $result!=-1 ) $this->result=$result;
	$this->fetched=@mysql_fetch_array($this->result,$type);
	return $this->fetched;
	}
	
	//Reihen einer Anfrage z�hlen
	function numrows($result=-1) {
		if ( $result!=-1 ) $this->result=$result;
	return @mysql_num_rows($this->result);
	}
	
	//Letzte "auto-increase"-ID
	function insert_id() {
	return mysql_insert_id();
	}
	
	//Anfrage "befreien"
	function free($result=-1) {
		if ( $result!=-1 ) $this->result=$result;
	@mysql_free_result($this->result);
	}
	
	//Gibt 1 zur�ck wenn das Ergebnis mindestens eine Reihe enth�lt
	function checkres($result=-1) {
		if ( $result!=-1 ) $this->result=$result;
	if ( @mysql_num_rows($this->result) ) return 1;
	else return 0;
	}
	
	//Verbindung schlie�en
	function close() {
	mysql_close(CONN);
	}
	
	//MySQL-Error schreiben
	function error($text) {
	echo'<p><b>Schwerer Ausnahmefehler!</b><br>'.$text.'</p>';
	}
}
?>