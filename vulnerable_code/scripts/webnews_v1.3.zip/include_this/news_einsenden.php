<?php 

$WN_BASEDIR=dirname(__file__)."/..";
require($WN_BASEDIR."/parse/parser.php");

//Execute Script
$WN->wnprint("sendnews");

//End Script
$WN->endscript();

?>