<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>WEB//NEWS - Installation</title>
<link href="design/style.css" type="text/css" rel="stylesheet">
</head>
<body>
<?php 

include("modules/config.inc.php");

if ( $_POST['do']=="Installation starten" ) {

function strpsl(&$array) {
reset($array);
	foreach($array AS $key => $val) {
	if(is_string($val)) $array[$key]=stripslashes($val);
	elseif(is_array($val)) $array[$key]=strpsl($val);
	}
return $array;
}

if (get_magic_quotes_gpc()) if(is_array($_POST)) $_POST=strpsl($_POST);
@set_magic_quotes_runtime(0);

//Create Tables
$mysql[]="CREATE TABLE ".$set['table']."_actions (action tinytext NOT NULL,caption tinytext NOT NULL,navi tinytext NOT NULL,cat tinytext NOT NULL,catname tinytext NOT NULL,visible int(1) NOT NULL default '0',extra int(1) NOT NULL default '0',extra_descr tinytext NOT NULL,navid int(1) NOT NULL default '1',ord int(1) NOT NULL default '0') TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_block (id int(11) NOT NULL auto_increment,type tinytext NOT NULL,string tinytext NOT NULL,endtime int(11) NOT NULL default '0',PRIMARY KEY  (id)) TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_blockip (ip tinytext NOT NULL,endtime int(11) NOT NULL default '0') TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_comment (id int(11) NOT NULL auto_increment,newsid int(11) NOT NULL default '0',name tinytext NOT NULL,feld1 tinytext NOT NULL,feld2 tinytext NOT NULL,feld3 tinytext NOT NULL,feld4 tinytext NOT NULL,feld5 tinytext NOT NULL,text text NOT NULL,time int(11) NOT NULL default '0',ip tinytext NOT NULL,PRIMARY KEY  (id)) TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_group (groupid int(11) NOT NULL auto_increment,groupname tinytext NOT NULL,grouprights text NOT NULL,groupsprights text NOT NULL,PRIMARY KEY  (groupid)) TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_log (time tinytext NOT NULL,userid tinytext NOT NULL,action tinytext NOT NULL) TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_news (id int(11) NOT NULL auto_increment,catid int(11) NOT NULL default '1',userid int(11) NOT NULL default '0',ext_user tinytext NOT NULL,ext_mail tinytext NOT NULL,topic tinytext NOT NULL,subtopic tinytext NOT NULL,text mediumtext NOT NULL,link1 text NOT NULL,link2 text NOT NULL,link3 text NOT NULL,time int(11) NOT NULL default '0',pubtime int(11) NOT NULL default '0',endtime int(11) NOT NULL default '0',pin int(1) NOT NULL default '0',allowcoms int(1) NOT NULL default '1',counter int(11) NOT NULL default '0',PRIMARY KEY  (id)) TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_newscat (id int(11) NOT NULL auto_increment,name tinytext NOT NULL,icon tinytext NOT NULL,KEY id (id)) TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_source (id int(11) NOT NULL auto_increment,name tinytext NOT NULL,url tinytext NOT NULL,text tinytext NOT NULL,PRIMARY KEY  (id)) TYPE=MyISAM";
$mysql[]="CREATE TABLE ".$set['table']."_user (userid int(11) NOT NULL auto_increment,username tinytext NOT NULL,password tinytext NOT NULL,email tinytext NOT NULL,groupid int(3) NOT NULL default '0',active int(1) NOT NULL default '1',lastonline int(11) NOT NULL default '0',lastonline_temp int(11) NOT NULL default '0',PRIMARY KEY  (userid)) TYPE=MyISAM";

//Insert Actions
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('index', 'Hauptseite', '', 'none', '', 0, 0, '', 1, 0)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('login', 'Login', '', 'none', '', 0, 0, '', 1, 0)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('logout', 'Logout', '', 'none', '', 0, 0, '', 1, 0)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.show', 'News-�bersicht', 'Artikel zeigen', 'news', 'Newsmanagement', 1, 1, 'Mit Sonderrechten kann ein Benutzer auch die Artikel Anderer einsehen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.add', 'Newseintrag hinzuf�gen', 'Neuer Artikel', 'news', 'Newsmanagement', 1, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.edit', 'Newseintrag bearbeiten', '', 'news', 'Newsmanagement', 0, 1, 'Sonderrechte erlauben einem Benutzer auch fremde Artikel zu l�schen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.del', 'Newseintrag l�schen', '', 'news', 'Newsmanagement', 0, 1, 'Sonderrechte erlauben einem Benutzer auch fremde Artikel zu l�schen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.pub', 'News ver�ffentlichen', '', 'news', 'Newsmanagement', 0, 1, 'Mit Sonderrechten lassen sich auch Artikel fremder Benutzer ver�ffentlichen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.unpub', 'News wiederrufen', '', 'news', 'Newsmanagement', 0, 1, 'Mit Sonderrechten lassen sich auch Artikel fremder Benutzer zur�cknehmen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.pics', 'Bildmanager', 'Bildmanager', 'news', 'Newsmanagement', 0, 1, 'Sonderrechte erm�glichen auch das Umbenennen, Verschieben und L�schen von Bildern.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.show', 'Newskategorien-�bersicht', 'Kategorien', 'news', 'Newsmanagement', 1, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.add', 'Newskategorie hinzuf�gen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.edit', 'Newskategorie bearbeiten', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.del', 'Newskategorie l�schen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.clean', 'Newskategorie r�umen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.show', 'Kommentar-�bersicht', 'Kommentare', 'news', 'Newsmanagement', 1, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.edit', 'Kommentar bearbeiten', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.del', 'Kommentar l�schen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.block.show', 'Kommentar-Sperren �bersicht', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.block.add', 'Kommentar-Sperre hinzuf�gen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.block.del', 'Kommentar-Sperre aufheben', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.source', 'Quellen', 'Quellen', 'news', 'Newsmanagment', 1, 1, 'Mit Sonderrechten lassen sich Quellen auch editieren und l�schen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.show', 'Benutzer-�bersicht', 'Benutzer zeigen', 'user', 'Userverwaltung', 1, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.profile', 'Benutzerprofil zeigen', '', 'user', 'Userverwaltung', 0, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.add', 'Benutzer hinzuf�gen', 'Neuer Benutzer', 'user', 'Userverwaltung', 1, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.edit', 'Benutzer bearbeiten', '', 'user', 'Userverwaltung', 0, 0, 'Seien Sie vorsichtig bei der Rechtevergabe. Mit dieser Funktion kann der Benutzer jeden beliebigen anderen Account ver�ndern!', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.del', 'Benutzer l�schen', '', 'user', 'Userverwaltung', 0, 0, 'Seien Sie vorsichtig bei der Rechtevergabe. Mit dieser Funktion kann der Benutzer jeden beliebigen anderen Account l�schen!', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.group.show', 'Benutzergruppen-�bersicht', 'Benutzergruppen', 'user', 'Userverwaltung', 1, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.group.add', 'Benutzergruppe erstellen', '', 'user', 'Userverwaltung', 0, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.group.edit', 'Benutzergruppe bearbeiten', '', 'user', 'Userverwaltung', 0, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.group.del', 'Benutzergruppe l�schen', '', 'user', 'Userverwaltung', 0, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.log', 'Protokoll einsehen', 'Protokoll', 'user', 'Userverwaltung', 1, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('pers.profile', 'Ihr Benutzerprofil', 'Benutzerprofil', 'pers', 'Personal', 1, 0, '', 1, 3)";

//Create User
$mysql[]="INSERT INTO ".$set['table']."_group VALUES (1, 'Chef-Administrator', 'global', '')";
$mysql[]="INSERT INTO ".$set['table']."_user VALUES (0,'".addslashes($_POST['ca_user'])."','".md5($_POST['ca_pwd1'])."','','1','1','".time()."','".time()."')";

define("CONN",@mysql_connect($set['server'], $set['user'], $set['password']));

if ( !$_POST['ca_user'] || !$_POST['ca_pwd1'] || !$_POST['ca_pwd2'] ) $message="<b>FEHLER:</b> Deine Angaben sind nicht komplett!";
elseif ( $_POST['ca_pwd1']!=$_POST['ca_pwd2'] ) $message="<b>FEHLER:</b> Passwort und Passwortwiederholung stimmen nicht �berein!";
elseif ( !CONN ) $message="<b>FEHLER:</b> Konnte keine Verbindung zur Datenbank herstellen!";
elseif ( !@mysql_select_db($set['database'], CONN) ) $message="<b>FEHLER:</b> Konnte Datenbank nicht ausw�hlen!";
else {
	foreach($mysql AS $q) {
		if ( $stop==false ) {
		$query=mysql_query($q);
			if ( !$query ) {
			$message="<b>FEHLER:</b> MySQL meldet ".mysql_error()."<br><br>Anfrage: ".$q;
			$stop=true;
			}
		}
	}
}
if ( !$message ) $message="<b>Installation erfolgreich abgeschlossen!</b>";

@mysql_close(CONN);

?>
<table width="400" cellpadding="0" cellspacing="3" border="0" align="center">
<tr><td><span style="font-size:20px;"><u><b>WEB//NEWS - Installation</b></u></span><br><b>(Neuinstallation)</b></td></tr>
<tr><td>&nbsp;<br><?=$message; ?></td></tr>
</table>
<?php
}

elseif ( $_POST['upver']=="12" ) {

function strpsl(&$array) {
reset($array);
	foreach($array AS $key => $val) {
	if(is_string($val)) $array[$key]=stripslashes($val);
	elseif(is_array($val)) $array[$key]=strpsl($val);
	}
return $array;
}

if (get_magic_quotes_gpc()) if(is_array($_POST)) $_POST=strpsl($_POST);
@set_magic_quotes_runtime(0);

//Rewrite News
$premysql="UPDATE ".$set['table']."_news SET text=CONCAT(pretext,'[MEHR]\n\n',text)";

//****** Update Tables *******
//Blockip
$mysql[]="CREATE TABLE ".$set['table']."_block (id int(11) NOT NULL auto_increment,type tinytext NOT NULL,string tinytext NOT NULL,endtime int(11) NOT NULL default '0',PRIMARY KEY  (id)) TYPE=MyISAM";

//News
$mysql[]="ALTER TABLE ".$set['table']."_news ADD subtopic TINYTEXT NOT NULL AFTER topic";
$mysql[]="ALTER TABLE ".$set['table']."_news ADD endtime INT NOT NULL AFTER pubtime";
$mysql[]="ALTER TABLE ".$set['table']."_news ADD pin INT( 1 ) NOT NULL AFTER endtime";
$mysql[]="ALTER TABLE ".$set['table']."_news ADD allowcoms INT( 1 ) DEFAULT '1' NOT NULL AFTER pin";
$mysql[]="ALTER TABLE ".$set['table']."_news DROP pretext";
$mysql[]="ALTER TABLE ".$set['table']."_news DROP pub";

//Comments
$mysql[]="ALTER TABLE ".$set['table']."_comment ADD feld1 TINYTEXT NOT NULL AFTER name ,ADD feld2 TINYTEXT NOT NULL AFTER feld1 ,ADD feld3 TINYTEXT NOT NULL AFTER feld2 ,ADD feld4 TINYTEXT NOT NULL AFTER feld3 ,ADD feld5 TINYTEXT NOT NULL AFTER feld4";
$mysql[]="UPDATE ".$set['table']."_comment SET feld1=email";
$mysql[]="ALTER TABLE ".$set['table']."_comment DROP email";

//User
$mysql[]="ALTER TABLE ".$set['table']."_user ADD active INT( 1 ) DEFAULT '1' NOT NULL AFTER groupid";

//Update INT Cols
$mysql[]="ALTER TABLE ".$set['table']."_comment CHANGE time time INT( 11 ) DEFAULT '0' NOT NULL";
$mysql[]="ALTER TABLE ".$set['table']."_news CHANGE time time INT( 11 ) DEFAULT '0' NOT NULL";
$mysql[]="ALTER TABLE ".$set['table']."_news CHANGE pubtime pubtime INT( 11 ) DEFAULT '0' NOT NULL";
$mysql[]="ALTER TABLE ".$set['table']."_user CHANGE lastonline lastonline INT( 11 ) DEFAULT '0' NOT NULL";
$mysql[]="ALTER TABLE ".$set['table']."_user CHANGE lastonline_temp lastonline_temp INT( 11 ) DEFAULT '0' NOT NULL";

//Update Actions
$mysql[]="DELETE FROM ".$set['table']."_actions";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('index', 'Hauptseite', '', 'none', '', 0, 0, '', 1, 0)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('login', 'Login', '', 'none', '', 0, 0, '', 1, 0)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('logout', 'Logout', '', 'none', '', 0, 0, '', 1, 0)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.show', 'News-�bersicht', 'Artikel zeigen', 'news', 'Newsmanagement', 1, 1, 'Mit Sonderrechten kann ein Benutzer auch die Artikel Anderer einsehen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.add', 'Newseintrag hinzuf�gen', 'Neuer Artikel', 'news', 'Newsmanagement', 1, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.edit', 'Newseintrag bearbeiten', '', 'news', 'Newsmanagement', 0, 1, 'Sonderrechte erlauben einem Benutzer auch fremde Artikel zu l�schen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.del', 'Newseintrag l�schen', '', 'news', 'Newsmanagement', 0, 1, 'Sonderrechte erlauben einem Benutzer auch fremde Artikel zu l�schen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.pub', 'News ver�ffentlichen', '', 'news', 'Newsmanagement', 0, 1, 'Mit Sonderrechten lassen sich auch Artikel fremder Benutzer ver�ffentlichen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.unpub', 'News wiederrufen', '', 'news', 'Newsmanagement', 0, 1, 'Mit Sonderrechten lassen sich auch Artikel fremder Benutzer zur�cknehmen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.pics', 'Bildmanager', 'Bildmanager', 'news', 'Newsmanagement', 0, 1, 'Sonderrechte erm�glichen auch das Umbenennen, Verschieben und L�schen von Bildern.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.show', 'Newskategorien-�bersicht', 'Kategorien', 'news', 'Newsmanagement', 1, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.add', 'Newskategorie hinzuf�gen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.edit', 'Newskategorie bearbeiten', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.del', 'Newskategorie l�schen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('cat.clean', 'Newskategorie r�umen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.show', 'Kommentar-�bersicht', 'Kommentare', 'news', 'Newsmanagement', 1, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.edit', 'Kommentar bearbeiten', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.del', 'Kommentar l�schen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.block.show', 'Kommentar-Sperren �bersicht', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.block.add', 'Kommentar-Sperre hinzuf�gen', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('com.block.del', 'Kommentar-Sperre aufheben', '', 'news', 'Newsmanagement', 0, 0, '', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('news.source', 'Quellen', 'Quellen', 'news', 'Newsmanagment', 1, 1, 'Mit Sonderrechten lassen sich Quellen auch editieren und l�schen.', 1, 1)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.show', 'Benutzer-�bersicht', 'Benutzer zeigen', 'user', 'Userverwaltung', 1, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.profile', 'Benutzerprofil zeigen', '', 'user', 'Userverwaltung', 0, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.add', 'Benutzer hinzuf�gen', 'Neuer Benutzer', 'user', 'Userverwaltung', 1, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.edit', 'Benutzer bearbeiten', '', 'user', 'Userverwaltung', 0, 0, 'Seien Sie vorsichtig bei der Rechtevergabe. Mit dieser Funktion kann der Benutzer jeden beliebigen anderen Account ver�ndern!', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.del', 'Benutzer l�schen', '', 'user', 'Userverwaltung', 0, 0, 'Seien Sie vorsichtig bei der Rechtevergabe. Mit dieser Funktion kann der Benutzer jeden beliebigen anderen Account l�schen!', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.group.show', 'Benutzergruppen-�bersicht', 'Benutzergruppen', 'user', 'Userverwaltung', 1, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.group.add', 'Benutzergruppe erstellen', '', 'user', 'Userverwaltung', 0, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.group.edit', 'Benutzergruppe bearbeiten', '', 'user', 'Userverwaltung', 0, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.group.del', 'Benutzergruppe l�schen', '', 'user', 'Userverwaltung', 0, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('user.log', 'Protokoll einsehen', 'Protokoll', 'user', 'Userverwaltung', 1, 0, '', 1, 2)";
$mysql[]="INSERT INTO ".$set['table']."_actions VALUES ('pers.profile', 'Ihr Benutzerprofil', 'Benutzerprofil', 'pers', 'Personal', 1, 0, '', 1, 3)";

define("CONN",@mysql_connect($set['server'], $set['user'], $set['password']));

if ( !CONN ) $message="<b>FEHLER:</b> Konnte keine Verbindung zur Datenbank herstellen!";
elseif ( !@mysql_select_db($set['database'], CONN) ) $message="<b>FEHLER:</b> Konnte Datenbank nicht ausw�hlen!";
else {
$query=true;

	if ( $_POST['pretext'] ) $query=mysql_query($premysql);
	if ( !$query ) $message="<b>FEHLER:</b> MySQL meldet ".mysql_error()."<br><br>Anfrage: ".$premysql;
	else {
	
		foreach($mysql AS $q) {
			if ( $stop==false ) {
			$query=mysql_query($q);
				if ( !$query ) {
				$message="<b>FEHLER:</b> MySQL meldet ".mysql_error()."<br><br>Anfrage: ".$q;
				$stop=true;
				}
			}
		}
	
	}
}
if ( !$message ) $message="<b>Update erfolgreich abgeschlossen!</b>";

@mysql_close(CONN);

?>
<p>&nbsp;</p>
<table width="400" cellpadding="0" cellspacing="3" border="0" align="center">
<tr><td><span style="font-size:20px;"><u><b>WEB//NEWS - Installation</b></u></span><br><b>(Update von 1.2 / 1.2 Patch A)</b></td></tr>
<tr><td>&nbsp;<br><?=$message; ?></td></tr>
</table>
<?php
}

elseif ( $_POST['type']=="neu" ) {
?>
<p>&nbsp;</p>
<form action="<?=$PHP_SELF; ?>" method="post">
<table width="400" cellpadding="0" cellspacing="3" border="0" align="center">
<tr><td colspan="2"><span style="font-size:20px;"><u><b>WEB//NEWS - Installation</b></u></span><br><b>(Neuinstallation)</b></td></tr>
<tr><td colspan="2"><span style="font-size:14px;">&nbsp;<br><u>MySQL-Benutzerdaten:</u></span></td></tr>
<tr>
<td width="40%">Server:</td>
<td width="60%"><?=$set['server']; ?></td>
</tr>
<tr>
<td width="40%">Benutzername:</td>
<td width="60%"><?=$set['user']; ?></td>
</tr>
<tr>
<td width="40%">Passwort:</td>
<td width="60%">[versteckt]</td>
</tr>
<tr>
<td width="40%">Datenbank:</td>
<td width="60%"><?=$set['database']; ?></td>
</tr>
<tr>
<td width="40%">Vorangestellte Tabellenbezeichnung:</td>
<td width="60%"><?=$set['table']; ?></td>
</tr>
<tr>
<td width="40%">Tabellen:</td>
<td width="60%">&bull; <?=$set['table']; ?>_actions<br>&bull; <?=$set['table']; ?>_blockip<br>&bull; <?=$set['table']; ?>_comment<br>&bull; <?=$set['table']; ?>_group<br>&bull; <?=$set['table']; ?>_log<br>&bull; <?=$set['table']; ?>_news<br>&bull; <?=$set['table']; ?>_newscat<br>&bull; <?=$set['table']; ?>_source<br>&bull; <?=$set['table']; ?>_user</td>
</tr>
<tr><td colspan="2"><span style="font-size:14px;">&nbsp;<br><u>Chef-Administrator:</u></span></td></tr>
<tr>
<td width="40%">Benutzername:</td>
<td width="60%"><input type="text" name="ca_user" size="35" class="input"></td>
</tr>
<tr>
<td width="40%">Passwort:</td>
<td width="60%"><input type="password" name="ca_pwd1" size="35" class="input"></td>
</tr>
<tr>
<td width="40%">Passwort: <font>(Wdh.)</font></td>
<td width="60%"><input type="password" name="ca_pwd2" size="35" class="input"></td>
</tr>
<tr><td colspan="2" align="center"><p align="justify">&nbsp;<br>Mit einem Klick auf &quot;Installation starten&quot; wird WEB//NEWS mit den oben stehenden Angaben installiert und die MySQL-Tabellen erstellt.</p><p><input type="submit" name="do" value="Installation starten" class="button"></p></td></tr>
</table>
</form>
<?php
}
elseif ( $_POST['type']=="update12" ) {
?>
<p>&nbsp;</p>
<form action="<?=$PHP_SELF; ?>" method="post">
<table width="400" cellpadding="0" cellspacing="3" border="0" align="center">
<tr><td colspan="2"><span style="font-size:20px;"><u><b>WEB//NEWS - Installation</b></u></span><br><b>(Update von 1.2 / 1.2 Patch A)</b></td></tr>
<tr><td colspan="2"><span style="font-size:14px;">&nbsp;<br><u>MySQL-Benutzerdaten:</u></span></td></tr>
<tr>
<td width="40%">Server:</td>
<td width="60%"><?=$set['server']; ?></td>
</tr>
<tr>
<td width="40%">Benutzername:</td>
<td width="60%"><?=$set['user']; ?></td>
</tr>
<tr>
<td width="40%">Passwort:</td>
<td width="60%">[versteckt]</td>
</tr>
<tr>
<td width="40%">Datenbank:</td>
<td width="60%"><?=$set['database']; ?></td>
</tr>
<tr>
<td width="40%">Vorangestellte Tabellenbezeichnung:</td>
<td width="60%"><?=$set['table']; ?></td>
</tr>
<tr>
<td width="40%">Tabellen:</td>
<td width="60%">&bull; <?=$set['table']; ?>_actions<br>&bull; <?=$set['table']; ?>_blockip<br>&bull; <?=$set['table']; ?>_comment<br>&bull; <?=$set['table']; ?>_group<br>&bull; <?=$set['table']; ?>_log<br>&bull; <?=$set['table']; ?>_news<br>&bull; <?=$set['table']; ?>_newscat<br>&bull; <?=$set['table']; ?>_source<br>&bull; <?=$set['table']; ?>_user</td>
</tr>
<tr>
<td width="40%">Einleitungs-Text:</td>
<td width="60%"><input type="checkbox" name="pretext" value="1"> Ich habe in Version 1.2 Einleitungs-Text verwendet</td>
</tr>
<tr><td colspan="2" align="center"><p align="justify">&nbsp;<br>Mit einem Klick auf &quot;Installation starten&quot; werden die MySQL-Tabellen von WEB//NEWS auf die Version 1.3 aktualisiert.</p><p><input type="hidden" name="upver" value="12"><input type="submit" name="do" value="Update starten" class="button"></p></td></tr>
</table>
</form>
<?php
}
else {
?>
<p>&nbsp;</p>
<form action="<?=$PHP_SELF; ?>" method="post">
<table width="400" cellpadding="0" cellspacing="3" border="0" align="center">
<tr><td><span style="font-size:20px;"><u><b>WEB//NEWS - Installation</b></u></span></td></tr>
<tr><td><span style="font-size:14px;">&nbsp;<br><u>Installationstyp w&auml;hlen:</u></span></td></tr>
<tr><td><input type="radio" name="type" value="neu" checked> Neuinstallation<br><input type="radio" name="type" value="update12"> Update (von 1.2/1.2 Patch A)</td></tr>
<tr><td align="center"><input type="submit" name="do" value="Weiter" class="button"></td></tr>
</table>
</form>
<?php
}

?>
</body>
</html>