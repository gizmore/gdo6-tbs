<?php

/*
	danish.php - Danish language file
	Created: May, 28 2001
	Author: Uffe Lund, Learning By Doing

	This is a language file. You can alter it to fit your language. For example if were to make a russian
	one, name it "russian.php" and put into the "lang" subdirectory along with the other language files.
	Then start editing the variables. Note that there are pieces of text that are actually format strings
	(those including a %s) somewhere in the text. Those %s have to be there, they are placeholders for
	information that is dynamically inserted at run-time. Mostly their content is self-explaining.
	
	If you have created a language file for a language that is not yet supported (in the official release),
	please email it to me (yes I will mention your name somewhere :). It will then be included in the next
	release.
*/


/*
	Variables for index.php
*/

$t_overview_upper_right = "%s brugere | Mest aktive bruger: %s (%s indl�g) | <b>%s brugere online</b>";
$t_welcome = "Velkommen";

$t_login = "Log p�";
$t_guest_access = "Brugerstatus: <b>g�st</b>. Du skal <a href=\"register.php\">registrere</a> hvis du vil kunne tilf�je indl�g.";
$t_username = "Brugernavn";
$t_password = "Adgangskode";
$t_logged_in = "Logget p�";
$t_reguser_welcome_phrase = "Velkommen, <b>%s</b>."; // %s = username
$t_reguser_rights = "Dine brugerrettigheder: <b>%s</b>."; // %s = rights (admin, moderator, normal)

$t_search = "S�g i fora";
$t_find = "Find:";
$t_infield = "i feltet:";
$t_search_subject = "Emne";
$t_search_text = "Tekst";
$t_indiscussion = "i forum:";

$t_forums = "Fora";
$t_forumname = "Navn";
$t_new = "Nyt";
$t_total = "I alt";
$t_lastpost = "Seneste indl�g";
$t_fdesc = "Beskrivelse";



/*
	Variables for profile.php
*/

$t_update_confirmation = "Brugerprofilen er opdateret. Du skal logge p� igen!";
$t_general_info = "Generel information om %s"; // %s = username
$t_real_name = "Fulde navn";
$t_emailaddr = "E-mail";
$t_newpwd = "Ny adgangskode";
$t_repeatpwd = "Gentag adgangskode";

$t_preferences = "Preferencer: ";
$t_threadsperpage = "Emnetr�de pr. side: ";
$t_signature = "Underskrift: ";


/*
	Variables for show.php
*/

$t_foruminfo = "(%s Tr�de, %s Indl�g i alt";
$t_usersonline = "%s bruger(e) online";

$t_post_new_topic = "Tilf�j nyt indl�g";
$t_collapse_threads = "Sammenfold emnetr�de";
$t_expand_threads = "Udvid emnetr�de";

$t_previous_page = "Forrige side";
$t_next_page = "N�ste side";

$t_subject_field = "Emne";
$t_author_field = "Forfatter";
$t_date_field = "Dato";

$t_one_reply = "(1 svar)";
$t_many_replies = "(%s svar)";
$t_delete_thread = "Slet emnetr�d";

$t_user_info = "Brugeroplysninger";
$t_text = "Tekst";
$t_user_posts = "(%s indl�g i alt, seneste indl�g: %s)";
$t_replies_to_this_msg = "Svar p� dette indl�g";
$t_postinfo = ", indf�jet af <b>%s</b>, [%s], %s. Set <b>%s</b> gange.";
$t_reply_to_msg = "Svar p� dette indl�g";


/*
	Variables for register.php
*/

$t_terms_of_usage = "Betingelser for brug";
$t_userinformation = "Brugeroplysninger";
$t_reg_info = "Straks efter din tilmelding, vil din adgangskode blive tilsendt i en e-mail.";

$t_regmail_head = "Du har tilmeldt dig et Cyphor forum (%s). Dette er din bekr�ftelse.";
$t_regmail_user = "Dit brugernavn: ";
$t_regmail_pass = "Din adgangskode: ";
$t_regmail_info = "Forumets URL er: ";
$t_regmail_subject = "[Cyphor] Tilmelding gennemf�rt!";
$t_reg_conf = "Tilmelding gennemf�rt! <br>Din bekr�ftelse bliver sendt til: %s"; // %s = email


/*
	Variables for search.php
*/

$t_search = "S�g";
$t_results = "%s resultater fundet i forum \"%s\".";
$t_found_nothing = "Ingen s�geresultater fundet i forumet \"%s\".";
$t_search_again = "S�g igen";

/*
	Variables for send.php
*/

$t_message_posted = "Indl�g tilf�jet.";
$t_view_your_message = "Se dit indl�g.";
$t_mail_header = "%s har svaret p� dit indl�g i forumet '%s'"; // %s = nickname, forum name
$t_mail_link = "Dette link vil sende dig direkte til svaret";
$t_mail_subject = "[Cyphor] Svar p�: %s"; // %s = subject of message

/*
	Variables for newmsg.php
*/

$t_new_msg_in_forum = "Nyt indl�g i forumet \"%s\""; // %s = forum name
$t_new_reply_in_forum = "Svar p� \"%s\" i forumet \"%s\""; // %s = subject of parent msg | forum name
$t_post_rules = "Lineskift bevares. Du beh�ver ikke gennemtvinge dem med &lt;BR&gt;.<br>HTML tags bortfiltreres! Links genereres automatisk.";
$t_msg_from_field = "Fra: ";
$t_msg_subject_field = "Emne: ";
$t_msg_text_field = "Tekst: ";
$t_email_notification = "Send mig en e-mail n�r nogen svarer p� dette indl�g.";
$t_attach_sig = "Tilf�j min personlige signatur til dette indl�g.";

/*
	Variables for lost_pwd.php
*/

$t_enter_email_address = "Indtast din e-mail adresse";
$t_lostpwd_info = "Hvis du indtaster dit brugernavn og din e-mail adresse (skal passe sammen), kan du f� tilsendt en ny adgangskode i en e-mail. Den nye adgangskode vil v�re g�ldende med det samme.";
$t_pwd_sent = "Ny adgangskode er sendt.";

/*
	Globals	
*/

$t_btnupdate = "�ndre brugerprofil";
$t_btnsignup = "Tilmelding!";
$t_btnsearch = "S�g";
$t_btnresetform = "Nulstil skema";
$t_btnpostmsg = "Send indl�g";
$t_btnquote = "Cit�r oprindeligt indl�g";
$t_back_link = "Tilbage";
$t_invalid_query = "Ugyldig foresp�rgsel!";
$t_btnsubmit = "Afsend";

/*
	Footer
*/

$t_forums_overview = "Forum oversigt";
$t_back_to_forum = "Tilbate til forumet";
$t_register = "Tilmelding";
$t_edit_profile = "Redig�r brugerprofil";
$t_logout = "Log af";
$t_administration = "Administration";
$t_btngo = "G� til";
$t_jump_to = "Hop til...";
$t_lost_password = "Glemt adgangskode?";

/*
	Error messages
*/

$terr_not_logged_in = "Ikke logget p�!";
$terr_no_admin_rights = "Bruger har ikke administratorrettigheder!";
$terr_no_forum = "Intet forum valgt!";
$terr_login_failed = "Log p� lykkedes ikke!";
$terr_required_fields = "Du har ikke udfyldt alle obligatoriske felter!";
$terr_pwd_match = "Adgangskoder er ikke ens!";

$terr_nick_alpha = "Brugernavnet skal indeholde bogstaver og evt. cifre!";
$terr_nick_len = "Brugernavnet skal v�re mindst tre tegn langt!";
$terr_nick_reg = "Dette brugernavn er optaget!";
$terr_dbl_email = "En anden bruger har allerede tilmeldt denne e-mail adresse!?!";



?>
