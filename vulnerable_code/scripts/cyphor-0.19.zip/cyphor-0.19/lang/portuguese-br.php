<?php

/*
	portuguese-br.php - Portuguese-br language file
	Created: April 25, 2001
	Author: Humberto Cruz

	This is a language file. You can alter it to fit your language. For example if were to make a russian
	one, name it "russian.php" and put into the "lang" subdirectory along with the other language files.
	Then start editing the variables. Note that there are pieces of text that are actually format strings
	(those including a %s) somewhere in the text. Those %s have to be there, they are placeholders for
	information that is dynamically inserted at run-time. Mostly their content is self-explaining.
	
	If you have created a language file for a language that is not yet supported (in the official release),
	please email it to me (yes I will mention your name somewhere :). It will then be included in the next
	release.
*/


/*
	Variables for index.php
*/

$t_overview_upper_right = "%s usu�rios reg. | Usu�rio mais ativo: %s (%s msgs) | <b>%s usu�rios on-line</b>";
$t_welcome = "Bem-vindo";

$t_login = "Login";
$t_guest_access = "Guest access granted. You have to <a href=\"register.php\">register</a> if you want to post messages.";
$t_username = "Username";
$t_password = "Password";
$t_logged_in = "Logado";
$t_reguser_welcome_phrase = "Bem-vindo, <b>%s</b>."; // %s = username
$t_reguser_rights = "Voc� tem direitos de <b>%s</b>."; // %s = rights (admin, moderador, normal)

$t_search = "Busca nos Forums";
$t_find = "Busca:";
$t_infield = "no Campo:";
$t_search_subject = "Assunto";
$t_search_text = "Texto";
$t_indiscussion = "no Forum:";

$t_forums = "Forums";
$t_forumname = "Nome";
$t_new = "Nova";
$t_total = "Total";
$t_lastpost = "�ltima mensagem";
$t_fdesc = "Descri��o";



/*
	Variables for profile.php
*/

$t_update_confirmation = "Profile atualizado, voc� precisa reconectar!";
$t_general_info = "Informa��o Geral para %s"; // %s = username
$t_real_name = "Nome verdadeiro";
$t_emailaddr = "Email";
$t_newpwd = "Nova Senha";
$t_repeatpwd = "Repita Senha";

$t_preferences = "Prefer�ncias: ";
$t_threadsperpage = "Threads por p�gina: ";
$t_signature = "Assinatura: ";


/*
	Variables for show.php
*/

$t_foruminfo = "(%s T�picos, %s Messagens no total)";
$t_usersonline = "%s usu�rio(s) online";

$t_post_new_topic = "Postar novo t�pico";
$t_collapse_threads = "Retrair T�picos";
$t_expand_threads = "Expandir T�picos";

$t_previous_page = "P�gina Anterior";
$t_next_page = "Pr�xima P�gina";

$t_subject_field = "Assunto";
$t_author_field = "Autor";
$t_date_field = "Data";

$t_one_reply = "(1 resposta)";
$t_many_replies = "(%s respostas)";
$t_delete_thread = "Apagar T�pico";

$t_user_info = "Informa��o do Usu�rio";
$t_text = "Texto";
$t_user_posts = "(%s total de postagens, �ltima postagem: %s)";
$t_replies_to_this_msg = "Respostas a essa mensagem";
$t_postinfo = ", postado por <b>%s</b>, [%s], %s. Visto <b>%s</b> vezes.";
$t_reply_to_msg = "Reponder a essa mensagem";


/*
	Variables for register.php
*/

$t_terms_of_usage = "Termos de uso";
$t_userinformation = "Informa��o do Usu�rio";
$t_reg_info = "Assim que voc� se registrar sua senha ser� enviada para voc�.";

$t_regmail_head = "Voc� se registrou a um forum da GAS: (%s). Essa � a confirma��o.";
$t_regmail_user = "Seu nome de usu�rio �: ";
$t_regmail_pass = "Sua senha �: ";
$t_regmail_info = "O endere�o do forum �: ";
$t_regmail_subject = "[GAS] Registro realizado com sucesso!";
$t_reg_conf = "Registro realizado com sucesso! Voc� vai receber a confirma��o por: %s"; // %s = email


/*
	Variables for search.php
*/

$t_search = "Busca";
$t_results = "%s resultado(s) para o forum \"%s\" encontrado(s).";
$t_found_nothing = "Nenhum resultado para o forum \"%s\" encontrado.";
$t_search_again = "Busque novamente";

/*
	Variables for send.php
*/

$t_message_posted = "Messagem enviada.";
$t_view_your_message = "Veja sua mensagem";
$t_mail_header = "%s respondeu sua mensagem no forum '%s'"; // %s = nickname, forum name
$t_mail_link = "Este link vai leva-lo diretamente a menssagem dele/dela";
$t_mail_subject = "[Gas] Resposta para: %s"; // %s = subject of message

/*
	Variables for newmsg.php
*/

$t_new_msg_in_forum = "Nova mensagem no forum \"%s\""; // %s = forum name
$t_new_reply_in_forum = "Repostas para \"%s\" no forum \"%s\""; // %s = subject of parent msg | forum name
$t_post_rules = "Qurbras de linhas s�o processadas, voc� nao precisa for�a-las com &lt;BR&gt;. Tags HTML ser�o filtradas! Links ser�o gerados automaticamente.";
$t_msg_from_field = "De: ";
$t_msg_subject_field = "Assunto: ";
$t_msg_text_field = "Texto: ";
$t_email_notification = "Avise-me quando algu�m responder a essa mensagem.";
$t_attach_sig = "Acrescente minha assinatura pessoal a essa mensagem.";

/*
	Variables for lost_pwd.php
*/

$t_enter_email_address = "Entre seu email";
$t_lostpwd_info = "Voc� pode ter sua senha enviada para voc� provendo seu Username e email. A GAS vai ent�o eniar a nova senha para seu email. Essa infoma��o vai ser enviada para o mail que voc� digitar abaixo.";
$t_pwd_sent = "Nova senha enviada.";

/*
	Globals	
*/

$t_btnupdate = "Atualizar Profile";
$t_btnsignup = "Assine!";
$t_btnsearch = "Busca";
$t_btnresetform = "Apagar Formul�rio";
$t_btnpostmsg = "Envie mensagem";
$t_btnquote = "Quote messagem original";
$t_back_link = "Volta";
$t_invalid_query = "Busca inv�lida!";
$t_btnsubmit = "Enviar";

/*
	Footer
*/

$t_forums_overview = "Vis�o Geral";
$t_back_to_forum = "Volte ao forum";
$t_register = "Registre-se";
$t_edit_profile = "Edite Profile";
$t_logout = "Logout";
$t_administration = "Administra��o";
$t_btngo = "Ir";
$t_jump_to = "Pule para...";
$t_lost_password = "Esqueceu a senha?";

/*
	Error messages
*/

$terr_not_logged_in = "N�o logado!";
$terr_no_admin_rights = "Usu�rio n�o possui direitos Admin!";
$terr_no_forum = "Nenhum forum foi especificado!";
$terr_login_failed = "Falha no Login!";
$terr_required_fields = "Voc� n�o especificou todos os campos requeridos!";
$terr_pwd_match = "As senhas n�o s�o iguais!";

$terr_nick_alpha = "Apelido deve ser alpha-numerico!";
$terr_nick_len = "Apelido deve conter ao menos 3 caracteres!";
$terr_nick_reg = "Apelido j� foi registrado antes!";
$terr_dbl_email = "Algu�m com o mesmo email j� foi registrado!";





?>
