<?php

/*
        italian.php - Italian language file
        Created: June 18, 2001
        Author: Alberto Savani, www.adriaweb.it

        This is a language file. You can alter it to fit your language. For example if were to make a russian
        one, name it "russian.php" and put into the "lang" subdirectory along with the other language files.
        Then start editing the variables. Note that there are pieces of text that are actually format strings
        (those including a %s) somewhere in the text. Those %s have to be there, they are placeholders for
        information that is dynamically inserted at run-time. Mostly their content is self-explaining.

        If you have created a language file for a language that is not yet supported (in the official release),
        please email it to me (yes I will mention your name somewhere :). It will then be included in the next
        release.
*/

/*
        ndt: nella traduzione ho utilizzato la seconda persona singolare perch� funzionale al sito in cui ho
        inserito il forum
*/

/*
        Variables for index.php
*/

$t_overview_upper_right = "%s utenti registrati | Utente pi&ugrave; attivo: %s (%s messaggi) | <b>%s utenti collegati</b>";
$t_welcome = "Benvenuto!";

$t_login = "Login";
$t_guest_access = "La lettura dei messaggi &egrave; permessa a tutti. Per poter inserire dei messaggi devi prima <a href=\"register.php\">registarti</a>.";
$t_username = "Username";
$t_password = "Password";
$t_logged_in = "Connesso";
$t_reguser_welcome_phrase = "Benvenuto, <b>%s</b>."; // %s = username
$t_reguser_rights = "Sei collegato come utente <b>%s</b>."; // %s = rights (admin, moderator, normal)

$t_search = "Cerca nei Forum";
$t_find = "Trova:";
$t_infield = "nel Campo:";
$t_search_subject = "Titolo";
$t_search_text = "Testo";
$t_indiscussion = "nel Forum:";

$t_forums = "Forum";
$t_forumname = "Nome";
$t_new = "Nuovi";
$t_total = "Totale";
$t_lastpost = "Ultimo messaggio";
$t_fdesc = "Descrizione";

/* Added for Release 0.19 */
$t_cookie_remember_box = " Memorizza (richiede i  cookies)";



/*
        Variables for profile.php
*/

$t_update_confirmation = "Profilo aggiornato, adesso devi uscire e rientrare!";
$t_general_info = "Informazioni generali per %s"; // %s = username
$t_real_name = "Nome";
$t_emailaddr = "Email";
$t_newpwd = "Nuova Password";
$t_repeatpwd = "Ripeti Password";

$t_preferences = "Preferenze: ";
$t_threadsperpage = "Discussioni per pagina: ";
$t_signature = "Firma: ";


/*
        Variables for show.php
*/

$t_foruminfo = "(%s Discussioni, %s Messaggi totali)";
$t_usersonline = "%s utente/i online";

$t_post_new_topic = "Inserisci un nuovo argomento";
$t_collapse_threads = "Riduci le discussioni";
$t_expand_threads = "Espandi le discussioni";

$t_previous_page = "Pagina Precedente";
$t_next_page ="Pagina Successiva";

$t_subject_field = "Oggetto";
$t_author_field = "Autore";
$t_date_field = "Data";

$t_one_reply = "(1 risposta)";
$t_many_replies = "(%s risposte)";
$t_delete_thread = "Cancella discussione";

$t_user_info = "Informazioni utente";
$t_text = "Testo";
$t_user_posts = "(%s messaggi totali, ultimo messaggio: %s)";
$t_replies_to_this_msg = "Risposte al messaggio";
$t_postinfo = ", inviato da <b>%s</b>, [%s], %s. Letto <b>%s</b> volte.";
$t_reply_to_msg = "Rispondi a questo messaggio";


/*
        Variables for register.php
*/

$t_terms_of_usage = "Termini di utilizzo";
$t_userinformation = "Informazioni sull'utente";
$t_reg_info = "Non appena ti sarai registarto la password ti verr&agrave; inviata via email.";

$t_regmail_head = "Ti sei appena registarto al forum (%s). Questa � la conferma.";
$t_regmail_user = "Il tuo username �: ";
$t_regmail_pass = "La tua password �: ";
$t_regmail_info = "L'indirizzo del forum �;: ";
$t_regmail_subject = "[Cyphor] Registrazione avvenuta con successo!";
$t_reg_conf = "Registrazione avvenuta con successo! Riceverai la conferma all'indirizzo: %s"; // %s = email


/*
        Variables for search.php
*/

$t_search = "Cerca";
$t_results = "%s risultati trovati nel forum forum \"%s\".";
$t_found_nothing = "Non si sono trovati risultati nel forum \"%s\".";
$t_search_again = "Cerca ancora";

/*
        Variables for send.php
*/

$t_message_posted = "Messaggio inviato.";
$t_view_your_message = "Visualizza il tuo messaggio";
$t_mail_header = "%s ha risposto al tuo messaggio nel forum '%s'"; // %s = nickname, forum name
$t_mail_link = "Questo link ti condurr� direttamente al suo messaggio";
$t_mail_subject = "[Cyphor] Risposta a: %s"; // %s = subject of message

/*
        Variables for newmsg.php
*/

$t_new_msg_in_forum = "Nuovi messagggi nel forum \"%s\""; // %s = forum name
$t_new_reply_in_forum = "Risposta a \"%s\" nel forum \"%s\""; // %s = subject of parent msg | forum name
$t_post_rules = "Gli a-capo vengono processati, non hai bisogno di forzarli utilizzando &lt;BR&gt;. I tag HTML verranno filtrati! eventuali Link verranno generati automaticamente.";
$t_msg_from_field = "Da: ";
$t_msg_subject_field = "Titolo: ";
$t_msg_text_field = "Testo: ";
$t_email_notification = "Avvisami quando qualcuno risponde a questo messaggio.";
$t_attach_sig = "Allega la mia firma a questo messaggio.";

/*
        Variables for lost_pwd.php
*/

$t_enter_email_address = "Inserisci l'email";
$t_lostpwd_info = "Puoi ottenere una nuova password via email inserendo il tuo username ed il tuo indirizzo email. Cyphor in seguito ti invier&agrave; una nuova password associata allo username fornitoci. Questa informazione ti verr&agrave; inviata all'indirizzo email inserito qui sotto.";
$t_pwd_sent = "Nuova password inviata.";

/*
        Globals
*/

$t_btnupdate = "Aggiorna profilo";
$t_btnsignup = "Iscriviti!";
$t_btnsearch = "Cerca";
$t_btnresetform = "Cancella il form";
$t_btnpostmsg = "Invia il messaggio";
$t_btnquote = "Quota il messaggio originale";
$t_back_link = "Indietro";
$t_invalid_query = "Richiesta invalida!";
$t_btnsubmit = "Invia";

/*
        Footer
*/

$t_forums_overview = "Forums";
$t_back_to_forum = "Torna al forum";
$t_register = "Registrati";
$t_edit_profile = "Modifica il profilo";
$t_logout = "Logout";
$t_administration = "Amministrazione";
$t_btngo = "Vai";
$t_jump_to = "Passa a...";
$t_lost_password = "Perso la password?";

/*
        Error messages
*/

$terr_not_logged_in = "Non collegato!";
$terr_no_admin_rights = "Questo utente non ha i privilegi di amministratore!";
$terr_no_forum = "Nessun forum specificato!";
$terr_login_failed = "Accesso fallito!";
$terr_required_fields = "Non hai riempito tutti i campi richiesti!";
$terr_pwd_match = "Le password non corrispondondono!";

$terr_nick_alpha = "Il nickname dev'essere alfanumerico!";
$terr_nick_len = "Il nickname dev'essere lungo almeno tre caratteri!";
$terr_nick_reg = "Nickname precedentemente registrato!";
$terr_dbl_email = "Qualcuno con la stessa e-mail &egrave; gi&agrave; iscritto al forum!";



?>
