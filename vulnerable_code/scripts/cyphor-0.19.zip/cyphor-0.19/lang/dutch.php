<?php

/*
        dutch.php - Nederlandse language file
        Created: March 14 2001
        Author: Sander Stad, AIKON WebDesign

        This is a language file. You can alter it to fit your language. For example if were to make a russian
        one, name it "russian.php" and put into the "lang" subdirectory along with the other language files.
        Then start editing the variables. Note that there are pieces of text that are actually format strings
        (those including a %s) somewhere in the text. Those %s have to be there, they are placeholders for
        information that is dynamically inserted at run-time. Mostly their content is self-explaining.

        If you have created a language file for a language that is not yet supported (in the official release),
        please email it to me (yes I will mention your name somewhere :). It will then be included in the next
        release.
*/
                                     
/*
        Variables for index.php
*/

$t_overview_upper_right = "%s Geregistreerde users | Meest actieve user: %s (%s posts) | <b>%s users online</b>";
$t_welcome = "Welcome";

$t_login = "Login";
$t_guest_access = "Gasten mogen in dit forum komen. Maar je moet je <a href=\"register.php\">registreren</a> als je berichten wilt plaatsen.";
$t_username = "Usernaam";
$t_password = "Wachtwoord";
$t_logged_in = "Ingelogd";
$t_reguser_welcome_phrase = "Welkom, <b>%s</b>."; // %s = username
$t_reguser_rights = "Je hebt <b>%s</b> rechten."; // %s = rights (admin, moderator, normal)

$t_search = "Zoeken in Forums";
$t_find = "Zoek:";
$t_infield = "in Veld:";
$t_search_subject = "Onderwerp";
$t_search_text = "Text";
$t_indiscussion = "in Forum:";

$t_forums = "Forums";
$t_forumname = "Naam";
$t_new = "Nieuw";
$t_total = "Totaal";
$t_lastpost = "Laatste bericht";
$t_fdesc = "Beschrijving";



/*
        Variables for profile.php
*/

$t_update_confirmation = "Profiel geupdate, log opnieuw in!";
$t_general_info = "Standaard informatie voor %s"; // %s = username
$t_real_name = "Echte naam";
$t_emailaddr = "Email";
$t_newpwd = "Nieuw Wachtwoord";
$t_repeatpwd = "Herhaal wachtwoord";

$t_preferences = "Eigenschappen: ";
$t_threadsperpage = "Threads per pagina: ";
$t_signature = "Handtekening: ";


/*
        Variables for show.php
*/

$t_foruminfo = "(%s Threads, %s Totaal aantal berichten)";
$t_usersonline = "%s user(s) online";

$t_post_new_topic = "Maak nieuw bericht";
$t_collapse_threads = "Threads inklappen";
$t_expand_threads = "Threads uitklappen";

$t_previous_page = "Vorige Pagina";
$t_next_page = "Volgende Pagina";

$t_subject_field = "Onderwerp";
$t_author_field = "Autheur";
$t_date_field = "Datum";

$t_one_reply = "(1 antwoord)";
$t_many_replies = "(%s antwoorden)";
$t_delete_thread = "Verwijder Thread";

$t_user_info = "User Informatie";
$t_text = "Text";
$t_user_posts = "(%s berichten totaal, laatste bericht: %s)";
$t_replies_to_this_msg = "Antwoorden op dit bericht";
$t_postinfo = ", gemaakt door <b>%s</b>, [%s], %s. Bekeken <b>%s</b> keer.";
$t_reply_to_msg = "Antwoord op dit bericht";


/*
        Variables for register.php
*/

$t_terms_of_usage = "Terms of usage";
$t_userinformation = "User informatie";
$t_reg_info = "Zodra je je geregistreerd hebt wordt je wachtwoord naar je email verzonden.";

$t_regmail_head = "Je hebt je geregistreerd voor het LINUXONLY Forum (%s). Dit is je conformatie.";
$t_regmail_user = "Je username is: ";
$t_regmail_pass = "Je wachtwoord is: ";
$t_regmail_info = "De forum's URL is: ";
$t_regmail_subject = "Registratie gelukt!";
$t_reg_conf = "Registratie gelukt! Je ontvangt je conformatie naar: %s"; // %s = email


/*
        Variables for search.php
*/

$t_search = "Zoeken";
$t_results = "%s resultaten voor forum \"%s\" gevonden.";
$t_found_nothing = "Geen resultaten voor forum \"%s\" gevonden.";
$t_search_again = "Opnieuw zoeken";

/*
        Variables for send.php
*/

$t_message_posted = "Bericht verzonden.";
$t_view_your_message = "Bekijk je bericht";
$t_mail_header = "%s heeft gereageerd op je bericht in forum '%s'"; // %s = nickname, forum name
$t_mail_link = "Deze link brengt je direct naar je bericht toe";
$t_mail_subject = "Antwoord naar: %s"; // %s = subject of message

/*
        Variables for newmsg.php
*/

$t_new_msg_in_forum = "Nieuw bericht in forum \"%s\""; // %s = forum name
$t_new_reply_in_forum = "Antwoord naar \"%s\" in forum \"%s\""; // %s = subject of parent msg | forum name
$t_post_rules = "Enters zijn doorgevoerd, je hoeft ze niet nog in te voeren &lt;BR&gt;. HTML tags worden doorgevoerd! Links worden automatisch gegenereerd.";
$t_msg_from_field = "Van: ";
$t_msg_subject_field = "Onderwerp: ";
$t_msg_text_field = "Text: ";
$t_email_notification = "Waarschuw me wanneer iemand op mijn bericht reageert.";
$t_attach_sig = "Zend mijn handtekening mee.";

/*
        Variables for lost_pwd.php
*/

$t_enter_email_address = "Geef je Email";
$t_lostpwd_info = "Je wachtwoord kan naar je toe gestuurd worden door je usernaam en Email te geven. Je nieuwe wachtwoord wordt dan naar je Email toegestuurd die we geassocieerd hebben met de Email die je opgegeven hebt. Deze informatie wordt verzonden naar het Emailadres hieronder.";
$t_pwd_sent = "Nieuw wachtwoord verzonden.";

/*
        Globals
*/

$t_btnupdate = "Update Profiel";
$t_btnsignup = "Registreren!";
$t_btnsearch = "Zoeken";
$t_btnresetform = "Wis Forumulier";
$t_btnpostmsg = "Verzend Bericht";
$t_btnquote = "Quote het originele bericht";
$t_back_link = "Terug";
$t_invalid_query = "Ongeldige zoekopdracht!";
$t_btnsubmit = "Verzenden";

/*
        Footer
*/

$t_forums_overview = "Forums Overzicht";
$t_back_to_forum = "Terug naar Forum";
$t_register = "Registreren";
$t_edit_profile = "Profiel Wijzigen";
$t_logout = "UItloggen";
$t_administration = "Administration";
$t_btngo = "Go";
$t_jump_to = "Ga naar .....";
$t_lost_password = "Wachtwoord verloren?";

/*
        Error messages
*/

$terr_not_logged_in = "Niet Ingelogd!";
$terr_no_admin_rights = "User heeft geen admin rechten!";
$terr_no_forum = "Geen forum gespecificeerd!";
$terr_login_failed = "Inloggen mislukt!";
$terr_required_fields = "Je hebt niet alle gevraagde velden ingevuld!";
$terr_pwd_match = "Wachtwoorden komen niet overeen!";

$terr_nick_alpha = "Nickname moet alpha-numeriek zijn!";
$terr_nick_len = "Nickname moet op zijn minst 3 letters!";
$terr_nick_reg = "Nickname is al geregistreerd!";
$terr_dbl_email = "Iemand met hetzelfde Emailadres is al geregistreerd!";





?>