<?php

/*
	spanish.php - Spanish language file
	Created: March 21, 2001
	Author: Jacobo E. Castillo
	Modified by: Vinko Vrsalovic <v@w.cl>

	On: June 25, 2001
	Changes:

	- Corrected a few errors I made :_)
	- Changes for 0.19
	
	On: June 21, 2001
	Changes: 

	- Multiple spelling corrections
	- Some gramatical corrections too


	This is a language file. You can alter it to fit your language. For example if were to make a russian
	one, name it "russian.php" and put into the "lang" subdirectory along with the other language files.
	Then start editing the variables. Note that there are pieces of text that are actually format strings
	(those including a %s) somewhere in the text. Those %s have to be there, they are placeholders for
	information that is dynamically inserted at run-time. Mostly their content is self-explaining.
	
	If you have created a language file for a language that is not yet supported (in the official release),
	please email it to me (yes I will mention your name somewhere :). It will then be included in the next
	release.
*/


/*
	Variables for index.php
*/

$t_overview_upper_right = "%s usuarios registrados | Usuario m�s activo: %s (%s mensajes) | <b>%s usuarios en l�nea</b>";
$t_welcome = "Bienvenido";

$t_login = "Conectar";
$t_guest_access = "Acceso permitido. Necesitas <a href=\"register.php\">registrarte</a> si quieres publicar tus mensajes.";
$t_username = "Usuario";
$t_password = "Contrase�a";
$t_logged_in = "Conectado";
$t_reguser_welcome_phrase = "Bienvenido, <b>%s</b>."; // %s = username
$t_reguser_rights = "Tienes derechos de tipo: <b>%s</b>."; // %s = rights (admin, moderator, normal)

$t_search = "Buscar en los foros";
$t_find = "Buscar:";
$t_infield = "en el campo:";
$t_search_subject = "Tema";
$t_search_text = "Texto";
$t_indiscussion = "en foro:";

$t_forums = "Foros";
$t_forumname = "Nombre";
$t_new = "Nuevo";
$t_total = "Total";
$t_lastpost = "�ltimo mensaje";
$t_fdesc = "Descripci�n";

/* added for release 0.19 */

$t_cookie_remember_box=" Recuerde (necesita cookies)";

/*
	Variables for profile.php
*/

$t_update_confirmation = "Perfil actualizado, �necesitar�s reconectarte!";
$t_general_info = "Informaci�n general para %s"; // %s = username
$t_real_name = "Nombre verdadero";
$t_emailaddr = "email";
$t_newpwd = "Contrase�a nueva";
$t_repeatpwd = "Repite la contrase�a";

$t_preferences = "Preferencias: ";
$t_threadsperpage = "Threads por p�gina: ";
$t_signature = "Firma: ";


/*
	Variables for show.php
*/

$t_foruminfo = "(%s Threads, %s mensajes en total)";
$t_usersonline = "%s usuario(s) en l�nea";

$t_post_new_topic = "Escribe un nuevo mensaje";
$t_collapse_threads = "Ver Listado de Mensajes";
$t_expand_threads = "Ver �rbol de Mensajes";

$t_previous_page = "P�gina anterior";
$t_next_page = "Pr�xima p�gina";

$t_subject_field = "Tema";
$t_author_field = "Autor";
$t_date_field = "Fecha";

$t_one_reply = "(1 respuesta)";
$t_many_replies = "(%s respuestas)";
$t_delete_thread = "Eliminar Thread";

$t_user_info = "Informaci�n del usuario";
$t_text = "Texto";
$t_user_posts = "(%s mensajes en total, ultimo mensaje: %s)";
$t_replies_to_this_msg = "Respuestas a este mensaje";
$t_postinfo = ", escrito por <b>%s</b>, [%s], %s. Le�do <b>%s</b> veces.";
$t_reply_to_msg = "Responder a este mensaje";


/*
	Variables for register.php
*/

$t_terms_of_usage = "Condiciones de uso";
$t_userinformation = "Informaci�n del usuario";
$t_reg_info = "Tan pronto te hayas registrado, la contrase�a ser� enviada a tu correo.";

$t_regmail_head = "Te has registrado en el foro (%s). Esta es tu confirmaci�n.";
$t_regmail_user = "Tu nombre de usuario es: ";
$t_regmail_pass = "Tu contrase�a es: ";
$t_regmail_info = "La direcci�n del foro es: ";
$t_regmail_subject = "Has completado el registro en el foro";
$t_reg_conf = "�Registro terminado! Recibir�s la confirmaci�n a: %s"; // %s = email


/*
	Variables for search.php
*/

$t_search = "Buscar";
$t_results = "%s resultados para el foro \"%s\" encontrado(s).";
$t_found_nothing = "No hay resultados.  \"%s\" encontrado(s).";
$t_search_again = "Buscar nuevamente";

/*
	Variables for send.php
*/

$t_message_posted = "Mensaje publicado.";
$t_view_your_message = "Lee tu mensaje";
$t_mail_header = "%s ha respondido a tu mensaje en el foro '%s'"; // %s = nickname, forum name
$t_mail_link = "Este enlace te llevar� directamente a tu mensaje";
$t_mail_subject = "Responder a: %s"; // %s = subject of message

/*
	Variables for newmsg.php
*/

$t_new_msg_in_forum = "Nuevo mensaje en el foro \"%s\""; // %s = forum name
$t_new_reply_in_forum = "Responder a \"%s\" en el foro \"%s\""; // %s = subject of parent msg | forum name
$t_post_rules = "Los tags HTML ser�n filtrados y los links ser�n generados autom�ticamente. No es necesario forzar los saltos de l�nea con &lt;BR&gt;.";
$t_msg_from_field = "De: ";
$t_msg_subject_field = "Tema: ";
$t_msg_text_field = "Texto: ";
$t_email_notification = "Notif�quenme cuando un usuario responda a este mensaje.";
$t_attach_sig = "Poner mi firma personal a este mensaje.";

/*
	Variables for lost_pwd.php
*/

$t_enter_email_address = "Escriba su email";
$t_lostpwd_info = "Puedes obtener una nueva contrase�a escribiendo un nombre de usuario y email. Nuestro foro te enviar� una nueva contrase�a asociada con la direcci�n de email que nos des. Esta informaci�n se te ser� enviada a la direcci�n de email que escribas abajo.";
$t_pwd_sent = "Nueva contrase�a enviada.";

/*
	Globals	
*/

$t_btnupdate = "Modificar o Actualizar mi perfil";
$t_btnsignup = "�Inscr�bete en nuestros foros!";
$t_btnsearch = "Buscar";
$t_btnresetform = "Limpiar formulario";
$t_btnpostmsg = "Enviar mensaje";
$t_btnquote = "Incluir mensaje original en la respuesta";
$t_back_link = "Regresar";
$t_invalid_query = "�Consulta inv�lida!";
$t_btnsubmit = "Enviar";

/*
	Footer
*/

$t_forums_overview = "Descripci�n de los foros";
$t_back_to_forum = "Regresar al foro";
$t_register = "Reg�strate";
$t_edit_profile = "Editar perfil";
$t_logout = "Salir";
$t_administration = "Administraci�n";
$t_btngo = "Ir";
$t_jump_to = "Ir a...";
$t_lost_password = "�Olvidaste tu contrase�a?";

/*
	Error messages
*/

$terr_not_logged_in = "�No est�s conectado!";
$terr_no_admin_rights = "�No tienes derecho de ingreso al �rea administrativa!";
$terr_no_forum = "�No especificaste un foro!";
$terr_login_failed = "�Error al conectar!";
$terr_required_fields = "�No has especificado los campos requeridos!";
$terr_pwd_match = "�Las contrase�as no son iguales!";

$terr_nick_alpha = "�El nombre de usuario debe ser alfanum�rico!";
$terr_nick_len = "�El nombre de usuario debe tener al menos tres (3) caract�res!";
$terr_nick_reg = "�El nombre de usuario ya ha sido registrado!";
$terr_dbl_email = "�Ya existe un usuario con el email que ingresaste, por favor especifica otro!";

?>
