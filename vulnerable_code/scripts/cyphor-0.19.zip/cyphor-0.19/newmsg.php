<?
    // newmsg.php         Nachrichten erstellen
    // Alex Suzuki, erstellt am 7. Oktober 2000
    //
    // M�gliche Parameter - pid
    // ------------------------
    // pid: ID der Nachricht, auf die geantwortet wird.
    // fid: Forum ID

    include("include/db_mysql.php");
    include("include/settings.php");
    include("include/global.php");

    /* Include the language file */
    $lang_file = "lang/" . $language . ".php";
    include($lang_file);
	
    open_session();

	if ($login && $pass)
		login($login, $pass);
	else {
        exit_page_with_msg($terr_not_logged_in, "index.php", $t_login);
		exit();
    }

    if (!$fid) {
        exit_page_with_msg($terr_no_forum, "javascript:history.back()", $t_back_link);
        exit();
    }

    $db = new DB_Cyphor;
    $db->connect();
    $query = "SELECT * FROM $tbl_prefix" . "forums WHERE id=$fid";
    $db->query($query);
    if ($db->num_rows()) {
        $db->next_record();
        $discussion_name = $db->f("name");
        $db_table_name = $db->f("db_table_name");
		$db_table_name = $tbl_prefix . $db_table_name;
    } else
        exit();

    $query = "SELECT email FROM $tbl_prefix" . "users WHERE nick='$login'";
    $db->query($query);
    $db->next_record();
    $user_email_address = $db->f("email");

    if ($pid) {
        $reply_mode = 1;
        $query = "SELECT * FROM $db_table_name WHERE id=$pid";
        $db->query($query);
        $db->next_record();
        $p_message_author_id = $db->f("author_id");
        $p_message_title = $db->f("title");

		// get message text and quote it.
        $p_message_data = $db->f("data");
		$p_message_data = "> " . $p_message_data;
		$p_message_data = str_replace("\n", "\n> ", $p_message_data);
		$p_message_data = htmlspecialchars(StripSlashes($p_message_data));

		$title = sprintf($t_new_reply_in_forum, htmlspecialchars(StripSlashes($p_message_title)), htmlspecialchars(StripSlashes($discussion_name)));
    } else {
        $reply_mode = 0;
		$title = sprintf($t_new_msg_in_forum, $discussion_name);
    }
	
	
	
?>
<html>
<head>
    <title><? echo ($forum_title . " | " . $title); ?></title>
    <link rel="stylesheet" type="text/css" href="cyphor.css">
</head>
<body>

<table border=0 cellspacing=0 cellpadding=1 width=100%>

<tr><td class=border>

	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<?
			// Header
			print "<tr><td class=title><span class=bigh>" . $title . "</span></td></tr>";			
		?>
	</table>
	
</td></tr>

<tr><td class=border>

	<form action="send.php" method="POST">
	<input type="hidden" name="login" value="<? echo $login ?>">
	<input type="hidden" name="fid" value="<? echo $fid ?>">
	<?
	    if ($reply_mode) {
	        printf("<input type=\"hidden\" name=\"pid\" value=\"%s\">", $pid);
	        printf("<input type=\"hidden\" name=\"quote_text\" value=\"%s\">", $p_message_data);
	    }
	?>
	
	<table border=0 cellpadding=2 cellspacing=0 width=100%>	
	<tr>
		<td class=standard colspan=2>
		<span class=i>
			<? print $t_post_rules; ?>
		</span><br><br></td>
	</tr>
	
	<tr>
	    <td class=standard><span class=t><? echo $t_msg_from_field ?></span></td>
	    <td class=standard><span class=b><? echo $login ?></span></td>
	</tr>
	<tr>
	    <td class=standard><span class=t><? echo $t_msg_subject_field ?></span></td>
	    <?
	    	if ($reply_mode) {
				$subject = "RE: ";
				$subject .= htmlspecialchars(StripSlashes($p_message_title));
				$subject = strip_re($subject);
	    	} else {
				$subject = htmlspecialchars(StripSlashes($f_title));
			}
		?>
	    <td class=standard>
	    	<input class=formbox type="text" name="f_title" size="20" maxlength="100" value="<? echo $subject ?>">
	    </td>
	    
	</tr>
	<tr>
	    <td class=standard><span class=t><? echo $t_msg_text_field ?></span></td>
	    <td class=standard>
<textarea class=textarea name="f_data" cols="60" rows="15" wrap="virtual">
</textarea>
		</td>
	</tr>
	<tr>
	    <td class=standard colspan=2>
	    	<input class=formbox type="checkbox" name="f_mailreply" checked value="1">
	    	<span class=t>
	    		<?
	    			print $t_email_notification;
	    		    print " (" . $user_email_address . ")";
	    		?>
	    	</span>
	    </td>
	</tr>
	<tr>
	    <td class=standard colspan=2>
	    	<input class=formbox type="checkbox" name="f_with_signature" checked value="1">
	    	<span class=t>
	    		<?
	    			print $t_attach_sig;
	    		?>
	    	</span>
	    </td>
	</tr>
	
	<tr><td class=standard colspan=2 align=center>
		<span class=t>
			<input class=button type="submit" name="submit" value="<? echo $t_btnpostmsg ?>">
			<input class=button type="reset" name="reset" value="<? echo $t_btnresetform ?>">
			<?
				if ($reply_mode)
					print "<input class=button type=\"button\" value=\"" . $t_btnquote . "\" onClick=\"this.form.f_data.value=this.form.quote_text.value;\">"
			?>				
		</span>
		
		<br><br>	
	</td></tr>
	</table>

</td></tr>

<tr><td class=border>

<?
	include("include/footer.php");
?>
	
</td></tr>

</table>



</body>

</html>
