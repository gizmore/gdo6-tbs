<?
	if ($submit) {
		# Create database tables
		include("../include/db_mysql.php");	
		include("../include/settings.php");
		
		$db = new DB_Cyphor;
		$db->connect();
		
		$query = "CREATE TABLE $tbl_prefix" . "forums (
		   id int(11) NOT NULL auto_increment,
		   name varchar(50) NOT NULL,
		   short_desc varchar(255) NOT NULL,
		   db_table_name varchar(20) NOT NULL,
		   PRIMARY KEY (id))";
		$db->query($query);
	
		# Create table for the useronline script
		$query = "CREATE TABLE $tbl_prefix" . "useronline ( 
			time int(15) NOT NULL, 
			ip varchar(15) NOT NULL)";
		$db->query($query);
					
		$query = "CREATE TABLE $tbl_prefix" . "groups (
		   id int(11) NOT NULL auto_increment,
		   group_name varchar(40) NOT NULL,
		   allow_moderate tinyint(4) NOT NULL,
		   allow_admin tinyint(4) NOT NULL,
		   PRIMARY KEY (id))";
		$db->query($query);
				
		# Create basic user groups
		$query = "INSERT INTO $tbl_prefix" . "groups (group_name, allow_moderate, allow_admin)
				  VALUES ('users', '0', '0')";
		$db->query($query);				  
		$query = "INSERT INTO $tbl_prefix" . "groups (group_name, allow_moderate, allow_admin)
				  VALUES ('moderators', '1', '0')";
		$db->query($query);				  
		$query = "INSERT INTO $tbl_prefix" . "groups (group_name, allow_moderate, allow_admin)
				  VALUES ('admins', '1', '1')";				  
		$db->query($query);				  
		
		$query = "CREATE TABLE $tbl_prefix" . "user_settings (
		   id int(11) NOT NULL,
		   threads_per_page int(11) DEFAULT '20' NOT NULL,
		   signature varchar(255) NOT NULL)";
		$db->query($query);
		
		$query = "CREATE TABLE $tbl_prefix" . "users (
			id int(11) NOT NULL auto_increment,
			group_id int(11) DEFAULT '1' NOT NULL,
			nick varchar(15) NOT NULL,
			real_name varchar(50) NOT NULL,
			email varchar(100) NOT NULL,
			password varchar(50) NOT NULL,
			signup_date int(11) NOT NULL,
			last_post int(11) NOT NULL,
			total_posts int(11) NOT NULL,
			PRIMARY KEY (id),
			UNIQUE nick (nick, email))";
		$db->query($query);
				
		$query = "CREATE TABLE $tbl_prefix" . "forum_settings (
					field VARCHAR (20) not null,
					name VARCHAR (30) not null,
					value TEXT not null,
					PRIMARY KEY (field))";
		$db->query($query);
		
		// default terms of usage
		$terms = "Registration for this forum is free! If you agree to our rules below, you may sign up.<br><br>
		Considering the real-time nature of these discussions, it's impossible for us to review messages
		or confirm the validity of a message. Please remember that we do not actively
		monitor the contents of these discussions. The messages express the views of the author of the message,
		not necessesarily the views of the forum.";
		$terms = AddSlashes($terms);

		$query = "INSERT INTO $tbl_prefix" . "forum_settings VALUES('terms_of_usage', 'Terms of usage', '$terms')";
		$db->query($query);
		$query = "INSERT INTO $tbl_prefix" . "forum_settings VALUES('welcome_msg', 'Welcome message', '')";
		$db->query($query);
		
        $signup_date = time();        
        // GENERATE STANDARD PASSWORD
        $p = crypt("cyphor", "admin");
		$query = "INSERT INTO $tbl_prefix" . "users (group_id, nick, real_name, email, password, signup_date, total_posts)
		          VALUES ('3', 'admin', 'Administrator', 'admin@admin', '$p', '$signup_date', '0')";
		$db->query($query);
		
		$query = "INSERT INTO $tbl_prefix" . "user_settings (id, threads_per_page, signature) VALUES('1', '20', '-\nthe admin')";
		$db->query($query);
			
		
		printf("<html><head><title>Done!</title></head><body>");
		printf("<h1>Databases initialized!</h1>
				: Created user <b>admin</b> with password <b>cyphor</b>. <a href=\"../index.php\">Login now</a> to change password.");
		printf("</body></html>");
		exit();
	}
?>

<html>

<head>
	<title>Cyphor - Setupscript</title>
</head>

<body>
	<h1>Database setup</h1>
	Make sure you have correctly configured all your database settings in /include/settings.php. You will
	see error messages if you did not do so. If you haven't already done so, read README.TXT.
	
	<form action="<? echo $PHP_SELF ?>" method="POST">
		<input type="submit" name="submit" value="Setup database (press once)">
	</form>
</body>

</html>
