Cyphor - README.TXT
*******************

GENERAL
*******
Cyphor is a configurable Webforum, which uses PHP4's session capabilities to authenticate users,
the MySQL database system to store all its data in, and Cascading Style Sheets (CSS) to configure
the "Look and Feel" of the forum.

Cyphor is NOT compatible with Win32 systems, this is because it encodes the user passwords using the crypt call which is only available on UNIX systems. I'm looking for a decent workaround. Note that Cyphor will RUN, but all passwords in the database are 0. (thanks to Tim Finnegan for pointing this out).

REQUIREMENTS
************

What do you need to run Cyphor?
*******************************

- PHP4 (http://www.php.net) or higher
- Running MySQL (http://www.mysql.com), should work with any recent version of MySQL
- A MySQL database
- Ability to create MySQL Tables

Viewing
*******
- Your users need a browser that understands CSS1-Stylesheets (every modern browser does)



INSTALLATION
************

Step 1
******
Extract the content of the compressed archive you downloaded from our website (www.cynox.ch/cyphor.php)
to a directory on your machine. It doesn't matter where you put it, you'll upload it later to your
webserver.

Step 2
******
It's time to configure Cyphor. Open the file "DIRECTORY/include/settings.php" in your favorite
editor. DIRECTORY the path to the directory where you extracted the files from the archive.

You first need to tell Cyphor where to store its data, so you need to configure the MySQL settings.

	var $Database = "cyphor";

Change the value of Database to an existing MySQL database name.
	
	var $User = "mysql_user";

Change "mysql_user" to your MySQL username.
This user must have CREATE SELECT, INSERT, DELETE, DROP grants on the database, basically everything.
	
	var $Password = "my_password";

Change "my_password" to the password of your MySQL user.


In this example we assume that MySQL is running on the same machine like your
webserver, so in most cases

	$Host = "localhost"

will apply. However, if you have a MySQL server running on a different machine, specify it's IP address.

	$Host = "123.123.123.123"

You're done with the MySQL settings. Now let's move on to configuring the forum itself.

	$forum_title = "My Discussions"

Change this to the name of your forum. It will be displayed on virtually an forumpage you run into.

	$forum_url = "http://www.domain.ext/cyphor"

Change this to the URL where your forum resides, so if you uploaded it to a directory called "forum"
type "http://www.domain.ext/forum", don't forget the http://

	$admin_email = "admin@domain.ext"
	
Change this to your email. It will be displayed when database error messages occur.
That's it, you're finished configuring Cyphor.

Step 3
******
Save the file settings.php. Maybe you have already noticed that there is another file in that
directory, called "settings.default.php", it contains the default settings, so you can always revert
back to them.

Step 4
******
Upload the whole directory "cyphor" with its subdirectories to your webserver, I assume you no how
this works, using your favorite FTP client.

Step 5
******
It's time to create the databases. I have included a script that does all the dirty work for you,
creating the MySQL tables, the user groups, and the admin user. The script is a file called "setup.php"
that resides in the "install" subdirectory. Point your browser to it.
Hit the button that says "Setup database". If you configured everything correctly, no error messages
should show up. All the tables should have been created for you now. You can use a tool like phpMyAdmin
(www.phpwizard.net) to check if you like. You should delete the file setup.php as soon as the forum is
up and running.

Step 6
******
You did it! Cyphor is now up and running, but no forums have yet been configured, and only one
user, namely "admin" exists. His password is "cyphor". Be sure to change it ASAP by logging in and
editing your profile.

Step 7
******
As soon as you've changed your password, go to the Administration console. (the link appears on the
bottom right of the pages)
Now start creating forums and....... have fun!