<?		
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    
	include("check.php");
	
	if (!$field) exit();

	$db = new DB_Cyphor;
	$db->connect();
	
	if ($submit && $field) {
		$value = AddSlashes($value);
		$query = "UPDATE $tbl_prefix" . "forum_settings SET value='$value' WHERE field='$field'";
		$db->query($query);
		admin_exit_page("Field ($name) updated!", "index.php", "Back to Administration");
		exit();
	}
	
	$query = "SELECT * FROM $tbl_prefix" . "forum_settings WHERE field='$field'";
	$db->query($query);	
	$db->next_record();
?>
<html>
<head>
    <title>Edit field: <? echo $db->f("name"); ?></title>
    <link rel="stylesheet" href="admin.css" type="text/css">
</head>

<body>
    <span class=h>Edit field: <? echo $db->f("name"); ?></span><br><br>
    
    <form action="<? echo $PHP_SELF; ?>" method="POST">
    	<textarea name="value" cols=50 rows=10><? echo StripSlashes($db->f("value")) ?></textarea>
    
    	<br><br>
    	<input type="hidden" name="field" value="<? echo $db->f("field") ?>">
    	<input type="hidden" name="name" value="<? echo $db->f("name") ?>">
    	<input type="submit" name="submit" value="Update">
	</form>
	    
    <br><br>
    <span class=t><a href="index.php">Back to Administration</a></span>
</body>

</html>