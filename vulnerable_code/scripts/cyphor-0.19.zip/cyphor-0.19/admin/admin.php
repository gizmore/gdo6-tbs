<?
    function admin_exit_page($msg, $link_url, $link_title) {
            printf("<html><head><title>%s</title><link rel=\"stylesheet\" href=\"../cyphor.css\" type=\"text/css\"></head>", $msg);
            printf("<body bgcolor=\"#FFFFFF\" text=\"#000000\"><span class=h>%s</span><br>", $msg);
            printf("<span class=t><a href=\"%s\">%s</a></span></body></html>", $link_url, $link_title);
    }

?>
