<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    
    $db = new DB_Cyphor;
    $db->connect();
    	
	# CHECKS IF YOU'RE AN ADMIN
	include("check-moderator.php");

	if ($submit && $forum && $days && ($ok == "OK")) {
		# DELETION CONFIRMED, DELETES ALL THREADS THAT ARE OLDER THAN $days DAYS
		$total = delete_old_threads($days, $forum);
		admin_exit_page("$total Threads deleted.", "index.php", "Back to Administration");
		exit();
	}
?>
<html>
<head>
    <title>Delete Old Threads</title>
    <link rel="stylesheet" href="admin.css" type="text/css">
</head>

<body>
    <span class=h>Delete Old Threads</span><br><br>
	
	<form action="<? echo $PHP_SELF ?>" method="POST">
		<span class=t>		
			Delete all threads of forum
			<select name="forum" size="1">
				<option value="all" selected>[ALL FORUMS]</option>
            <?
                $query = "SELECT id, name FROM $tbl_prefix" . "forums ORDER BY id ASC";
                $db->query($query);
                while ($db->next_record())
                    printf("<option value=\"%s\"> %s</option>", $db->f("id"), $db->f("name"));
            ?>
			</select>
			
			that are older than
			<input type="text" name="days" size=5> days.<br>
			Confirm (type OK): <input type="text" name="ok" size=2 maxlength=2><br>
			<span class=red>Warning: This a final decision. The threads cannot be restored.</span>
			<br><br>
			<input type="submit" name="submit" value="Delete Threads">
		</span>
	</form>
    <br><br>
    <span class=t><a href="index.php">Back to Administration</a></span>
</body>

</html>
