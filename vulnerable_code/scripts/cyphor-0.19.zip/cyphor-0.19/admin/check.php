<?
    # Start PHP4 Session
    open_session();	

	$admin = 0;
	$moderator = 0;

	# AUTHENTICATION
    if (!$login || !$pass) {
        admin_exit_page("Not logged in!", "../index.php", "Login"); exit();
    } else
    	if (login($login, $pass)) {
    		if (!$admin) {
		    	admin_exit_page("User does not have admin rights!", "../index.php", "Login"); exit();
		    }
    	} else {
    		admin_exit_page("Login failed!", "../index.php", "Login"); exit();
    	}
    # END AUTHENTICATION
?>