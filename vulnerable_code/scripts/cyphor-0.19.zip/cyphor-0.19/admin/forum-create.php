<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    
	include("check.php");

	if ($submit) {		
	    $db = new DB_Cyphor;
	    $db->connect();
	
	    $query = "SELECT * FROM $tbl_prefix" . "forums WHERE name='$f_name'";
	    $db->query($query);
	    if ($db->num_rows()) {
	        admin_exit_page("A forum with the name '$f_name' already exists!", "javascript:history.back()", "Back"); exit();
	    }
	
	    $query = "SELECT * FROM $tbl_prefix" . "forums WHERE db_table_name='$f_db_table_name'";
	    $db->query($query);
	    if ($db->num_rows()) {
	    	admin_exit_page("A MySQL table with the name '$tbl_prefix" . "$f_db_table_name' already exists!", "javascript:history.back()", "Back"); exit();
	    }
	
		$name = AddSlashes($name);
		$short_desc = AddSlashes($short_desc);
	
	    $query = "INSERT INTO $tbl_prefix" ."forums (name, short_desc, db_table_name) VALUES('$f_name', '$f_short_desc', '$f_db_table_name')";
	    $db->query($query);
	
	    $query = "CREATE TABLE $tbl_prefix" . "$f_db_table_name (id INT not null AUTO_INCREMENT, parent_id INT not null , thread_id INT not null , author_id INT not null , date INT not null , title VARCHAR (100) not null , data TEXT not null , mail_reply SMALLINT not null, hostname CHAR(30) not null, num_read INT DEFAULT '0' not null, PRIMARY KEY (id))";
	    $db->query($query);
	
	    admin_exit_page("Forum created successfully!", "index.php", "Back to Administration");
	    exit();
	}
?>

<html>
<head>
	<title>Create A New Forum</title>
	<link rel="stylesheet" href="admin.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">

<span class=h>Create A New Forum</span><br><br>

<form action="<? echo $PHP_SELF ?>" method="POST">
 
<table border=1 cellspacing=0 cellpadding=3>
	<tr>
	    <td><span class=b>Name</span></td>
	    <td><input type="text" name="f_name" size="30" maxlength="50"></td>
	</tr>
	<tr>
	    <td><span class=b>Short description (max. 255 chars)</span></td>
	    <td><textarea cols="40" rows="3" name="f_short_desc" maxlength="255" wrap=virtual></textarea></td>
	</tr>
	<tr>
	    <td><span class=b>MySQL-Tablename (no spaces, for example: "msg_test") <b>Table prefix will be added automatically</b>.</span></td>
	    <td><input type="text" name="f_db_table_name" size="20" maxlength="20"></td>
	</tr>
	<tr><td colspan=2 align=center>
        <span class=red>Hit button only once!</span><br>
		<input type="submit" name="submit" value="Create Forum">
	</td></tr>
</table>

</form>

<br><br>
<span class=t><a href="index.php">Back to Administration</a></span>

</body>
</html>