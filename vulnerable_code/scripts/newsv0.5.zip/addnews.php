<!--
This script was made by James-inlineshots.com on 20th April 05
Ripping is not allowed and if we find out we will report you
You may modify the script as much as you want without taking 
our link of the admin page
thanks

James
--><?
$date = date("l d F "); 
$dataf = "news.php";         // Which the shout save
$length = 100;                 // How long the message can be
$comments = 12;             // How many message to appear


if (!$name)
{ $name = "!!!!!!!!!!HACKER!!!!!!!!!!!!"; }
else $name .= "";


$story = stripslashes($story);
$comfile = file($dataf);


if ($story != "") {$df = fopen ($dataf, "w");
$story = stripslashes($story);fwrite ($df, "<p><table width='100%'  border='0' cellspacing='0'><tr><td width='94%' valign='bottom'><strong><a href='mailto:$email'>$name</a> - $title </strong></td></tr><tr><td><em><font color='#CCCCCC'>$story</font></em></td></tr><tr><td><hr></td></tr><tr><td><div align='left'><p>$date posted by - $name</p></div></td></tr></table></p> 
");
for ($i = 0; $i < $comments; $i++) {fwrite ($df, $comfile[$i]);}fclose($df);}
?>
 News posted! <br>
 <?php echo $df; ?>