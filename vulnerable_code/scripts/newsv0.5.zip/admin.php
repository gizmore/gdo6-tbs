<!--
This script was made by James-inlineshots.com on 20th April 05
Ripping is not allowed and if we find out we will report you
You may modify the script as much as you want without taking 
our link of the admin page
thanks

James
-->
<?
$pass = "webmaster";
if (  $password == $pass )
{
?>


<strong>Welcome to IS simple news v0.5</strong>
<p><strong>Add news 
</strong>
<form action="addnews.php" method="post" enctype="multipart/form-data">
  <table width="60%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="13%">posted by </td>
    <td width="87%"><input name="name" type="text" id="name"></td>
  </tr>
  <tr>
    <td>email</td>
    <td><input name="email" type="text" id="email"></td>
  </tr>

  <tr>
    <td>Title</td>
    <td><input name="title" type="text" id="title" size="54"></td>
  </tr>
  <tr>
    <td>story</td>
    <td><textarea name="story" cols="50" rows="10" id="story"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Post">
      <input type="reset" name="Reset" value="Reset"></td>
  </tr>
</table>

</form></p>
<?
}
else
{ ?>
Please refrain from hacking its kinda annoying you little pathetic she man 
<? } ?>
