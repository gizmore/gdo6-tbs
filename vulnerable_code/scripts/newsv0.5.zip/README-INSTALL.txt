-----------<}IS simple news{<-----------------

This script was made by inlineshots.com no hacking!!!!!

Install<------------

>1< 	Edit the variables in config.php
>2< 	Upload everything to a subdirectory (do not add any folders 
	or rename any files)
>3<	CHMOD the news.php permissions to (777) via ftp or your cpanel file
	manager
>4<	Load up http://www.yourdomain.com/news_directory and logg in with 
	the password you set in config.php

Help/Support<-------

>1< 	Go to http://inlineshots.com/support/index.php?id=newsv0-5
if that fails
>2<	http://inlineshots.com/v7/contact.php

Remotely hosted?<---

>1<	Go to http://www.inlineshots.com/v7/hosting.php?id=script

Updates? <----------

>1<	Go to http://inlineshots.com/scripts/updates.php?id=newsv0-5

// This will help insure you get the latest version with fixed errors if 
some pop-up and more advanced features
