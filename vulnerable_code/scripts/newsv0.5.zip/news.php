<p><table width='100%'  border='0' cellspacing='0'><tr>
  <td width='94%' valign='bottom'><strong><a href='mailto:inlineshots@msn.com'>James-inlineshots.com</a> - Welcome to inlineshots </strong></td>
</tr><tr><td><em><font color='#CCCCCC'>Hey welcome to the new version of inlineshots. We have many cool new things on the site including a nice tutorial area code generators, snippets, scripts great services, gfx section and much more content is higher than ever! We now have a new domain aswell - inlineshots.com I am now going about making tutorials templates and scripts so there will still be a lot of updates to come on version 7!</font></em></td></tr><tr><td><hr></td></tr><tr><td><div align='left'>
  <p>Wednesday 20 April  posted by - James-inlineshots.com</p>
</div></td></tr></table>
