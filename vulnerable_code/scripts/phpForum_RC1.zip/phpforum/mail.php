<?php
        include("head.php");        //Header mit Bild, Suchen...
        access("send_mail");        //Zugriff beschr�nken
echo "<br>";

$userinfo = get_user_info($HTTP_GET_VARS[id]);

//User eMail-nicht Public
if (!$userinfo[email_show]) {
    msg("user", "2", "back()");
}

###################################### eingabe Form. #################################### +++
if (!$HTTP_GET_VARS[action] AND !$HTTP_POST_VARS[action]) {
    ?>
    <form method='post' action='<?php echo "mail.php?$Sess_Name=$Sess&id=$HTTP_GET_VARS[id]"; ?>'>
          <input type='hidden' name='action' value='send'>
          <input type='hidden' name='gz_site' value='off'>
          <?php table_header("eMail verschicken an: $userinfo[name]", "90%", "1", "colspan='2'"); ?>
                <tr>
                    <td width='40%' class='cat_two'>
                        <b>Angemeldet als:</b>
                    <td width='60%' class='cat_one'>
                        <b><?php echo "$HTTP_SESSION_VARS[USER_Log]&nbsp;"; ?></b><?php echo "<a href='login.php?$Sess_Name=$Sess&action=logout'>[logout]</a>"; ?>
                    </td>
                <tr>
                    <td width='40%' class='cat_two'>
                        <b>Betreff:</b>
                    <td width='60%' class='cat_one'>
                        <input type='text' name='subject' size='50' maxlength='255' tabindex='1' value='<?php echo $HTTP_GET_VARS[subject]; ?>'>
                    </td>
                <tr>
                    <td width='40%' valign='top' class='cat_two'>
                        <b>Nachricht:</b><br><br>
                        <span class='font_small'>
                              Anmerkung:Wenn sie dieses Formular benutzen,<br>
                              wird dem Empf�nger ihre eMail-Adresse mitgeteilt.
                        </span>
                    <td width='60%' class='cat_one'>
                        <textarea name='message' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' tabindex='2'><?php echo $HTTP_GET_VARS[message]; ?></textarea>
                    </td>
                </tr>
          </table>
          <p></p>
          <center>
                  <input type='submit' value='senden' tabindex='3'>&nbsp;<input type='reset' value='zur�cksetzen' tabindex='4'>
          </center>
    </form>
    <?php
###################################### eingabe Form. #################################### ---
#
#
####################################### Nachricht senden ################################ +++
} elseif (!$HTTP_GET_VARS[action] AND $HTTP_POST_VARS[action] == "send") {

    //nicht alle Felder ausgef�llt
    if(!$HTTP_GET_VARS[id] OR !$HTTP_POST_VARS[subject] OR !$HTTP_POST_VARS[message]) {
       msg("email_fault", "2", "back()");
    }

    $from=get_user_info("");

    if (user_exist($HTTP_GET_VARS[id])) {
        if(mail($userinfo[email], StripSlashes($HTTP_POST_VARS[subject]), "Hallo!\n\nDiese Nachricht kommt von $from[name] ($from[email]), sie wurde mit dem eMail-Formular von $TITEL_KURZ (http://$SITE/index.php) verschickt.\n\nNachricht:\n".StripSlashes($HTTP_POST_VARS[message])."\n\n\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\nN�tzliche Links:\n\nForum Index:\nhttp://$SITE/index.php\n\neMail Formular:\nhttp://$SITE/mail.php?id=$from[id]", "From: $from[name] <$from[email]>\nReturn-Path: <$GLOBALS[SITE_ADMIN]>")) {
           $Fehler = "email";
           $goto = "index.php";
        } else {
           $Fehler="email_fault";
           $goto = "back()";
        }

    } else {
        $Fehler="email_fault";
        $goto = "back()";
    }

    msg($Fehler, "2", $goto);
}
####################################### Nachricht senden ################################ ---
echo "<br>";
footer();
?>