<?php
// DB - Einstellungen
$DB_SERVER = "";
$DB_USER = "";
$DB_PASS = "";
$DB_NAME = "";
$DOMAIN = "";
$SITE = "";
$MAIN_PATH = "";

// Namen der DB-Tabellen
$TB_USER = "users";                                //Benutzer
$TB_STATUS = "status";                             //Status des Users (Member...)
$TB_ACCESS = "access";                             //Benutzergruppen
$TB_CAT = "categories";                            //Kategorien
$TB_FORUM = "forums";                              //Foren
$TB_TOPIC = "topics";                              //Topics
$TB_POST = "posts";                                //Beitr�ge
$TB_MOD = "forums_mods";                           //Forum-Mods
$TB_SEARCH = "search";                             //Suche
$TB_ABO = "topic_abo";                             //Topic - Abo�s
$TB_AVATARS = "avatars";                           //Benutzer Avatare
$TB_FILES = "attachements";                        //Datei Anh�nge
$TB_SMILIES = "smilies";                           //Smilies :)
$TB_MSG = "priv_msgs";                             //Private Nachrichten
$TB_WORDS = "words";                               //Words (F***, ...)
$TB_SESSION = "sessions";                          //Sessions (Who is Online)
$TB_BBCODES = "bb_codes";                          //Board Codes [b]fett[/b]
$TB_SETTINGS = "settings";                         //Einstellungen
$TB_SETTING_GROUP = "setting_groups";              //Einstellung�s Gruppen
$TB_FORUM_ACCESS = "forums_access";                //Sonder-zugriffsrechte der Foren
$TB_POLL = "poll";                                 //Umfragen (Haupttabelle)
$TB_POLL_USER = "poll_users";                      //Umfragen (Benutzer die ihre Stimme schon abgegeben haben)
$TB_POLL_TEXT = "poll_texts";                      //Umfragen (Auswahlm�glichkeiten)
$TB_STYLES = "styles";                             //Foren-Styles
?>