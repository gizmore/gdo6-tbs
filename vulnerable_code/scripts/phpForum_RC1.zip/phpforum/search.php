<?php
        include("head.php");        //Header mit Bild, Suchen...
        access("search");           //Zugriff beschr�nken

switch ($HTTP_GET_VARS[action]) {

        case "":
              search_form();
              break;

        case "search":
              get_sql();
              break;

        case "result":
              search_result($HTTP_GET_VARS[search_id], $HTTP_GET_VARS[typ]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
#
#
##################### Such Formular ##################### +++
function search_form() {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=search"; ?>'>
               <input type='hidden' name='get' value='text'>
               <?php
               table_header("phpForum - Suche...","100%","", "colspan='2'");
               ?>
                <tr class='default_tr'>
                    <td width='70%' align='center'>
                        <b>Suche nach Schl&uuml;sselwort</b>
                    <td width='30%' align='center'>
                        <b>Benutzer</b>
                    </td>
                <tr>
                    <td width='70%' valign='top' align='left' class='cat_one'>
                        <br>
                        <input type='text' name='search' maxlength='50' size='45' tabindex='1'>
                        <br><br>
                        <b>Suche:</b>
                        <br>
                        <span class='font_small'>
                              <b>-</b> Sie k&ouml;nnen "AND" und "OR" benutzen um detailierter zu suchen
                        </span>
                    <td width='30%' valign='top' align='left' class='cat_one'>
                        <p>
                           <br>
                           <input type='text' name='search_user' maxlength='50' size='20' tabindex='2'>
                           <br><br>
                           <input type='radio' name='user_typ' value='exact' checked> Exakter Name<br>
                           <input type='radio' name='user_typ' value='teil'> Teil eines Namens
                        <p>
                    </td>
                </tr>
               </table>
         <p><p>
               <?php
               table_header("Such Optionen...","100%","", "colspan='3'");
               ?>
                <tr class='default_tr'>
                    <td width='40%' align='center'>
                        <b>Durchsuche Forum...</b>
                    <td width='30%' align='center'>
                        <b>Anzeigen...</b>
                    <td width='30%' align='center'>
                        <b>Treffer Sortieren...</b>
                    </td>
                <tr>
                    <td width='40%' valign='top' align='center' class='cat_one'>
                        <p>
                           <br>
                           <select name='search_forum' tabindex='5'>
                                   <option value='%'>### Suche in allen Foren ###</option>
                                   <?php
                                   $result = mySQL_query ("SELECT $GLOBALS[TB_FORUM].id, $GLOBALS[TB_FORUM].name
                                                           FROM $GLOBALS[TB_FORUM], $GLOBALS[TB_CAT]
                                                           WHERE $GLOBALS[TB_FORUM].show_forum='on'
                                                             AND $GLOBALS[TB_FORUM].cat_id=$GLOBALS[TB_CAT].id
                                                             AND $GLOBALS[TB_CAT].show_cat='on'
                                                           ORDER BY $GLOBALS[TB_FORUM].name");
                                   while ($Daten = mysql_fetch_array ($result)) {
                                          echo "<option value='$Daten[id]'>$Daten[name]</option>\n";
                                   }
                                   ?>
                           </select>
                        </p>
                    <td width='30%' valign='top' align='left' class='cat_one'>
                        <p>
                           <br>
                           <input type='radio' name='show_typ' value='forum' checked> Treffer als Themen anzeigen<br>
                           <input type='radio' name='show_typ' value='topic'> Treffer als Beitr&auml;ge anzeigen
                        </p>
                    <td width='30%' valign='top' align='left' class='cat_one'>
                        <p>
                           <br>
                           <input type='radio' name='sort_typ' value='DESC' checked>  neuster Beitrag zuerst<br>
                           <input type='radio' name='sort_typ' value='ASC'> &auml;ltere Beitr&auml;ge zuerst
                        <p>
                    </td>
                </tr>
               </table>
               <br>
               <div align='center'>
                    <input type='submit' value='Suchen' tabindex='3'>
                    &nbsp;<input type='reset' name='Reset' value='Zur&uuml;cksetzen' tabindex='4'>
               </div>
         </form>
         <?php
}
##################### Such Formular ##################### ---
#
#
##################### Such Ergebnisse ##################### +++
function search_result($search_id, $typ) {
         global $HTTP_GET_VARS, $HTTP_SERVER_VARS, $_style;
         //Search_id daten herraussuchen
         $Sql = mysql_fetch_array(mySQL_query ("SELECT *
                                                FROM $GLOBALS[TB_SEARCH]
                                                WHERE id='$search_id'"));
         if (user_login() == TRUE) {
             $userinfo = get_user_info("");
         } else {
             $userinfo[access_id] = $GLOBALS[NO_LOGIN];
         }
         $Daten_sql[sql] = "SELECT $GLOBALS[TB_POST].id,
                                   $GLOBALS[TB_POST].topic_id,
                                   $GLOBALS[TB_TOPIC].forum_id,
                                   $GLOBALS[TB_TOPIC].views,
                                   $GLOBALS[TB_TOPIC].posts,
                                   $GLOBALS[TB_TOPIC].name AS topic_name,
                                   $GLOBALS[TB_TOPIC].poster_id,
                                   $GLOBALS[TB_FORUM].name AS forum_name
                            FROM $GLOBALS[TB_POST], $GLOBALS[TB_TOPIC], $GLOBALS[TB_FORUM], $GLOBALS[TB_CAT], $GLOBALS[TB_FORUM_ACCESS]
                            WHERE $GLOBALS[TB_TOPIC].id=$GLOBALS[TB_POST].topic_id
                                  AND $GLOBALS[TB_TOPIC].show_topic='on'
                                  AND $GLOBALS[TB_FORUM].show_forum='on'
                                  AND $GLOBALS[TB_TOPIC].forum_id=$GLOBALS[TB_FORUM].id
                                  AND $GLOBALS[TB_FORUM_ACCESS].forum_id=$GLOBALS[TB_FORUM].id
                                  AND $GLOBALS[TB_FORUM_ACCESS].view='on'
                                  AND $GLOBALS[TB_CAT].id=$GLOBALS[TB_FORUM].cat_id
                                  AND $GLOBALS[TB_FORUM_ACCESS].access_id='$userinfo[access_id]' ".$Sql[sql];

         $Topic_anz = mySQL_num_rows(mysql_query($Daten_sql[sql]));

         //wenn Result == 0
         if ($Topic_anz == 0 OR !$search_id OR !$Sql[sql]) {
             @mysql_query("DELETE FROM $GLOBALS[TB_SEARCH] WHERE id='$search_id'");
             msg("search_null", "", "");
         }

         //f�r Navigation
         if ($typ == "topic") {
             $max = $GLOBALS[ANZ_POST];
         } else {
             $max = $GLOBALS[ANZ_TOPIC];
         }

         //wenn keine Page �bergeben wurde
         if (!$HTTP_GET_VARS[Page]) {
             $HTTP_GET_VARS[Page] = "1";
         }
         ### anzeigen als: Forum
         if ($HTTP_GET_VARS[typ] == "forum" OR !$HTTP_GET_VARS[typ]) {
             //f�r die LIMIT
             if ($Topic_anz > $GLOBALS[ANZ_TOPIC]) {
                 $p=$HTTP_GET_VARS[Page]-1;
                 $L_AB=$GLOBALS[ANZ_TOPIC]*$p;
             }
             if ($L_AB < "0") {
                 $L_AB="0";
             }
             $Daten_sql[sql] .= " LIMIT $L_AB,$GLOBALS[ANZ_TOPIC]";
             $navi_extra = "colspan='7'";
             $result_sql = mySQL_query ($Daten_sql[sql]);
             ?>
             <BR>
             <?php
             echo "<table width='100%' cellspacing='0' cellpadding='0'><tr><td width='50%' class='font_normal'>Zeige Themen: ";
             echo $L_AB+1;
             echo " bis ";
             echo $L_AB+mysql_num_rows($result_sql);
             echo " von ".$Topic_anz."</td>";
             //Seiten - Navigation
             echo "<td width='50%' align='right'>".navi($HTTP_GET_VARS[Page], $Topic_anz, $max, "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result&search_id=$search_id&typ=$HTTP_GET_VARS[typ]")."</td></tr></table>";
             ?>
             <table border='0' cellpadding='2' cellspacing='1' width='100%' class='default_table'>
                    <tr class='default_tr'>
                        <td width='3%' align='center'>
                            &nbsp;
                        <td width='32%'>
                            <B>Thema</B>
                        <td width='20%' NOWRAP align='center'>
                            <b>Forum</b>
                        <td width='10%' NOWRAP align='center'>
                            <b>Antworten</b>
                        <td width='5%' NOWRAP align='center'>
                            <b>Hits</b>
                        <td width='15%' NOWRAP align='center'>
                            <b>Letzter Beitrag</b>
                        <td width='15%' NOWRAP align='center'>
                            <b>erstellt von</b>
                        </td>
                    </tr>
                    <?php
         ### anzeigen als: Thema
         } elseif ($HTTP_GET_VARS[typ] == "topic") {
             //f�r die LIMIT
             if ($Topic_anz > $GLOBALS[ANZ_POST]) {
                 $p=$HTTP_GET_VARS[Page]-1;
                 $L_AB=$GLOBALS[ANZ_POST]*$p;
             }
             if ($L_AB < "0") {
                 $L_AB="0";
             }
             $Daten_sql[sql] .= " LIMIT $L_AB,$GLOBALS[ANZ_POST]";
             $navi_extra = "colspan='6'";
             $result_sql = mySQL_query ($Daten_sql[sql]);
             ?>
             <BR>
             <?php
             echo "<table width='100%' cellspacing='0' cellpadding='0'><tr><td width='50%' class='font_normal'>Zeige Themen: ";
             echo $L_AB+1;
             echo " bis ";
             echo $L_AB+mysql_num_rows($result_sql);
             echo " von ".$Topic_anz."</td>";
             //Seiten - Navigation
             echo "<td width='50%' align='right'>".navi($HTTP_GET_VARS[Page], $Topic_anz, $max, "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result&search_id=$search_id&typ=$HTTP_GET_VARS[typ]")."</td></tr></table>";
             ?>
             <table border='0' cellpadding='2' cellspacing='1' width='100%' class='default_table'>
                    <tr class='default_tr'>
                        <td width='3%' align='center'>
                            &nbsp;
                        <td width='35%'>
                            <B>Thema</B>
                        <td width='20%' NOWRAP align='center'>
                            <b>Forum</b>
                        <td width='10%' NOWRAP align='center'>
                            <b>Antworten</b>
                        <td width='5%' NOWRAP align='center'>
                            <b>Hits</b>
                        <td width='15%' NOWRAP align='center'>
                            <b>erstellt von</b>
                        </td>
                    </tr>
                    <?php
         }
         #
         ### Navigation ### +++
         ?>
         <tr>
             <td width='100%' valign='top' <?php echo $navi_extra; ?> class='cat_tr'>
                 <b><a href='<?php echo "index.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'><?php echo $GLOBALS[TITEL_KURZ]; ?></a>&nbsp;:&nbsp;<a href='<?php echo "search.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>Suche</a>&nbsp;-&nbsp;<?php echo $Sql[name]; ?>&nbsp;-</b>
             </td>
         </tr>
         <?php
         ### Navigation ### ---
         #
         #
         ### Liste erstellen
         $anz=0;
         while ($Daten = mysql_fetch_array ($result_sql)) {

                //ist eine Umfrage ?
                $Poll = mysql_num_rows (mySQL_query ("SELECT *
                                                      FROM $GLOBALS[TB_POLL]
                                                      WHERE $GLOBALS[TB_POLL].topic_id='$Daten[topic_id]'"));

                ##### TABELLE #####
                ?>
                <tr>
                <?php
                ### Als Thema anzeigen  ### +++
                if ($typ == "forum" OR !$typ) {
                    echo "<td width='3%' align='center' class='cat_two'>";
                    echo topic_new($Daten[topic_id]);
                    ?>
                    <td width='35%' class='cat_one'>
                        <?php if ($Poll == 1) { echo "Umfrage: ";} ?>
                        <b><a href='<?php echo "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$Daten[topic_id]"; ?>'><?php echo $Daten[topic_name]; ?></a></b>
                    <td width='20%' align='center' class='cat_one'>
                        <b><a href='<?php echo "showforum.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Forum_id=$Daten[forum_id]"; ?>'><?php echo $Daten[forum_name]; ?></a></b>
                    <td width='10%' align='center' class='cat_two'>
                        <b><?php echo $Daten[posts]; ?></b>
                    <td width='5%' align='center' class='cat_one'>
                        <b><?php echo $Daten[views]; ?></b>
                    <td width='15%' align='center' class='cat_two'>
                        <span class='font_small'>
                              <?php
                              $last_post = last_post($Daten[topic_id]);
                              echo "<a href='showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$Daten[topic_id]&goto=lastpost' title='Gehe zum letzten Beitrag'><img src='$_style[pic_last_post]' border='0' alt='Gehe zum letzten Beitrag'></a>&nbsp;von&nbsp;<a href='showuser.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=$last_post[user_id]'>$last_post[user_name]</a>";
                              echo "<br>am&nbsp;$last_post[post_date]";
                              ?>
                        </span>
                    <td width='15%' align='center' class='cat_one'>
                        <?php $userinfo = get_user_info($Daten[poster_id]); ?>
                        <a href='<?php echo "showuser.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=$userinfo[id]"; ?>'><?php echo $userinfo[name]; ?></a>
                    </td>
                </tr>
                <?php
                ### Als Beitrag anzeigen ??? ### +++
                } elseif ($typ == "topic") {

                    //Text des Beitrag�s
                    $Daten_post = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_POST].text
                                                                  FROM $GLOBALS[TB_POST]
                                                                  WHERE topic_id='$Daten[topic_id]'
                                                                  ORDER BY $GLOBALS[TB_POST].id
                                                                  LIMIT 0,1"));

                    echo "<td width='3%' align='center' class='cat_two'>";
                    echo topic_new($Daten[topic_id]);
                    ?>
                    <td width='35%' align='center' class='cat_one'>
                        <span class='font_small'>
                              <table border='0' align='left' width='100%'>
                                     <tr>
                                         <td width='100%' colspan='2'>
                                             <span class='font_small'>
                                                   Thema:&nbsp;<b><a href='<?php echo "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$Daten[topic_id]"; ?>'><?php echo $Daten[topic_name]; ?></a></b>
                                             </span>
                                     <tr>
                                         <td width='40%'>
                                             <span class='font_small'>
                                                   <?php
                                                   $last_post = last_post($Daten[topic_id]);
                                                   echo "<a href='showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$Daten[topic_id]&goto=lastpost' title='Gehe zum letzten Beitrag'><img src='$_style[pic_last_post]' border='0' alt='Gehe zum letzten Beitrag'></a>&nbsp;von&nbsp;<a href='showuser.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=$last_post[user_id]'>$last_post[user_name]</a>";
                                                   echo "<br>am&nbsp;$last_post[post_date]";
                                                   ?>
                                             </span>
                                         <td width='80%' class='inset_table'>
                                             <span class='font_small'>
                                                   <?php
                                                   echo bbcode(substr($Daten_post[text], 0, 100), "on", "", "", "on", "");
                                                   if (strlen($Daten_post[text]) > 100) {
                                                       echo "&nbsp;<b>...</b>";
                                                   }
                                                   ?>
                                             </span>
                                         </td>
                                     </tr>
                              </table>
                        </span>
                    <td width='20%' align='center' class='cat_two'>
                        <b><a href='<?php echo "showforum.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Forum_id=$Daten[forum_id]"; ?>'><?php echo $Daten[forum_name]; ?></a></b>
                    <td width='10%' align='center' class='cat_one'>
                        <b><?php echo $Daten[posts]; ?></b>
                    <td width='5%' align='center' class='cat_two'>
                        <b><?php echo $Daten[views]; ?></b>
                    <td width='15%' align='center' class='cat_one'>
                        <?php $userinfo = get_user_info("$Daten[poster_id]"); ?>
                        <a href='<?php echo "showuser.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=$userinfo[id]"; ?>'><?php echo $userinfo[name]; ?></a>
                    </td>
                </tr>
                <?php
                }
         }
echo "</table>";

echo "<div align='right'>".navi($HTTP_GET_VARS[Page], $Topic_anz, $max, "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result&search_id=$search_id&typ=$HTTP_GET_VARS[typ]")."</div>";
}
##################### Such Ergebnisse ##################### ---
#
#
##################### get_sql ##################### +++
function get_sql() {
         global $HTTP_POST_VARS, $HTTP_GET_VARS, $HTTP_SERVER_VARS;

         //nicht per GET �bertragen ???
         if (!$HTTP_GET_VARS[get]) {
             $HTTP_GET_VARS[get] = $HTTP_POST_VARS[get];
         }
         if (!$HTTP_GET_VARS[search]) {
             $HTTP_GET_VARS[search] = $HTTP_POST_VARS[search];
         }

         switch ($HTTP_GET_VARS[get]) {

                 case "text":
                       if (!$HTTP_GET_VARS[search] AND !$HTTP_POST_VARS[search_user]) {
                           msg("search_text_fault", "5", "back()");
                       }
                       $sql = where();
                       if ($HTTP_POST_VARS[search_user]) {
                           $Navi = "$HTTP_GET_VARS[search] ( $HTTP_POST_VARS[search_user] )";
                       } else {
                           $Navi = $HTTP_GET_VARS[search];
                       }
                       break;

                 case "user":
                       $sql = where();
                       $userinfo = get_user_info($HTTP_GET_VARS[search]);
                       $Navi = "Beitr&auml;ge von $userinfo[name]";
                       break;

                 case "new":
                       $sql = where();
                       $Navi = "neue Beitr&auml;ge";
                       break;

                 case "today":
                       $sql = where();
                       $Navi = "Beitr&auml;ge von heute";
                       break;
         }
         $userinfo = get_user_info();
         mysql_query("INSERT INTO $GLOBALS[TB_SEARCH] (user_id, date, name, sql)
                      VALUES ('$userinfo[id]',NOW(),'$Navi','".addslashes($sql)."')");
         $id = mysql_insert_id();
         msg("search", "2", "$HTTP_SERVER_VARS[PHP_SELF]?action=result&search_id=$id&typ=$HTTP_POST_VARS[show_typ]");
}
##################### get_sql ##################### ---
#
#
##################### WHERE erstellen ##################### +++
function where() {
         global $HTTP_POST_VARS, $HTTP_GET_VARS, $HTTP_SESSION_VARS;

         if ($HTTP_POST_VARS[search_forum] != "%" AND $HTTP_GET_VARS[get] != "new" AND $HTTP_GET_VARS[get] != "user" AND $HTTP_GET_VARS[get] != "today") {
             $where = "AND $GLOBALS[TB_FORUM].id='$HTTP_POST_VARS[search_forum]'
                                AND $GLOBALS[TB_CAT].show_cat='on' ";
         } else {
             $where = "AND $GLOBALS[TB_FORUM].id LIKE '%'
                                AND $GLOBALS[TB_CAT].show_cat='on' ";
         }

         switch ($HTTP_GET_VARS[get]) {

                 case "text":
                       //Leerstellen durch "AND ...OR" ersetzen
                       if ($HTTP_GET_VARS[search]) {
                           $where .= "AND (($GLOBALS[TB_POST].text LIKE '%";
                           $where .= eregi_replace(" and ", "%' AND $GLOBALS[TB_POST].text LIKE '%", eregi_replace(" OR ", "%' ) OR ($GLOBALS[TB_POST].text LIKE '%",$HTTP_GET_VARS[search]));
                           $where .= "%'))";
                       }

                       //Typ des Benutzers
                       if ($HTTP_POST_VARS[search_user]) {
                           //exacter Benutzer-Name
                           if ($HTTP_POST_VARS[user_typ] == "exact") {
                               $user_id = mysql_fetch_object (mySQL_query ("SELECT id FROM $GLOBALS[TB_USER] WHERE $GLOBALS[TB_USER].name='$HTTP_POST_VARS[search_user]'"));
                           //nur ein teil des Benutzer-Names
                           } elseif ($HTTP_POST_VARS[user_typ] == "teil") {
                               $user_id = mysql_fetch_object (mySQL_query ("SELECT id FROM $GLOBALS[TB_USER] WHERE $GLOBALS[TB_USER].name LIKE '%$HTTP_POST_VARS[search_user]%'"));
                           }
                           $where .= " AND $GLOBALS[TB_POST].user_id='$user_id->id'";
                       }
                       $where .= " GROUP BY $GLOBALS[TB_POST].topic_id ORDER BY $GLOBALS[TB_TOPIC].post_date $HTTP_POST_VARS[sort_typ]";
                       break;

                 case "user":
                       $where .= " AND $GLOBALS[TB_POST].user_id='$HTTP_GET_VARS[search]' GROUP BY $GLOBALS[TB_POST].topic_id ORDER BY $GLOBALS[TB_TOPIC].post_date DESC ";
                       break;

                 case "new":
                       $where .= " AND DATE_FORMAT($GLOBALS[TB_POST].post_date,'%Y%m%d%H%i%s') > DATE_FORMAT('$HTTP_SESSION_VARS[VISIT_Log]','%Y%m%d%H%i%s') GROUP BY $GLOBALS[TB_POST].topic_id ORDER BY $GLOBALS[TB_TOPIC].post_date DESC ";
                       break;

                 case "today":
                       $where .= " AND (TO_DAYS(NOW()) - TO_DAYS($GLOBALS[TB_POST].post_date) = 0) GROUP BY $GLOBALS[TB_POST].topic_id ORDER BY $GLOBALS[TB_TOPIC].post_date DESC ";
                       break;
         }
         return $where;
}
##################### WHERE erstellen ##################### ---
#
#
###############################################################
echo "<br>";
footer_list();
echo "<br>";
footer();
?>