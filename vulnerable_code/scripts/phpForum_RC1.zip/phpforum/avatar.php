<?php
         include("config.inc.php");
         include("config.php");

         $Daten = mysql_fetch_array(mysql_query("SELECT name, data FROM $TB_AVATARS WHERE user_id='$HTTP_GET_VARS[id]'"));
         header("Cache-control: max-age=60");
         header("Expires: ".gmdate("D, d M Y H:i:s",time()+60)." GMT");
         header("Content-disposition: filename=$Daten[name]");
         header("Content-Length: ".strlen($Daten[data]));
         echo $Daten[data];
?>
