<?php
function msg_text($typ) {
         global $HTTP_SERVER_VARS, $HTTP_SESSION_VARS;
         switch ($typ) {

                 case "user":
                       if ($HTTP_SESSION_VARS[USER_Log] != "") {
                           //Eingeloggt
                           $Fehler_code="Sie haben keine Rechte diese Seite zu betreten. Dies k&ouml;nnte einer der Gr&uuml;nde sein:
                                         <ol>
                                         <li>Sie haben keine Rechte, diese Seite zu betreten.
                                         <li>Sie versuchen vielleicht den Beitrag eines anderen Nutzers zu bearbeiten oder eine Aktion durchzuf&uuml;hren, die Administratoren vorbehalten ist? Bitte pr&uuml;fen sie in den Forum Regeln, ob sie die Erlaubnis f&uuml;r diese Aktion haben.
                                         <li>Sie versuchen einen Beitrag zu verfassen und haben keine Rechte.
                                         </ol>
                                         <center><b>Angemeldet als:</b>&nbsp;$HTTP_SESSION_VARS[USER_Log]&nbsp;&nbsp;<a href='login.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=logout'>[logout]</a></center>";
                       } else {
                           //Ausgeloggt
                           $Fehler_code="Sie haben keine Rechte diese Seite zu betreten. Dies k&ouml;nnte einer der Gr&uuml;nde sein:
                                         <ol>
                                         <li>Sie sind nicht angemeldet.
                                         <li>Sie haben keine Rechte, diese Seite zu betreten.
                                         <li>Sie versuchen vielleicht den Beitrag eines anderen Nutzers zu bearbeiten oder eine Aktion durchzuf&uuml;hren, die Administratoren vorbehalten ist? Bitte pr&uuml;fen sie in den Forum Regeln, ob sie die Erlaubnis f&uuml;r diese Aktion haben.
                                         <li>Sie versuchen einen Beitrag zu verfassen und haben keine Rechte.
                                         </ol>
                                         <table border='0' cellpadding='4' cellspacing='1' width='80%' align='center' class='default_table'>
                                         <form name='form1' method='post' action='login.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]'>
                                               <input type='hidden' name='action' value='login_now'>
                                               <input type='hidden' name='goto' value='$HTTP_SERVER_VARS[REQUEST_URI]'>
                                               <tr>
                                                   <td width='20%' class='cat_two'>
                                                       <b>Benutzer:</b>
                                                   <td width='80%' align='left' class='cat_one'>
                                                       <input type='text' name='Name' maxlength='20' size='20' tabindex='1'>&nbsp;&nbsp;&nbsp;
                                                       <span class='font_small'>
                                                             <a href='signup.php'>M&ouml;chten sie sich registrieren?</a>
                                                       </span>
                                                   </td>
                                               <tr>
                                                   <td width='20%' class='cat_two'>
                                                       <b>Passwort:</b>
                                                   <td width='80%' class='cat_one'>
                                                       <input type='password' name='Pass' maxlength='10' size='20' tabindex='2'>&nbsp;&nbsp;&nbsp;
                                                       <span class='font_small'>
                                                             <a href='mailpass.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=pass'>Passwort vergessen ?</a>
                                                       </span>
                                                   </td>
                                               </tr>
                                               <tr valign='top'>
                                                   <td align='center' colspan='2' class='cat_two'>
                                                       <input type='submit' name='submit' value='Login' tabindex='3'>
                                                   </td>
                                               </tr>
                                         </table>
                                         <p><span class='font_small'>Sie m&uuml;ssen <a href='signup.php'>registriert</a> sein, um diese Seite aufrufen zu k&ouml;nnen. <a href='mailpass.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=pass'>Passwort vergessen ?</a></span></p>";
                       }
                       break;

                 case "login_fault":
                       $Fehler_code="<span class='font_fault'><b>Falscher Benutzername / Passwort.</b></span><br> Bitte klicke auf Zur&uuml;ck, gib den korrekten Benutzernamen ein und versuche es erneut.";
                       break;

                 case "login_del":
                       $Fehler_code="<span class='font_fault'><b>Benutzer wurde gesperrt.</b></span><br> Bei fragen bitte an den <a href='mailto:$GLOBALS[SITE_ADMIN]'>Administrator</a> wenden.";
                       break;

                 case "login":
                       $Fehler_code="<b>Danke f&uuml;r ihre Anmeldung, <i>$HTTP_SESSION_VARS[USER_Log]</i>.</b>";
                       break;

                 case "logout":
                       $Fehler_code="<b>Erfolgreich ausgeloggt. Alle Cookies wurden gel&ouml;scht</b>";
                       break;

                 case "topic_fault":
                       $Fehler_code="<b>Thema nicht mehr vorhanden.</b>";
                       break;

                 case "topic_new":
                       $Fehler_code="<b>Danke f&uuml;r ihren Beitrag. Sie werden zu ihren Beitrag weitergeleitet.<br>
                                     Wenn sie eine Umfrage erstellen wollten, k&ouml;nnen sie dies jetzt tun.</b>";
                       break;

                 case "topic_new_fault":
                       $Fehler_code="<span class='font_fault'><b>Bitte einen Betreff / eine Nachricht eingeben.</b></span>";
                       break;

                 case "topic_poll":
                       $Fehler_code="<b>Deine Umfrage wurde erfolgreich erstellt.</b>";
                       break;

                 case "cat_fault":
                       $Fehler_code="<b>Kategorie nicht mehr vorhanden.</b>";
                       break;

                 case "forum_fault":
                       $Fehler_code="<b>Forum nicht mehr vorhanden.</b>";
                       break;

                 case "post_new":
                       $Fehler_code="<b>Danke f&uuml;r ihren Beitrag. sie werden zu ihren Beitrag weitergeleitet.</b>";
                       break;

                 case "post_del":
                       $Fehler_code="<b>Der Beitrag wurde erfolgreich gel&ouml;scht. Sie werden zum letzten Beitrag weitergeleitet.</b>";
                       break;

                 case "post_edit":
                       $Fehler_code="<b>Der Beitrag wurde erfolgreich bearbeitet. Sie werden zu dem Beitrag weitergeleitet.</b>";
                       break;

                 case "post_edit_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim bearbeiten der Nachricht aufgetreten.</b></span>";
                       break;

                 case "post_new_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim erstellen der Nachricht aufgetreten.</b></span>";
                       break;

                 case "email_fault":
                       $Fehler_code="<b><span class='font_fault'>Fehler beim senden der eMail aufgetreten, dies k&ouml;nnte einer der Gr&uuml;nde sein:</span></b>
                                     <ol>
                                     <li>Es wurde keine eMail bei der Registrierung angegeben.
                                     <li>Der Benutzer wurde nicht gefunden.
                                     <li>Der Mail Server ist momentan nicht verf&uuml;gbar.
                                     </ol>";
                       break;

                 case "email":
                       $Fehler_code="<b>eMail wurde gesendet.</b>";
                       break;

                 case "signup":
                       $Fehler_code="<b>Ihre Registrierung war erfolgreich.<br>
                                     Ihnen wird in k&uuml;rze eine eMail mit ihrem Passwort zu geschickt.</b>";
                       break;

                 case "signup_fault":
                       $Fehler_code="<b><span class='font_fault'>Es ist ein Fehler bei ihrer Registrierung aufgetreten, dies k&ouml;nnte einer der Gr&uuml;nde sein:</span></b>
                                     <ol>
                                     <li>Es wurde kein Name angegeben
                                     <li>Es wurde keine eMail-Adresse angegeben
                                     <li>Die eMail-Adresse wurde nicht wiederholt
                                     <li>Der gew&auml;hlte Benutzername ist nicht zul&auml;sslig
                                     </ol>";
                       break;

                 case "signup_exist":
                       $Fehler_code="<b><span class='font_fault'>Benutzer schon vorhanden.</span></b>";
                       break;

                 case "pic_fault":
                       $Fehler_code="<b><span class='font_fault'>Fehler bei Datei-Upload:</span></b>
                                     <ol>
                                     <li>Die Datei ist zu gro�.
                                     <li>Die Datei hat nicht das Richtige Datei-Format.
                                     </ol>";
                       break;

                 case "file":
                       $Fehler_code="<b>Datei-Upload erfolgreich.</b>";
                       break;

                 case "eingabe_fault":
                       $Fehler_code="<b><span class='font_fault'>Bitte die Pflicht Felder ausf&uuml;llen.</span></b>";
                       break;

                 case "profile_fault":
                       $Fehler_code="<b><span class='font_fault'>Fehler beim aktualisieren aufgetreten.</span></b>";
                       break;

                 case "profile":
                       $Fehler_code="<b>Profil erfolgreich aktualisiert.</b>";
                       break;

                 case "post_edit":
                       $Fehler_code="<b>Ihr Beitrag wurde erfolgreich ge&auml;ndert.</b>";
                       break;

                 case "search":
                       $Fehler_code="<b>Ihre Suchanfrage wird bearbeitet. Dies kann eine gewisse Zeit dauern.</b>";
                       break;

                 case "search_null":
                       $Fehler_code="<b>Ihre Suchanfrage ergab leider keine Ergebnisse.</b>";
                       break;

                 case "search_user_fault":
                       $Fehler_code="Die Suche ergab keine Treffer. Dies k&ouml;nnte einer der Gr&uuml;nde sein:
                                     <ol>
                                     <li>Der Benutzer hat noch keine Beitr&auml;ge erstellt
                                     <li>Der Benutzer ist nicht vorhanden
                                     </ol>";
                       break;

                 case "search_text_fault":
                       $Fehler_code="Die Suche ergab keine Treffer. Dies k&ouml;nnte einer der Gr&uuml;nde sein:
                                     <ol>
                                     <li>Es ist kein Beitrag vorhanden der diesen Text enth&auml;lt
                                     <li>Es wurde kein Such-Text eingegeben
                                     <li>Der Benutzer hat noch keine Beitr&auml;ge erstellt
                                     <li>Der Benutzer ist nicht vorhanden
                                     </ol>";
                       break;

                 case "footer_list_fault":
                       $Fehler_code="Die von ihnen gew&auml;hlte Seite ist nicht vorhanden.<br>Bei Fragen / Problemen informieren sie bitte den <a href='mailto:$GLOBALS[SITE_ADMIN]'>Administrator</a>.";
                       break;

                 case "private_fault":
                       $Fehler_code="Die von ihnen gew&auml;hlte Nachricht ist nicht an sie gerichtet.<br>Bei Fragen / Problemen informieren sie bitte den <a href='mailto:$GLOBALS[SITE_ADMIN]'>Administrator</a>.";
                       break;

                 case "private_user_fault":
                       $Fehler_code="<span class='font_fault'><b>Sie k&ouml;nnen diesen Benutzer keine Private Nachricht senden, da dieser keine Rechte hat diese zu lesen.</b></span>";
                       break;

                 case "private_new_fault":
                       $Fehler_code="Die Nachricht konnte nicht gesendet werden. Dies k&ouml;nnte einer der Gr&uuml;nde sein:
                                     <ol>
                                     <li>Sie haben keinen Empf&auml;nger eingetragen
                                     <li>Sie haben das Nachrichtenfeld / Betreff leer gelassen
                                     <li>Der Benutzer ist nicht vorhanden
                                     </ol>";
                       break;

                 case "private_send":
                       $Fehler_code="<b>Nachricht erfolgreich verschickt.</b>";
                       break;

                 case "private_send_fault":
                       $Fehler_code="<span class='font_fault'><b>Fehler beim senden der Nachricht aufgetreten.</b></span>";
                       break;

                 case "private_send_full":
                       $Fehler_code="<span class='font_fault'><b>Fehler beim senden der Nachricht aufgetreten.</b></span>
                                     <br>Das Postfach des Empf&auml;ngers ist voll, dieser wurde per E-Mail benachrichtigt.
                                     <br>Deine Nachricht wurde ihm per E-Mail geschickt !";
                       break;

                 case "private_del":
                       $Fehler_code="<b>Nachricht erfolgreich gel&ouml;scht.</b>";
                       break;

                 case "private_del_all":
                       $Fehler_code="<b>Alle Nachrichten aus ihrem Posteingang wurden erfolgreich gel&ouml;scht.</b>";
                       break;

                 case "private_del_fault":
                       $Fehler_code="Die Nachricht konnte nicht gel&ouml;scht werden. Dies k&ouml;nnte einer der Gr&uuml;nde sein:
                                     <ol>
                                     <li>Diese Nachricht geh&ouml;rt ihnen nicht
                                     <li>Das k&auml;stchen zum l&ouml;schen wurde nicht aktiviert
                                     </ol>";
                       break;

                 case "private_read":
                       $Fehler_code="<b>Alle Nachrichten in ihrem Posteingang wurden als gelesen markiert.</b>";
                       break;

                 case "private_read_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim markieren aller Nachrichten als gelesen aufgetreten.</b></span>";
                       break;

                 case "poll":
                       $Fehler_code="<b>Sie haben erfolgreich abgestimmt.</b>";
                       break;

                 case "poll_add":
                       $Fehler_code="<b>Die Umfrage wurde erfolgreicht erstellt.</b>";
                       break;

                 case "poll_edit":
                       $Fehler_code="<b>Die Umfrage wurde erfolgreicht bearbeitet.</b>";
                       break;

                 case "poll_fault":
                       $Fehler_code="<b>Es ist ein Fehler beim abstimmen aufgetreten. Dies k&ouml;nnte einer der Gr&uuml;nde sein:</b>
                                     <ol>
                                     <li>Sie haben bereits abgestimmt
                                     <li>Die Umfrage ist bereits abgelaufen
                                     </ol>";
                       break;

                 case "user_del":
                       $Fehler_code="<b>Der Benutzer wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Topic abonnieren
                 case "topic_abo_add":
                       $Fehler_code="<b>Das Abonnement dieses Themas wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "topic_abo_fault":
                       $Fehler_code="<span class='font_fault'><b>Sie haben dieses Themas bereits abonniert.</b></span>";
                       break;

                 case "topic_abo_del":
                       $Fehler_code="<b>Das ausgew&auml;hlte Abonnement wurde erfolgreich gel&ouml;scht.</b>";
                       break;

                 case "topic_abo_delall":
                       $Fehler_code="<b>Alle Ihre abonnierten Themen wurden erfolgreich gel&ouml;scht.</b>";
                       break;

                 case "topic_abo_post_email":
                       $Fehler_code="<span class='font_fault'><b>Das Abonnement konnte nicht hinzugef&uuml;gt werden, Sie m&uuml;ssen diese Funktion in Ihrem Profil aktivieren.</b></span>";
                       break;

                 case "topic_abo_read":
                       $Fehler_code="<b>Alle Themen wurden als gelesen markiert.</b>";
                       break;
//goto
                 case "goto":
                       $Fehler_code="<b>Sie werden gleich zur gew&uuml;nschten Seite weiter geleitet.</b>";
                       break;
//Mod - open / close
                 case "mod_close":
                       $Fehler_code="<b>Topic wurde auf <span class='font_fault'>CLOSED</span> gesetzt.</b>";
                       break;

                 case "mod_open":
                       $Fehler_code="<b>Das Topic wurde ge&ouml;ffnet.</b>";
                       break;
//Mod - top / untop
                 case "mod_top":
                       $Fehler_code="<b>Topic wird jetzt oben festgehalten.</b>";
                       break;

                 case "mod_untop":
                       $Fehler_code="<b>Das Topic wurde gel&ouml;st.</b>";
                       break;
//Mod - move_topic
                 case "mod_move_topic":
                       $Fehler_code="<b>Das Topic wurde in das ausgew&auml;hlte Forum verschoben.</b>";
                       break;
//Mod - move_post (new)
                 case "mod_move_post_new":
                       $Fehler_code="<b>Die ausgew&auml;hlten Beitr&auml;ge wurden erfolgreich in das neu erstellte Thema verschoben.</b>";
                       break;
//Mod - move_post (move)
                 case "mod_move_post_move":
                       $Fehler_code="<b>Die ausgew&auml;hlten Beitr&auml;ge wurden erfolgreich in das ausgew&auml;hlte Thema verschoben.</b>";
                       break;
//Mod - edit
                 case "mod_edit":
                       $Fehler_code="<b>Der Topic-Name wurde erfolgreich ge&auml;ndert.</b>";
                       break;
//Mod - del
                 case "mod_del":
                       $Fehler_code="<b>Das Thema und alle darin enthaltenen Beitr�ge wurden erfolgreich gel&ouml;scht.</b>";
                       break;
//Mod - join
                 case "mod_join":
                       $Fehler_code="<b>Die Topic�s wurden erfolgreich zusammengef&uuml;hrt.</b>";
                       break;
//Mod - fault
                 case "mod_fault":
                       $Fehler_code="<b><span class='font_fault'>Fehler beim aktualisieren aufgetreten.</span></b>";
                       break;
//Admin - Categorien
                 case "cat_add":
                       $Fehler_code="<b>Die Kategorie wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "cat_add_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim hinzuf&uuml;gen der Kategorie aufgetreten.</b></span>";
                       break;

                 case "cat_edit":
                       $Fehler_code="<b>Die Kategorie wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "cat_edit_false":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim bearbeiten der Kategorie aufgetreten.</b></span>";
                       break;

                 case "cat_del":
                       $Fehler_code="<b>Die Kategorie wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Admin - Forum
                 case "forum_add":
                       $Fehler_code="<b>Das Forum wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "forum_add_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim hinzuf&uuml;gen des Forums aufgetreten.</b></span>";
                       break;

                 case "forum_edit":
                       $Fehler_code="<b>Das Forum wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "forum_edit_false":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim bearbeiten des Forums aufgetreten.</b></span>";
                       break;

                 case "forum_del":
                       $Fehler_code="<b>Das Forum wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Admin - Settings
                 case "settings":
                       $Fehler_code="<b>Die Einstellungen wurden erfolgreich gespeichert.</b>";
                       break;

                 case "settings_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim bearbeiten der Einstellungen aufgetreten.</b></span>";
                       break;

//Admin - Benutzergruppen
                 case "usergroup_add":
                       $Fehler_code="<b>Die Benutzergruppe wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "usergroup_add_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim hinzuf&uuml;gen der Benutzergruppe aufgetreten.</b></span>";
                       break;

                 case "usergroup_edit":
                       $Fehler_code="<b>Die Benutzergruppe wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "usergroup_edit_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim bearbeiten der Benutzergruppe aufgetreten.</b></span>";
                       break;

                 case "usergroup_del":
                       $Fehler_code="<b>Die Benutzergruppe wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Admin - Forenberechtigungen
                 case "forum_access_edit":
                       $Fehler_code="<b>Die Forenberechtigung wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "forum_access_edit_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim bearbeiten der Forenberechtigungen aufgetreten.</b></span>";
                       break;

                 case "forum_access_default":
                       $Fehler_code="<b>Die Standard Berechtigungen dieser Gruppe wurde &uuml;bernommen.</b>";
                       break;
//Admin - Smilies
                 case "smilie_add":
                       $Fehler_code="<b>Das Smilie wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "smilie_edit":
                       $Fehler_code="<b>Das Smilie wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "smilie_del":
                       $Fehler_code="<b>Das Smilie wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Admin - BBCodes
                 case "bbcodes_add":
                       $Fehler_code="<b>Der Board Code wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "bbcodes_edit":
                       $Fehler_code="<b>Der Board Code wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "bbcodes_del":
                       $Fehler_code="<b>Der Board Code wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Admin - Words
                 case "words_add":
                       $Fehler_code="<b>Das \"Zensierte Wort\" wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "words_edit":
                       $Fehler_code="<b>Das \"Zensierte Wort\" wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "words_del":
                       $Fehler_code="<b>Das \"Zensierte Wort\" wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Admin - Status
                 case "status_add":
                       $Fehler_code="<b>Der Benutzer-Titel wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "status_edit":
                       $Fehler_code="<b>Der Benutzer-Titel wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "status_del":
                       $Fehler_code="<b>Der Benutzer-Titel wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Admin - Moderatoren
                 case "forum_mod_add":
                       $Fehler_code="<b>Der Moderator wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "forum_mod_add_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim hinzuf�gen des Moderators aufgetreten.</b></span>";
                       break;

                 case "forum_mod_edit":
                       $Fehler_code="<b>Der Moderator wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "forum_mod_edit_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim bearbeiten des Moderators aufgetreten.</b></span>";
                       break;

                 case "forum_mod_default":
                       $Fehler_code="<b>Die Standard Berechtigungen der Benutzergruppe wurde &uuml;bernommen.</b>";
                       break;

                 case "forum_mod_del":
                       $Fehler_code="<b>Der Moderator wurde erfoldreich gel&ouml;scht.</b>";
                       break;

//Admin - Benutzer
                 case "user_add":
                       $Fehler_code="<b>Der Benutzer wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "user_edit":
                       $Fehler_code="<b>Der Benutzer wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "user_del":
                       $Fehler_code="<b>Der Benutzer wurde erfolgreich gel&ouml;scht.</b>";
                       break;
//Admin - Styles
                 case "admin_styles_add":
                       $Fehler_code="<b>Der Foren-Style wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "admin_styles_copy":
                       $Fehler_code="<b>Der Foren-Style wurde erfolgreich kopiert.</b>";
                       break;

                 case "admin_styles_edit":
                       $Fehler_code="<b>Der Foren-Style wurde erfolgreich bearbeitet.</b>";
                       break;

                 case "admin_styles_fault":
                       $Fehler_code="<span class='font_fault'><b>Es ist ein Fehler beim bearbeiten des Foren-Styles aufgetreten.</b></span>";
                       break;

                 case "admin_styles_del":
                       $Fehler_code="<b>Der Foren-Style wurde erfolgreich gel&ouml;scht.</b>";
                       break;

                 case "admin_styles_default":
                       $Fehler_code="<b>Der gew&auml;hlte Foren-Style ist jetzt das Standard Style.</b>";
                       break;
//Admin - Backup
                 case "admin_backup_restore":
                       $Fehler_code="<b>Das Backup wurde erfolgreich wiederhergestellt.</b>";
                       break;

                 case "admin_backup_restore_fault":
                       $Fehler_code="<span class='font_fault'><b>Das Backup konnte nicht wiederhergestellt werden, versuchen sie es noch einmal oder benutzen sie ein &auml;lteres Backup.</b></span>";
                       break;

                 case "admin_backup_restore_file":
                       $Fehler_code="<span class='font_fault'><b>Das Backup konnte nicht wiederhergestellt werden, da die Datei keine phpForum-Backup Datei ist.</b></span>";
                       break;

                 case "admin_backup_create_fault":
                       $Fehler_code="<span class='font_fault'><b>Das Backup konnte nicht erstellt werden.</b></span>";
                       break;
//Admin - Styles
                 case "admin_styles_upload":
                       $Fehler_code="<b>Der Foren-Style wurde erfolgreich hinzugef&uuml;gt.</b>";
                       break;

                 case "admin_styles_upload_fault":
                       $Fehler_code="<span class='font_fault'><b>Der Foren-Style konnte nicht hinzugef�gt werden.</b></span>";
                       break;

                 case "admin_styles_upload_file":
                       $Fehler_code="<span class='font_fault'><b>Der Foren-Style konnte nicht hinzugef&uuml;gt werden, da die Datei keine phpForum-Style Datei ist.</b></span>";
                       break;
//Zugriffskontrolle
                 case "banned_ip":
                       $Fehler_code="Ihre IP-Adresse wurde vom Foren-Administrator gesperrt. Bei Fragen wenden sie sich bitte an den <a href='mailto:$GLOBALS[SITE_ADMIN]'>Administrator</a>.";
                       break;
         }
return $Fehler_code;
}
?>