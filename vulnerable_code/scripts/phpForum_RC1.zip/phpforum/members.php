<?php
        include("head.php");        //Header mit Bild, Suchen...
        access("show_members");     //Zugriff beschr�nken

######### ANZ - Members ##### +++
        $Members_anz = mySQL_num_rows(mySQL_query ("SELECT *
                                                    FROM $TB_USER"));
        //wenn keine Page �bergeben wurde
        if (!$HTTP_GET_VARS[Page]) {
            $HTTP_GET_VARS[Page]="1";
        }
        //f�r die LIMIT
        if ($Members_anz > $ANZ_MEMBERS) {
            $p=$HTTP_GET_VARS[Page]-1;
            $L_AB=$ANZ_MEMBERS*$p;
        }
        //f�r die LIMIT
        if ($L_AB < "0") {
            $L_AB="0";
        }
######### ANZ - Members ##### +++
#
#
######### Sortierung ######## +++
switch ($HTTP_GET_VARS[Sort]) {
        case "name":
              $SORT_BY="name";
              break;

        case "posts":
              $SORT_BY="points";
              break;

        case "reg":
              $SORT_BY="reg";
              break;

        default:
              $SORT_BY=$MEMBERS_SORT;
              break;
}
######### Sortierung ######## ---
#
#
######### Reihenfolge ######## +++
switch (strtoupper($HTTP_GET_VARS[Order])) {
        case "ASC":
              $new_order="DESC";
              break;

        case "DESC":
              $new_order="ASC";
              break;

        default:
              $HTTP_GET_VARS[Order]=$MEMBERS_ORDER;
              if ($MEMBERS_ORDER == "ASC") {
                  $new_order="DESC";
              } else {
                  $new_order="ASC";
              }
              break;
}
######### Reihenfolge ######## +++
#
echo "<br>";
###*** Seiten Navigation ***
echo "<div align='right'>".navi($HTTP_GET_VARS[Page], $Members_anz, $ANZ_MEMBERS, "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Sort=$SORT_BY&Order=$HTTP_GET_VARS[Order]")."</div>";
###*** Seiten Navigation ***
table_header("$TITEL_KURZ Members", "100%", "", "colspan='5'");
?>
       <tr id='nav'>
           <td width='30%' align='center'>
               <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Page=$HTTP_GET_VARS[Page]&Sort=name&Order=$new_order"; ?>'><b>Name</b></a>
           <td width='25%' align='center'>
               <b>Kontakt</b>
           <td width='20%' align='center'>
               <b>Beitr&auml;ge dieses Benutzers</b>
           <td width='15%' align='center'>
               <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Page=$HTTP_GET_VARS[Page]&Sort=reg&Order=$new_order"; ?>'><b>Registriert seit</b></a>
           <td width='10%' align='center'>
               <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Page=$HTTP_GET_VARS[Page]&Sort=posts&Order=$new_order"; ?>'><b>Beitr&auml;ge</b></a>
           </td>
       </tr>
       <?php
       $result = mySQL_query ("SELECT * FROM $TB_USER ORDER BY $SORT_BY $HTTP_GET_VARS[Order] LIMIT $L_AB,$ANZ_MEMBERS");
       while($Daten = mysql_fetch_array ($result)) {
             ?>
             <tr>
                 <td width='30%' class='cat_two'>
                     <a href='<?php echo "showuser.php?$Sess_Name=$Sess&id=$Daten[id]"; ?>'><b><?php echo $Daten[name]; ?></b></a>
                 <td width='25%' class='cat_one'>
                     <?php
                           $user_perm = get_forum_perm("", $Daten[id]);
                           //--E-Mail--
                           if ($Daten[email_show] == "on") {
                               echo "<a href='mail.php?$Sess_Name=$Sess&id=$Daten[id]'><img src='$_style[pic_mail]' border='0' alt='eine E-Mail an $Daten[name] schicken'></a>&nbsp;&nbsp;\n";
                           }
                           //--PM--
                           if ($user_perm[send_pm] == "on") {
                               echo "<a href='private.php?$Sess_Name=$Sess&action=new&user_id=$Daten[id]'><img src='$_style[pic_pm]' border='0' alt='$Daten[name] eine PM schicken'></a>&nbsp;&nbsp;\n";
                           }
                           //--Homepage--
                           if ($Daten[homepage]) {
                               echo "<a href='$Daten[homepage]' target='_blank'><img src='$_style[pic_home]' border='0' alt='Homepage von $Daten[name] anzeigen'></a>&nbsp;&nbsp;\n";
                           }
                           //--ICQ--
                           if ($Daten[icq]) {
                               echo "<a href='http://wwp.icq.com/scripts/search.dll?to=$Daten[icq]'><img src='http://wwp.icq.com/scripts/online.dll?icq=$Daten[icq]&img=5' border='0' width='18' height='18' alt='$Daten[name] zur ICQ-Kontaktliste hinzuf&uuml;gen'></a>&nbsp;&nbsp;\n";
                           }
                     ?>
                 <td width='20%' align='center' class='cat_two'>
                     <a href='<?php echo "search.php?$Sess_Name=$Sess&action=search&get=user&search=$Daten[id]"; ?>'><img src='<?php echo $_style[pic_search]; ?>' border='0' alt='Beitr&auml;ge von <?php echo $Daten[name]; ?> suchen'></a>
                 <td width='15%' align='center' class='cat_one'>
                     <?php echo $Daten[reg]; ?>
                 <td width='10%' align='center' class='cat_two'>
                     <?php echo $Daten[points]; ?>
                 </td>
             </tr>
       <?php
       }
       ?>
</table>
<?php
###*** Seiten Navigation ***
echo "<div align='right'>".navi($HTTP_GET_VARS[Page], $Members_anz, $ANZ_MEMBERS, "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Sort=$SORT_BY&Order=$HTTP_GET_VARS[Order]")."</div>";
###*** Seiten Navigation ***
echo "<br>";
footer_list();
footer();
?>