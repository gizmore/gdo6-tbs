<?php
include("$MAIN_PATH/config.php");    //Konfiguration

##################### Cookie auslesen (ob eingeloggt) ##################### +++
$user = get_user_info();
    //Login �ber Cookie :)
    if (!$HTTP_SESSION_VARS["USER_Log"] AND !$HTTP_SESSION_VARS["PASS_Log"] AND $HTTP_COOKIE_VARS["USER"] AND $HTTP_COOKIE_VARS["PASS"] AND $HTTP_GET_VARS["action"] != "logout") {
        @session_start();
        session_register ("USER_Log");
                           $HTTP_SESSION_VARS["USER_Log"]=$HTTP_COOKIE_VARS["USER"];
        session_register ("PASS_Log");
                           $HTTP_SESSION_VARS["PASS_Log"]=$HTTP_COOKIE_VARS["PASS"];

#        echo "<br>Login �ber Cookie (Session wird erstellt)<br>";
        last_login();

    //setzen des Cookies weil Eingeloggt
    } elseif ($HTTP_SESSION_VARS["USER_Log"] AND $HTTP_SESSION_VARS["PASS_Log"] AND !$HTTP_COOKIE_VARS["USER"] AND !$HTTP_COOKIE_VARS["PASS"]) {
        if ($user["stay_login"] == "on") {
            cookie($HTTP_SESSION_VARS["USER_Log"], $HTTP_SESSION_VARS["PASS_Log"], $HTTP_SESSION_VARS["VISIT_Log"]);
#            echo "<br>setzen des Cookies weil Eingeloggt (Login �ber Session)<br>";
        }


    //nicht eingeloggt =>> $NO_LOGIN (Login als Standard Benutzer)
    } elseif (!$HTTP_SESSION_VARS["USER_Log"] AND !$HTTP_SESSION_VARS["PASS_Log"] AND !$HTTP_COOKIE_VARS["USER"] AND !$HTTP_COOKIE_VARS["PASS"]) {

#        echo "<br>gast<br>";

    //Cookie l�schen :(
    } elseif ($HTTP_GET_VARS["action"] == "logout" OR !$user[stay_login]) {
        cookie("","","");
#    echo "<br>Cookie l�schen :(<br>";
    }
#echo "<br>VISIT_Log=".$HTTP_SESSION_VARS[VISIT_Log]."<br>USER_Log = ".$HTTP_SESSION_VARS[USER_Log]."<br>PASS_Log = ".$HTTP_SESSION_VARS[PASS_Log]."<br>Cookie_Visit = ".$HTTP_COOKIE_VARS["VISIT"]."<br>Cookie_User = ".$HTTP_COOKIE_VARS["USER"]."<br>Cookie_PASS = ".$HTTP_COOKIE_VARS["PASS"]."<br>Stay_Login = ".$user[stay_login];
##################### Cookie auslesen (ob eingeloggt) ##################### ---
#
#
##################### Switches ##################### +++
who_is_online("set"); //Who
##################### Switches ##################### ---
#
#
################################################################################
################################################################################
################################################################################
#
#
#
##################### Get_user_info ##################### +++
//(Wenn keine ID �bergeben dann aktueller User)
function get_user_info($id="") {
         global $HTTP_SESSION_VARS;
         if (!$id) {
             $result = mySQL_query ("SELECT $GLOBALS[TB_USER].id
                                     FROM $GLOBALS[TB_USER]
                                     WHERE $GLOBALS[TB_USER].name='$HTTP_SESSION_VARS[USER_Log]'
                                       AND $GLOBALS[TB_USER].pass='$HTTP_SESSION_VARS[PASS_Log]'");
             $Daten = mysql_fetch_object ($result);
                      $id=$Daten->id;
         }
         $result = mySQL_query ("SELECT * FROM $GLOBALS[TB_USER] WHERE $GLOBALS[TB_USER].id='$id'");
         $userinfo = mysql_fetch_array ($result);
         return $userinfo;
}
##################### Get_user_info ##################### ---
#
#
##################### USER_ID ##################### +++
//(Name muss �bergeben werden)
function user_id($name) {
         $result = mySQL_query ("SELECT id
                                 FROM $GLOBALS[TB_USER]
                                 WHERE $GLOBALS[TB_USER].name LIKE '$name'");
         $Daten = mysql_fetch_object ($result);
                  $STATUS=$Daten->id;
         return $STATUS;
}
##################### USER_ID ##################### ---
#
#
##################### USER - Exist ??? ##################### +++
function user_exist($id) {
         $result_user = mySQL_query ("SELECT $GLOBALS[TB_USER].name
                                      FROM $GLOBALS[TB_USER]
                                      WHERE $GLOBALS[TB_USER].id='$id'");
         if (mysql_num_rows($result_user) == 1) {
             $STATUS=TRUE;

         } else {
             $STATUS=FALSE;
         }
         return $STATUS;
}
##################### USER - Exist ??? ##################### ---
#
#
##################### USER - Eingeloggt ??? ##################### +++
function user_login() {
         global $HTTP_SESSION_VARS;
         $result_user = mySQL_query ("SELECT $GLOBALS[TB_USER].id
                                      FROM $GLOBALS[TB_USER]
                                      WHERE $GLOBALS[TB_USER].name='$HTTP_SESSION_VARS[USER_Log]'
                                        AND $GLOBALS[TB_USER].pass='$HTTP_SESSION_VARS[PASS_Log]'");
         if (mysql_num_rows($result_user) == 1) {
             return TRUE;
         } else {
             return FALSE;
         }
}
##################### USER - Eingeloggt ??? ##################### ---
#
#
##################### Board-Code ##################### +++
function bbcode($message, $bbcode="on", $html="", $smilies="on", $words="on", $br="on") {
         # html an ?
         if (!$html) {
             $message = eregi_replace("<", "&lt;", $message);
             $message = eregi_replace(">", "&gt;", $message);
         }
         # Board Codes hinzuf�gen
         if ($bbcode) {
             $result=mysql_query("SELECT *
                                  FROM $GLOBALS[TB_BBCODES]");//LIMIT 0,1
             while($Daten=mysql_fetch_array($result)) {
                   //keine Wiederholungen
                   $replace = $Daten[replacement];
                   $search = preg_replace("/\\\\([0-9])/si", "(.*?)", $Daten[search]);
                   $search = preg_replace("/\[/si", "\\\[", $search);
                   $search = preg_replace("/\]/si", "\\\]", $search);
                   $search = preg_replace("/\//si", "\/", $search);
                   $message = preg_replace("/$search/si", "$replace", $message);
                   //wiederholungen
                   if ($Daten[repeat] == "on" AND $Daten[repeat_replace] != "") {
                       $repeat_replace = preg_replace("/\\\\([0-9])/si", "", $Daten[repeat_replace]);
                       $message = preg_replace("/(\[\*\])(.*?)/si", "$repeat_replace\\2", $message);
                   }
             }
         }
         # Smilies hinzuf�gen
         if ($smilies) {
             $result_smilies = mySQL_query ("SELECT * FROM $GLOBALS[TB_SMILIES]");
             while ($Daten = mysql_fetch_array ($result_smilies)) {
                    $message = str_replace("$Daten[code]", "<img src='http://$GLOBALS[SITE]/functions.php?action=smilie&id=$Daten[id]' border='0'>", $message);
             }
         }
         # Zensierte W�rter "entsch�rfen"
         if ($words) {
             $result = mySQL_query ("SELECT * FROM $GLOBALS[TB_WORDS]");
             while ($Word = mysql_fetch_array ($result)) {
                    $message = eregi_replace("$Word[search]", "$Word[replacement]", $message);
             }
         }
         # Zeilenumbr�che hinzuf�gen
         if ($br) {
             $message = str_replace("\n", "<BR>", $message);
         }
         return $message;
}
##################### Board-Code ##################### ---
#
#
##################### Forum Msg�s ##################### +++
function msg($typ, $time="", $goto="") {
         include("$GLOBALS[MAIN_PATH]/msg.php");
         //wenn kein php? dann php? ran h�ngen
         if ($goto == "back()") {
             $goto="javascript:history.back()";
         } elseif (!stristr($goto, ".php?")) {
                    $goto=str_replace(".php", ".php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]", $goto);
         }
         echo "<br>";
         open_table("phpForum - Mitteilung","60%");

                     echo msg_text($typ);
                     if ($goto) {
                         echo "<p align='center'>
                                  <a href='$goto'>
                                     <span class='font_small'>
                                           Klicken sie hier, wenn sie nicht l&auml;nger warten wollen.<br>
                                           (oder wenn ihr Browser keine automatische Weiterleitung unterst&uuml;tzt)
                                     </span>
                                  </a>
                               </p>";
                     }
         close_table("");
         echo "<br>";

         //wenn goto �bergeben dann gehe dahin nach Zeit "time"
         if ($goto != "") {
             echo "<meta http-equiv='Refresh' content='$time;URL=$goto'>";
         }
         gz_site();
         exit();
}
##################### Forum Msg�s ##################### ---
#
#
##################### Footer ##################### +++
function footer() {
         global $_style;

         ?>
         <!--Copyright-->
         <div align='center'><font size='2'><a href='http://phpForum.ath.cx' target='_blank'>phpForum</a> by <b><a href='mailto:KillerGod2000@gmx.net'>Christoph Roeder</a></b></font><br><font size='1'>Version <?php echo $GLOBALS[VER]; ?></font></div>
         <!--Copyright-->
         <?php echo $_style[footer]; ?>
         </body>
         </html>
         <?php
         ### Stop
         /*
         echo "<b>";
         echo getmicrotime() - $GLOBALS[time_start];
         echo "</b>";
         */

         # Seiten Kompression
         gz_site();
}
##################### Footer ##################### ---
#
#
##################### Footer - Liste ##################### +++
function footer_list() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;
             $userinfo = get_user_info();
             $access = get_forum_perm("","");
             ?>
             <form name='footer' method='post' action='<?php echo "functions.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=goto"; ?>'>
                   <span class='font_small'>
                         <b>Gehe zu:</b>
                   </span><br>
                   <select name='go' <?php echo "onchange=\"window.location=('functions.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=goto&go='+this.options[this.selectedIndex].value)\""; ?>>
                           <option value=''>W&auml;hle:</option>
                           <option value=''>--------------------</option>
                           <option value='w-home'>-- Startseite</option>
                           <?php
                           ### Admin - Zugriff erlaubt ???
                           if ($access[admin_settings] == "on"
                               OR $access[admin_cats] == "on"
                               OR $access[admin_forums] == "on"
                               OR $access[admin_announcements] == "on"
                               OR $access[admin_users] == "on"
                               OR $access[admin_user_groups] == "on"
                               OR $access[admin_user_titles] == "on"
                               OR $access[admin_smilies] == "on"
                               OR $access[admin_bbcodes] == "on"
                               OR $access[admin_status] == "on"
                               OR $access[admin_styles] == "on"
                               OR $access[admin_words] == "on") {
                                  echo "<option value='w-admin'>--Admin</option>";
                           }
                           ### Admin - Zugriff erlaubt ???
                           ?>
                           <option value='w-members'>--Memberliste</option>
                           <option value='w-search'>--Suche</option>
                           <?php
                           ### hat User Profil Rechte ?
                           if ($access[edit_profil] == "on") {
                               echo "<option value='w-private'>--Private Nachrichten</option>\n";
                           }
                           echo "<option value=''>--------------------</option>\n";

                           ### Kategorien ###
                           $result_cat = mySQL_query ("SELECT id, name
                                                       FROM $GLOBALS[TB_CAT]
                                                       WHERE $GLOBALS[TB_CAT].show_cat='on'
                                                       ORDER BY $GLOBALS[TB_CAT].rang");
                           while ($Daten_cat = mysql_fetch_array ($result_cat)) {
                                  echo "<option value='c-$Daten_cat[id]'><<< $Daten_cat[name] >>></option>\n";

                                  ### Foren ###
                                  $result_forum = mySQL_query ("SELECT id, name
                                                                FROM $GLOBALS[TB_FORUM]
                                                                WHERE $GLOBALS[TB_FORUM].cat_id='$Daten_cat[id]'
                                                                AND $GLOBALS[TB_FORUM].show_forum='on'");
                                  while ($Daten_forum = mysql_fetch_array ($result_forum)) {
                                         echo "<option value='f-$Daten_forum[id]'>-- $Daten_forum[name]</option>\n";
                                  }
                           }
                           ?>
                   </select>
                   <input type='submit' value='go'>
             </form>
             <?php
}
##################### Footer - Liste ##################### ---
#
#
##################### Mod - Liste ##################### +++
function mod_list() {
         global $HTTP_GET_VARS;

         //in einem Thema
         if ($HTTP_GET_VARS[Topic_id]) {
             $Daten = mysql_fetch_object(mySQL_query ("SELECT $GLOBALS[TB_TOPIC].forum_id
                                                       FROM $GLOBALS[TB_TOPIC]
                                                       WHERE $GLOBALS[TB_TOPIC].id='$HTTP_GET_VARS[Topic_id]'"));
             $forum_id=$Daten->forum_id;

             ### Benutzer-Rechte
             $perm = get_forum_perm($forum_id, "");
             if ($perm[mod_openclose] == "on" OR
                 $perm[mod_top] == "on" OR
                 $perm[mod_move_topic] == "on" OR
                 $perm[mod_move_post] == "on" OR
                 $perm[mod_edit] == "on" OR
                 $perm[mod_del] == "on" OR
                 $perm[mod_join] == "on") {
                 ?>
                 <form method='post' action='<?php echo "mod.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
                   <input type='hidden' name='Topic_id' value='<?php echo $HTTP_GET_VARS[Topic_id]; ?>'>
                   <span class='font_small'>
                         <b>Admin:</b>
                   </span><br>
                   <select name='action'>
                           <?php
                           if ($perm[mod_openclose] == "on") {
                               echo "<option value='openclose'>&ouml;ffnen / schliessen</option>";
                           }
                           if ($perm[mod_top] == "on") {
                               echo "<option value='top'>oben festhalten / l&ouml;sen</option>";
                           }
                           if ($perm[mod_move_topic] == "on") {
                               echo "<option value='move_topic'>Thema verschieben</option>";
                           }
                           if ($perm[mod_move_post] == "on") {
                               echo "<option value='move_post'>Beitr&auml;ge verschieben</option>";
                           }
                           if ($perm[mod_edit] == "on") {
                               echo "<option value='edit'>bearbeiten</option>";
                           }
                           if ($perm[mod_del] == "on") {
                               echo "<option value='delete'>l&ouml;schen</option>";
                           }
                           if ($perm[mod_join] == "on") {
                               echo "<option value='join'>zusammenf&uuml;hren</option>";
                           }
                           ?>
                   </select>
                   <input type='submit' value='go'>
                 </form>
                 <?php
             }
         }
}
##################### Mod - Liste ##################### ---
#
#
##################### Footer - Rulez ##################### +++
function footer_rulez() {
         global $HTTP_GET_VARS;

         if ($GLOBALS[VIEW_FORUM_RULEZ] == "on") {
             //in einem Forum
             if ($HTTP_GET_VARS[Forum_id] != "") {
                 $forum_id = $HTTP_GET_VARS[Forum_id];

             //in einem Thema
             } elseif ($HTTP_GET_VARS[Topic_id] != "") {
                 $Daten = mysql_fetch_object(mySQL_query ("SELECT $GLOBALS[TB_TOPIC].forum_id
                                                           FROM $GLOBALS[TB_TOPIC]
                                                           WHERE $GLOBALS[TB_TOPIC].id='$HTTP_GET_VARS[Topic_id]'"));
                 $forum_id=$Daten->forum_id;
             //in einem Beitrag (bearbeiten)
             } elseif ($HTTP_GET_VARS[Post_id] != "") {
                 $Daten = mysql_fetch_object(mySQL_query ("SELECT $GLOBALS[TB_TOPIC].forum_id
                                                           FROM $GLOBALS[TB_TOPIC], $GLOBALS[TB_POST]
                                                           WHERE $GLOBALS[TB_POST].id='$HTTP_GET_VARS[Post_id]'
                                                             AND $GLOBALS[TB_TOPIC].id=$GLOBALS[TB_POST].topic_id"));
                 $forum_id=$Daten->forum_id;
             }

             ### Zugriffsberechtigungen wird zur�ck gegeben
             $forum_perm=get_forum_perm($forum_id,"");
             $Daten = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_FORUM].*
                                                      FROM $GLOBALS[TB_FORUM]
                                                      WHERE $GLOBALS[TB_FORUM].id='$forum_id'"));
             ?>
             <span class='font_small'>
                   <b>Forum Regeln:</b>
             </span>
             <br>
             <table border='0' cellpadding='2' cellspacing='1' width='450' class='default_table'>
                    <tr class='cat_two'>
                        <td width='70%'>
                            <span class='font_small'>
                                  Es ist ihnen <?php
                                  if ($forum_perm[new_post] == "on") {
                                      echo "<b>erlaubt</b>";
                                  } else {
                                      echo "<b>nicht erlaubt</b>";
                                  }
                                  ?>, neue Beitr&auml;ge zu schreiben.
                                  <br>
                                  Es ist ihnen <?php
                                  if ($forum_perm[new_topic] == "on") {
                                      echo "<b>erlaubt</b>";
                                  } else {
                                      echo "<b>nicht erlaubt</b>";
                                  }
                                  ?>, neue Themen zu erstellen.
                                  <br>
                                  Es ist ihnen <?php
                                  if ($forum_perm[edit_post] == "on") {
                                      echo "<b>erlaubt</b>";
                                  } else {
                                      echo "<b>nicht erlaubt</b>";
                                  }
                                  ?>, ihre Beitr&auml;ge zu bearbeiten.
                                  <br>
                                  Es ist ihnen <?php
                                  if ($forum_perm[del_post] == "on") {
                                      echo "<b>erlaubt</b>";
                                  } else {
                                      echo "<b>nicht erlaubt</b>";
                                  }
                                  ?>, ihre Beitr&auml;ge zu l&ouml;schen.
                            </span>
                        <td width='30%'>
                            <span class='font_small'>
                                  HTML Code ist <?php
                                  if ($Daten[html] == "on") {
                                      echo "<b>AN</b>";
                                  } else {
                                      echo "<b>AUS</b>";
                                  }
                                  ?>
                                  <br>
                                  <a href="javascript:onclick=BBCode()">Board Code</a> ist <?php
                                  if ($Daten[bbcodes] == "on") {
                                      echo "<b>AN</b>";
                                  } else {
                                      echo "<b>AUS</b>";
                                  }
                                  ?>
                                  <br>
                                  <a href="javascript:onclick=Smilies()">Smilies</a> sind <?php
                                  if ($Daten[smilies] == "on") {
                                      echo "<b>AN</b>";
                                  } else {
                                      echo "<b>AUS</b>";
                                  }
                                  ?>
                            </span>
                        </td>
                    </tr>
             </table>
             <?php
         }
}
##################### Footer - Rulez ##################### ---
#
#
##################### Cookie - setzten ##################### +++
function cookie($name="", $pass="", $visit="") {
         //Benutzername + Passwort + Visit
         if ($name AND $pass AND $visit) {
             setcookie ("USER", $name, time()+$GLOBALS[COOKIE_TIME], "$GLOBALS[COOKIE_DOMAIN]");
             setcookie ("PASS", $pass, time()+$GLOBALS[COOKIE_TIME], "$GLOBALS[COOKIE_DOMAIN]");
             setcookie ("VISIT", $visit, time()+$GLOBALS[COOKIE_TIME], "$GLOBALS[COOKIE_DOMAIN]");
         //Alles l�schen !!!
         } else {
             setcookie ("USER", "", time()-$GLOBALS[COOKIE_TIME], "$GLOBALS[COOKIE_DOMAIN]");
             setcookie ("PASS", "", time()-$GLOBALS[COOKIE_TIME], "$GLOBALS[COOKIE_DOMAIN]");
             setcookie ("VISIT", "", time()-$GLOBALS[COOKIE_TIME], "$GLOBALS[COOKIE_DOMAIN]");
         }
}
##################### Cookie - setzten ##################### ---
#
#
##################### Table-Header ##################### +++
function table_header($text, $width, $typ="", $extra="", $no_head="") {
         global $HTTP_GET_VARS;

         if (!$no_head) {
             ?>
             <table border='0' cellpadding='2' cellspacing='1' width='<?php echo $width; ?>' align='center' <?php
                    if (!$typ) {
                        echo "class='default_table'";
                    } elseif ($typ == "1" OR $typ == "2" OR $typ == "3") {
                        echo "class='cat_table'";
                    } ?>>
             <?php
         }
         ?>
                <tr <?php
                    if ($typ == "") {
                        echo "class='cat_tr'";
                    } elseif ($typ == "1") {
                        echo "class='default_tr'";
                    } elseif ($typ == "2") {
                        echo "class='cat_one'";
                    } elseif ($typ == "3") {
                        echo "class='cat_two'";
                    }
                    ?>>
                    <td width='100%' align='left' <?php echo $extra; ?>>
                        <b>
                           <?php echo $text; ?>
                        </b>
                    </td>
                </tr>
         <?php
}
##################### Table-Header ##################### ---
#
#
##################### Open - Table (standard-tabelle) ##################### +++
function open_table($msg, $width) {
         ?>
         <table border="0" cellpadding="4" cellspacing="1" align='center' width='<?php echo $width; ?>' class='default_table'>
                <tr class='default_tr'>
                    <td width='100%' align='left'>
                        <b><?php echo $msg; ?></b>
                    </td>
                </tr>
         </table>
         <table border="0" cellpadding="4" cellspacing="1" align='center' width='<?php echo $width; ?>' class='default_table'>
                <tr>
                    <td align='left' class='cat_one'>
                        <span class='font_normal'>
         <?php
}
##################### Open - Table (standard-tabelle) ##################### ---
#
#
##################### Close - Table (standard-tabelle) ##################### +++
function close_table($msg="") {
         ?>
                        </span>
                        <?php if ($msg) {
                            echo "<p><span class='font_small'>$msg</span></p>";
                        }
                        ?>
                    </td>
                </tr>
         </table>
<?php
}
##################### Close - Table (standard-tabelle) ##################### ---
#
#
##################### PM status ##################### +++
function pm_status() {
         $userinfo = get_user_info("");
         return mySQL_num_rows(mySQL_query ("SELECT *
                                             FROM $GLOBALS[TB_MSG]
                                             WHERE $GLOBALS[TB_MSG].to_id='$userinfo[id]'
                                               AND $GLOBALS[TB_MSG].status='0'"));
}
##################### PM status ##################### ---
#
#
##################### Status_NAME (Admin, Mod, ...) ##################### +++
function status_name($id) {
         $userinfo = get_user_info($id);
         ### Sondername ???
         $Daten_access = mysql_fetch_array (mySQL_query ("SELECT *
                                                          FROM $GLOBALS[TB_ACCESS]
                                                          WHERE $GLOBALS[TB_ACCESS].id='$userinfo[access_id]'"));
         if ($Daten_access[special] == "on") {
             $STATUS = $Daten_access[name];

         ### normaler Status-Name
         } else {
             $result_status = mySQL_query ("SELECT $GLOBALS[TB_STATUS].*
                                            FROM $GLOBALS[TB_STATUS]
                                            ORDER BY $GLOBALS[TB_STATUS].points DESC");
             while ($Daten_status = mysql_fetch_array ($result_status)) {
                    //Richtigen Status gefunden
                    if ($userinfo[points] >= $Daten_status[points]) {
                        $STATUS=$Daten_status[name];
                        break;
                    }
             }
         }
         return $STATUS;
}
##################### Status_NAME (Admin, Mod, ...) ##################### ---
#
#
##################### Status_STARS (Admin, Mod, ...) ##################### +++
function status_stars($id) {
         $userinfo = get_user_info($id);
         ### Sonderbild ???
         $Daten_access = mysql_fetch_array (mySQL_query ("SELECT *
                                                          FROM $GLOBALS[TB_ACCESS]
                                                          WHERE $GLOBALS[TB_ACCESS].id='$userinfo[access_id]'"));
         if ($Daten_access[special] == "on" AND $Daten_access[data] != "") {
             $STATUS = "<img src='functions.php?action=access&id=$Daten_access[id]' border='0' alt='$Daten_access[name]'>";

         ### normales Status-Bild
         } else {
             $result_status = mySQL_query ("SELECT $GLOBALS[TB_STATUS].*
                                            FROM $GLOBALS[TB_STATUS]
                                            ORDER BY $GLOBALS[TB_STATUS].points DESC");
             while ($Daten_status = mysql_fetch_array ($result_status)) {
                 if ($Daten_status[points] <= $userinfo[points]) {
                     break;
                 }
             }
             //HTML-Generieren !!!!
             if ($Daten_status[data] != "") {
                 $STATUS="<img src='functions.php?action=status&id=$Daten_status[id]' border='0'>";
             } else {
                 $STATUS = "";
             }
         }
         return $STATUS;
}
##################### Status_STARS (Admin, Mod, ...) ##################### ---
#
#
##################### Who is Online ##################### +++
function who_is_online($action="") {
         global $HTTP_SERVER_VARS;
         //aktuelle Zeit ( Y-M-T--h-m-s )
         $time = date("Y").date("m").date("d").date("H").date("i").date("s");

         ### L�schen der Inaktiven User aus der sessions
         @mySQL_query ("DELETE FROM $GLOBALS[TB_SESSION]
                        WHERE action < $time-$GLOBALS[TIMEOUT]");

         ### Anzeigen der "Who is Online" Liste
         if (!$action) {
             //Member
             $result_user=mySQL_query ("SELECT $GLOBALS[TB_USER].*
                                        FROM $GLOBALS[TB_SESSION], $GLOBALS[TB_USER]
                                        WHERE $GLOBALS[TB_SESSION].uid = $GLOBALS[TB_USER].id
                                          AND $GLOBALS[TB_USER].access_id > '0'");
             $user = mysql_num_rows ($result_user);
             //G�ste
             $guest = mysql_num_rows (mySQL_query ("SELECT $GLOBALS[TB_SESSION].*
                                                    FROM $GLOBALS[TB_SESSION]
                                                    WHERE $GLOBALS[TB_SESSION].uid = '0'"));
             table_header("Zur Zeit aktive Benutzer", "100%", "", "colspan='6'", "1");
                   ?>
                   <td width='15%' colspan='6' class='cat_one'>
                       <span class='font_small'>
                             <?php
                             echo "Es sind momentan <b>$user</b> Member(s) und <b>$guest</b> G&auml;st(e) im Forum unterwegs.<br>\n";
                             while ($Daten = mysql_fetch_array($result_user)) {
                                    $liste .= "<a href='showuser.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=$Daten[id]'>$Daten[name]</a>, ";
                             }
                             echo ereg_replace(", $", "", $liste);
                             ?>
                       </span>
                   </td>
             </tr>
             <?php
         ### Aktualisieren der sessions Tabelle ###
         } elseif ($action) {
             $userinfo = get_user_info();
             //User schon in der Liste ?
             if (mysql_num_rows(mysql_query("SELECT uid FROM $GLOBALS[TB_SESSION] WHERE host='$HTTP_SERVER_VARS[REMOTE_ADDR]' AND uid='$userinfo[id]'")) == 1) {
                 mySQL_query ("UPDATE $GLOBALS[TB_SESSION]
                               SET sess='$GLOBALS[Sess]',
                                   host='$HTTP_SERVER_VARS[REMOTE_ADDR]',
                                   action='$time'
                               WHERE host='$HTTP_SERVER_VARS[REMOTE_ADDR]'
                                 AND uid='$userinfo[id]'");
             //User Online aber nicht in Liste
             } else {
                 mySQL_query ("INSERT INTO $GLOBALS[TB_SESSION] (sess,host,uid,action)
                               VALUES ('$GLOBALS[Sess]','$HTTP_SERVER_VARS[REMOTE_ADDR]','$userinfo[id]','$time')");
             }
         }
}
##################### Who is Online ##################### ---
#
#
##################### Goto (last Topic...) ##################### +++
function goto($goto) {
         global $HTTP_SESSION_VARS, $HTTP_GET_VARS;
         if ($goto) {
             switch ($goto) {
                     //zum letztem Post in einem Topic !!!
                     case "lastpost":
                           $Daten = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_POST].id
                                                                    FROM $GLOBALS[TB_POST]
                                                                    WHERE $GLOBALS[TB_POST].topic_id='$HTTP_GET_VARS[Topic_id]'
                                                                      AND DATE_FORMAT($GLOBALS[TB_POST].post_date,'%Y%m%d%H%i%s') > DATE_FORMAT('$HTTP_SESSION_VARS[VISIT_Log]','%Y%m%d%H%i%s')
                                                                    ORDER BY $GLOBALS[TB_POST].post_date ASC
                                                                    LIMIT 0,1"));
                           //nix gefunden --> zum letzen Beitrag gehen !
                           if (!$Daten[id]) {
                               $Daten = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_POST].id
                                                                        FROM $GLOBALS[TB_POST]
                                                                        WHERE $GLOBALS[TB_POST].topic_id='$HTTP_GET_VARS[Topic_id]'
                                                                        ORDER BY $GLOBALS[TB_POST].post_date DESC
                                                                        LIMIT 0,1"));
                           }
                           //Anzahl der Beitr�ge im Thema
                           $MAX_Posts = mySQL_num_rows(mySQL_query ("SELECT *
                                                                     FROM $GLOBALS[TB_POST]
                                                                     WHERE $GLOBALS[TB_POST].topic_id='$HTTP_GET_VARS[Topic_id]'"));
                           if ($MAX_Posts > $GLOBALS[ANZ_POST]) {
                               $ANZ_S=$MAX_Posts / $GLOBALS[ANZ_POST];
                               $Page = ceil($ANZ_S);
                           } else {
                               $Page="1";
                           }
                           header("Location: showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$HTTP_GET_VARS[Topic_id]&Page=$Page#Post$Daten[id]");
                           break;
             }
         }
}
##################### Goto (last Topic...) ##################### ---
#
#
##################### PM - Eingang (Status-Leiste) ##################### +++
function footer_pm() {
         global $_style;
         $userinfo = get_user_info("");
         if ($userinfo[pm_footer] == "on") {
             $Daten = mysql_num_rows(mysql_query("SELECT *
                                                  FROM $GLOBALS[TB_MSG]
                                                  WHERE to_id='$userinfo[id]'"));
             $width=100*$Daten/$GLOBALS[ANZ_PM];
             $width=ceil($width);
             ?>
             <span class='font_small'>
                   <b>PM-Status:</b>
             </span>
             <br>
             <table border='0' cellpadding='2' cellspacing='1' width='100%' class='default_table'>
                    <tr class='cat_two'>
                        <td width='100%'>
                            <span class='font_small'>
                                  Ihr Posteingang ist zu <?php echo $width; ?>% voll.
                            </span>
                            <br>
                            <img src='<?php echo $_style[pic_pm_status]; ?>' width='<?php echo $width; ?>%' height='10' border='0'>
                            <table border='0' width='100%'>
                                   <tr>
                                       <td align='left' width='20%'>
                                           <span class='font_small'>
                                                 <b>0%</b>
                                           </span>
                                       <td align='center' width='60%'>
                                           <span class='font_small'>
                                                 <b>50%</b>
                                           </span>
                                       <td align='right' width='20%'>
                                           <span class='font_small'>
                                                 <b>100%</b>
                                           </span>
                                       </td>
                                   </tr>
                            </table>
                        </td>
                    </tr>
             </table>
         <?php
         }
}
##################### PM - Eingang (Status-Leiste) ##################### ---
#
#
##################### Get_forum_perm ##################### +++
//(Wenn keine ID �bergeben dann aktueller User)
function get_forum_perm($forum_id, $user_id="") {

         $userinfo = get_user_info($user_id);

         //nicht Eingeloggt !!!
         if (!$userinfo[name]) {
             $id = $GLOBALS[NO_LOGIN];
         //Eingeloggt !!!
         } else {
             $id = $userinfo[access_id];
         }
         $result_forum_access = mySQL_query ("SELECT *
                                              FROM $GLOBALS[TB_FORUM_ACCESS]
                                              WHERE $GLOBALS[TB_FORUM_ACCESS].forum_id='$forum_id'
                                                AND $GLOBALS[TB_FORUM_ACCESS].access_id='$id'");
         $forum_access = mysql_num_rows ($result_forum_access);

         ### Foren Rechte
         if ($forum_access == 1) {
             $STATUS = mysql_fetch_array ($result_forum_access);
             //extra Mod-Rechte ?
             $result_mod = mySQL_query ("SELECT *
                                         FROM $GLOBALS[TB_MOD]
                                         WHERE $GLOBALS[TB_MOD].forum_id='$forum_id'
                                           AND $GLOBALS[TB_MOD].user_id='$userinfo[id]'");
             //ist Mod !!!
             if (mysql_num_rows($result_mod) == 1) {
                 $Mod = mysql_fetch_array($result_mod);
                 $STATUS[mod_openclose] = $Mod[mod_openclose];
                 $STATUS[mod_top] = $Mod[mod_top];
                 $STATUS[mod_move_topic] = $Mod[mod_move_topic];
                 $STATUS[mod_move_post] = $Mod[mod_move_post];
                 $STATUS[mod_edit] = $Mod[mod_edit];
                 $STATUS[mod_del] = $Mod[mod_del];
                 $STATUS[mod_join] = $Mod[mod_join];
             }

         ### Access Rechte
         } else {
             $result_forum_access = mySQL_query ("SELECT *
                                                  FROM $GLOBALS[TB_ACCESS]
                                                  WHERE $GLOBALS[TB_ACCESS].id='$id'");
             $STATUS = mysql_fetch_array ($result_forum_access);
         }
         return $STATUS;
}
##################### Get_forum_perm ##################### ---
#
#
##################### access ##################### +++
function access($typ) {
         global $HTTP_GET_VARS;

         ### in einem Forum ###
         if ($HTTP_GET_VARS[Forum_id]) {
             $forum_id = $HTTP_GET_VARS[Forum_id];

         ### in einem Thema ###
         } elseif ($HTTP_GET_VARS[Topic_id]) {
             $forum_id = get_forum_id($HTTP_GET_VARS[Topic_id]);
         }

         $Daten = get_forum_perm($forum_id);
         switch ($typ) {
                 case "send_pm":
                       if ($Daten[send_pm] != "on") {
                           msg("user","","");
                       }
                       break;
                 case "edit_profil":
                       if ($Daten[edit_profil] != "on") {
                           msg("user","","");
                       }
                       break;
                 case "avatar":
                       if ($Daten[avatar] != "on") {
                           msg("user","","");
                       }
                       break;
                 case "send_mail":
                       if ($Daten[send_mail] != "on") {
                           msg("user","","");
                       }
                       break;
                 case "show_members":
                       if ($Daten[show_members] != "on") {
                           msg("user","","");
                       }
                       break;
                 case "search":
                       if ($Daten[search] != "on") {
                           msg("user","","");
                       }
                       break;
                 case "new_post":
                       if ($Daten[new_post] != "on" OR user_login() == FALSE) {
                           msg("user","","");
                       }
                       break;
                 case "new_topic":
                       if ($Daten[new_topic] != "on" OR user_login() == FALSE) {
                           msg("user","","");
                       }
                       break;
         }
}
##################### access ##################### ---
#
#
##################### get_forum_id ##################### +++
function get_forum_id ($topic_id) {
         $result = mySQL_query ("SELECT forum_id
                                 FROM $GLOBALS[TB_TOPIC]
                                 WHERE $GLOBALS[TB_TOPIC].id='$topic_id'");
         $Daten = mysql_fetch_object ($result);

         return $Daten->forum_id;
}
##################### get_forum_id ##################### ---
#
#
##################### forum_list ##################### +++
function forum_list($Topic, $sort="DESC") {
         if ($GLOBALS[VIEW_FORUM_HISTORY] == "on") {
                   $result = mySQL_query ("SELECT $GLOBALS[TB_POST].text, $GLOBALS[TB_USER].name
                                           FROM $GLOBALS[TB_POST], $GLOBALS[TB_USER], $GLOBALS[TB_TOPIC]
                                           WHERE $GLOBALS[TB_TOPIC].id = '$Topic'
                                             AND $GLOBALS[TB_POST].topic_id=$GLOBALS[TB_TOPIC].id
                                             AND $GLOBALS[TB_POST].user_id=$GLOBALS[TB_USER].id
                                           ORDER BY $GLOBALS[TB_POST].post_date $sort
                                           LIMIT 0, 10");
             ?>
             <table border='0' cellpadding='4' cellspacing='1' width='100%' class='default_table'>
                    <tr class='default_tr'>
                        <td width='100%' align='center' colspan='2'>
                            <B>&Uuml;bersicht <?php
                            if (strtolower($sort) == "desc") {
                                echo "(Neuster Beitrag zuerst)";
                            }
                            ?></B>
                        </td>
                    </tr>
                    <?php
                    $n = 1;
                    while ($Daten = mysql_fetch_array ($result)) {

                           if ($n == "2") {
                               $n = 0;
                               $color = "class='cat_one'";
                           } else {
                               $color = "class='cat_two'";
                           }
                           ?>
                           <tr>
                               <td width='20%' align='left' <?php echo $color; ?>>
                                   <span class='font_small'>
                                         <?php echo $Daten[name]; ?>
                                   </span>
                               <td width='80%' align='left' valign='top' <?php echo $color; ?>>
                                   <span class='font_small'>
                                         <?php echo bbcode($Daten[text], "on", "", "", "on", "", ""); ?>
                                   </span>
                               </td>
                           </tr>
                           <?php
                           $n++;
                    }
             echo "</table>";
         }
}
##################### forum_list ##################### ---
#
#
##################### smilie_list ##################### +++
function smilie_list($view="on") {
         if ($view == "on") {
             ?>
             <table width='80%' align='center' style='border-width: 2px; border-style: outset'>
                    <tr>
                        <td>
                            <table width='100%' style='border-width: 2px; border-style: inset'>
                                   <tr>
                                       <td align='center'>
                                           <span class='font_normal'>
                                                 <b>Smilies</b>
                                           </span>
                                       </td>
                                   </tr>
                            </table>
                        </td>
                    <tr>
                        <td>
                            <table border='0'>
                                   <tr>
                                       <?php
                                       if ($GLOBALS[SMILIES_LIST] > "0") {
                                           $limit = "LIMIT 0, $GLOBALS[SMILIES_LIST]";
                                       }
                                       $result = mysql_query("SELECT *
                                                              FROM $GLOBALS[TB_SMILIES]
                                                              ORDER BY id ASC $limit");
                                       $width = 100 / $GLOBALS[SMILIES_ZEILE];
                                       $n = 0;
                                       while ($Daten = mysql_fetch_array($result)) {
                                              echo "<td align='center' width='$width%'><a href=\"javascript:bbsmilie('$Daten[code]')\"><img src='functions.php?action=smilie&id=$Daten[id]' border='0' alt='$Daten[name]'></a></td>";
                                              $n++;
                                              if ($n == $GLOBALS[SMILIES_ZEILE]) {
                                                  echo "<tr>";
                                                  $n = 0;
                                              }
                                       }
                                       ?>
                                   </tr>
                            </table>
                        </td>
                    </tr>
             </table>
             <?php
             if ($GLOBALS[SMILIES_LIST] != "0") {
                 echo "<div align='center' class='font_small'><b><a href=\"javascript:onclick=Smilies()\">[mehr Smilies]</a></b></div>";
             }
         }
}
##################### smilie_list ##################### ---
#
#
##################### last_login ##################### +++
function last_login($login="") {
         global $HTTP_SESSION_VARS;

         $userinfo = get_user_info();
         ### letztes Login in einer Session Variable speichern...
         @session_start();
         @session_register ("VISIT_Log");
         //kein Datum �bergeben
         if (!$login) {
             $HTTP_SESSION_VARS["VISIT_Log"]=$userinfo["last_login"];
         } else {
             $HTTP_SESSION_VARS["VISIT_Log"]=$login;
         }
         ### in Cookie Speichern
         cookie($userinfo["name"],$userinfo["pass"], $HTTP_SESSION_VARS["VISIT_Log"]);
         ### heutiges Login in DB speichern
         mysql_query("UPDATE $GLOBALS[TB_USER] SET last_login=NOW() WHERE id='$userinfo[id]'");
}
##################### last_login ##################### ---
#
#
##################### topic_abo ##################### +++
function topic_abo($topic, $typ="") {
         $userinfo = get_user_info("");

         ### Senden der eMail�s bei neuem Beitrag seit letzten Besuch
         if ($typ == "send") {
             $result = mysql_query("SELECT $GLOBALS[TB_USER].id AS user_id,
                                           $GLOBALS[TB_USER].email,
                                           $GLOBALS[TB_USER].name,
                                           $GLOBALS[TB_TOPIC].name AS topic_name,
                                           $GLOBALS[TB_FORUM].name AS forum_name
                                    FROM $GLOBALS[TB_ABO], $GLOBALS[TB_USER], $GLOBALS[TB_TOPIC], $GLOBALS[TB_FORUM]
                                    WHERE $GLOBALS[TB_ABO].topic_id='$topic'
                                      AND $GLOBALS[TB_TOPIC].id=$GLOBALS[TB_ABO].topic_id
                                      AND $GLOBALS[TB_FORUM].id=$GLOBALS[TB_TOPIC].forum_id
                                      AND $GLOBALS[TB_USER].id=$GLOBALS[TB_ABO].user_id
                                      AND $GLOBALS[TB_USER].id <> '$userinfo[id]'
                                      AND $GLOBALS[TB_USER].post_email='on'
                                      AND DATE_FORMAT($GLOBALS[TB_ABO].send_date,'%Y%m%d%H%i%s') < DATE_FORMAT($GLOBALS[TB_USER].last_login,'%Y%m%d%H%i%s')");
             while($Daten = mysql_fetch_array($result)) {
                   @mail($Daten[email], "Antwort auf den Beitrag: ".get_html($Daten[topic_name]), "Hallo $Daten[name],\n\n$userinfo[name] hat zu dem Thema: ".get_html($Daten[topic_name])." geantwortet, welches Sie abonniert haben.\nDas Thema befindet sich im Forum: $Daten[forum_name] im $GLOBALS[TITEL_KURZ] Board.\n\n-> http://$GLOBALS[SITE]/showtopic.php?Topic_id=$topic&goto=lastpost\n\nIn diesem Thema k�nnten noch weitere Antworten sein, doch solange Sie das Board nicht wieder betreten, bekommen Sie keine neuen Benachrichtigungen.\n\nGruss,\nIhr $GLOBALS[TITEL_KURZ] Board Team\n\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\nInformation zur Abbestellung:\n\nUm das Thema abzubestellen, m�ssen Sie auf diesen Link klicken:\nhttp://$GLOBALS[SITE]/functions.php?action=abo&op=del&Topic_id=$topic\n\nUm alle Themen abzubestellen, m�ssen Sie auf folgenden Link klicken:\nhttp://$GLOBALS[SITE]/functions.php?action=abo&op=delall", "From: $GLOBALS[TITEL_KURZ] <$GLOBALS[SITE_ADMIN]>\nReturn-Path: <$GLOBALS[SITE_ADMIN]>");
                   mysql_query("UPDATE $GLOBALS[TB_ABO] SET send_date=NOW() WHERE topic_id='$topic' AND user_id='$Daten[user_id]'");
             }
         }

         ### hinzuf�gen zur Abo-Liste
         if ($typ == "add" OR $typ == "send") {

             $anz = mysql_num_rows(mysql_query("SELECT *
                                                FROM $GLOBALS[TB_ABO]
                                                WHERE topic_id='$topic'
                                                  AND user_id='$userinfo[id]'"));
             //hinzuf�gen des Abo�s
             if ($userinfo[post_email] == "on") {
                 //noch kein Abo
                 if ($anz == 0) {
                     mysql_query("INSERT INTO $GLOBALS[TB_ABO] (topic_id, user_id) VALUES ('$topic','$userinfo[id]')");
                     return "topic_abo_add";
                 //Abo schon vorhanden
                 } else {
                     return "topic_abo_fault";
                 }
             //Abo-Funktion deaktiviert
             } else {
                 return "topic_abo_post_email";
             }
         }

         ### l�schen von der Abo-Liste
         if ($typ == "del" AND $topic) {
             mysql_query("DELETE FROM $GLOBALS[TB_ABO] WHERE topic_id='$topic' AND user_id='$userinfo[id]'");
             return "topic_abo_del";
         } elseif ($typ == "delall") {
             mysql_query("DELETE FROM $GLOBALS[TB_ABO] WHERE user_id='$userinfo[id]'");
             return "topic_abo_delall";
         }
}
##################### topic_abo ##################### ---
#
#
##################### avatar ##################### +++
function avatar($id) {
         if (mysql_num_rows(mysql_query("SELECT *
                                         FROM $GLOBALS[TB_AVATARS]
                                         WHERE user_id='$id'")) >= 1) {
            return "<img src='http://$GLOBALS[SITE]/avatar.php?id=$id' border='0'>";
         }
}
##################### avatar ##################### ---
#
#
##################### attachement ##################### +++
function attachement($id) {
         global $_style;
         $result = mysql_query("SELECT *
                                FROM $GLOBALS[TB_FILES]
                                WHERE post_id='$id'");
         $Daten = mysql_fetch_array($result);
         if (mysql_num_rows($result) >= 1){
            return "<p><span class='font_normal'><img src='$_style[pic_file]' border='0'>Anhang: <a href='attachements.php?id=$id' target='_blank'>$Daten[name]</a></span><br>
                    <span class='font_small'>Bisher $Daten[views] x heruntergeladen.</span></p";
         }
}
##################### attachement ##################### ---
#
#
##################### Topic_new ##################### +++
function topic_new($topic_id) {
         global $HTTP_SESSION_VARS, $_style;

         //eingeloggt ???
         if ($HTTP_SESSION_VARS[VISIT_Log]) {
             $result = mysql_query("SELECT $GLOBALS[TB_TOPIC].id
                                    FROM $GLOBALS[TB_TOPIC]
                                    WHERE $GLOBALS[TB_TOPIC].id='$topic_id'
                                      AND DATE_FORMAT($GLOBALS[TB_TOPIC].post_date,'%Y%m%d%H%i%s') > DATE_FORMAT('$HTTP_SESSION_VARS[VISIT_Log]','%Y%m%d%H%i%s')");
         //neu (heute) ???
         } else {
             $result = mysql_query("SELECT $GLOBALS[TB_TOPIC].id
                                    FROM $GLOBALS[TB_TOPIC]
                                    WHERE $GLOBALS[TB_TOPIC].id='$topic_id'
                                      AND TO_DAYS(NOW()) - TO_DAYS($GLOBALS[TB_TOPIC].post_date) = 0");
         }
         $Daten = mysql_fetch_array(mysql_query("SELECT closed
                                                 FROM $GLOBALS[TB_TOPIC]
                                                 WHERE $GLOBALS[TB_TOPIC].id='$topic_id'"));
         //neues Topic !!!
         if (mysql_num_rows($result) == 1) {
             if ($Daten[closed] == "on") {
                 $STATUS = "<img src='$_style[pic_on_lock]' border='0'>";
             } else {
                 $STATUS = "<img src='$_style[pic_on]' border='0'>";
             }
         //altes Topic
         } else {
             if ($Daten[closed] == "on") {
                 $STATUS = "<img src='$_style[pic_off_lock]' border='0'>";
             } else {
                 $STATUS = "<img src='$_style[pic_off]' border='0'>";
             }
         }
         return $STATUS;
}
##################### Topic_new ##################### ---
#
#
##################### Forum_new ##################### +++
function forum_new($forum_id) {
         global $HTTP_SESSION_VARS, $_style;

         //eingeloggt ???
         if ($HTTP_SESSION_VARS[VISIT_Log]) {
             $result = mysql_query("SELECT $GLOBALS[TB_POST].id
                                                FROM $GLOBALS[TB_TOPIC], $GLOBALS[TB_POST]
                                                WHERE $GLOBALS[TB_TOPIC].forum_id='$forum_id'
                                                  AND $GLOBALS[TB_POST].topic_id=$GLOBALS[TB_TOPIC].id
                                                  AND DATE_FORMAT($GLOBALS[TB_POST].post_date,'%Y%m%d%H%i%s') > DATE_FORMAT('$HTTP_SESSION_VARS[VISIT_Log]','%Y%m%d%H%i%s')
                                                ORDER BY $GLOBALS[TB_TOPIC].post_date DESC,
                                                         $GLOBALS[TB_POST].post_date DESC
                                                LIMIT 0,1");
         //neu (heute) ???
         } else {
             $result = mysql_query("SELECT $GLOBALS[TB_POST].id
                                                FROM $GLOBALS[TB_TOPIC], $GLOBALS[TB_POST]
                                                WHERE $GLOBALS[TB_TOPIC].forum_id='$forum_id'
                                                  AND $GLOBALS[TB_POST].topic_id=$GLOBALS[TB_TOPIC].id
                                                  AND TO_DAYS(NOW()) - TO_DAYS($GLOBALS[TB_POST].post_date) = 0
                                                ORDER BY $GLOBALS[TB_TOPIC].post_date DESC,
                                                         $GLOBALS[TB_POST].post_date DESC
                                                LIMIT 0,1");
         }
         //neues Topic !!!
         if (mysql_num_rows($result) == 1) {
                 $STATUS = "<img src='$_style[pic_on]' border='0'>";
         //altes Topic
         } else {
                 $STATUS = "<img src='$_style[pic_off]' border='0'>";
         }
         return $STATUS;
}
##################### Forum_new ##################### ---
#
#
##################### Post_new ##################### +++
function post_new($post_id) {
         global $HTTP_SESSION_VARS, $_style;

         //eingeloggt ???
         if ($HTTP_SESSION_VARS[VISIT_Log]) {
             $result = mysql_query("SELECT $GLOBALS[TB_POST].id
                                    FROM $GLOBALS[TB_POST]
                                    WHERE $GLOBALS[TB_POST].id='$post_id'
                                      AND DATE_FORMAT($GLOBALS[TB_POST].post_date,'%Y%m%d%H%i%s') > DATE_FORMAT('$HTTP_SESSION_VARS[VISIT_Log]','%Y%m%d%H%i%s')");
         //neu (heute) ???
         } else {
             $result = mysql_query("SELECT $GLOBALS[TB_POST].id
                                    FROM $GLOBALS[TB_POST]
                                    WHERE $GLOBALS[TB_POST].id='$post_id'
                                      AND TO_DAYS(NOW()) - TO_DAYS($GLOBALS[TB_POST].post_date) = 0");
         }
         //neuer Post !!!
         if (mysql_num_rows($result) == 1) {
                 $STATUS = "<img src='$_style[pic_post_on]' border='0'>";
         //alter post !!!
         } else {
                 $STATUS = "<img src='$_style[pic_post_off]' border='0'>";
         }
         return $STATUS;
}
##################### Post_new ##################### ---
#
#
##################### Navigation (navi) ##################### +++
function navi($page, $anz, $max, $url) {
         //Anzahl Seiten
         $Seiten = @ceil($anz / $max);

         ### nur wenn mehr als eine Seite !!!
         if ($Seiten > 1) {
             //URL Anpassen
             if (!stristr($url, ".php?")) {
                 $url = str_replace(".php", ".php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]", $url);
             }

             ### R�ckgabewert erstellen
             $STATUS = "<span class='font_normal'>Seiten($Seiten): ";
             //Pfeil zur�ck weil nicht auf erster Seite
             if ($page >= 2) {
                 $back = $page -1;
                 $STATUS .= "<a href='$url&Page=$back'>&lt;&lt;</a>";
                 $from = $page-1;
             } else {
                 $from = 1;
             }
             //bis welche Seite ?
             if ($page+2 < $Seiten) {
                 $to = $page+3;
             } else {
                 $to = $Seiten+1;
             }

             for ($n=$from; $n < $to; $n++) {

                  if ($page != $n) {
                      $STATUS .= "&nbsp;<a href='$url&Page=$n'>$n</a>&nbsp;";
                  } else {
                      $STATUS .= "<b>[$n]</b>";
                  }
             }
             //Pfeil vor Weil $n < $Seiten
             if ($page <= $Seiten-1) {
                 $next = $page +1;
                 $STATUS .= "&nbsp;<a href='$url&Page=$next'>&gt;&gt;</a>";
                 //&nbsp;<a href='$url&Page=$Seiten'>...Letzte</a>
             }
             $STATUS .= "</span>";
         }
         return $STATUS;
}
##################### Navigation (navi) ##################### ---
#
#
##################### last_topic ##################### +++
function last_topic($topic_id) {
         $Daten = mysql_fetch_array(mysql_query("SELECT $GLOBALS[TB_TOPIC].name AS topic_name,
                                                        $GLOBALS[TB_USER].id AS user_id,
                                                        $GLOBALS[TB_USER].name AS user_name,
                                                        $GLOBALS[TB_POST].post_date
                                                 FROM $GLOBALS[TB_TOPIC], $GLOBALS[TB_POST], $GLOBALS[TB_USER]
                                                 WHERE $GLOBALS[TB_TOPIC].id='$topic_id'
                                                   AND $GLOBALS[TB_POST].topic_id=$GLOBALS[TB_TOPIC].id
                                                   AND $GLOBALS[TB_USER].id=$GLOBALS[TB_POST].user_id
                                                 ORDER BY $GLOBALS[TB_POST].post_date DESC
                                                 LIMIT 0,1"));
         return $Daten;
}
##################### last_topic ##################### ---
#
#
##################### last_post ##################### +++
function last_post($topic_id) {
         $Daten = mysql_fetch_array(mysql_query("SELECT $GLOBALS[TB_USER].id AS user_id,
                                                        $GLOBALS[TB_USER].name AS user_name,
                                                        $GLOBALS[TB_POST].post_date
                                                 FROM $GLOBALS[TB_POST], $GLOBALS[TB_USER]
                                                 WHERE $GLOBALS[TB_POST].topic_id='$topic_id'
                                                   AND $GLOBALS[TB_USER].id=$GLOBALS[TB_POST].user_id
                                                 ORDER BY $GLOBALS[TB_POST].post_date DESC
                                                 LIMIT 0,1"));
         return $Daten;
}
##################### last_post ##################### ---
#
#
##################### del_topic ##################### +++
function del_topic($topic) {

         //Forum id bekommen
         $forum = mysql_fetch_array(mysql_query("SELECT * FROM $GLOBALS[TB_TOPIC] WHERE id='$topic'"));
         //Topic l�schen
         mysql_query("DELETE FROM $GLOBALS[TB_TOPIC] WHERE $GLOBALS[TB_TOPIC].id='$topic'");
         //Abo�s l�schen
         mysql_query("DELETE FROM $GLOBALS[TB_ABO] WHERE $GLOBALS[TB_ABO].topic_id='$topic'");

         ### Beitr�ge l�schen
         $result = mysql_query("SELECT $GLOBALS[TB_POST].id
                                FROM $GLOBALS[TB_POST]
                                WHERE $GLOBALS[TB_POST].topic_id='$topic'");
         $anz = 0;
         while ($post = mysql_fetch_array($result)) {
                $anz++;
                //Dateianh�nge l�schen
                mysql_query("DELETE FROM $GLOBALS[TB_FILES] WHERE $GLOBALS[TB_FILES].post_id='$post[id]'");
         }
         //Beitr�ge l�schen
         mysql_query("DELETE FROM $GLOBALS[TB_POST] WHERE $GLOBALS[TB_POST].topic_id='$topic'");

         $last_topic = mysql_fetch_array(mysql_query("SELECT * FROM $GLOBALS[TB_TOPIC] WHERE forum_id='$forum[forum_id]' ORDER BY post_date DESC LIMIT 0,1"));
         mysql_query("UPDATE $GLOBALS[TB_FORUM] SET posts=posts-$anz, topics=topics-1, last_topic='$last_topic[id]' WHERE $GLOBALS[TB_FORUM].id='$forum[forum_id]'");

         ### Umfragen l�schen
         $result = mysql_query("SELECT $GLOBALS[TB_POLL].id, $GLOBALS[TB_POLL_TEXT].id AS text_id
                                FROM $GLOBALS[TB_POLL], $GLOBALS[TB_POLL_TEXT]
                                WHERE $GLOBALS[TB_POLL].topic_id='$topic'
                                  AND $GLOBALS[TB_POLL_TEXT].poll_id=$GLOBALS[TB_POLL].id");
         while ($poll = mysql_fetch_array($result)) {
                //Poll - Benutzer l�schen
                mysql_query("DELETE FROM $GLOBALS[TB_POLL_USER] WHERE $GLOBALS[TB_POLL_USER].text_id='$poll[text_id]'");
                //Poll - Texte l�schen
                mysql_query("DELETE FROM $GLOBALS[TB_POLL_TEXT] WHERE $GLOBALS[TB_POLL_TEXT].id='$poll[text_id]'");
         }
         //Poll l�schen
         mysql_query("DELETE FROM $GLOBALS[TB_POLL] WHERE $GLOBALS[TB_POLL].topic_id='$topic'");
}
##################### del_topic ##################### ---
#
#
##################### del_post ##################### +++
function del_post ($post) {

         $Daten = mysql_fetch_array(mysql_query("SELECT $GLOBALS[TB_FORUM].id AS forum_id,
                                                        $GLOBALS[TB_TOPIC].id AS topic_id
                                                 FROM $GLOBALS[TB_FORUM], $GLOBALS[TB_TOPIC], $GLOBALS[TB_POST]
                                                 WHERE $GLOBALS[TB_POST].id='$post'
                                                   AND $GLOBALS[TB_POST].topic_id=$GLOBALS[TB_TOPIC].id
                                                   AND $GLOBALS[TB_FORUM].id=$GLOBALS[TB_TOPIC].forum_id"));
         //Beitrag l�schen
         mysql_query("DELETE FROM $GLOBALS[TB_POST] WHERE $GLOBALS[TB_POST].id='$post'");
         //Attachements l�schen
         mysql_query("DELETE FROM $GLOBALS[TB_FILES] WHERE $GLOBALS[TB_FILES].post_id='$post'");
         //Forum - Update
         mysql_query("UPDATE $GLOBALS[TB_FORUM] SET posts=posts-1 WHERE id='$Daten[forum_id]'");
         //Topic - Update
         mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET posts=posts-1 WHERE id='$Daten[topic_id]'");

}
##################### del_post ##################### ---
#
#
##################### upload_liste ##################### +++
function upload_liste($path, $name="sysfile", $selected="", $filter="") {
         echo "<select name='$name'>";
               echo "<option value=''>--- auswahl ---";
               $verz = dir("$GLOBALS[MAIN_PATH]/$path");
               while ($entry = $verz->read()) {
                      if (is_file("$GLOBALS[MAIN_PATH]/$path/$entry") AND $entry != "." AND $entry != "..") {
                          //Filter
                          if ($filter) {
                              //Filter OK ???
                              $sub = substr($filter, 1, strlen($filter));
                              if (strtolower($filter) == strtolower(substr($entry, -strlen($filter)))) {
                                  echo "<option value='$path/$entry'";
                                  if ("$path/$entry" == $selected) { echo " selected"; }
                                  echo ">$path/$entry";

                              //Filter negiert
                              } elseif (substr($filter, 0, 1) == "!" AND strtolower($sub) != strtolower(substr($entry, -strlen($sub)))) {
                                  echo "<option value='$path/$entry'";
                                  if ("$path/$entry" == $selected) { echo " selected"; }
                                  echo ">$path/$entry";
                              }

                          //kein Filter
                          } else {
                              echo "<option value='$path/$entry'";
                              if ("$path/$entry" == $selected) { echo " selected"; }
                              echo ">$path/$entry";
                          }

                      }
               }
         echo "</select>";
}
##################### upload_liste ##################### ---
#
#
##################### get_html ##################### +++
function get_html($message) {
         //Sonderzeichen
         $message = preg_replace("/&lt;/si", "<", $message);
         $message = preg_replace("/&gt;/si", ">", $message);
         $message = preg_replace("/&amp;/si", "&", $message);
         $message = preg_replace("/&quot;/si", "\"", $message);
         $message = preg_replace("/&euro;/si", "�", $message);
         //Umlaute
         $message = preg_replace("/&auml;/si", "�", $message);
         $message = preg_replace("/&Auml;/si", "�", $message);
         $message = preg_replace("/&ouml;/si", "�", $message);
         $message = preg_replace("/&Ouml;/si", "�", $message);
         $message = preg_replace("/&uuml;/si", "�", $message);
         $message = preg_replace("/&Uuml;/si", "�", $message);
         $message = preg_replace("/&szlig;/si", "�", $message);
         return $message;
}
##################### get_html ##################### ---
#
#
##################### gz_site ##################### +++
function gz_site() {
         global $HTTP_SERVER_VARS, $HTTP_POST_VARS;

         //Puffer bekommen
         $contents = ob_get_contents();

         //Puffer leeren
         ob_end_clean();

         ### Kompression !!!
         if(ereg('gzip, deflate', $HTTP_SERVER_VARS['HTTP_ACCEPT_ENCODING']) AND $GLOBALS["GZ_COMPRESS"] == "on" AND $contents AND !$HTTP_POST_VARS["gz_site"]) {
            //Header senden
            header("Content-Encoding: gzip");

            //Komprimierten String erzeugen und ausgeben
            $return = "\x1f\x8b\x08\x00\x00\x00\x00\x00";
            $return .= substr(gzcompress($contents,$GLOBALS["GZ_LEVEL"]),0,-4);
            $return .= pack("V", crc32($contents));
            $return .= pack("V", strlen($contents));
            echo $return;

         ### keine !!! Kompression
         } else {
            echo $contents;
         }
         exit();
}
##################### gz_site ##################### ---
#
#
##################### "Stopuhr" ##################### +++
function getmicrotime(){
    list($usec, $sec) = explode(" ",microtime());
    return ((float)$usec + (float)$sec);
}
##################### "Stopuhr" ##################### ---
#
#
##################### Style "bekommen" ##################### +++
function get_style($id="") {
         if ($id) {
             $result = mysql_query("SELECT * FROM $GLOBALS[TB_STYLES] WHERE id='$id'");
         } else {
             $result = mysql_query("SELECT * FROM $GLOBALS[TB_STYLES] WHERE active='on'");
         }
         return mysql_fetch_array($result);
}
##################### Style "bekommen" ##################### ---
#
#
################################################################################
################################################################################
################################################################################
?>