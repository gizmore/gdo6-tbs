<?php
        include("head.php");        //Header mit Bild, Suchen...

######### ANZ - Posts ##### +++
        $Topic_anz = mySQL_num_rows(mySQL_query ("SELECT id FROM $TB_TOPIC WHERE $TB_TOPIC.forum_id='$HTTP_GET_VARS[Forum_id]'"));

        //wenn keine Page �bergeben wurde
        if ($HTTP_GET_VARS[Page] == "") {
            $HTTP_GET_VARS[Page]="1";
        }

        //f�r die LIMIT
        if ($Topic_anz > $ANZ_TOPIC) {
            $p=$HTTP_GET_VARS[Page]-1;
            $L_AB=$ANZ_TOPIC*$p;
        }
        //f�r die LIMIT
        if ($L_AB < "0") {
            $L_AB="0";
        }
######### ANZ - Posts ##### ---
#
#
######### Navigation ##### +++
$Daten_forum = mysql_fetch_array(mySQL_query ("SELECT $TB_FORUM.name AS forum_name,
                                                      $TB_CAT.name AS cat_name,
                                                      $TB_CAT.id AS cat_id
                                               FROM $TB_FORUM, $TB_CAT
                                               WHERE $TB_FORUM.id='$HTTP_GET_VARS[Forum_id]'
                                                 AND $TB_FORUM.cat_id=$TB_CAT.id"));
?>
<BR>
<?php
###*** Seiten Navigation ***
echo "<div align='right'>".navi($HTTP_GET_VARS[Page], $Topic_anz, $ANZ_TOPIC, "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Forum_id=$HTTP_GET_VARS[Forum_id]")."</div>";
###*** Seiten Navigation ***
?>
<table border='0' cellpadding='2' cellspacing='1' width='100%' class='default_table'>
       <tr class='default_tr'>
           <td width='3%' NOWRAP align='left'>
               &nbsp;
           <td width='47%' NOWRAP align='left'>
               <B>Thema</B>
           <td width='10%' NOWRAP align='center'>
               <b>Antworten</b>
           <td width='5%' NOWRAP align='center'>
               <b>Hits</b>
           <td width='15%' NOWRAP align='center'>
               <b>Letzter Beitrag</b>
           <td width='20%' NOWRAP align='center'>
               <b>erstellt von</b>
           </td>
       </tr>
       <tr class='cat_tr'>
           <td width='100%' valign='top' colspan='6'>
               <?php
               echo "<a href='index.php?$Sess_Name=$Sess'><b>$TITEL_KURZ</b></a>&nbsp;:&nbsp;<a href='index.php?$Sess_Name=$Sess&Cat_id=$Daten_forum[cat_id]'><b>$Daten_forum[cat_name]</b></a>&nbsp;:&nbsp;<b>$Daten_forum[forum_name]</b>";
               ?>
           </td>
       </tr>
<?php
######### Navigation ##### ---
#
#
######### Topics ##### +++
$result_topic = mySQL_query ("SELECT $TB_TOPIC.*,
                                     $TB_USER.id AS user_id,
                                     $TB_USER.name AS user_name
                              FROM $TB_TOPIC, $TB_USER
                              WHERE $TB_TOPIC.forum_id='$HTTP_GET_VARS[Forum_id]'
                                AND $TB_TOPIC.show_topic='on'
                                AND $TB_USER.id=$TB_TOPIC.poster_id
                              ORDER BY $TB_TOPIC.top DESC, $TB_TOPIC.post_date DESC
                              LIMIT $L_AB,$ANZ_TOPIC");
while ($Daten_topic = mysql_fetch_array ($result_topic)) {
       ?>
              <tr class='default_tr'>
                  <td width='3%' align='center' class='cat_two'>
                      <?php echo topic_new($Daten_topic[id]); ?>
                  <td width='47%' class='cat_one'>
                      <?php
                      //Top ???
                      if ($Daten_topic[top]) { echo "Wichtig: "; }
                      //Umfrage ???
                      $Topic_poll = mysql_num_rows(mySQL_query ("SELECT $TB_POLL.id
                                                                 FROM $TB_POLL
                                                                 WHERE $TB_POLL.topic_id='$Daten_topic[id]'"));
                      if ($Topic_poll == "1") { echo "Umfrage: "; }
                      ?>
                      <a href='<?php echo "showtopic.php?$Sess_Name=$Sess&Topic_id=$Daten_topic[id]"; ?>'><b><?php echo $Daten_topic[name]; ?></b></a>
                  <td width='10%' align='center' class='cat_two'>
                      <b><?php echo $Daten_topic[posts]; ?></b>
                  <td width='5%' align='center' class='cat_one'>
                      <b><?php echo $Daten_topic[views]; ?></b>
                  <td width='15%' align='center' class='cat_two'>
                      <span class='font_small'>
                            <?php
                            $last_post = last_post($Daten_topic[id]);
                            echo "<a href='showtopic.php?$Sess_Name=$Sess&Topic_id=$Daten_topic[id]&goto=lastpost' title='Gehe zum letzten Beitrag'><img src='$_style[pic_last_post]' border='0' alt='Gehe zum letzten Beitrag'></a>&nbsp;von&nbsp;<a href='showuser.php?$Sess_Name=$Sess&id=$last_post[user_id]'>$last_post[user_name]</a>";
                            echo "<br>am&nbsp;$last_post[post_date]";
                            ?>
                      </span>
                  <td width='20%' align='center' class='cat_one'>
                            <a href='<?php echo "showuser.php?$Sess_Name=$Sess&id=$Daten_topic[user_id]"; ?>'><?php echo $Daten_topic[user_name]; ?></a>
                      </span>
                  </td>
              </tr>
       <?php
}
echo "</table>";
###*** Seiten Navigation ***
echo "<div align='right'>".navi($HTTP_GET_VARS[Page], $Topic_anz, $ANZ_TOPIC, "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Forum_id=$HTTP_GET_VARS[Forum_id]")."</div>";
###*** Seiten Navigation ***

//new Topic
echo "<br><div align='right'><a href='newtopic.php?$Sess_Name=$Sess&Forum_id=$HTTP_GET_VARS[Forum_id]'><img src='$_style[pic_new_topic]' border='0'></a></div>";

echo "<br>";
footer_list();
footer_rulez();
echo "<br>";
footer();
?>