<?php
        include("head.php");        //Header mit Bild, Suchen...
        echo "<script language=\"Javascript\" src=\"bbcode.js\"></script>";
        access("send_pm");      //Zugriff beschr�nken
echo "<br>";
//action == "" --> in !!! (Posteingang)
if (!$HTTP_GET_VARS[action]) {
    $HTTP_GET_VARS[action]="in";
}
//action == "" --> in !!! (Posteingang)
################################################################################
############################## != neue PM ############################## +++
if ($HTTP_GET_VARS[action] != "new") {
    ?>
    <table border='0' align='center' cellpadding='4' cellspacing='1' width='100%' class='default_table'>
       <tr id='nav'>
         <td align='center'>
             <a href='<?php echo "user.php?$Sess_Name=$Sess"; ?>'><b>&Uuml;bersicht</b></a>
         <td align='center'>
             <a href='<?php echo "user.php?$Sess_Name=$Sess&action=profile"; ?>'><b>Profil bearbeiten</b></a>
         <td align='center'>
             <a href='<?php echo "user.php?$Sess_Name=$Sess&action=settings"; ?>'><b>Einstellungen bearbeiten</b></a>
         <td align='center'>
             <a href='<?php echo "user.php?$Sess_Name=$Sess&action=pass"; ?>'><b>Passwort &auml;ndern</b></a>
         <td align='center'>
             <a href='<?php echo "user.php?$Sess_Name=$Sess&action=pic"; ?>'><b>Avatar bearbeiten</b></a>
         <td align='center'>
             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=in"; ?>'><b>Private Nachrichten</b></a>
         </td>
       </tr>
    </table>
    <br>
    <?php
    if ($HTTP_GET_VARS[action] == "in") {
        table_header("Posteingang", "100%", "", "colspan='4'");
    } elseif ($HTTP_GET_VARS[action] == "out") {
        table_header("Postausgang", "100%", "", "colspan='4'");
    }
}
############################## != neue PM ############################## ---
#
#
##################### Switches ##################### +++
switch ($HTTP_GET_VARS[action]) {

        case "in":
              pm_liste("in");
              break;

        case "out":
              pm_liste("out");
              break;

        case "view":
              pm_view($HTTP_GET_VARS[id]);
              break;

        case "new":
              pm_new($HTTP_GET_VARS[user_id], $HTTP_GET_VARS[quote]);
              break;

        case "del":
              pm_del($HTTP_POST_VARS[id]);
              break;

        case "delall":
              pm_delall();
              break;

        case "read":
              pm_read();
              break;

        case "save":
              pm_save();
              break;
}
##################### Switches ##################### ---
#
#
#################################################################
######################### Funktionen ############################
#################################################################
#
#
##################### Postein- / ausgang ##################### +++
function pm_liste($typ) {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS, $_style;
         ?>
         <tr class='default_tr'>
             <td width='5%' align='center'>&nbsp;</td>
             <td width='60%' align='center'>
                 <b>Betreff</b>
             <td width='20%' align='center'>
                 <b><?php
                 if ($typ == "in") {
                     echo "Sender";
                 } elseif($typ == "out") {
                     echo "Empf&auml;nger";
                 }
                 ?></b>
             <td width='20%' align='center'>
                 <b>Datum Zeit</b>
             </td>
         </tr>
         <?php
         $userinfo = get_user_info();
         if ($typ == "in") {
             $result = mySQL_query ("SELECT *
                                     FROM $GLOBALS[TB_MSG]
                                     WHERE $GLOBALS[TB_MSG].to_id='$userinfo[id]'
                                     ORDER BY $GLOBALS[TB_MSG].date DESC");
         } elseif($typ == "out") {
             $result = mySQL_query ("SELECT *
                                     FROM $GLOBALS[TB_MSG]
                                     WHERE $GLOBALS[TB_MSG].from_id='$userinfo[id]'
                                     ORDER BY $GLOBALS[TB_MSG].date DESC");
         }
         while ($Daten = mysql_fetch_array ($result)) {
                ?>
                <tr>
                    <td width='5%' align='center' class='cat_two'>
                        <?php
                        if ($Daten[status] == "1") {
                            echo "<img src='$_style[pic_off]' border='0'>\n";
                        } elseif ($Daten[status] == "0") {
                            echo "<img src='$_style[pic_on]' border='0'>\n";
                        }
                        ?>
                    <td width='55%' class='cat_one'>
                        <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=view&id=$Daten[id]"; ?>'><b><?php echo $Daten[name]; ?></b></a>
                    <td width='20%' align='center' class='cat_two'>
                        <a href='<?php echo "showuser.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=";
                           if ($typ == "in") {
                               $from = get_user_info($Daten[from_id]);
                               echo $from[id]."'>";
                               echo $from[name];
                           } elseif ($typ == "out") {
                               $from = get_user_info($Daten[to_id]);
                               echo $from[id]."'>";
                               echo $from[name];
                           }
                           ?></a>
                    <td width='20%' align='center' class='cat_one'>
                        <?php echo $Daten[date]; ?>
                    </td>
                </tr>
                <?php
         }
         ?>
                <tr class='default_tr'>
                    <form method='get' action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                          <input type='hidden' name='<?php echo $GLOBALS[Sess_Name]; ?>' value='<?php echo $GLOBALS[Sess]; ?>'>
                          <td width='100%' align='right' colspan='6'>
                              <b>Gehe zu:</b>
                              <select name='action' <?php echo "onchange=\"window.location=('$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action='+this.options[this.selectedIndex].value)\""; ?>>
                                      <option value='in'<?php if ($HTTP_GET_VARS[action] == "in") { echo " selected"; } ?>>Posteingang</option>
                                      <option value='out'<?php if ($HTTP_GET_VARS[action] == "out") { echo " selected"; } ?>>Postausgang</option>
                              </select>
                              <input type='submit' value='OK'>
                          </td>
                    </form>
                </tr>
         </table>
         <br>
         <div align='right'>
              <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=delall"; ?>'><img src='<?php echo $_style[pic_pm_delall]; ?>' border='0' alt='Alle Nachrichten l&ouml;schen'></a>
              &nbsp;&nbsp;
              <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=read"; ?>'><img src='<?php echo $_style[pic_pm_readall]; ?>' border='0' alt='Alle Nachrichten als gelesen markieren'></a>
              &nbsp;&nbsp;
              <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=new"; ?>'><img src='<?php echo $_style[pic_pm_new]; ?>' border='0' alt='eine neue Nachricht erstellen'></a>
         </div>
         <br>
         <?php
}
##################### Postein- / ausgang ##################### ---
#
#
##################### PM anzeigen (view) ##################### +++
function pm_view($id) {
         global $HTTP_SERVER_VARS, $_style;

         $userinfo = get_user_info();

         //Nachricht - Info�s
         $Daten = mysql_fetch_array(mySQL_query("SELECT $GLOBALS[TB_MSG].*,
                                                        $GLOBALS[TB_USER].name AS from_name,
                                                        $GLOBALS[TB_USER].points AS from_points,
                                                        $GLOBALS[TB_USER].reg AS from_reg,
                                                        $GLOBALS[TB_USER].reg AS from_sign
                                                 FROM $GLOBALS[TB_MSG], $GLOBALS[TB_USER]
                                                 WHERE $GLOBALS[TB_MSG].id='$id'
                                                   AND $GLOBALS[TB_MSG].from_id=$GLOBALS[TB_USER].id"));

         //nicht der Ersteller / Empf�nger der PM !!!
         if ($userinfo[id] != $Daten[to_id] AND $userinfo[id] != $Daten[from_id]) {
             msg("private_fault", "2", "");
         }

         //Nachricht gelesen !!! (nur wenn ich der Empf�nger bin)
         if ($Daten[to_id] == $userinfo[id]) {
             mysql_query("UPDATE $GLOBALS[TB_MSG] SET status='1' WHERE id='$id'");
         }
         ?>
         <table border='0' cellpadding='2' cellspacing='1' width='100%' class='default_table'>
                <tr class='default_tr'>
                    <td width='20%' align='center'>
                        <b>Autor</b>
                    <td width='80%' align='center'>
                        <b>Nachricht</b>
                    </td>
                <tr>
                    <td width='20%' align='center' valign='top' class='cat_two'>
                        <b><?php echo $Daten[from_name]; ?></b>
                        <br>
                        <span class='font_small'>
                              (<?php echo status_name($Daten[from_id]); ?>)
                              <?php
                              echo "<br>";
                              echo status_stars($Daten[from_id]);
                              echo "<br>";
                              ?>
                              <br>Beitr&auml;ge: <?php echo $Daten[from_points]; ?>
                                  <?php echo "<br>".avatar($Daten[from_id])."<br>"; ?>
                              <p>
                                 Registriert seit: <?php echo $Daten[from_reg]; ?>
                              </p>
                        </span>
                    <td width='80%' align='left' valign='top' class='cat_one'>
                        <b><?php echo $Daten[name]; ?></b>
                        <br><br>
                        <?php
                        #### BB-Code durch HTML-Code ersetzen ###+++
                        $message = bbcode($Daten[text], $Daten[bbcodes], $Daten[html], $Daten[smilies], "on", "on");
                        //Signatur
                        $message .= "<br><br>_________________<br>".bbcode("$Daten_poster[sign]", $GLOBALS[SIGN_BBCODES], $GLOBALS[SIGN_HTML], $GLOBALS[SIGN_SMILIES], "on", "on");
                        #### BB-Code durch HTML-Code ersetzen ###---
                        echo $message;
                        ?>
                    </td>
                <tr height='10'>
                    <td width='20%' align='center' class='cat_two'>
                        <img src='<?php echo $_style[pic_post_off]; ?>' border='0'>&nbsp;
                        <span class='font_small'>
                              <?php echo $Daten[date]; ?>
                        </span>
                    <td width='80%' align='left' class='cat_two'>
                        <a href='<?php echo "showuser.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=$Daten[from_id]"; ?>' target='_blank'><img src='<?php echo $_style[pic_profile]; ?>' border='0' alt='Profil von <?php echo $Daten[from_name]; ?> anzeigen'></a>
                        <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=new&user_id=$Daten[from_id]"; ?>'><img src='<?php echo $_style[pic_pm]; ?>' border='0' alt='eine neue Nachricht an <?php echo $Daten[from_name]; ?> schicken'></a>
                    </td>
                </tr>
         </table>
         <p></p>
         <table width="100%">
                <tr>
                    <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del"; ?>'>
                          <td>
                              <input type='hidden' name='id' value='<?php echo $Daten[id]; ?>'>
                              <span class='font_normal'>
                                    <b>L&ouml;schen</b>&nbsp;<input type='checkbox' name='del'>
                              </span>
                              <input type='submit' value='L&ouml;schen'>
                          <td align='right'>
                              <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=new&quote=$Daten[id]"; ?>'><img src='<?php echo $_style[pic_pm_reply]; ?>' border='0' alt='auf diese Nachricht antworten'></a>
                          </td>
                    </form>
                </tr>
         </table>
<?php
}
##################### PM anzeigen (view) ##################### ---
#
#
############################## New ############################## +++
function pm_new($user_id, $quote="") {
         global $HTTP_SERVER_VARS, $_style;
         //Optionen des akt. Users herraus bekommen
         $userinfo = get_user_info();

         ##### Quote - Post ??? ##### +++
         if ($quote) {
             //Quote - Text !!!
             $result_quote = mySQL_query ("SELECT *
                                           FROM $GLOBALS[TB_MSG]
                                           WHERE $GLOBALS[TB_MSG].id='$quote'");
             $Daten_quote = mysql_fetch_array ($result_quote);

             //Quote zeichen
             $message = "[quote] $Daten_quote[text] [/quote]\n";
             //Empf�nger
             $to_user = get_user_info($Daten_quote[from_id]);
             //nicht der Ersteller / Empf�nger der PM !!!
             if ($userinfo[id] != $Daten_quote[to_id] AND $userinfo[id] != $Daten_quote[from_id]) {
                 msg("private_fault", "2", "");
             }
         } elseif ($user_id) {
             $to_user = get_user_info($user_id);
             $user_perm = get_forum_perm("", $to_user[id]);
             if ($user_perm[send_pm] != "on") {
                 msg("private_user_fault", "3", "back()");
             }
         }
         ##### Quote - Post ??? ##### ---


         ################################ Hier geht�s los ############################### +++
         echo "<form name='bbform' onSubmit='return validate(this)' method='post' action='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save'>";
         ################################################################################
         table_header("Neue PM erstellen", "100%","1","colspan='2'");
               ?>
                <tr>
                    <td width='100%' valign='top' colspan='2' class='cat_tr'>
                        <?php
                        echo "<a href='index.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]'><b>$GLOBALS[TITEL_KURZ]</b></a>&nbsp;:&nbsp;<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]'><b>Private Nachrichten</b></a>&nbsp;:&nbsp;<b>new PM</b>";
                        ?>
                    </td>
                <tr>
                    <td width='30%' class='cat_two'>
                        <b>Angemeldet als:</b>
                    <td width='70%' align='left' class='cat_one'>
                        <b><?php echo $userinfo[name]; ?></b>&nbsp;&nbsp;
                        <a href='<?php echo "login.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=logout"; ?>'>[Logout]</a>
                    </td>
                <tr>
                    <td width='30%' class='cat_two'>
                        <b>Empf&auml;nger:</b>
                    <td width='70%' align='left' class='cat_one'>
                        <input type='text' name='to_name' maxlength='255' size='30' value="<?php echo $to_user[name]; ?>" tabindex='1'>&nbsp;
                        <a href='#members' onclick="window.open('<?php echo "http://$GLOBALS[SITE]/functions.php?action=member_search&$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>','Members','height=150, width=350, toolbar=no, scrollbars=no, resizable=no')">[members]</a>
                    </td>
                <tr>
                    <td width='30%' class='cat_two'>
                        <b>Betreff:</b>
                    <td width='70%' align='left' class='cat_one'>
                        <input type='text' name='subject' maxlength='255' size='60' value="<?php
                        if ($quote) {
                            echo "RE: ".$Daten_quote[name];
                        }
                        ?>" tabindex='2'>
                    </td>
         <?php if ($GLOBALS[PM_BBCODES] == "on") { ?>
         <tr>
             <td width='30%' valign='top' class='cat_two'>
                 <b>Board-Code:</b>
                 <span class='font_small'>
                       <a href="javascript:BBCode()">[Hilfe]</a>
                 </span>
             <td width='70%' class='cat_one'>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'SIZE')" name='select_size'>
                         <option value='0'>SIZE
                         <option value='1'>winzig
                         <option value='2'>klein
                         <option value='3'>mittel
                         <option value='4'>gro&szlig;
                         <option value='5'>riesig
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'FONT')" name='select_font'>
                         <option value='0'>FONT
                         <option value='arial'>Arial
                         <option value='comic sans ms'>Comic
                         <option value='courier'>Courier
                         <option value='courier new'>Courier New
                         <option value='tahoma'>Tahoma
                         <option value='times new roman'>Times New Roman
                         <option value='verdana'>Verdana
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'COLOR')" name='select_color'>
                         <option value='0'>COLOR
                         <option value='skyblue' style='color:skyblue'>sky blue</option>
                         <option value='royalblue' style='color:royalblue'>royal blue</option>
                         <option value='blue' style='color:blue'>blue</option>
                         <option value='darkblue' style='color:darkblue'>dark-blue</option>
                         <option value='orange' style='color:orange'>orange</option>
                         <option value='orangered' style='color:orangered'>orange-red</option>
                         <option value='crimson' style='color:crimson'>crimson</option>
                         <option value='red' style='color:red'>red</option>
                         <option value='firebrick' style='color:firebrick'>firebrick</option>
                         <option value='darkred' style='color:darkred'>dark red</option>
                         <option value='green' style='color:green'>green</option>
                         <option value='limegreen' style='color:limegreen'>limegreen</option>
                         <option value='seagreen' style='color:seagreen'>sea-green</option>
                         <option value='deeppink' style='color:deeppink'>deeppink</option>
                         <option value='tomato' style='color:tomato'>tomato</option>
                         <option value='coral' style='color:coral'>coral</option>
                         <option value='purple' style='color:purple'>purple</option>
                         <option value='indigo' style='color:indigo'>indigo</option>
                         <option value='burlywood' style='color:burlywood'>burlywood</option>
                         <option value='sandybrown' style='color:sandybrown'>sandy brown</option>
                         <option value='sienna' style='color:sienna'>sienna</option>
                         <option value='chocolate' style='color:chocolate'>chocolate</option>
                         <option value='teal' style='color:teal'>teal</option>
                         <option value='silver' style='color:silver'>silver</option>
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'ALIGN')" name='select_align'>
                         <option value='0'>Ausrichtung
                         <option value='center'>Center
                         <option value='left'>Left
                         <option value='right'>Right
                         <option value='justify'>Justify
                 </select>
                 <br>
                 <input type='button' value=' B ' onclick="bbcode(this.form,'B','')" title='Fett (alt+b)' accesskey='b'>
                 <input type='button' value=' I ' onclick="bbcode(this.form,'I','')" title='Kursiv (alt+i)' accesskey='i'>
                 <input type='button' value=' U ' onclick="bbcode(this.form,'U','')" title='Unterstrichen (alt+u)' accesskey='u'>
                 <input type='button' value='http://' onclick="bbnamed(this.form,'URL')" title='Hyperlink einf&uuml;gen'>
                 <input type='button' value=' @ ' onclick="bbnamed(this.form,'EMAIL')" title='Email Adresse einf&uuml;gen'>
                 <input type='button' value='IMG' onclick="bbcode(this.form,'IMG','http://')" title='Bild einf&uuml;gen'>
                 <input type='button' value=' # ' onclick="bbcode(this.form,'CODE','')" title='Quelltext einf&uuml;gen'>
                 <input type='button' value='Liste' onclick="bblist(this.form)" title='Liste einf&uuml;gen' accesskey='l'>
                 <input type='button' value='Zitat' onclick="bbcode(this.form,'QUOTE','')" title='Zitat einf&uuml;gen'>
             </td>
         <?php } ?>
         <tr>
                    <td width='30%' valign='top' class='cat_two'>
                        <b>Nachricht:</b>
                        <br><br>
                        <?php smilie_list($GLOBALS[PM_SMILIES]); ?>
                    </td>
                    <td width='70%' valign='top' class='cat_one'>
                        <textarea name='message' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' WRAP='soft' tabindex="3" onChange=getActiveText(this) onclick=getActiveText(this) onFocus=getActiveText(this)><?php
                                  echo htmlentities($message);
                        ?></textarea>
                        <br>
                        <span class='font_small'>
                              <a href='javascript:checklength(document.bbform)'>[Beitragsl&auml;nge pr&uuml;fen]</a>
                        </span>
                    </td>
                </tr>
                <?php if ($GLOBALS[PM_OPTIONS] == "on") { ?>
                <tr>
                    <td width='30%' class='cat_two'>
                        <b>Optionen:</b>
                    <td width='70%' class='cat_one'>
                        <span class='font_small'>
                              <input type="checkbox" name="bbcodes" <?php
                                     if ($userinfo[bbcodes_show] == "on") {
                                         echo "CHECKED";
                                     } ?>>
                              <b>Board-Codes aktivieren ?</b> erstellt z.B. einen Link mit [url]http://phpForum.ath.cx[/url]
                              <br>
                              <input type="checkbox" name="html" <?php
                                     if ($userinfo[html_show] == "on") {
                                         echo "CHECKED";
                                     } ?>>
                              <b>HTML-Code aktivieren ?</b> HTML-Code wird in diesem Beitrag aktiviert.
                              <br>
                              <input type="checkbox" name="smilies" <?php
                                     if ($userinfo[smilies_show] == "on") {
                                         echo "CHECKED";
                                     } ?>>
                              <b>Grafische Smilies aktivieren ?</b> Zeichenkombinationen werden in Grafiken umgewandelt.
                        </span>
                    </td>
                </tr>
                <?php
                } else {
                    ?>
                    <input type="hidden" name="bbcodes" value='<?php echo $userinfo[bbcodes_show]; ?>'>
                    <input type="hidden" name="html" value='<?php echo $userinfo[html_show]; ?>'>
                    <input type="hidden" name="smilies" value='<?php echo $userinfo[smilies_show]; ?>'>
                    <?php
                }
                ?>
         </table>
         <p></p>
         <center>
                 <input type='submit' value='Erstellen' tabindex='13'>
                 <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
         </center>
         </form>
<?php
}
############################## New ############################## ---
#
#
############################## Delete ############################## +++
function pm_del($id) {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;
         ##### Checkbox - aktiviert ??? ##### +++
         if ($HTTP_POST_VARS[del] == "on") {

             $userinfo = get_user_info();
             $result_del = mySQL_query ("SELECT *
                                         FROM $GLOBALS[TB_MSG]
                                         WHERE $GLOBALS[TB_MSG].id='$id'");
             $Daten = mysql_fetch_array ($result_del);

             if ($userinfo[id] == $Daten[from_id] OR $userinfo[id] == $Daten[to_id]) {
                 //PM l�schen
                 mysql_query("DELETE FROM $GLOBALS[TB_MSG] WHERE $GLOBALS[TB_MSG].id='$id'");
                 $Fehler="private_del";
                 $goto="$HTTP_SERVER_VARS[PHP_SELF]";
             } else {
                 $Fehler="private_del_fault";
                 $goto="back()";
             }
         } else {
             $Fehler="private_del_fault";
             $goto="back()";
         }
         msg($Fehler, "2", $goto);

}
############################## Delete ############################## ---
#
#
############################## Delete - All ############################## +++
function pm_delall() {
         global $HTTP_SERVER_VARS, $HTTP_POST_VARS;
         ##### Checkbox - aktiviert ??? ##### +++
         if ($HTTP_POST_VARS[del] == "on") {

             $userinfo = get_user_info("");
             if (mysql_query("DELETE FROM $GLOBALS[TB_MSG] WHERE $GLOBALS[TB_MSG].to_id='$userinfo[id]'")) {
                 //PM l�schen
                 $Fehler="private_del_all";
                 $goto="$HTTP_SERVER_VARS[PHP_SELF]";
             } else {
                 $Fehler="private_del_fault";
                 $goto="back()";
             }
             msg($Fehler, "2", $goto);
         } else {

             echo "<form method='post' action='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=delall'>";
             open_table("phpForum - Mitteilung", "70%");
                         echo "Sollen wirklich alle ihre Privaten Nachrichten gel&ouml;scht werden ?";
                         echo "<p align='center'>";
                         echo "<input type='checkbox' name='del' value='on'>&nbsp;";
                         echo "<input type='submit' value='L&ouml;schen'>";
                         echo "</p>";
             close_table("");
             echo "</form>";
         }
}
############################## Delete - All ############################## ---
#
#
############################## alle PM�s markieren ############################## +++
function pm_read() {
         global $HTTP_SERVER_VARS;

         $userinfo = get_user_info();
         //alle PM�s als gelesen markieren
         $query = "UPDATE $GLOBALS[TB_MSG] SET $GLOBALS[TB_MSG].status='1' WHERE $GLOBALS[TB_MSG].to_id='$userinfo[id]'";
         if (mysql_query($query)) {
             $Fehler="private_read";
             $goto="$HTTP_SERVER_VARS[PHP_SELF]";
         } else {
             $Fehler="private_read_fault";
             $goto="back()";
         }
         msg($Fehler, "2", $goto);
}
############################## alle PM�s markieren ############################## ---
#
#
############################## Nachricht Speichern ############################## +++
function pm_save() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         ### message, subject, to_name = leer ??? +++
         if (!$HTTP_POST_VARS[message] OR !$HTTP_POST_VARS[subject] OR !$HTTP_POST_VARS[to_name]) {
             msg("private_new_fault", "2", "back()");
         }
         ### message, subject, to_name = leer ??? ---

         $from = get_user_info();
         $to_id = user_id($HTTP_POST_VARS[to_name]);
         ####### Empf�nger vorhanden ??? +++
         if (!$to_id) {
             msg("private_new_fault", "2", "back()");
         } else {
             $to = get_user_info($to_id);
             $perm = get_forum_perm("", $to_id);
             if ($perm[send_pm] != "on") {
                 msg("private_user_fault", "2", "back()");
             }
         }
         ####### Empf�nger vorhanden ??? ---

         ### hat Empf�nger noch Speicherplatz ??? +++
         $user_anz = mysql_num_rows(mySQL_query ("SELECT *
                                                  FROM $GLOBALS[TB_MSG]
                                                  WHERE $GLOBALS[TB_MSG].to_id='$to[id]'"));
         if ($user_anz >= $GLOBALS[ANZ_PM]) {
             @mail($to[email], "$GLOBALS[TITEL_KURZ] - Private Nachricht", "Hallo!\n\nBitte leeren sie ihren Posteingang ! Sie d&uuml;rfen maximal $GLOBALS[ANZ_PM] Nachrichten speichern.\n\nSie haben von $from[name] eine neue Nachricht erhalten:\n\nBetreff:\n--------\n$HTTP_POST_VARS[subject]\n\nNachricht:\n----------\n$HTTP_POST_VARS[message]\n\n\nGruss,\nIhr $GLOBALS[TITEL_KURZ] Board Team\n\n\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\nN�tzliche Links:\n\nForum Index:\nhttp://$GLOBALS[SITE]/index.php\n\nIhre Privaten Nachrichten:\nhttp://$GLOBALS[SITE]/private.php", "From: $GLOBALS[TITEL_KURZ] <$GLOBALS[SITE_ADMIN]>\nReturn-Path: <$GLOBALS[SITE_ADMIN]>");
             msg("private_send_full", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_name]=$GLOBALS[Sess]");
         }
         ### hat Empf�nger noch Speicherplatz ??? ---

         ##### Hier geht�s los ##### +++
         $query = "INSERT INTO $GLOBALS[TB_MSG] (from_id, to_id, date, status, name, text, html, bbcodes, smilies)
                   VALUES ('$from[id]','$to[id]',NOW(),'0','$HTTP_POST_VARS[subject]','$HTTP_POST_VARS[message]','$HTTP_POST_VARS[html]','$HTTP_POST_VARS[bbcodes]','$HTTP_POST_VARS[smilies]')";
         if (mysql_query($query)) {
             $Fehler="private_send";
             $goto="$HTTP_SERVER_VARS[PHP_SELF]";

             if ($to[pm_email] == "on") {
                 @mail($to[email], "$GLOBALS[TITEL_KURZ] - Private Nachricht", "Hallo $to[name],\n\nSie haben eine Private Nachricht auf http://$GLOBALS[SITE]/index.php von $from[name] erhalten.\n\n-> Posteingang: http://$GLOBALS[SITE]/private.php\n\nGruss,\n$GLOBALS[TITEL_KURZ]\n\n\n", "From: $GLOBALS[TITEL_KURZ] <$GLOBALS[SITE_ADMIN]>\nReturn-Path: <$GLOBALS[SITE_ADMIN]>");
             }
             ### Fenster f�r die aktuellen PM�s deaktivieren ###
             mysql_query("UPDATE $GLOBALS[TB_USER] SET pm_popup_show='' WHERE id='$to[id]'");
         } else {
             $Fehler="private_send_fault";
             $goto="back()";
         }
         msg($Fehler, "2", $goto);
}
############################## Nachricht Speichern ############################## +++
#
#
################################################################################
################################################################################
echo "<br>";
footer_pm();
echo "<br>";
footer();
?>