<?php
################################################################################
################################ Check ######################################### +++
################################################################################
    ##### in einem Forum #####
    if ($HTTP_GET_VARS[Forum_id] != "") {
        $forum_id = $HTTP_GET_VARS[Forum_id];
        // Zugriffsberechtigungen wird zur�ck gegeben

        $forum_perm=get_forum_perm($forum_id);

        if ($forum_perm[view] != "on") {
            msg("user");
        }
        //Test ob closed !
        $Daten = mysql_fetch_array(mySQL_query("SELECT $TB_FORUM.show_forum,
                                                             $TB_CAT.show_cat
                                                      FROM $TB_FORUM, $TB_CAT
                                                      WHERE $TB_FORUM.id='$forum_id'
                                                        AND $TB_FORUM.cat_id=$TB_CAT.id"));
        if ($Daten[show_forum] != "on") {
            msg("forum_fault", "2", "back()");
        } elseif ($Daten[show_cat] != "on") {
            msg("cat_fault", "2", "back()");
        }

    ##### in einem Thema #####
    } elseif ($HTTP_GET_VARS[Topic_id] != "") {
        $Daten = mysql_fetch_object(mySQL_query ("SELECT $TB_FORUM.id
                                                  FROM $TB_FORUM, $TB_TOPIC
                                                  WHERE $TB_TOPIC.id='$HTTP_GET_VARS[Topic_id]'
                                                    AND $TB_FORUM.id=$TB_TOPIC.forum_id"));
        $forum_id=$Daten->id;
        // Zugriffsberechtigungen wird zur�ck gegeben
        $forum_perm=get_forum_perm($forum_id);
        if ($forum_perm[view] != "on") {
            msg("user");
        }
        //Test ob closed !
        $Daten = mysql_fetch_array(mySQL_query("SELECT $TB_FORUM.show_forum,
                                                       $TB_CAT.show_cat,
                                                       $TB_TOPIC.show_topic
                                                FROM $TB_FORUM, $TB_CAT, $TB_TOPIC
                                                WHERE $TB_FORUM.id='$forum_id'
                                                  AND $TB_FORUM.cat_id=$TB_CAT.id
                                                  AND $TB_TOPIC.id='$HTTP_GET_VARS[Topic_id]'"));
        if ($Daten[show_forum] != "on") {
            msg("forum_fault", "2", "back()");
        } elseif ($Daten[show_cat] != "on") {
            msg("cat_fault", "2", "back()");
        } elseif ($Daten[show_topic] != "on") {
            msg("topic_fault", "2", "back()");
        }
    }
################################################################################
################################ Check ######################################### ---
################################################################################
#
#
################################################################################
########################## Public Board ??? #################################### ---
if (!$PUBLIC_BOARD AND user_login() == FALSE AND $ACCESS_PAGE != "public") {
    msg("user");
}

########################## Public Board ??? #################################### +++
################################################################################
#
#
################################################################################
############################# IP - Check ####################################### +++
################################################################################
if ($ACCESS_PAGE != "public" AND $BANNED_IP) {
    $ip_addys = split("\n", trim($BANNED_IP));
    foreach ($ip_addys AS $key => $ip) {
           if (preg_match("/$ip.*/", $HTTP_SERVER_VARS["REMOTE_ADDR"])) {
               msg("banned_ip","","");
           }
    }
}
################################################################################
############################# IP - Check ####################################### ---
################################################################################
#
#
################################################################################
########################### Board - Closed ##################################### +++
################################################################################
if ($CLOSED_BOARD == "on" AND !$admin AND $ACCESS_PAGE != "public" ) {
    echo "<br>";
    open_table("phpForum Mitteilung", "60%");
                echo $CLOSED_BOARD_TEXT;
    close_table();
    echo "<p>&nbsp;</p>";
    footer();
    exit();
}
echo "</pre>";
################################################################################
########################### Board - Closed ##################################### ---
################################################################################
?>