<?php
    $ACCESS_PAGE = "public";
    include("head.php");        //Header mit Bild, Suchen...


if (!$HTTP_POST_VARS[action] AND !$HTTP_GET_VARS[action]) {
#################################### Login ############## +++
    echo "<br>";
    open_table("phpForum - Login", "70%");
            ?>
            Zum einloggen geben sie bitte ihren Benutzernamen und ihr Passwort ein.
            <p></p>
            <table cellpadding="4" cellspacing="1" width='65%' align='center' class='default_table'>
            <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess"; ?>'>
                  <input type='hidden' name='action' value='login_now'>
                  <input type='hidden' name='goto' value='<?php echo $HTTP_POST_VARS[goto]; ?>'>
                  <tr>
                      <td width='20%' class='cat_two'>
                          <b>Benutzer:</b>
                      <td width='80%' align='left' class='cat_one'>
                          <input type='text' name='Name' maxlength='20' size='20' tabindex='1'>&nbsp;&nbsp;
                          <span class='font_small'>
                                <a href='signup.php'>M&ouml;chten sie sich registrieren?</a>
                          </span>
                      </td>
                  <tr>
                      <td width='20%' class='cat_two'>
                          <b>Passwort:</b>
                      <td width='80%' align='left' class='cat_one'>
                          <input type='password' name='Pass' maxlength='32' size='20' tabindex='2'>&nbsp;&nbsp;
                          <span class='font_small'>
                                <a href='<?php echo "mailpass.php?action=pass"; ?>'>Passwort vergessen?</a>
                          </span>
                      </td>
                  <tr>
                      <td align='center' colspan='2' class='cat_two'>
                          <input type='submit' name='submit' value='Login' tabindex='3'>&nbsp;
                          <input type='reset' value='Zur�cksetzen' tabindex='4'>
                      </td>
                  </tr>
            </table>
            <?php
    close_table("Sie m&uuml;ssen <a href='signup.php'>registriert</a> sein, um diese Seite aufrufen zu k�nnen. <a href='mailpass.php?action=pass'>Passwort vergessen ?</a>");
    echo "<br>";
#################################### Login ############## ---
#
} elseif ($HTTP_POST_VARS[action] == "login_now") {
#
#################################### Login NOW ############## +++
//----------
    $Pass = md5($HTTP_POST_VARS[Pass]);
//----------
$result = mySQL_query ("SELECT * FROM $TB_USER");
while ($Daten = mysql_fetch_array ($result)) {

       if (strtolower($HTTP_POST_VARS[Name]) == strtolower($Daten[name]) AND strtolower($Pass) == strtolower($Daten[pass])) {
           //darf Benutzer sich einloggen ?
           $Login = mysql_fetch_array (mysql_query("SELECT login
                                                    FROM $TB_ACCESS
                                                    WHERE $TB_ACCESS.id='$Daten[access_id]'"));
           if ($Login[login] == "on") {
               @session_start();
               session_register ("USER_Log");
                                  $HTTP_SESSION_VARS["USER_Log"]=$Daten["name"];
                                  $USER_Log=$Daten[name];
               session_register ("PASS_Log");
                                  $HTTP_SESSION_VARS["PASS_Log"]=$Pass;
                                  $PASS_Log=$Pass;
               session_register ("VISIT_Log");
                                  $HTTP_SESSION_VARS["VISIT_Log"]=$Daten["last_login"];
                                  $VISIT_Log=$Daten["last_login"];
               $Fehler = "login";
               $time = 2;
           } else {
               $Fehler = "login_del";
               $time = 5;
           }
           break;
       } else {
           $Fehler = "login_fault";
           $time = 5;
       }
}
//goto == "" ==> zur Startseite
if ($HTTP_POST_VARS[goto] == "") {
    $HTTP_POST_VARS[goto]="index.php?$Sess_Name=$Sess";
}
##### Fehler ausgeben #####
if ($Fehler == "login_fault" OR $Fehler == "login_del") {
    $HTTP_POST_VARS[goto] = "back()";
}
### last_login ###
last_login();

##### Fehler ausgeben #####
msg($Fehler, $time, $HTTP_POST_VARS[goto]);

#################################### Login NOW ############## ---
#
} elseif ($HTTP_GET_VARS[action] == "logout") {
#
#################################### Logout ################# +++
          $userinfo = get_user_info("");
          mysql_query("DELETE
                       FROM $TB_SESSION
                       WHERE host='$HTTP_SERVER_VARS[REMOTE_ADDR]'
                         AND uid='$userinfo[id]'");
          session_destroy();
          $HTTP_SESSION_VARS["USER_Log"]="";
          $HTTP_SESSION_VARS["PASS_Log"]="";
          $HTTP_SESSION_VARS["VISIT_Log"]="";
          msg("logout", "2","index.php");
#################################### Logout ################# ---
#
}
#
footer();
?>