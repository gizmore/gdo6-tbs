<?php
        include("head.php");        //Header mit Bild, Suchen...
        if ($HTTP_GET_VARS[action] == "pic") {
            access("avatar");      //Zugriff beschr�nken
        } else {
            access("edit_profil");      //Zugriff beschr�nken
        }

$userinfo = get_user_info("");
echo "<br>";
?>
<table border='0' align='center' cellpadding='4' cellspacing='1' width='100%' class='default_table'>
       <tr id='nav'>
         <td align='center'>
             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess"; ?>'><b>&Uuml;bersicht</b></a>
         <td align='center'>
             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=profile"; ?>'><b>Profil bearbeiten</b></a>
         <td align='center'>
             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=settings"; ?>'><b>Einstellungen bearbeiten</b></a>
         <td align='center'>
             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=pass"; ?>'><b>Passwort &auml;ndern</b></a>
         <td align='center'>
             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=pic"; ?>'><b>Avatar bearbeiten</b></a>
         <td align='center'>
             <a href='<?php echo "private.php?$Sess_Name=$Sess&action=in"; ?>'><b>Private Nachrichten</b></a>
         </td>
       </tr>
</table>
<?php
################################################################################
################################################################################
################################################################################
#
#
############################## �bersicht ############################## +++
if (!$HTTP_GET_VARS[action] AND !$HTTP_POST_VARS[action]) {

    if (!$HTTP_POST_VARS[date_anz]) {
        $HTTP_POST_VARS[date_anz] = "+0";
    }
    echo "<br>";
    table_header("Neue Private Nachrichten...","100%","","colspan='4'"); ?>
                 <tr class='default_tr'>
                     <td width='60%' align='center' colspan='2'>
                         <b>Betreff</b>
                     <td width='20%' align='center'>
                         <b>Sender</b>
                     <td width='20%' align='center'>
                         <b>Datum Zeit</b>
                     </td>
                 </tr>
                 <?php
                 $result = mySQL_query ("SELECT *
                                         FROM $TB_MSG
                                         WHERE $TB_MSG.to_id='$userinfo[id]'
                                           AND $TB_MSG.status='0'
                                         ORDER BY $TB_MSG.date DESC");
                 while ($Daten = mysql_fetch_array ($result)) {
                        ?>
                        <tr>
                            <td width='5%' align='center' class='cat_two'>
                                <img src='<?php echo $_style[pic_on]; ?>' border='0'>
                            <td width='55%' class='cat_one'>
                                <a href='<?php echo "private.php?$Sess_Name=$Sess&action=view&id=$Daten[id]"; ?>'><b><?php echo $Daten[name]; ?></b></a>
                            <td width='20%' align='center' class='cat_two'>
                                <a href='<?php echo "showuser.php?$Sess_Name=$Sess&id=";
                                   $from = get_user_info($Daten[from_id]);
                                   echo $from[id]."'>";
                                   echo $from[name];
                                ?></a>
                            <td width='20%' align='center' class='cat_one'>
                                <?php echo $Daten[date]; ?>
                            </td>
                            <?php
                 }
                 ?>
                 </tr>
          </table>
          <p>&nbsp;</p>
    <form method='post' action='<?php echo "user.php?$Sess_Name=$Sess"; ?>'>
          <?php table_header("Abonnierte Themen...","100%", "", "colspan='6'"); ?>

             <tr class='default_tr'>
                 <td width='3%' NOWRAP align='left'>
                     &nbsp;
                 <td width='47%' NOWRAP align='left'>
                     <B>Thema</B>
                 <td width='10%' NOWRAP align='center'>
                     <b>Antworten</b>
                 <td width='5%' NOWRAP align='center'>
                     <b>Hits</b>
                 <td width='15%' NOWRAP align='center'>
                     <b>Letzter Beitrag</b>
                 <td width='20%' NOWRAP align='center'>
                     <b>erstellt von</b>
                 </td>
             </tr>
             <?php
             if ($HTTP_POST_VARS[date_anz] != "*") {
                 $result = mysql_query("SELECT $TB_TOPIC.*
                                        FROM $TB_ABO, $TB_TOPIC
                                        WHERE $TB_ABO.user_id='$userinfo[id]'
                                          AND $TB_TOPIC.id=$TB_ABO.topic_id
                                          AND TO_DAYS(NOW()) $HTTP_POST_VARS[date_anz] <= TO_DAYS($TB_TOPIC.post_date)
                                        ORDER BY $TB_TOPIC.post_date DESC");
             } else {
                 $result = mysql_query("SELECT $TB_TOPIC.*
                                        FROM $TB_ABO, $TB_TOPIC
                                        WHERE $TB_ABO.user_id='$userinfo[id]'
                                          AND $TB_TOPIC.id=$TB_ABO.topic_id
                                        ORDER BY $TB_TOPIC.post_date DESC");
             }
             while ($Daten_topic = mysql_fetch_array ($result)) {
                    ?>
                    <tr>
                        <td width='3%' align='center' class='cat_two'>
                            <?php echo topic_new($Daten_topic[id]); ?>
                        <td width='47%' class='cat_one'>
                            <?php
                            //Top ???
                            if ($Daten_topic[top]) { echo "Wichtig: "; }
                            //Umfrage ???
                            $Topic_poll = mysql_num_rows (mySQL_query ("SELECT *
                                                                        FROM $TB_POLL
                                                                        WHERE $TB_POLL.topic_id='$Daten_topic[id]'"));
                            if ($Topic_poll == 1) { echo "Umfrage: "; }
                            ?>
                            <a href='<?php echo "showtopic.php?$Sess_Name=$Sess&Topic_id=$Daten_topic[id]"; ?>'><b><?php echo $Daten_topic[name]; ?></b></a>
                            <br>
                            <span class='font_small'>
                                  <b>
                                     <a href='<?php echo "newpost.php?$Sess_Name=$Sess&Topic_id=$Daten_topic[id]"; ?>'>Antworten</a>&nbsp;|&nbsp;<a href='<?php echo "functions.php?$Sess_Name=$Sess&action=abo&op=del&Topic_id=$Daten_topic[id]"; ?>'>Abbestellen</a>
                                  </b>
                            </span>
                        <td width='10%' align='center' class='cat_two'>
                            <b><?php echo $Daten_topic[posts]; ?></b>
                        <td width='5%' align='center' class='cat_one'>
                            <b><?php echo $Daten_topic[views]; ?></b>
                        <td width='15%' align='center' class='cat_two'>
                            <span class='font_small'>
                                  <?php
                                  $last_post = last_post($Daten_topic[id]);
                                  echo "<a href='showtopic.php?$Sess_Name=$Sess&Topic_id=$Daten_topic[id]&goto=lastpost' title='Gehe zum letzten Beitrag'><img src='$_style[pic_last_post]' border='0' alt='Gehe zum letzten Beitrag'></a>&nbsp;von&nbsp;<a href='showuser.php?$Sess_Name=$Sess&id=$last_post[user_id]'>$last_post[user_name]</a>";
                                  echo "<br>am&nbsp;$last_post[post_date]";
                                  ?>
                            </span>
                        <td width='20%' align='center' class='cat_one'>
                            <?php $userinfo = get_user_info($Daten_topic[poster_id]); ?>
                            <a href='<?php echo "showuser.php?$Sess_Name=$Sess&id=$userinfo[id]"; ?>'><?php echo $userinfo[name]; ?></a>
                        </td>
                        <?php
             }
             ?>
                    <tr class='default_tr'>
                        <td width='100%' align='right' colspan='6'>
                            <b>Zeige aktive Themen:</b>
                            <select name='date_anz'>
                                    <?php
                                    $array_date_anz = array("+0" => "von heute",
                                                            "-1" => "von gestern",
                                                            "-2" => "der letzten 2 Tage",
                                                            "-5" => "der letzten 5 Tage",
                                                            "-10" => "der letzten 10 Tage",
                                                            "-20" => "der letzten 20 Tage",
                                                            "-30" => "der letzten 30 Tage",
                                                            "-40" => "der letzten 40 Tage",
                                                            "-50" => "der letzten 50 Tage",
                                                            "-100" => "der letzten 100 Tage",
                                                            "*" => "vom Anfang an");
                                    while(list($key, $val) = each($array_date_anz)) {
                                          ?>
                                          <option value='<?php echo $key; ?>'<?php
                                                  if ($HTTP_POST_VARS[date_anz] == $key) {
                                                      echo " selected";
                                                  }
                                          ?>><?php echo $val; ?></option>
                                          <?php
                                    }
                                    ?>
                            </select>
                            <input type='submit' value='OK'>
                        </td>
                    </tr>
             </table>
             <div align='right' class='font_normal'>
                  <a href='<?php echo "functions.php?$Sess_Name=$Sess&action=abo&op=delall"; ?>'><b>[Alle Themen Abbestellen]</b></a>
             </div>
    </form>
    <?php
}
############################## �bersicht ############################## ---
#
#
############################## Edit ############################## +++
if ($HTTP_GET_VARS[action] == "profile") {
    ?>
    <form name='bbform' method='post' action='<?php echo "user.php?$Sess_Name=$Sess"; ?>'>
          <input type='hidden' name='action' value='save'>
          <input type='hidden' name='op' value='edit'>
          <?php
          table_header("Profil bearbeiten...","100%", "", "colspan='2'"); ?>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Benutzername:</b>
                     <td width='70%' class='cat_one'>
                         <b><?php echo $userinfo[name]; ?></b>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Avatar:</b>
                     <td width='70%' class='cat_one'>
                         <?php
                         echo avatar($userinfo[id]);
                         ?>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Registriert seit:</b>
                     <td width='70%' class='cat_one'>
                         <?php echo $userinfo[reg]; ?>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Posts:</b>
                     <td width='70%' class='cat_one'>
                         <?php echo $userinfo[points]; ?>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Status:</b>
                     <td width='70%' class='cat_one'>
                         <?php echo status_name($userinfo[id]); ?>&nbsp;
                         <?php echo status_stars($userinfo[id]); ?>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Geburtstag:</b>
                     <td width='70%' class='cat_one'>
                         <?php
                         list ($Geb_jahr, $Geb_monat, $Geb_tag) = split ("-", $userinfo[geb]);
                         ?>
                         <table border='0'>
                                <tr>
                                    <td align='center'>
                                        <span class='font_small'>
                                              Tag
                                        </span>
                                    <td align='center'>
                                        <span class='font_small'>
                                              Monat
                                        </span>
                                    <td align='center'>
                                        <span class='font_small'>
                                              Jahr
                                        </span>
                                    </td>
                                <tr>
                                    <td>
                                        <select name='User_geb_tag' tabindex='1'>
                                                <option VALUE=''></option>
                                                <?php
                                                for ($n=1; $n <= 31; $n++) {
                                                     echo "<option value='$n' ";
                                                     if ($n == $Geb_tag) {
                                                         echo "selected";
                                                     }
                                                     echo ">$n</option>";
                                                }
                                                ?>
                                        </select>
                                    <td>
                                        <select name='User_geb_monat' tabindex='2'>
                                                <option VALUE=''></option>
                                                <?php
                                                $monat = array(1=>"Januar",2=>"Februar",3=>"M&auml;rz",4=>"April",5=>"Mai",6=>"Juni",7=>"Juli",8=>"August",9=>"September",10=>"Oktober",11=>"November",12=>"Dezember");
                                                for ($n=1; $n <= 12; $n++) {
                                                     echo "<option value='$n' ";
                                                     if ($n == $Geb_monat) {
                                                         echo "selected";
                                                     }
                                                     echo ">$monat[$n]</option>";
                                                }
                                                ?>
                                        </select>
                                    <td>
                                        <input type='text' name='User_geb_jahr' maxlength='4' size='4' value="<?php echo $Geb_jahr; ?>" tabindex='3'>
                                    </td>
                                </tr>
                         </table>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Geschlecht:</b>
                     <td width='70%' class='cat_one'>
                         <select name='User_gender' tabindex='4'>
                                 <?php
                                 if ($userinfo[gender] == "m") {
                                     echo "<option value='m' selected>m&auml;nnlich</option>";
                                     echo "<option value='w'>weiblich</option>";
                                 } else {
                                     echo "<option value='m'>m&auml;nnlich</option>";
                                     echo "<option value='w' selected>weiblich</option>";
                                 }
                                 ?>
                         </select>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Homepage:</b>
                     <td width='70%' class='cat_one'>
                         <input type='text' name='User_homepage' maxlength='255' size='45' value="<?php echo $userinfo[homepage]; ?>" tabindex='5'>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>eMail:</b>
                     <td width='70%' class='cat_one'>
                         <input type='text' name='User_email' maxlength='255' size='45' value="<?php echo $userinfo[email]; ?>" tabindex='6'>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Beruf:</b>
                     <td width='70%' class='cat_one'>
                         <input type='text' name='User_job' maxlength='255' size='30' value="<?php echo $userinfo[job]; ?>" tabindex='7'>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Wohnort:</b>
                     <td width='70%' class='cat_one'>
                         <input type='text' name='User_location' maxlength='255' size='30' value="<?php echo $userinfo[location]; ?>" tabindex='8'>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>ICQ Nummer:</b>
                     <td width='70%' class='cat_one'>
                         <input type='text' name='User_icq' maxlength='20' size='15' value="<?php echo $userinfo[icq]; ?>" tabindex='9'>
                         <?php
                         if ($userinfo[icq] != "") {
                             ?>
                             <a href='http://wwp.icq.com/scripts/search.dll?to=<?php echo $userinfo[icq]; ?>'>
                                <img src='http://wwp.icq.com/scripts/online.dll?icq=<?php echo $userinfo[icq]; ?>&img=5' border='0'>
                             </a>
                             <?php
                         }
                         ?>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>AOL Instant Messenger:</b>
                     <td width='70%' class='cat_one'>
                         <input type='text' name='User_aim' maxlength='255' size='15' value="<?php echo $userinfo[aim]; ?>" tabindex='10'>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Yahoo Instant Messenger:</b>
                     <td width='70%' class='cat_one'>
                         <input type='text' name='User_yim' maxlength='255' size='15' value="<?php echo $userinfo[yim]; ?>" tabindex='11'>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>Signatur:</b><br>
                         <span class='font_small'>
                               <?php
                               echo "HTML Code ist ";
                                     if ($SIGN_HTML == "on") {
                                         echo "AN";
                                     } else {
                                         echo "AUS";
                                     }
                               echo "<br><a href=\"javascript:onclick=BBCode()\">Board Code</a> ist ";
                                     if ($SIGN_BBCODES == "on") {
                                         echo "AN";
                                     } else {
                                         echo "AUS";
                                     }
                               echo "<br><a href=\"javascript:onclick=Smilies()\">Smilies</a> sind ";
                                     if ($SIGN_SMILIES == "on") {
                                         echo "AN";
                                     } else {
                                         echo "AUS";
                                     }
                               ?>
                         </span>
                     <td width='70%' class='cat_one'>
                         <textarea name='message' cols='37' rows='5' tabindex='12'><?php echo $userinfo[sign]; ?></textarea>
                     </td>
                 </tr>
          </table>
          <p></p>
          <center>
                  <input type='submit' value='&auml;ndern' tabindex='13'>
                  <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
          </center>
    </form>
    <?php
}
############################## Edit ############################## ---
#
#
############################## Settings ########################## +++
if ($HTTP_GET_VARS[action] == "settings") {
    ?>
    <form name='settings' method='post' action='<?php echo "user.php?$Sess_Name=$Sess"; ?>'>
          <input type='hidden' name='action' value='save'>
          <input type='hidden' name='op' value='settings'>
          <?php
          table_header("Einstellungen bearbeiten...","100%", "", "colspan='2'");
          table_header("Login & Cookies","100%", "1", "colspan='2'", "nohead"); ?>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>"Automatischer Login", wenn sie in dieses Forum zur&uuml;ckkehren ?</b><br>
                         <span class='font_small'>
                               Wenn sie diese Funktion aktivieren wird ihr Benutzername und ihr Passwort bei ihnen auf dem PC verschl&uuml;sselt in einem Cookie gespeichert.
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[stay_login] == "on") {
                             echo "<input type='radio' name='stay_login' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='stay_login' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='stay_login' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='stay_login' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 </tr>
          <?php
          table_header("eMail Verkehr, Private Nachrichten","100%", "1", "colspan='2'", "nohead"); ?>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>"eMail Benachrichtigung" standardm&auml;ssig aktivieren ?</b><br>
                         <span class='font_small'>
                               Sie erh&auml;lten immer eine eMail, wenn jemand in ein Thema, in welches sie geschrieben haben, antwortet.
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[post_email] == "on") {
                             echo "<input type='radio' name='post_email' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='post_email' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='post_email' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='post_email' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>eMail-Adresse verstecken ?</b><br>
                         <span class='font_small'>
                               W&auml;hlen sie hier ja, wenn anderen Nutzern ihre eMail-Adresse im &ouml;ffentlichen Profil nicht angezeigt werden soll.
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[email_show] == "on") {
                             echo "<input type='radio' name='email_show' value=''>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='email_show' value='on' checked>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='email_show' value='' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='email_show' value='on'>&nbsp;nein";
                         }
                         ?>
                     </td>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>eMail Benachrichtigung f&uuml;r Private Nachrichten ?</b>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[pm_email] == "on") {
                             echo "<input type='radio' name='pm_email' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='pm_email' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='pm_email' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='pm_email' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>Pop-up Benachrichtung f&uuml;r PN aktivieren ?</b><br>
                         <span class='font_small'>
                               Wenn sie auf das Forum gehen und eine neue Private Nachricht haben, &ouml;ffnet sich ein Fenster, in dem sie einen Hinweis erhalten dass sie eine neue Private Nachricht erhalten haben!
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[pm_popup] == "on") {
                             echo "<input type='radio' name='pm_popup' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='pm_popup' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='pm_popup' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='pm_popup' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>Status f&uuml;r PN aktivieren ?</b><br>
                         <span class='font_small'>
                               Wenn sie diese Option aktivieren wird ihnen der Status ihres Postfaches angezeigt!
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[pm_footer] == "on") {
                             echo "<input type='radio' name='pm_footer' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='pm_footer' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='pm_footer' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='pm_footer' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 </tr>
                 <?php
          table_header("neue Themen / Beitr&auml;ge","100%", "1", "colspan='2'", "nohead"); ?>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>Board-Codes aktivieren ?</b><br>
                         <span class='font_small'>
                               W&auml;hlen sie hier ja, wenn sie wollen das die Foren-Codes bei ihren Beitr&auml;gen automatisch aktiviert werden!
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[bbcodes_show] == "on") {
                             echo "<input type='radio' name='bbcodes_show' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='bbcodes_show' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='bbcodes_show' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='bbcodes_show' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>HTML-Code aktivieren ?</b><br>
                         <span class='font_small'>
                               W&auml;hlen sie hier ja, wenn sie HTML-Code in ihren Beitr&auml;gen automatisch aktivieren wollen!
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[html_show] == "on") {
                             echo "<input type='radio' name='html_show' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='html_show' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='html_show' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='html_show' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>Smilies aktivieren ?</b><br>
                         <span class='font_small'>
                               W&auml;hlen sie hier ja, wenn sie Smilies in ihren Beitr&auml;gen automatisch aktiviert haben m&ouml;chten!
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[smilies_show] == "on") {
                             echo "<input type='radio' name='smilies_show' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='smilies_show' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='smilies_show' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='smilies_show' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>eigene Signatur anzeigen ?</b><br>
                         <span class='font_small'>
                               Um ihre Signatur f&uuml;r neune Beitr&auml;ge zu aktivieren m&uuml;ssen sie hier ja w&auml;hlen!
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <?php
                         if ($userinfo[sign_show] == "on") {
                             echo "<input type='radio' name='sign_show' value='on' checked>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='sign_show' value=''>&nbsp;nein";
                         } else {
                             echo "<input type='radio' name='sign_show' value='on'>&nbsp;ja&nbsp;";
                             echo "<input type='radio' name='sign_show' value='' checked>&nbsp;nein";
                         }
                         ?>
                     </td>
                 </tr>
                 <?php
          table_header("weitere Einstellungen","100%", "1", "colspan='2'", "nohead"); ?>
                 <tr>
                     <td width='70%' class='cat_two'>
                         <b>Pers�nlicher Foren - Style:</b><br>
                         <span class='font_small'>
                               W&auml;hlen sie hier ihren Pers&ouml;nlichen Foren Style.
                         </span>
                     <td width='30%' align='center' class='cat_one'>
                         <select name='style'>
                                 <?php
                                 $result = mysql_query("SELECT id, name, active FROM $TB_STYLES WHERE $TB_STYLES.choice='on' ORDER BY name");
                                 while ($Daten = mysql_fetch_array($result)) {
                                        echo "<option value='$Daten[id]'";
                                        if ($userinfo[style] == $Daten[id]) {
                                            echo " selected";
                                        } elseif (!$userinfo[style] AND $Daten[active] == "on") {
                                            echo " selected";
                                        }
                                        echo ">$Daten[name]";
                                        if ($Daten[active] == "on") {
                                            echo " (Standard)";
                                        }
                                 }
                                 ?>
                         </select>
                     </td>
                 </tr>
          </table>
          <p></p>
          <center>
                  <input type='submit' value='&auml;ndern' tabindex='13'>
                  <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
          </center>
    </form>
<?php
}
############################## Settings ########################## ---
#
#
############################## Pass ############################## +++
if ($HTTP_GET_VARS[action] == "pass"){
    ?>
    <form name='pass' method='post' action='<?php echo "user.php?$Sess_Name=$Sess"; ?>'>
          <input type='hidden' name='action' value='save'>
          <input type='hidden' name='op' value='pass'>
          <?php
          table_header("Passwort &auml;ndern...","100%", "", "colspan='2'"); ?>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>altes Passwort:</b>
                     <td width='70%' class='cat_one'>
                         <input type='password' name='Pass_alt' maxlength='255' size='30' tabindex='1'>&nbsp;
                         <span class='font_small'>
                               <a href='<?php echo "mailpass.php?$Sess_Name=$Sess"; ?>'>Passwort vergessen ?</a>
                         </span>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>neues Passwort:</b>
                     <td width='70%' class='cat_one'>
                         <input type='password' name='Pass_neu' maxlength='255' size='30' tabindex='2'>
                     </td>
                 <tr>
                     <td width='30%' class='cat_two'>
                         <b>neues Passwort wiederholen:</b>
                     <td width='70%' class='cat_one'>
                         <input type='password' name='Pass_neu_repeat' maxlength='255' size='30' tabindex='3'>
                     </td>
                 </tr>
          </table>
          <p></p>
          <center>
                  <input type='submit' value='&auml;ndern' tabindex='13'>
                  <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
          </center>
    </form>
<?php
}
############################## Pass ############################## ---
#
#
############################## Bild ############################## +++
if ($HTTP_GET_VARS[action] == "pic"){
    ?>
    <form name='pic' <?php if ($ALLOW_FILE_UPLOADS == "on") { echo "enctype='multipart/form-data'"; } ?> method='post' action='<?php echo "user.php?$Sess_Name=$Sess"; ?>'>
          <input type='hidden' name='action' value='save'>
          <input type='hidden' name='op' value='pic'>
          <?php
          table_header("Bild &auml;ndern...","100%", "", "colspan='2'"); ?>
                 <tr>
                     <td width='30%' valign='top' class='cat_two'>
                         <b>Avatar:</b><br><br>
                         <span class='font_small'>
                               Format: jpg / gif<br>
                               max. Aufl&ouml;sung: <?php echo $PIC_X."x".$PIC_Y; ?> Pixel
                         </span>
                     <td width='70%' class='cat_one'>
                         <?php
                         if ($avatar = avatar($userinfo[id])) {
                             echo "$avatar<br><input type='checkbox' name='pic_del'>&nbsp;<b>l&ouml;schen</b>";
                         } ?>
                     </td>
                 <?php if ($ALLOW_FILE_UPLOADS == "on") { ?>
                 <tr>
                     <td width='50%' class='cat_two'>
                         <b>Datei:</b><br>
                         <span class='font_small'>
                               Hier k&ouml;nnen sie ein Bild von ihrer Festplatte ausw&auml;hlen.
                         </span>
                     <td width='50%' class='cat_one'>
                         <input type='file' name='userfile'>
                     </td>
                 <?php } ?>
                 <tr>
                     <td width='50%' class='cat_two'>
                         <b>Link zu einem Avatar:</b><br>
                         <span class='font_small'>
                               Hier k&ouml;nnen sie einen Link zu einem Avatar auf einem anderen Server angeben.
                         </span>
                     <td width='50%' class='cat_one'>
                         <input type='text' size='30' name='avatar_link'>
                     </td>
                 </tr>
          </table>
          <p></p>
          <center>
                  <input type='submit' value='&auml;ndern' tabindex='13'>
                  <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
          </center>
    </form>
<?php
}
############################## Bild ############################## ---
#
#
################################################################################
################################### SAVE ####################################### +++
################################################################################
#
#
if ($HTTP_POST_VARS[action] == "save" AND $HTTP_POST_VARS[op]) {

    ##### EDIT ##### +++
    if ($HTTP_POST_VARS[op] == "edit") {

        if (!$HTTP_POST_VARS[User_email]) {
            ### Fehler ausgeben
            msg("eingabe_fault", "2", "back()");
            ### Fehler ausgeben
        }
        ### Homepage mit http versehen ###
        if(substr(strtolower($HTTP_POST_VARS[User_homepage]), 0, 7) != "http://" AND $HTTP_POST_VARS[User_homepage]) {
           $HTTP_POST_VARS[User_homepage] = "http://".$HTTP_POST_VARS[User_homepage];
        }
        $query = "UPDATE $TB_USER
                  SET geb='$HTTP_POST_VARS[User_geb_jahr]-$HTTP_POST_VARS[User_geb_monat]-$HTTP_POST_VARS[User_geb_tag]',
                      gender='$HTTP_POST_VARS[User_gender]',
                      homepage='$HTTP_POST_VARS[User_homepage]',
                      job='$HTTP_POST_VARS[User_job]',
                      location='$HTTP_POST_VARS[User_location]',
                      email='$HTTP_POST_VARS[User_email]',
                      icq='$HTTP_POST_VARS[User_icq]',
                      aim='$HTTP_POST_VARS[User_aim]',
                      yim='$HTTP_POST_VARS[User_yim]',
                      sign='$HTTP_POST_VARS[message]'
                  WHERE id='$userinfo[id]'";
        if (mysql_query($query)) {
            $Fehler="profile";
            $goto="user.php?$Sess_Name=$Sess&action=profile";
        } else {
            $Fehler="profile_fault";
            $goto="back()";
        }
        // Nachricht
        msg($Fehler, "2", $goto);
    ##### EDIT ##### ---
    #
    #
    ##### SETTINGS ##### +++
    } elseif ($HTTP_POST_VARS[op] == "settings") {

        $query = "UPDATE $TB_USER
                  SET post_email='$HTTP_POST_VARS[post_email]',
                      pm_email='$HTTP_POST_VARS[pm_email]',
                      pm_popup='$HTTP_POST_VARS[pm_popup]',
                      email_show='$HTTP_POST_VARS[email_show]',
                      bbcodes_show='$HTTP_POST_VARS[bbcodes_show]',
                      html_show='$HTTP_POST_VARS[html_show]',
                      smilies_show='$HTTP_POST_VARS[smilies_show]',
                      sign_show='$HTTP_POST_VARS[sign_show]',
                      stay_login='$HTTP_POST_VARS[stay_login]',
                      pm_footer='$HTTP_POST_VARS[pm_footer]',
                      style='$HTTP_POST_VARS[style]'
                  WHERE id='$userinfo[id]'";
        if (mysql_query($query)) {
            $Fehler="profile";
            $goto="user.php?$Sess_Name=$Sess&action=settings";
        } else {
            $Fehler="profile_fault";
            $goto="back()";
        }
        // Nachricht
        msg($Fehler, "2", $goto);
    ##### SETTINGS ##### ---
    #
    #
    ##### PASS ##### +++
    } elseif ($HTTP_POST_VARS[op] == "pass") {

        $HTTP_POST_VARS[Pass_alt] = md5($HTTP_POST_VARS[Pass_alt]);
        $HTTP_POST_VARS[Pass_neu] = md5($HTTP_POST_VARS[Pass_neu]);
        $HTTP_POST_VARS[Pass_neu_repeat] = md5($HTTP_POST_VARS[Pass_neu_repeat]);

        if ($HTTP_POST_VARS[Pass_alt] == $userinfo[pass] AND $HTTP_POST_VARS[Pass_neu] == $HTTP_POST_VARS[Pass_neu_repeat]) {
            if (mysql_query("UPDATE $TB_USER SET pass='$HTTP_POST_VARS[Pass_neu]' WHERE $TB_USER.id='$userinfo[id]'")) {
                $HTTP_SESSION_VARS[PASS_Log] = $HTTP_POST_VARS[Pass_neu];
                $PASS_Log = $HTTP_POST_VARS[Pass_neu];
                $Fehler="profile";
                $goto="user.php?$Sess_Name=$Sess&action=pass";
            } else {
                $Fehler="profile_fault";
                $goto="back()";
            }
        } else {
            $Fehler="profile_fault";
            $goto="back()";
        }
        // Nachricht
        msg($Fehler, "2", $goto);
        // Nachricht
    ##### PASS ##### ---
    #
    #
    ##### AVATAR ##### +++
    } elseif ($HTTP_POST_VARS[op] == "pic") {
        ### Datei einlesen ### +++
             ### per Upload
             if ($HTTP_POST_FILES[userfile][size] > 0) {
                 $filename = $HTTP_POST_FILES[userfile][name];
                 $Typ = GetImageSize ($HTTP_POST_FILES[userfile][tmp_name]);
                 if ($Typ[0] <= $PIC_X AND $Typ[1] <= $PIC_Y AND $Typ[2] <= "2" AND (strtolower(substr($filename, -4)) == ".gif" OR strtolower(substr($filename, -4)) == ".jpg")) {
                     $fp=@fopen($HTTP_POST_FILES[userfile][tmp_name],"rb");
                     $filestuff=@fread($fp,$HTTP_POST_FILES[userfile][size]);
                     @fclose($fp);
                     @unlink($HTTP_POST_FILES[userfile][tmp_name]);
                     ### alte Avatare des Users l�schen ###
                     mysql_query("DELETE FROM $TB_AVATARS WHERE user_id='$userinfo[id]'");
                     ### neuen Avatar hinzuf�gen ###
                     mysql_query("INSERT INTO $TB_AVATARS (user_id, data, name)
                                  VALUES ('$userinfo[id]','".addslashes($filestuff)."','$filename')");
                 } else {
                     msg("pic_fault", "3", "back()");
                 }

             ### per Link
             } elseif ($HTTP_POST_VARS[avatar_link]) {
                 $filename = basename($HTTP_POST_VARS[avatar_link]);
                 $fp=@fopen($HTTP_POST_VARS[avatar_link],"rb");
                 $filestuff="";
                 while (!@feof($fp)) {
                        $filestuff.=@fread($fp,1024); //filesize($filename));
                 }
                 @fclose($fp);

                 //tmp-Datei erzeugen
                   $tmp_name=@tempnam(get_cfg_var("upload_tmp_dir"),"avatar");
                   $fp=@fopen($tmp_name,"wb");
                       @fwrite($fp, $filestuff);
                   @fclose($fp);

                 //Format OK ?
                 $Typ = GetImageSize ($tmp_name);
                 if ($Typ[0] <= $PIC_X AND $Typ[1] <= $PIC_Y AND $Typ[2] <= "2") {
                     ### alte Avatare des Users l�schen ### +++
                     mysql_query("DELETE FROM $TB_AVATARS WHERE user_id='$userinfo[id]'");
                     mysql_query("INSERT INTO $TB_AVATARS (user_id, data, name)
                                  VALUES ('$userinfo[id]','".addslashes($filestuff)."','$filename')");
                 } else {
                     msg("pic_fault", "3", "back()");
                 }
                 @unlink($tmp_name);
             } elseif ($HTTP_POST_VARS[pic_del] == "on") {
                 mysql_query("DELETE FROM $TB_AVATARS WHERE user_id='$userinfo[id]'");
             }
        ### Datei einlesen ### ---
        msg("file", "2", "user.php?$Sess_Name=$Sess&action=pic");
    ##### AVATAR ##### ---
    }
}
################################################################################
################################### SAVE ####################################### ---
################################################################################
echo "<br>";
footer();
?>