<?php
        include("head.php");        //Header mit Bild, Suchen...
        access("new_post");         //Zugriff beschr�nken
        echo "<script language=\"Javascript\" src=\"bbcode.js\"></script>";

####### Topic, Forum, Cat - Closed ### +++
        $Daten = mysql_fetch_array (mySQL_query ("SELECT $TB_TOPIC.closed AS topic_closed,
                                                         $TB_TOPIC.name AS topic_name,
                                                         $TB_FORUM.name AS forum_name,
                                                         $TB_FORUM.id AS forum_id,
                                                         $TB_FORUM.files,
                                                         $TB_FORUM.bbcodes,
                                                         $TB_FORUM.smilies,
                                                         $TB_FORUM.options,
                                                         $TB_CAT.name AS cat_name,
                                                         $TB_CAT.id AS cat_id
                                                  FROM $TB_TOPIC, $TB_FORUM, $TB_CAT
                                                  WHERE $TB_TOPIC.id = '$HTTP_GET_VARS[Topic_id]$HTTP_POST_VARS[Topic_id]'
                                                    AND $TB_FORUM.id = $TB_TOPIC.forum_id
                                                    AND $TB_CAT.id = $TB_FORUM.cat_id"));
if ($Daten[topic_closed] == "on") {
    msg("user", "5", "back()");
}
####### Topic, Forum, Cat - Closed ### ---

//Formular anzeigen !!!
if ($HTTP_POST_VARS[action] == "") {
################################################################################
         ################################ Hier geht�s los ############################### +++
         echo "<form name='bbform' ";
         if ($ALLOW_FILE_UPLOADS == "on") { echo "enctype='multipart/form-data'"; }
         echo " onSubmit='return validate(this)' method='post' action='newpost.php?$Sess_Name=$Sess'>";
         echo "<input type='hidden' name='Topic_id' value='$HTTP_GET_VARS[Topic_id]'>";
         echo "<input type='hidden' name='action' value='save'>";
         echo "<input type='hidden' name='gz_site' value='off'>";
         ################################################################################
         table_header("Neuen Beitrag erstellen", "100%", "1", "colspan='2'");
         ?>
         <tr>
             <td width='100%' valign='top' colspan='2' class='cat_tr'>
                 <?php
                 echo "<a href='index.php?$Sess_Name=$Sess'><b>$TITEL_KURZ</b></a>&nbsp;:&nbsp;<a href='index.php?$Sess_Name=$Sess&Cat_id=$Daten[cat_id]'><b>$Daten[cat_name]</b></a>&nbsp;:&nbsp;<a href='showforum.php?$Sess_Name=$Sess&Forum_id=$Daten[forum_id]'><b>$Daten[forum_name]</b></a>&nbsp;:&nbsp;<a href='showtopic.php?$Sess_Name=$Sess&Topic_id=$HTTP_GET_VARS[Topic_id]'><b>$Daten[topic_name]</b></a>&nbsp;:&nbsp;<b>new Post</b>";
                 ?>
             </td>
         <tr>
             <td width='30%' class='cat_two'>
                 <b>Angemeldet als:</b>
             <td width='70%' align='left' class='cat_one'>
                       <b><?php echo $HTTP_SESSION_VARS[USER_Log]; ?></b>&nbsp;&nbsp;<a href='<?php echo "login.php?$Sess_Name=$Sess&action=logout"; ?>'>[Logout]</a>
             </td>
         <?php if ($Daten[bbcodes] == "on") { ?>
         <tr>
             <td width='30%' valign='top' class='cat_two'>
                 <b>Board-Code:</b>
                 <span class='font_small'>
                       <a href="javascript:BBCode()">[Hilfe]</a>
                 </span>
             <td width='70%' class='cat_one'>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'SIZE')" name='select_size'>
                         <option value='0'>SIZE
                         <option value='1'>winzig
                         <option value='2'>klein
                         <option value='3'>mittel
                         <option value='4'>gro&szlig;
                         <option value='5'>riesig
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'FONT')" name='select_font'>
                         <option value='0'>FONT
                         <option value='arial'>Arial
                         <option value='comic sans ms'>Comic
                         <option value='courier'>Courier
                         <option value='courier new'>Courier New
                         <option value='tahoma'>Tahoma
                         <option value='times new roman'>Times New Roman
                         <option value='verdana'>Verdana
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'COLOR')" name='select_color'>
                         <option value='0'>COLOR
                         <option value='skyblue' style='color:skyblue'>sky blue</option>
                         <option value='royalblue' style='color:royalblue'>royal blue</option>
                         <option value='blue' style='color:blue'>blue</option>
                         <option value='darkblue' style='color:darkblue'>dark-blue</option>
                         <option value='orange' style='color:orange'>orange</option>
                         <option value='orangered' style='color:orangered'>orange-red</option>
                         <option value='crimson' style='color:crimson'>crimson</option>
                         <option value='red' style='color:red'>red</option>
                         <option value='firebrick' style='color:firebrick'>firebrick</option>
                         <option value='darkred' style='color:darkred'>dark red</option>
                         <option value='green' style='color:green'>green</option>
                         <option value='limegreen' style='color:limegreen'>limegreen</option>
                         <option value='seagreen' style='color:seagreen'>sea-green</option>
                         <option value='deeppink' style='color:deeppink'>deeppink</option>
                         <option value='tomato' style='color:tomato'>tomato</option>
                         <option value='coral' style='color:coral'>coral</option>
                         <option value='purple' style='color:purple'>purple</option>
                         <option value='indigo' style='color:indigo'>indigo</option>
                         <option value='burlywood' style='color:burlywood'>burlywood</option>
                         <option value='sandybrown' style='color:sandybrown'>sandy brown</option>
                         <option value='sienna' style='color:sienna'>sienna</option>
                         <option value='chocolate' style='color:chocolate'>chocolate</option>
                         <option value='teal' style='color:teal'>teal</option>
                         <option value='silver' style='color:silver'>silver</option>
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'ALIGN')" name='select_align'>
                         <option value='0'>Ausrichtung
                         <option value='center'>Center
                         <option value='left'>Left
                         <option value='right'>Right
                         <option value='justify'>Justify
                 </select>
                 <br>
                 <input type='button' value=' B ' onclick="bbcode(this.form,'B','')" title='Fett (alt+b)' accesskey='b'>
                 <input type='button' value=' I ' onclick="bbcode(this.form,'I','')" title='Kursiv (alt+i)' accesskey='i'>
                 <input type='button' value=' U ' onclick="bbcode(this.form,'U','')" title='Unterstrichen (alt+u)' accesskey='u'>
                 <input type='button' value='http://' onclick="bbnamed(this.form,'URL')" title='Hyperlink einf&uuml;gen'>
                 <input type='button' value=' @ ' onclick="bbnamed(this.form,'EMAIL')" title='Email Adresse einf&uuml;gen'>
                 <input type='button' value='IMG' onclick="bbcode(this.form,'IMG','http://')" title='Bild einf&uuml;gen'>
                 <input type='button' value=' # ' onclick="bbcode(this.form,'CODE','')" title='Quelltext einf&uuml;gen'>
                 <input type='button' value='Liste' onclick="bblist(this.form)" title='Liste einf&uuml;gen' accesskey='l'>
                 <input type='button' value='Zitat' onclick="bbcode(this.form,'QUOTE','')" title='Zitat einf&uuml;gen'>
             </td>
         <?php } ?>
         <tr>
             <?php
             ##### Quote - Post ??? ##### +++
             if ($HTTP_GET_VARS[quote]) {
                 //Quote - Text !!!
                 $Daten_quote = mysql_fetch_array(mySQL_query("SELECT $TB_POST.text, $TB_USER.name
                                                               FROM $TB_POST, $TB_USER
                                                               WHERE $TB_POST.id='$HTTP_GET_VARS[quote]'
                                                                 AND $TB_POST.user_id=$TB_USER.id"));
                 //Quote zeichen
                 $message = "[quote=".$Daten_quote[name]."] ".$Daten_quote[text]." [/quote]\n";
             }
             ##### Quote - Post ??? ##### ---
             ?>
             <td width='30%' valign='top' class='cat_two'>
                 <b>Nachricht:</b>
                 <br><br>
                 <?php smilie_list($Daten[smilies]); ?>
             <td width='70%' valign='top' class='cat_one'>
                 <textarea name='message' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' WRAP='soft' tabindex="2" onChange=getActiveText(this) onclick=getActiveText(this) onFocus=getActiveText(this)><?php
                           echo htmlentities($message);
                 ?></textarea>
                 <br>
                 <span class='font_small'>
                        <a href='javascript:checklength(document.bbform)'>[Beitragsl&auml;nge pr&uuml;fen]</a>
                 </span>
             </td>
         <?php if ($Daten[options] == "on") { ?>
         <tr>
             <?php
             //Optionen des akt. Users herraus bekommen
             $userinfo = get_user_info();
             ?>
             <td width='30%' class='cat_two'>
                 <b>Optionen:</b>
             <td width='70%' class='cat_one'>
                 <input type="checkbox" name="bbcodes" <?php if ($userinfo[bbcodes_show] == "on") { echo "CHECKED"; } ?>>
                 <span class='font_small'>
                       <b>Board-Codes aktivieren ?</b> erstellt z.B. einen Link mit [url]http://phpForum.ath.cx[/url]
                 </span>
                 <br>
                 <input type="checkbox" name="html" <?php if ($userinfo[html_show] == "on") { echo "CHECKED"; } ?>>
                 <span class='font_small'>
                       <b>HTML-Code aktivieren ?</b> HTML-Code wird in diesem Beitrag aktiviert.
                 </span>
                 <br>
                 <input type="checkbox" name="smilies" <?php if ($userinfo[smilies_show] == "on") { echo "CHECKED"; } ?>>
                 <span class='font_small'>
                       <b>Grafische Smilies aktivieren ?</b> Zeichenkombinationen werden in Grafiken umgewandelt.
                 </span>
             </td>
             <?php
         } else {
             ?>
             <input type="hidden" name="bbcodes" value='<?php echo $userinfo[bbcodes_show]; ?>'>
             <input type="hidden" name="html" value='<?php echo $userinfo[html_show]; ?>'>
             <input type="hidden" name="smilies" value='<?php echo $userinfo[smilies_show]; ?>'>
             <?php
         }
         if ($Daten[files] == "on") {
                 ?>
         <tr>
                 <td width='30%' class='cat_two'>
                     <b>Datei anh&auml;ngen:</b>
                     <br>
                     <span class='font_small'>
                           Maximale Gr&ouml;sse: <?php echo $UPLOAD_SIZE; ?> Byte
                     </span>
                 <td width='70%' align='left' class='cat_one'>
                     <input type='file' name='userfile' value='' tabindex="5">
                     <br>
                     <span class='font_small'>
                           Erlaubte Dateiendungen: <?php echo $FILE_TYPES; ?>
                     </span>
                 </td>
                 <?php
             }
             ?>

         </table>
         <p></p>
         <center>
                 <input type='submit' value='Beitrag erstellen' tabindex='13'>
                 <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
         </center>
         </form>
         <?php
echo "<br>";
footer_rulez();
echo "<br>";
forum_list($HTTP_GET_VARS[Topic_id], "DESC");

################################################################################
########################### Speichern  #########################################
} elseif ($HTTP_POST_VARS[action] == "save") {
################################################################################

    ############# Datei ######### +++
    if ($HTTP_POST_FILES[userfile][size] > $UPLOAD_SIZE){ //Bild ausgew�hlt ???
        msg("pic_fault", "2", "back()");
    }
    ############# Datei ######### ---
    #
    $userinfo = get_user_info("");
    #
    ### Post hinzuf�gen ###
    if (mysql_query("INSERT INTO $TB_POST (user_id, post_date, text, topic_id, html, bbcodes, smilies, ip)
                     VALUES ('$userinfo[id]',NOW(),'$HTTP_POST_VARS[message]','$HTTP_POST_VARS[Topic_id]','$HTTP_POST_VARS[html]','$HTTP_POST_VARS[bbcodes]','$HTTP_POST_VARS[smilies]','".$HTTP_SERVER_VARS["REMOTE_ADDR"]."')")) {
        $Post_id=mysql_insert_id();
        ### Senden von eMail�s an Leute die dieses Topic abonniert haben
        topic_abo($HTTP_POST_VARS[Topic_id], "send");
        ### Kopieren der Datei ### +++
        if ($HTTP_POST_FILES[userfile][size] > 0) {
            ### Datei einlesen ### +++
            $fp=@fopen($HTTP_POST_FILES[userfile][tmp_name],"rb");
                 $filestuff=@fread($fp,$HTTP_POST_FILES[userfile][size]);
            @fclose($fp);
            ### Datei einlesen ### ---
            $typ = split (" ", $FILE_TYPES);
            while (list($id, $end) = each($typ)) {
                   if (eregi("$end$", $HTTP_POST_FILES[userfile][name])) {
                       mysql_query("INSERT INTO $TB_FILES (post_id, name, data, typ)
                                    VALUES ('$Post_id','".$HTTP_POST_FILES[userfile][name]."','".addslashes($filestuff)."','".$HTTP_POST_FILES[userfile][type]."')");
                       break;
                   }
            }
        }
        ### Kopieren der Datei ### ---

        //Topic post_date + posts
        mysql_query("UPDATE $TB_TOPIC SET post_date=NOW(), posts=posts+1 WHERE id='$HTTP_POST_VARS[Topic_id]'");
        //Forums + posts
        mysql_query("UPDATE $TB_FORUM SET posts=posts+1, last_topic='$HTTP_POST_VARS[Topic_id]' WHERE id='$Daten[forum_id]'");
        //User Punkt  / last_post update
        mysql_query("UPDATE $TB_USER SET points=points+1, last_post='$Post_id' WHERE id='$userinfo[id]'");

        $Fehler = "post_new";
        $goto = "showtopic.php?$Sess_Name=$Sess&Topic_id=$HTTP_POST_VARS[Topic_id]&goto=lastpost";
    } else {
        $Fehler = "post_new_fault";
        $goto = "back()";
    }
    msg($Fehler, "2", $goto);
}
echo "<br>";
footer();
?>