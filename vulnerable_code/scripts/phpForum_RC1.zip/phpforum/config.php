<?php
###############################################################################
###############################################################################
######################### phpForum by Christoph Roeder ########################
###############################################################################
############################ Do not edit this Code ############################
###############################################################################
######################### Copyright by Christoph Roeder #######################
###############################################################################
######################## Contact: http://phpForum.ath.cx ######################
######################## E-Mail:  KillerGod2000@gmx.net  ######################
######################## ICQ: 108532751                  ######################
###############################################################################
         //Fehler beim DB Aufbau ==> besondere Fehlerausschrift +++
                  if (!$GLOBALS[link]) {
                       if (!$GLOBALS[link] = @mysql_connect ($DB_SERVER, $DB_USER, $DB_PASS)) {
                           echo "<h2><b>Es ist ein Problem mit der Datenbank aufgetreten, bitte den Administrator melden.</b></h2>";
                           exit();
                       }
                       if (!@mysql_select_db ($DB_NAME)) {
                           echo "<h2><b>Es ist ein Problem mit der Datenbank aufgetreten, bitte den Administrator melden.</b></h2>";
                           exit();
                       }
                  }
         if ($GLOBALS[MAIN_PATH] != "") {
             include("$GLOBALS[MAIN_PATH]/config.inc.php");
         }
         //Fehler beim DB Aufbau ==> besondere Fehlerausschrift ---


//Version
        $VER = "2.0 RC1";                    //Version

//Variablen setzten !!!
if (!$HTTP_POST_VARS[no_vars] AND !$no_vars) {
       $result=mysql_query("SELECT * FROM $TB_SETTINGS");
        while($Daten=mysql_fetch_array($result)) {
              $$Daten[name]=$Daten[value];
        }
}
//Variablen setzten !!!

//Magic Quotes
set_magic_quotes_runtime(0);

########### Session starten ################## +++
@session_cache_limiter('nocache');
@session_start();
$Sess_Name = @session_name();
$Sess = @session_id();
########### Session starten ################## ---
?>