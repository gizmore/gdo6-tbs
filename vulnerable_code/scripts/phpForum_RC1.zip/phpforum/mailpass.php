<?php
     $ACCESS_PAGE = "public";
     include("head.php");        //Header mit Bild, Suchen...

################################################################################
################################# pass ??? #####################################
if (($HTTP_GET_VARS[action] == "pass" OR !$HTTP_GET_VARS[action]) AND !$HTTP_POST_VARS[action]) {
    ################################# pass ??? #####################################
    echo "<br>";
    open_table("phpForum - Passwort senden", "60%");
         ?>
         Bitte geben sie ihren Benutzernamen ein, um ein neues Passwort zu erhalten.
         <br><br>
         <form method='post' action='<?php echo "mailpass.php?$Sess_Name=$Sess"; ?>'>
               <input type='hidden' name='action' value='sendpass'>
               <input type='hidden' name='gz_site' value='off'>
               <table border='0' cellpadding='4' cellspacing='1' width='80%' align='center' class='default_table'>
                      <tr>
                          <td width='40%' class='cat_two'>
                              <b>Benutzername:</b>
                          <td width='60%' align='left' class='cat_one'>
                              <input type='text' name='Name' size='30' tabindex='1'>
                          </td>
                      <tr valign="top">
                          <td align='center' colspan='2' class='cat_two'>
                              <input type='submit' name='Abschicken' value='Anfordern' tabindex='2'>
                          </td>
                      </tr>
               </table>
         </form>
    <?php
    close_table("Sie m&uuml;ssen <a href='signup.php'>registriert</a> sein, um ihr Passwort anfordern zu k&ouml;nnen.");
    echo "<p>&nbsp;</p>";
    footer();
################################# pass ??? #####################################
#
#
################################ send-pass #####################################
} elseif ($HTTP_GET_VARS[action] == "sendpass" OR $HTTP_POST_VARS[action] == "sendpass") {
        //$TB_USER - E-Mail herraus bekommen
        $result = mySQL_query ("SELECT $TB_USER.id, $TB_USER.name, $TB_USER.email
                                FROM $TB_USER
                                WHERE $TB_USER.name LIKE '$HTTP_POST_VARS[Name]$HTTP_GET_VARS[Name]'
                                LIMIT 0,1");
        $Daten = mysql_fetch_array($result);

        if (mysql_num_rows($result) == 1 AND $Daten[email]) {
            ### neues Passwort generieren ###
            mt_srand((double)microtime()*1000000);
            $Pass = mt_rand(1000000000,2000000000);
            if (@mail($Daten[email], "$TITEL_KURZ - Passwort","Hallo !\n\nSie erhalten nun das neu angeforderte Passwort f�r ihren Account.\nSie ben�tigen die folgenden Informationen, um sich in unserem Forum: http://$SITE/index.php anzumelden und neue Beitr�ge schreiben zu k�nnen.\n\nBenutzername: $Daten[name]\nKennwort: $Pass\nIhre eMail-Adresse lautet: $Daten[email]", "From: $TITEL_KURZ <$SITE_ADMIN>\nReturn-Path: <$GLOBALS[SITE_ADMIN]>")) {
                ### Mail mit neuem Passwort schicken ###
                $Pass=md5($Pass);
                @mysql_query("UPDATE $TB_USER
                              SET $TB_USER.pass='$Pass'
                              WHERE id='$Daten[id]'");
                ### eMail ohne Probleme verschickt
                $Fehler = "email";
                $goto = "index.php?$Sess_Name=$Sess";
            } else {
                ### Fehler weil SMTP-Server nicht funtzt !!!
                $Fehler = "email_fault";
                $goto = "back()";
            }
        } else {
            ### Fehler weil keine eMail / Benutzer falsch
            $Fehler = "email_fault";
            $goto = "back()";
        }
msg($Fehler, "2", $goto);
}
################################ send-pass #####################################
?>