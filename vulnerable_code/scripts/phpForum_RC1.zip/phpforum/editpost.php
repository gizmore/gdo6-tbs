<?php
        include("head.php");        //Header mit Bild, Suchen...
        access("edit_post");        //Zugriff beschr�nken
        echo "<script language=\"Javascript\" src=\"bbcode.js\"></script>";
        //Optionen des akt. Users herraus bekommen
        $userinfo = get_user_info("");

####### Topic, Forum, Cat - Closed ### +++
        $Daten = mysql_fetch_array (mySQL_query ("SELECT $TB_POST.*,
                                                         $TB_TOPIC.closed AS topic_closed,
                                                         $TB_TOPIC.id AS topic_id,
                                                         $TB_TOPIC.name AS topic_name,
                                                         $TB_FORUM.name AS forum_name,
                                                         $TB_FORUM.bbcodes,
                                                         $TB_FORUM.options,
                                                         $TB_FORUM.smilies,
                                                         $TB_FORUM.id AS forum_id,
                                                         $TB_FORUM.files,
                                                         $TB_CAT.name AS cat_name,
                                                         $TB_CAT.id AS cat_id
                                                  FROM $TB_POST, $TB_TOPIC, $TB_FORUM, $TB_CAT
                                                  WHERE $TB_POST.id='$HTTP_GET_VARS[Post_id]'
                                                    AND $TB_TOPIC.id = $TB_POST.topic_id
                                                    AND $TB_FORUM.id = $TB_TOPIC.forum_id
                                                    AND $TB_CAT.id = $TB_FORUM.cat_id"));
//Mod-Rechte
$perm = get_forum_perm($Daten[forum_id], $userinfo[id]);

//Topic closed ?
if ($Daten[topic_closed] == "on" AND (!$perm[mod_edit] OR !$perm[mod_del])) {
    msg("user", "", "");

//habe Rechte zum bearbeiten / l�schen ?
} elseif (($Daten[user_id] != $userinfo[id] AND $perm[mod_edit] != "on" AND $perm[mod_del] != "on") OR ($Daten[user_id] == $userinfo[id] AND $perm[edit_post] != "on" AND $perm[del_post] != "on")) {
    msg("user", "", "");

} else {
    //bearbeiten
    if (($Daten[user_id] != $userinfo[id] AND $perm[mod_edit] == "on") OR ($Daten[user_id] == $userinfo[id] AND $perm[edit_post] == "on")) {
        $post_edit = "on";
    } else {
        $post_edit = "";
    }
    //l�schen
    if (($Daten[user_id] != $userinfo[id] AND $perm[mod_del] == "on") OR ($Daten[user_id] == $userinfo[id] AND $perm[del_post] == "on")) {
        $post_del = "on";
    } else {
        $post_del = "";
    }
}
####### Topic, Forum, Cat - Closed ### ---

//Formular anzeigen !!!
if (!$HTTP_POST_VARS[action]) {
################################################################################
    if ($post_del == "on") {
         ################################ Hier geht�s los ############################### +++
         echo "<form method='post' action='editpost.php?$Sess_Name=$Sess&Post_id=$HTTP_GET_VARS[Post_id]'>";
         echo "<input type='hidden' name='action' value='del'>";
         ################################################################################
         table_header("Beitrag l&ouml;schen", "100%", "1", "colspan=2");
         ?>
                       <tr>
                           <td width='100%' valign='top' colspan='2' class='cat_one'>
                               <table width='100%' border='0'>
                                      <tr class='cat_one'>
                                          <td width='10%'>
                                              <input type='checkbox' name='del' value='on'>&nbsp;<b>l&ouml;schen?</b>
                                          <td width='80%'>
                                              Um diesen Beitrag zu l&ouml;schen, markiere das K&auml;stchen und klicke auf "l&ouml;schen".
                                              <br>
                                              <span class='font_small'>
                                                    Anmerkung: Es wird das gesamte Thema gel&ouml;scht, wenn dieser Beitrag der erste in diesem Thema ist.
                                              </span>
                                          <td width='10%'>
                                              <input type='submit' value='l&ouml;schen'>
                                          </td>
                                      <tr>
                               </table>
                           </td>
                       </tr>
               </table>
         </form>
         <br>
         <?php
    }
    if ($post_edit == "on") {
         ################################ Hier geht�s los ############################### +++
         echo "<form name='bbform' ";
         if ($ALLOW_FILE_UPLOADS == "on") {
             echo "enctype='multipart/form-data'";
         }
         echo " onSubmit='return validate(this)' method='post' action='editpost.php?$Sess_Name=$Sess&Post_id=$HTTP_GET_VARS[Post_id]'>";
         echo "<input type='hidden' name='action' value='save'>";
         ################################################################################
         table_header("Beitrag bearbeiten", "100%", "1", "colspan='2'");
         ?>
         <tr>
             <td width='100%' valign='top' colspan='2' class='cat_tr'>
                 <?php
                 echo "<a href='index.php?$Sess_Name=$Sess'><b>$TITEL_KURZ</b></a>&nbsp;:&nbsp;<a href='index.php?$Sess_Name=$Sess&Cat_id=$Daten[cat_id]'><b>$Daten[cat_name]</b></a>&nbsp;:&nbsp;<a href='showforum.php?$Sess_Name=$Sess&Forum_id=$Daten[forum_id]'><b>$Daten[forum_name]</b></a>&nbsp;:&nbsp;<a href='showtopic.php?$Sess_Name=$Sess&Topic_id=$Daten[topic_id]'><b>$Daten[topic_name]</b></a>&nbsp;:&nbsp;<b>edit Post</b>";
                 ?>
             </td>
         <tr>
             <td width='30%' class='cat_two'>
                       <b>Angemeldet als:</b>
             <td width='70%' align='left' class='cat_one'>
                 <b><?php echo $HTTP_SESSION_VARS[USER_Log]; ?></b>&nbsp;&nbsp;<a href='<?php echo "login.php?$Sess_Name=$Sess&action=logout"; ?>'>[Logout]</a>
             </td>
         <?php if ($Daten[bbcodes] == "on") { ?>
         <tr>
             <td width='30%' valign='top' class='cat_two'>
                 <b>Board-Code:</b>
                 <span class='font_small'>
                       <a href="javascript:BBCode()">[Hilfe]</a>
                 </span>
             <td width='70%' class='cat_one'>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'SIZE')" name='select_size'>
                         <option value='0'>SIZE
                         <option value='1'>winzig
                         <option value='2'>klein
                         <option value='3'>mittel
                         <option value='4'>gro&szlig;
                         <option value='5'>riesig
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'FONT')" name='select_font'>
                         <option value='0'>FONT
                         <option value='arial'>Arial
                         <option value='comic sans ms'>Comic
                         <option value='courier'>Courier
                         <option value='courier new'>Courier New
                         <option value='tahoma'>Tahoma
                         <option value='times new roman'>Times New Roman
                         <option value='verdana'>Verdana
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'COLOR')" name='select_color'>
                         <option value='0'>COLOR
                         <option value='skyblue' style='color:skyblue'>sky blue</option>
                         <option value='royalblue' style='color:royalblue'>royal blue</option>
                         <option value='blue' style='color:blue'>blue</option>
                         <option value='darkblue' style='color:darkblue'>dark-blue</option>
                         <option value='orange' style='color:orange'>orange</option>
                         <option value='orangered' style='color:orangered'>orange-red</option>
                         <option value='crimson' style='color:crimson'>crimson</option>
                         <option value='red' style='color:red'>red</option>
                         <option value='firebrick' style='color:firebrick'>firebrick</option>
                         <option value='darkred' style='color:darkred'>dark red</option>
                         <option value='green' style='color:green'>green</option>
                         <option value='limegreen' style='color:limegreen'>limegreen</option>
                         <option value='seagreen' style='color:seagreen'>sea-green</option>
                         <option value='deeppink' style='color:deeppink'>deeppink</option>
                         <option value='tomato' style='color:tomato'>tomato</option>
                         <option value='coral' style='color:coral'>coral</option>
                         <option value='purple' style='color:purple'>purple</option>
                         <option value='indigo' style='color:indigo'>indigo</option>
                         <option value='burlywood' style='color:burlywood'>burlywood</option>
                         <option value='sandybrown' style='color:sandybrown'>sandy brown</option>
                         <option value='sienna' style='color:sienna'>sienna</option>
                         <option value='chocolate' style='color:chocolate'>chocolate</option>
                         <option value='teal' style='color:teal'>teal</option>
                         <option value='silver' style='color:silver'>silver</option>
                 </select>
                 <select onchange="bbfont(this.form,this.options[this.selectedIndex].value,'ALIGN')" name='select_align'>
                         <option value='0'>Ausrichtung
                         <option value='center'>Center
                         <option value='left'>Left
                         <option value='right'>Right
                         <option value='justify'>Justify
                 </select>
                 <br>
                 <input type='button' value=' B ' onclick="bbcode(this.form,'B','')" title='Fett (alt+b)' accesskey='b'>
                 <input type='button' value=' I ' onclick="bbcode(this.form,'I','')" title='Kursiv (alt+i)' accesskey='i'>
                 <input type='button' value=' U ' onclick="bbcode(this.form,'U','')" title='Unterstrichen (alt+u)' accesskey='u'>
                 <input type='button' value='http://' onclick="bbnamed(this.form,'URL')" title='Hyperlink einf&uuml;gen'>
                 <input type='button' value=' @ ' onclick="bbnamed(this.form,'EMAIL')" title='Email Adresse einf&uuml;gen'>
                 <input type='button' value='IMG' onclick="bbcode(this.form,'IMG','http://')" title='Bild einf&uuml;gen'>
                 <input type='button' value=' # ' onclick="bbcode(this.form,'CODE','')" title='Quelltext einf&uuml;gen'>
                 <input type='button' value='Liste' onclick="bblist(this.form)" title='Liste einf&uuml;gen' accesskey='l'>
                 <input type='button' value='Zitat' onclick="bbcode(this.form,'QUOTE','')" title='Zitat einf&uuml;gen'>
             </td>
         <?php } ?>
         <tr>
             <td width='30%' valign='top' class='cat_two'>
                 <b>Nachricht:</b>
                 <br><br>
                 <?php smilie_list($Daten[smilies]); ?>
             <td width='70%' valign='top' class='cat_one'>
                 <span class='font_small'>
                       <?php
                       $from = get_user_info($Daten[user_id]);
                       echo "Original Beitrag von: <b>".$from[name]."</b><br>"; ?>
                 </span>
                 <textarea name='message' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' WRAP='soft' tabindex="1" onChange=getActiveText(this) onclick=getActiveText(this) onFocus=getActiveText(this)><?php
                           echo htmlentities($Daten[text]);
                 ?></textarea>
                 <br>
                 <span class='font_small'>
                        <a href='javascript:checklength(document.bbform)'>[Beitragsl&auml;nge pr&uuml;fen]</a>
                 </span>
             </td>
         <?php if ($Daten[options] == "on") { ?>
         <tr>
             <td width='30%' class='cat_two'>
                 <b>Optionen:</b>
             <td width='70%' class='cat_one'>
                 <span class='font_small'>
                       <input type="checkbox" name="bbcodes" <?php if ($Daten[bbcodes] == "on") { echo "CHECKED"; } ?>>
                       <b>Board-Codes aktivieren ?</b> erstellt z.B. einen Link mit [url]http://phpForum.ath.cx[/url]
                       <br>
                       <input type="checkbox" name="html" <?php if ($Daten[html] == "on") { echo "CHECKED"; } ?>>
                       <b>HTML-Code aktivieren ?</b> HTML-Code wird in diesem Beitrag aktiviert.
                       <br>
                       <input type="checkbox" name="smilies" <?php if ($Daten[smilies] == "on") { echo "CHECKED"; } ?>>
                       <b>Grafische Smilies aktivieren ?</b> Zeichenkombinationen werden in Grafiken umgewandelt.
                 </span>
             </td>
             <?php
         }
         if ($Daten[files] == "on") {
         ?>
         <tr>
                 <td width='30%' class='cat_two'>
                     <b>Datei anh&auml;ngen:</b>
                     <br>
                     <span class='font_small'>
                           Maximale Gr&ouml;sse: <?php echo $UPLOAD_SIZE; ?> Byte<br>
                           Erlaubte Dateiendungen: <?php echo $FILE_TYPES; ?>
                     </span>
                 <td width='70%' align='left' class='cat_one'>
                     <span class='font_small'>
                           <?php $result_file = mysql_query("SELECT *
                                                          FROM $TB_FILES
                                                          WHERE post_id='$HTTP_GET_VARS[Post_id]'");
                              $Daten_file = mysql_fetch_array($result_file);
                           if (mysql_num_rows($result_file) != 0) {
                               ?>
                               <input type='radio' name='file' VALUE='keep' checked>&nbsp;Aktuellen Anhang erhalten (<?php echo "<a href='attachements.php?id=$HTTP_GET_VARS[Post_id]' target='_blank'><b>$Daten_file[name]</b></a>"; ?>)<br>
                               <input type='radio' name='file' VALUE='del'>&nbsp;Aktuellen Anhang l&ouml;schen<br>
                               <input type='radio' name='file' VALUE='edit'>&nbsp;Neuen Anhang ausw&auml;hlen: <input type='file' name='userfile' tabindex="2">
                               <?php
                           } else {
                               ?>
                               <input type='hidden' name='file' VALUE='new'>
                               <input type='file' name='userfile' tabindex="2">
                               <?php
                           }
                           ?>
                     </span>
                 </td>
                 <?php
         }
         ?>
         </tr>
         </table>
         <p></p>
         <center>
                 <input type='submit' value='Beitrag bearbeiten' tabindex='3'>
                 <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
         </center>
         </form>
         <?php
    }
echo "<br>";
footer_rulez();
echo "<br>";
forum_list($Daten[topic_id], "DESC");

################################################################################
########################### Speichern  #########################################
} elseif ($HTTP_POST_VARS[action] == "save") {
################################################################################

    ############# Datei ######### +++
    if ($HTTP_POST_FILES[userfile][size] > $UPLOAD_SIZE){ //Datei ausgew�hlt ???
        msg("pic_fault", "2", "back()");
    }
    ############# Datei ######### ---
    #
    $userinfo = get_user_info("");
    #
    ### Post updaten ###
    if (mysql_query("UPDATE $TB_POST SET text='$HTTP_POST_VARS[message]', html='$HTTP_POST_VARS[html]', bbcodes='$HTTP_POST_VARS[bbcodes]', smilies='$HTTP_POST_VARS[smilies]', edit='$userinfo[id]'
                     WHERE $TB_POST.id='$HTTP_GET_VARS[Post_id]'")) {

        //Datei l�schen
        if ($HTTP_POST_VARS[file] == "del") {
            mysql_query("DELETE FROM $TB_FILES WHERE post_id='$HTTP_GET_VARS[Post_id]'");
        //Datei hinzuf�gen / Updaten
        } elseif ($HTTP_POST_FILES[userfile][size] > 0 AND ($HTTP_POST_VARS[file] == "new" OR $HTTP_POST_VARS[file] == "edit")) {
            ### Datei einlesen ### +++
            $fp=@fopen($HTTP_POST_FILES[userfile][tmp_name],"rb");
                 $filestuff=@fread($fp,$HTTP_POST_FILES[userfile][size]);
            @fclose($fp);
            ### Datei einlesen ### ---
            $typ = split (" ", $FILE_TYPES);
            while (list($id, $end) = each($typ)) {
                   if (eregi("$end$", $HTTP_POST_FILES[userfile][name])) {
                       if ($HTTP_POST_VARS[file] == "new") {
                           mysql_query("INSERT INTO $TB_FILES (post_id, name, data, typ)
                                        VALUES ('$HTTP_GET_VARS[Post_id]','".$HTTP_POST_FILES[userfile][name]."','".addslashes($filestuff)."','".$HTTP_POST_FILES[userfile][type]."')");
                       } elseif ($HTTP_POST_VARS[file] == "edit") {
                           mysql_query("UPDATE $TB_FILES SET name='".$HTTP_POST_FILES[userfile][name]."', data='".addslashes($filestuff)."', typ='".$HTTP_POST_FILES[userfile][type]."', views='0'
                                        WHERE $TB_FILES.post_id='$HTTP_GET_VARS[Post_id]'");
                       }
                       break;
                   }
            }
        }
        ### Kopieren der Datei ### ---
        $topic = mysql_fetch_array(mysql_query("SELECT $TB_TOPIC.id
                                                FROM $TB_POST, $TB_TOPIC
                                                WHERE $TB_POST.id='$HTTP_GET_VARS[Post_id]'
                                                  AND $TB_TOPIC.id=$TB_POST.topic_id"));
        $Fehler = "post_edit";
        $goto = "showtopic.php?$Sess_Name=$Sess&Topic_id=$topic[id]&goto=lastpost";
    } else {
        $Fehler = "post_edit_fault";
        $goto = "back()";
    }
    msg($Fehler, "2", $goto);

################################################################################
############################# l�schen  #########################################
} elseif ($HTTP_POST_VARS[action] == "del") {
################################################################################
    if ($post_del == "on" AND $HTTP_POST_VARS[del] == "on") {

        $topic = mysql_fetch_array(mysql_query("SELECT $TB_TOPIC.id, $TB_TOPIC.forum_id
                                                FROM $TB_POST, $TB_TOPIC
                                                WHERE $TB_POST.id='$HTTP_GET_VARS[Post_id]'
                                                  AND $TB_TOPIC.id=$TB_POST.topic_id"));
        $Daten = mysql_fetch_array(mysql_query("SELECT $TB_POST.id
                                                FROM $TB_POST
                                                WHERE $TB_POST.topic_id='$topic[id]'
                                                ORDER BY $TB_POST.id
                                                LIMIT 0,1"));
        //erster Post in diesem Thema => ganzes Thema + Poll l�schen
        if ($Daten[id] == $HTTP_GET_VARS[Post_id]) {
            del_topic($topic[id]);
            $goto = "showforum.php?$Sess_Name=$Sess&Forum_id=$topic[forum_id]";

        //nur diesen Post l�schen
        } else {
            del_post($HTTP_GET_VARS[Post_id]);
            $goto = "showtopic.php?Topic_id=$topic[id]&goto=lastpost";
        }
        msg("post_del", "", "$goto");

    } else {
        msg("post_edit_fault", "2", "back()");
    }
}

echo "<br>";
footer();
?>