<?php
        include("head.php");        //Header mit Bild, Suchen...
        echo "<br>";
######### ANZ - Posts ##### +++
        $Posts_anz = mySQL_num_rows(mySQL_query ("SELECT *
                                                  FROM $TB_POST
                                                  WHERE $TB_POST.topic_id='$HTTP_GET_VARS[Topic_id]'"));
        //wenn keine Page �bergeben wurde
        if ($HTTP_GET_VARS[Page] == "") {
            $HTTP_GET_VARS[Page]="1";
        }

        //f�r die LIMIT
        if ($Posts_anz > $ANZ_POST) {
            $p=$HTTP_GET_VARS[Page]-1;
            $L_AB=$ANZ_POST*$p;
        }
        //f�r die LIMIT
        if ($L_AB < "0") {
            $L_AB="0";
        }
######### ANZ - Posts ##### ---
#
#
##### Polls ##### +++
      include("poll.php");        //Wenn ein Poll vorhanden ist
##### Polls ##### ---
#
#
######### Navigation ##### +++
$Daten_topic = mysql_fetch_array(mySQL_query ("SELECT $TB_FORUM.name AS forum_name,
                                                      $TB_FORUM.id AS forum_id,
                                                      $TB_CAT.name AS cat_name,
                                                      $TB_CAT.id AS cat_id,
                                                      $TB_TOPIC.name AS topic_name,
                                                      $TB_TOPIC.id AS topic_id,
                                                      $TB_TOPIC.views AS topic_views,
                                                      $TB_TOPIC.closed
                                               FROM $TB_FORUM, $TB_CAT, $TB_TOPIC
                                               WHERE $TB_TOPIC.id='$HTTP_GET_VARS[Topic_id]'
                                                 AND $TB_FORUM.id=$TB_TOPIC.forum_id
                                                 AND $TB_FORUM.cat_id=$TB_CAT.id"));

### "Hit" hinzuf�gen ### +++
if (!$HTTP_GET_VARS[goto] AND !preg_match("/.*Page=([0-9]*)/",$HTTP_SERVER_VARS[HTTP_REFERER])) {
    mysql_query("UPDATE $TB_TOPIC SET views=views+1 WHERE id='$Daten_topic[topic_id]'");
}
### "Hit" hinzuf�gen ### ---
#
#
###*** Seiten Navigation ***
echo "<div align='right'>".navi($HTTP_GET_VARS[Page], $Posts_anz, $ANZ_POST, "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Topic_id=$HTTP_GET_VARS[Topic_id]")."</div>";
###*** Seiten Navigation ***
?>
<table border='0' cellpadding='2' cellspacing='1' width='100%' class='default_table'>
       <tr class='default_tr'>
           <td width='20%' NOWRAP align='center'>
               <B>Autor</B>
           <td width='80%' NOWRAP align='center'>
               <b>Nachricht</b>
           </td>
       </tr>
       <tr class='cat_tr'>
           <td width='100%' valign='top' colspan='2'>
               <?php
               echo "<a href='index.php?$Sess_Name=$Sess'><b>$TITEL_KURZ</b></a>&nbsp;:&nbsp;<a href='index.php?$Sess_Name=$Sess&Cat_id=$Daten_topic[cat_id]'><b>$Daten_topic[cat_name]</b></a>&nbsp;:&nbsp;<a href='showforum.php?$Sess_Name=$Sess&Forum_id=$Daten_topic[forum_id]'><b>$Daten_topic[forum_name]</b></a>&nbsp;:&nbsp;<b>$Daten_topic[topic_name]</b>";
               ?>
           </td>
       </tr>
<?php
######### Navigation ##### ---
#
#
######### Nachrichten ##### +++
$Rules = mysql_fetch_array (mySQL_query ("SELECT $TB_FORUM.bbcodes,
                                                 $TB_FORUM.html,
                                                 $TB_FORUM.smilies
                                          FROM $TB_FORUM, $TB_TOPIC
                                          WHERE $TB_TOPIC.id='$HTTP_GET_VARS[Topic_id]'
                                            AND $TB_FORUM.id=$TB_TOPIC.forum_id"));

$result_post = mySQL_query ("SELECT $TB_POST.*,
                                    $TB_USER.id AS poster_id,
                                    $TB_USER.name AS poster_name,
                                    $TB_USER.reg AS poster_reg,
                                    $TB_USER.points AS poster_points,
                                    $TB_USER.email_show AS poster_email_show,
                                    $TB_USER.homepage AS poster_homepage,
                                    $TB_ACCESS.send_pm AS access_send_pm
                             FROM $TB_POST, $TB_USER, $TB_ACCESS
                             WHERE $TB_POST.topic_id='$HTTP_GET_VARS[Topic_id]'
                               AND $TB_USER.id=$TB_POST.user_id
                               AND $TB_ACCESS.id=$TB_USER.access_id
                             ORDER BY $TB_POST.post_date ASC
                             LIMIT $L_AB,$ANZ_POST");
while ($Daten = mysql_fetch_array ($result_post)) {
       ?>
       <tr>
           <td width='20%' align='center' valign='top' class='cat_two'>
               <a name='Post<?php echo $Daten[id]; ?>'></a><b><?php echo $Daten[poster_name]; ?></b>
               <br>
               <span class='font_small'>
                     <?php
                     echo status_stars($Daten[poster_id]);
                     ?>
                     <br>
                     (<?php echo status_name($Daten[poster_id]); ?>)
                     <br>
                     <br>
                     Beitr&auml;ge: <?php echo $Daten[poster_points]; ?>
                     <br>
                     <?php echo avatar($Daten[poster_id]); ?>
                     <p>
                        Registriert seit: <?php echo $Daten[poster_reg]; ?>
                     </p>
               </span>
           <td width='80%' align='left' valign='top' class='cat_one'>
               <?php
               #### BB-Code durch HTML-Code ersetzen ###+++
                     if ($Rules[bbcodes] == "on") {
                         $bbcodes = $Daten[bbcodes];
                     } else {
                         $bbcodes = "";
                     }
                     if ($Rules[html] == "on") {
                         $html = $Daten[html];
                     } else {
                         $html = "";
                     }
                     if ($Rules[smilies] == "on") {
                         $smilies = $Daten[smilies];
                     } else {
                         $smilies = "";
                     }
                     $message = bbcode($Daten[text], $bbcodes, $html, $smilies, "on", "on");
                     $message .= attachement($Daten[id]);

                          //Signatur
                          if ($Poster[sign_show] == "on") {
                              $message .= "<br><br>_________________<br>".bbcode("$Poster[sign]", $SIGN_BBCODES, $SIGN_HTML, $SIGN_SMILIES, "on", "on");
                          }
               #### BB-Code durch HTML-Code ersetzen ###---
               #
               #
               ### Ge�ndert ??? ### +++
                     if ($Daten[edit] != "") {
                         $edit = get_user_info($Daten[edit]);
                         $message = "<span class='font_small'>ge&auml;ndert von: $edit[name]</span><br><br>".$message;
                     }
               ### Ge�ndert ??? ### ---
               echo $message; ?>
           </td>
       <tr height='10'>
           <td width='20%' align='center' class='cat_two'>
               <?php echo post_new($Daten[id]); ?>
               <span class='font_small'>
                     <?php echo $Daten[post_date]; ?>
               </span>
           <td width='80%' align='center' class='cat_two'>
               <table width='100%' border='0' cellpadding='0' cellspacing='0'>
                      <tr valign='buttom' class='cat_two'>
                          <td width='50%' align='left'>
                              <a href='<?php echo "showuser.php?$Sess_Name=$Sess&id=$Daten[user_id]"; ?>'><img src='<?php echo $_style[pic_profile]; ?>' border='0' alt='Profil von <?php echo $Daten[poster_name]; ?> anzeigen'></a>
                              <?php
                              if ($Daten[poster_email_show] == "on") {
                                  ?>
                                  &nbsp;<a href='<?php echo "mail.php?$Sess_Name=$Sess&id=$Daten[user_id]"; ?>'><img src='<?php echo $_style[pic_mail]; ?>' border='0' alt='eine eMail an <?php echo $Daten[poster_name]; ?> schicken'></a>
                                  <?php
                              }
                              if ($Daten[access_send_pm] == "on") {
                                  ?>
                                  &nbsp;<a href='<?php echo "private.php?$Sess_Name=$Sess&action=new&user_id=$Daten[user_id]"; ?>'><img src='<?php echo $_style[pic_pm]; ?>' border='0' alt='eine neue Nachricht an <?php echo $Daten[poster_name]; ?> schicken'></a>
                                  <?php
                              }
                              if ($Daten[poster_homepage]) {
                                  ?>
                                  &nbsp;<a href='<?php echo $Daten[poster_homepage]; ?>' target='_blank'><img src='<?php echo $_style[pic_home]; ?>' border='0' alt='Homepage von <?php echo $Daten[poster_name]; ?> anzeigen'></a>
                                  <?php
                              }
                              ?>
                              &nbsp;<a href='<?php echo "search.php?$Sess_Name=$Sess&action=search&get=user&search=$Daten[user_id]"; ?>'><img src='<?php echo $_style[pic_search]; ?>' border='0' alt='Beitr&auml;ge von <?php echo $Daten[poster_name]; ?> anzeigen'></a>
                          <td width='50%' align='right'>
                              <a href='<?php echo "newpost.php?$Sess_Name=$Sess&Topic_id=$HTTP_GET_VARS[Topic_id]&quote=$Daten[id]"; ?>'><img src='<?php echo $_style[pic_quote]; ?>' border='0' alt='Beitrag von <?php echo $Daten[poster_name]; ?> zitieren'></a>
                              &nbsp;<a href='<?php echo "editpost.php?$Sess_Name=$Sess&Post_id=$Daten[id]"; ?>'><img src='<?php echo $_style[pic_edit]; ?>' border='0' alt='Beitrag editieren'></a>
                              &nbsp;<a href='#Post<?php echo $Daten[id]; ?>' onclick="window.open('<?php echo "http://$SITE/functions.php?action=mod_ip&$Sess_Name=$Sess&id=$Daten[id]"; ?>','IP','height=150, width=350, toolbar=no, scrollbars=no, resizable=no, top=200, left=250')"><img src='<?php echo $_style[pic_ip]; ?>' border='0' alt='IP-Adresse anzeigen'></a>
                          </td>
                      </tr>
               </table>
           </td>
       </tr>
       <?php
}
?>
</table>
<?php
###*** Seiten Navigation ***
echo "<div align='right'>".navi($HTTP_GET_VARS[Page], $Posts_anz, $ANZ_POST, "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Topic_id=$HTTP_GET_VARS[Topic_id]")."</div>";
###*** Seiten Navigation ***
#
#
####### Closed ??? +++
if ($Daten_topic[closed] == "on") {
    // Closed
    echo "<br><div align='right'><img src='$_style[pic_closed]' border='0'></div>";
} else {
    // new Post
    echo "<br><div align='right'><a href='newpost.php?$Sess_Name=$Sess&Topic_id=$HTTP_GET_VARS[Topic_id]'><img src='$_style[pic_new_post]' border='0'></a></div>";
}
####### Closed ??? ---
#
#
echo "<div align='center' class='font_normal'>[<a href='functions.php?$Sess_Name=$Sess&action=abo&op=add&Topic_id=$HTTP_GET_VARS[Topic_id]'><img src='$_style[pic_topic_abo]' border='0'>&nbsp;Dieses Thema abonnieren</a>]</div>";

echo "<br>";
mod_list();
footer_list();
footer_rulez();
echo "<br>";
footer();
?>