<?php
        include("config.inc.php");        //Konfiguration
        include("$GLOBALS[MAIN_PATH]/config.php");

        switch ($HTTP_GET_VARS[action]) {

                case "":
                      poll_result($HTTP_GET_VARS[Topic_id]);
                      break;

                case "vote":
                      poll_vote($HTTP_POST_VARS[vote]);
                      break;

                case "add":
                      include("$GLOBALS[MAIN_PATH]/head.php");
                      poll_addedit($HTTP_GET_VARS[Topic_id]);
                      break;

                case "edit":
                      include("$GLOBALS[MAIN_PATH]/head.php");
                      //Mod-Rechte
                      $forum = mysql_fetch_array(mysql_query("SELECT $TB_TOPIC.forum_id
                                                              FROM $TB_TOPIC, $TB_POLL
                                                              WHERE $TB_POLL.id='$HTTP_GET_VARS[poll_id]'
                                                                AND $TB_TOPIC.id=$TB_POLL.topic_id"));
                      $perm = get_forum_perm($forum[forum_id], "");
                      if ($perm[mod_edit] == "on") {
                          poll_addedit($HTTP_GET_VARS[poll_id]);
                      } else {
                         msg("user", "2", "back()");
                      }
                      break;

                case "adv":
                      include("$GLOBALS[MAIN_PATH]/head.php");
                      //Mod-Rechte
                      $forum = mysql_fetch_array(mysql_query("SELECT $TB_TOPIC.*
                                                              FROM $TB_TOPIC, $TB_POLL
                                                              WHERE $TB_POLL.id='$HTTP_GET_VARS[poll_id]'
                                                                AND $TB_TOPIC.id=$TB_POLL.topic_id"));
                      $perm = get_forum_perm($forum[forum_id], "");
                      if ($perm[mod_edit] == "on") {
                          poll_adv($HTTP_GET_VARS[poll_id]);
                      } else {
                         msg("user", "2", "back()");
                      }
                      break;
        }

###############################################################################
############################### Funktionen ####################################
###############################################################################
#
#
##################### poll_form ##################### +++
function poll_result($topic) {
         global $HTTP_SERVER_VARS, $_style;
         $userinfo = get_user_info();

         $result_poll = mySQL_query ("SELECT $GLOBALS[TB_POLL].*
                                      FROM $GLOBALS[TB_POLL]
                                      WHERE $GLOBALS[TB_POLL].topic_id='$topic'");
         $Poll = mysql_fetch_array($result_poll);

         ### dieser Beitrag hat eine Umfrage
         if (mysql_num_rows($result_poll) == 1) {
             //Daten zum Poll
             $Daten = mysql_fetch_array (mySQL_query ("SELECT id, text
                                                       FROM $GLOBALS[TB_POLL_TEXT]
                                                       WHERE $GLOBALS[TB_POLL_TEXT].poll_id='$Poll[id]'"));
             $result_text = mysql_query("SELECT *
                                         FROM $GLOBALS[TB_POLL_TEXT]
                                         WHERE $GLOBALS[TB_POLL_TEXT].poll_id='$Poll[id]'
                                         ORDER BY $GLOBALS[TB_POLL_TEXT].id");
             $result_poll_user = mysql_query("SELECT $GLOBALS[TB_POLL_USER].user_id
                                              FROM $GLOBALS[TB_POLL_USER], $GLOBALS[TB_POLL_TEXT], $GLOBALS[TB_POLL]
                                              WHERE $GLOBALS[TB_POLL].id='$Poll[id]'
                                                AND $GLOBALS[TB_POLL_TEXT].poll_id=$GLOBALS[TB_POLL].id
                                                AND $GLOBALS[TB_POLL_TEXT].id=$GLOBALS[TB_POLL_USER].text_id");
             $Poll_text_anz = mysql_num_rows($result_poll_user);
             //$Daten_users aufbauen
             while ($Daten_result_users = mysql_fetch_array($result_poll_user)) {
                    if ($Daten_result_users[user_id] == $userinfo[id] OR user_login() == FALSE) {
                        $can_vote = FALSE;
                        $status = "Sie haben bereits an dieser Umfrage teil genommen.";
                        $colspan_o = 4;
                        $colspan_u = 2;
                        break;
                    } else {
                        $can_vote = TRUE;
                        $colspan_o = 5;
                        $colspan_u = 3;
                    }
             }
             if (mysql_num_rows($result_poll_user) <= 0) {
                 $can_vote = TRUE;
                 $colspan_o = 5;
                 $colspan_u = 3;
             }
             //Poll schon geschlossen ???
             if ($Poll[date] < date("Y-m-d") AND $Poll[date] != "0000-00-00") {
                 $status = "Die Umfrage ist leider abgelaufen.";
                 $can_vote = FALSE;
                 $colspan_o = 4;
                 $colspan_u = 2;
             }
             $Poll_prozent_gesamt = 0;
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=vote"; ?>'>
                   <input type='hidden' name='poll' value='<?php echo $Poll[id]; ?>'>
                   <input type='hidden' name='Topic_id' value='<?php echo $topic; ?>'>
                   <table border='0' cellpadding='2' cellspacing='1' width='100%' class='default_table'>
                          <tr class='default_tr'>
                              <td width='100%' align='center' colspan='<?php echo $colspan_o; ?>'>
                                  <B><?php echo $Poll[name]; ?></B>
                                  <?php
                                  if ($status) {
                                      echo "<br><span class='font_small'>
                                                  $status
                                            </span>";
                                  }
                                  ?>
                              </td>
                          </tr>
                          <?php
                          while ($Daten_text=mysql_fetch_array ($result_text)) {

                                 ### Prozent !!! ### +++
                                 $Poll_votes = mysql_num_rows(mySQL_query("SELECT *
                                                                           FROM $GLOBALS[TB_POLL_USER]
                                                                           WHERE $GLOBALS[TB_POLL_USER].text_id='$Daten_text[id]'"));
                                 @$Poll_prozent = 100 / $Poll_text_anz * $Poll_votes;
                                 $Poll_prozent_gesamt=$Poll_prozent_gesamt+$Poll_prozent;
                                 ### Prozent !!! ### ---
                                 echo "<tr>";
                                 if ($can_vote == TRUE) {
                                     ?>
                                     <td width='5%' align='center' class='cat_two'>
                                         <input type='radio' name='vote' value='<?php echo $Daten_text[id]; ?>'>
                                     <td width='40%' align='left' class='cat_one'>
                                         <?php echo "<b>".$Daten_text[text]."</b>";
                                 } else {
                                     ?>
                                     <td width='45%' align='left' class='cat_one'>
                                         <?php echo "<b>".$Daten_text[text]."</b>";
                                 } ?>
                                 <td width='30%' align='left' class='cat_two'>
                                     <?php
                                     $width = number_format($Poll_prozent,0)+number_format($Poll_prozent,0);
                                     echo "<img src='$_style[pic_poll_l]' height='15' border='0'><img src='$_style[pic_poll_m]' width='$width' height='15' border='0'><img src='$_style[pic_poll_r]' height='15' border='0'>";
                                     ?>
                                 <td width='15%' align='center' class='cat_one'>
                                     <b><?php echo $Poll_votes; ?></b>
                                 <td width='10%' align='center' class='cat_two'>
                                     <?php echo number_format($Poll_prozent,2)." %"; ?>
                                 </td>
                                 <?php
                          } ?>
                          <tr class='default_tr'>
                              <td width='75%' align='right' colspan='<?php echo $colspan_u; ?>'>
                                  <B>Summe:</B>
                              <td width='15%' align='center'>
                                  <B><?php echo $Poll_text_anz; ?>&nbsp;Stimmen</B>
                              <td width='10%' align='center'>
                                  <B><?php echo number_format($Poll_prozent_gesamt)." %"; ?></B>
                              </td>
                          </tr>
                   </TABLE>
                   <div align='right' class='font_normal'>
                        <a href='<?php echo "poll.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&poll_id=$Poll[id]"; ?>'>[bearbeiten]</a>
                   </div>
                   <?php
                   if ($can_vote == TRUE) {
                       echo "<input type='submit' value='Abstimmen'>";
                   }
                   ?>
             </form>
             <?php
         }
}
##################### poll_form ##################### ---
#
#
##################### poll_vote ##################### +++
function poll_vote($vote) {
         global $HTTP_POST_VARS;

         $userinfo = get_user_info();
         $Poll = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_POLL].*
                                                 FROM $GLOBALS[TB_POLL]
                                                 WHERE $GLOBALS[TB_POLL].id='$HTTP_POST_VARS[poll]'"));

         $result_poll_user = mysql_query("SELECT $GLOBALS[TB_POLL_USER].user_id
                                          FROM $GLOBALS[TB_POLL_USER], $GLOBALS[TB_POLL_TEXT]
                                          WHERE $GLOBALS[TB_POLL_TEXT].poll_id='$Poll[id]'
                                                AND $GLOBALS[TB_POLL_TEXT].id=$GLOBALS[TB_POLL_USER].text_id");
         //$Daten_users aufbauen
         while ($Daten_result_users = mysql_fetch_array($result_poll_user)) {
                if ($Daten_result_users[user_id] == $userinfo[id]) {
                    msg("poll_fault", "2", "back()");
                }
         }
         //Poll schon geschlossen ???
         if ($Poll[date] < date("Y-m-d") AND $Poll[date] != "0000-00-00") {
             msg("poll_fault", "2", "back()");
         }
         mysql_query("INSERT INTO $GLOBALS[TB_POLL_USER] (text_id, user_id)
                      VALUES ('$vote','$userinfo[id]')");
         msg("poll", "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$HTTP_POST_VARS[Topic_id]");
}
##################### poll_vote ##################### ---
#
#
##################### poll_addedit ##################### +++
function poll_addedit($id="") {
         global $HTTP_POST_VARS, $HTTP_GET_VARS, $HTTP_SERVER_VARS;

         if (!$HTTP_POST_VARS[poll_anz]) {
              $HTTP_POST_VARS[poll_anz] = $HTTP_GET_VARS[poll_anz];
         }
         $polls = $HTTP_POST_VARS[polls];

         ###### hinzuf�gen
         if ($HTTP_GET_VARS[action] == "add" OR !$HTTP_GET_VARS[action]) {
             $typ = "erstellen";
             $topic = $HTTP_GET_VARS[Topic_id];
             if (is_array($polls) == FALSE) {
                 $polls = array();
             }

         ###### bearbeiten
         } elseif ($HTTP_GET_VARS[action] == "edit" AND !$HTTP_POST_VARS[send]) {
             $typ = "bearbeiten";

                 $result = mysql_query("SELECT $GLOBALS[TB_POLL].id,
                                               $GLOBALS[TB_POLL].name,
                                               $GLOBALS[TB_POLL].topic_id,
                                               $GLOBALS[TB_POLL_TEXT].text,
                                               TO_DAYS($GLOBALS[TB_POLL].date)-TO_DAYS(NOW()) AS max
                                        FROM $GLOBALS[TB_POLL], $GLOBALS[TB_POLL_TEXT]
                                        WHERE $GLOBALS[TB_POLL].id='$id'
                                          AND $GLOBALS[TB_POLL_TEXT].poll_id=$GLOBALS[TB_POLL].id
                                        ORDER BY $GLOBALS[TB_POLL_TEXT].id");
                 if (is_array($polls) == FALSE) {
                     $polls = range(1, mysql_num_rows($result)-1);
                 }
                 $n = 1;
                 while ($Daten = mysql_fetch_array($result)) {

                        //nur wenn nicht ge�ndert (is_array)
                        if (!$HTTP_POST_VARS[update]) {
                            $polls[$n] = $Daten[text];
                            $HTTP_POST_VARS[name] = $Daten[name];
                            $HTTP_POST_VARS[limit] = $Daten[max];
                        }
                        $HTTP_GET_VARS[poll_id] = $Daten[id];
                        $topic = $Daten[topic_id];
                        $n++;
                 }
             //Zeitlich unbegrenzt
             if ($HTTP_POST_VARS[limit] == "0000-00-00") {
                 $HTTP_POST_VARS[limit] = "";
             }
             if (!$HTTP_POST_VARS[poll_anz]) {
                 $HTTP_POST_VARS[poll_anz] = mysql_num_rows($result);
             }
         }

         ###### l�schen / schliessen
         if ($HTTP_GET_VARS[action] == "edit" AND (in_array("", $polls) == TRUE OR !$HTTP_POST_VARS[name] OR $HTTP_POST_VARS[send] != "bearbeiten")) {
             echo "<form method='post' action='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=adv&poll_id=$id'>";
             echo "<input type='hidden' name='Topic_id' value='$topic'>";
             table_header("Umfrage bearbeiten", "90%", "1", "colspan=2");
                       ?>
                       <tr>
                           <td width='100%' valign='top' colspan='2' class='cat_one'>
                               <table width='100%' border='0'>
                                      <tr>
                                          <td width='10%'>
                                              <span class='font_normal'>
                                                    <input type='checkbox' name='del' value='on'>&nbsp;<b>l&ouml;schen?</b>
                                              </span>
                                          <td width='80%'>
                                              <span class='font_normal'>
                                                    Um diese Umfrage zu l&ouml;schen, markiere das K&auml;stchen und klicke auf "l&ouml;schen".
                                              </span>
                                          <td width='10%'>
                                              <input type='submit' value='l&ouml;schen'>
                                          </td>
                                      <tr>
                                          <td width='10%'>
                                              <span class='font_normal'>
                                                    <input type='checkbox' name='close' value='on'>&nbsp;<b>schlie&szlig;en?</b>
                                              </span>
                                          <td width='80%'>
                                              <span class='font_normal'>
                                                    Um diese Umfrage zu schlie&szlig;en, markiere das K&auml;stchen und klicke auf "schlie&szlig;en".
                                              </span>
                                          <td width='10%'>
                                              <input type='submit' value='schlie&szlig;en'>
                                          </td>
                                      </tr>
                               </table>
                           </td>
                       </tr>
                       </table>
             </form>
             <br>
             <?php
         }

         ###### Formular
         if (in_array("", $polls) == TRUE OR !$HTTP_POST_VARS[name] OR !$HTTP_POST_VARS[send]) {
         ?>
         <form name='form' method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=$HTTP_GET_VARS[action]&poll_id=$id&Topic_id=$topic"; ?>'>
               <?php
               table_header("Umfrage $typ...","90%", "1", "colspan='2'");
                     ?>
                      <tr>
                          <td width='30%' class='cat_two'>
                              <b>Betreff:</b>
                          <td width='70%' class='cat_one'>
                              <input type='text' name='name' maxlength='255' size='30' value='<?php echo $HTTP_POST_VARS[name]; ?>' tabindex='1'>
                          </td>
                      <tr>
                          <td width='30%' class='cat_two'>
                              <b>Anzahl Antworten:</b>
                          <td width='70%' class='cat_one'>
                              <select name='poll_anz' tabindex='2'><?php
                                      for ($n=2; $n <= $GLOBALS[POLL_LIMIT]; $n++) {
                                           echo "<option value='$n' ";
                                           if ($n == $HTTP_POST_VARS[poll_anz]) {
                                               echo "selected";
                                           }
                                           echo ">$n</option>";
                                      }
                                      ?>
                              </select>&nbsp;
                              <input type='submit' name='update' value='Anzahl �ndern' tabindex='3'>
                          </td>
                      <tr>
                          <td width='30%' class='cat_two'>
                                    <b>Antworten:</b>
                                    <?php
                                    if ($HTTP_POST_VARS[action] == "edit") {
                                        ?>
                                        <br><br>
                                        <span class='font_small'>
                                              <b>Hinweis:</b> Wenn sie diese Umfrage bearbeiten werden alle vorhandenen Abstimmenungen verworfen.
                                        </span>
                                        <?php
                                    }
                                    ?>
                          <td width='70%' class='cat_one'>
                              <table>
                                     <?php
                                     for ($n=1; $n <= $HTTP_POST_VARS[poll_anz]; $n++) {
                                          ?>
                                          <tr>
                                              <td class='font_normal'>
                                                  <?php echo "$n."; ?>
                                              <td>
                                                  <input type='text' name='<?php echo "polls[$n]"; ?>' maxlength='255' size='40' value='<?php echo $polls[$n]; ?>' tabindex='<?php echo $n+3; ?>'>
                                              </td>
                                          </tr>
                                          <?php
                                     }
                                     ?>
                              </table>
                          </td>
                      <tr>
                          <td width='30%' class='cat_two'>
                              <b>Laufzeit der Umfrage:</b><br>
                              <span class='font_small'>
                                    Lass dieses Feld leer wenn die Umfrage zeitlich unbegrenzt sein soll.
                              </span>
                          <td width='70%' class='cat_one'>
                              <input type='text' name='limit' maxlength='10' size='10' value='<?php echo $HTTP_POST_VARS[limit]; ?>' tabindex='<?php echo $HTTP_POST_VARS[poll_anz]+4; ?>'>&nbsp;Tage
                          </td>
                      </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' name='send' value='<?php echo $typ; ?>' tabindex='<?php echo $HTTP_POST_VARS[poll_anz]+5; ?>'>
                       <input type='reset' name='Reset' value='Zur&uuml;cksetzen' tabindex='<?php echo $HTTP_POST_VARS[poll_anz]+6; ?>'>
               </center>
         </form>
         <?php
         ###### Speichern
         } elseif ($HTTP_POST_VARS[send] == "bearbeiten" OR $HTTP_POST_VARS[send] == "erstellen") {

             //laufzeit (unbeschr�nkt)
             if ($HTTP_POST_VARS[limit] == "") {
                 $date = "0000-00-00";
             //laufzeit (beschr�nkt)
             } else {
                 $date = date("Y-m-d", mktime(0,0,0,date("m"),date("d")+$HTTP_POST_VARS[limit],date("Y")));
             }
             ### hinzuf�gen
             if ($HTTP_GET_VARS[action] == "add") {
                 mysql_query("INSERT INTO $GLOBALS[TB_POLL] (name, topic_id, date)
                              VALUES ('$HTTP_POST_VARS[name]','$HTTP_GET_VARS[Topic_id]','$date')");
                 $poll_id = mysql_insert_id();
                 while (list($id, $val) = each($polls)) {
                        mysql_query("INSERT INTO $GLOBALS[TB_POLL_TEXT] (poll_id, text)
                                     VALUES ('$poll_id','$val')");
                 }
                 msg("poll_add", "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$HTTP_GET_VARS[Topic_id]&goto=lastpost");

             ### bearbeiten
             } elseif ($HTTP_GET_VARS[action] == "edit") {
                 ### Umfragen-Texte l�schen
                 $result = mysql_query("SELECT $GLOBALS[TB_POLL_TEXT].id
                                        FROM $GLOBALS[TB_POLL_TEXT], $GLOBALS[TB_POLL]
                                        WHERE $GLOBALS[TB_POLL_TEXT].poll_id=$GLOBALS[TB_POLL].id
                                          AND $GLOBALS[TB_POLL].id='$HTTP_GET_VARS[poll_id]'");
                 while ($Daten = mysql_fetch_array($result)) {
                        //Poll - Benutzer l�schen
                        mysql_query("DELETE FROM $GLOBALS[TB_POLL_USER] WHERE $GLOBALS[TB_POLL_USER].text_id='$Daten[id]'");
                        //Poll - Texte l�schen
                        mysql_query("DELETE FROM $GLOBALS[TB_POLL_TEXT] WHERE $GLOBALS[TB_POLL_TEXT].id='$Daten[id]'");
                 }
                 ### Update
                 mysql_query("UPDATE $GLOBALS[TB_POLL] SET name='$HTTP_POST_VARS[name]', date='$date' WHERE id='$HTTP_GET_VARS[poll_id]'");
                 while (list($id, $val) = each($polls)) {
                        mysql_query("INSERT INTO $GLOBALS[TB_POLL_TEXT] (poll_id, text)
                                     VALUES ('$HTTP_GET_VARS[poll_id]','$val')");
                 }
                 msg("poll_edit", "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$HTTP_GET_VARS[Topic_id]&goto=lastpost");
             }
         }
         footer();
}
##################### poll_addedit ##################### ---
#
#
##################### poll_adv ##################### +++
function poll_adv($id) {
         global $HTTP_POST_VARS;
         ### Umfragen l�schen
         if ($HTTP_POST_VARS[del] == "on") {
             $result = mysql_query("SELECT $GLOBALS[TB_POLL].id, $GLOBALS[TB_POLL_TEXT].id AS text_id
                                    FROM $GLOBALS[TB_POLL], $GLOBALS[TB_POLL_TEXT]
                                    WHERE $GLOBALS[TB_POLL].id='$id'
                                      AND $GLOBALS[TB_POLL_TEXT].poll_id=$GLOBALS[TB_POLL].id");
             while ($poll = mysql_fetch_array($result)) {
                //Poll - Benutzer l�schen
                mysql_query("DELETE FROM $GLOBALS[TB_POLL_USER] WHERE $GLOBALS[TB_POLL_USER].text_id='$poll[text_id]'");
                //Poll - Texte l�schen
                mysql_query("DELETE FROM $GLOBALS[TB_POLL_TEXT] WHERE $GLOBALS[TB_POLL_TEXT].id='$poll[text_id]'");
             }
             //Poll l�schen
             mysql_query("DELETE FROM $GLOBALS[TB_POLL] WHERE $GLOBALS[TB_POLL].id='$id'");

         ### Umfrage schlie�en
         } elseif ($HTTP_POST_VARS[close] == "on") {
             mysql_query("UPDATE $GLOBALS[TB_POLL] SET $GLOBALS[TB_POLL].date=CURDATE()-1 WHERE $GLOBALS[TB_POLL].id='$id'");
         }
         msg("poll_edit", "2","showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$HTTP_POST_VARS[Topic_id]&goto=lastpost");
}
##################### poll_adv ##################### ---
?>