<?php
$COLOR_TB_BACK = "#000000";
$COLOR_GROUP = "#bbbbbb";
$COLOR_ENTRIE = "#FFFFFF";
$COLOR_ENTRIE_dark = "#f1f1f1";
$COLOR_TEXT = "#000000";
$COLOR_TB_BACK = "#000000";
$COLOR_TEXT_TITLE = "#FFFFFF";
$COLOR_TITLE = "#666666";
$FONT_FACE = "verdana,arial,helvetica";
$COLOR_BACK = "white";
$FONT_SIZE_COMMENT = "1";
$FONT_SIZE_TITLE = "2";
$FONT_SIZE = "2";

@set_time_limit(0);

switch ($HTTP_GET_VARS[step]) {
        case "":
              head("Start");
              inst_start();
              break;

        case "1":
              head("phpForum - config.inc.php aktualisieren");
              inst_config_update();
              break;

        case "2":
              head("phpForum - Datenbank aktualisieren");
              inst_update();
              break;

        case "3":
              head("phpForum - Forum aktualisieren");
              inst_update_forum();
              break;

        case "final":
              head("Fertig");
              inst_final();
              break;
}
#
#
################################################################################
############################## Installation #################################### +++
################################################################################
#
#
##################### Installation (Start) ##################### +++
function inst_start() {
         include("../config.inc.php");
         $no_vars = "on";
         include("$MAIN_PATH/config.php");
         global $HTTP_SERVER_VARS;

         if (!db_connect()) {
             msg("Es konnte keine Verbindung zum <b>mySQL-Server</b> aufgebaut werden, &uuml;berpr&uuml;fen sie die <b>config.inc.php</b> und Versuchen sie es erneut.", "", "$HTTP_SERVER_VARS[PHP_SELF]");
         }
         //schon aktuell !!!
         if (ereg("RC1$", $VER) == TRUE) {
             msg("Die installierte Version ($VER) vom <b>phpForum</b> ist bereits die zu installierende Version.");
         }
         //nicht aktuell genug ???
         if (ereg("20020621$", $VER) == FALSE) {
             msg("Die installierte Version ($VER) vom <b>phpForum</b> ist nicht aktuell genug, sie ben�tigen die Version: 20020526. (<a href='http://phpforum.ath.cx/'>Download</a>)");
         }

         echo "<form method='post' action='$HTTP_SERVER_VARS[PHP_SELF]?step=1'>";
         table_header("phpForum Update", "100%", "1", "colspan='2'");
         table_header("aktuelle Installation", "100%", "", "colspan='2'", "nohead"); ?>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Version:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Wenn einer dieser Daten fehlerhat ist bitte die "config.inc.php" bearbeiten
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <?php echo $VER; ?>
                       </font>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Server:</b>
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <?php echo $DOMAIN; ?>
                       </font>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>System-Pfad:</b>
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <?php echo $MAIN_PATH; ?>
                       </font>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Server-URL:</b>
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <?php echo $SITE; ?>
                       </font>
                   </td>
               </tr>
         <?php table_header("Datenbank", "100%", "", "colspan='2'", "nohead"); ?>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Tabellen-Pr&auml;fix:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Wenn sie bereits Tabellen mit gleichen Namen in ihrer Datenbank besitzen, k&ouml;nnen sie hiermit jeder Tabelle einen Pr�fix voranstellen.
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='praefix' size='30'>
                   </td>
               </tr>
         <?php table_header("Administrator", "100%", "", "colspan='2'", "nohead"); ?>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Benutzername:</b>
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <select name='user_id'>
                               <?php
                               $result = mysql_query("SELECT $TB_USER.name, $TB_USER.id
                                                      FROM $TB_ACCESS, $TB_USER
                                                      WHERE $TB_USER.access_id=$TB_ACCESS.id
                                                        AND $TB_ACCESS.admin_settings='on'");
                               while($Daten = mysql_fetch_array($result)) {
                                     echo "<option value='$Daten[id]'>$Daten[name]";
                               }
                               ?>
                       </select>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Passwort:</b>
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='password' name='user_pass' size='30' MAXLENGTH='32'>
                   </td>
               </tr>
         </table>
         <p></p>
         <center>
                 <input type='submit' value='phpForum update'>
         </center>
         </form>
         <?php
}
##################### Installation (Start) ##################### ---
#
#
##################### Installation (Config-Update) ##################### +++
function inst_config_update() {
         include("../config.inc.php");
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         //DB-Server Verbindung aufbauen
         if (!db_connect()) {
             msg("Es konnte keine Verbindung zum <b>mySQL-Server</b> aufgebaut werden, &uuml;berpr&uuml;fen sie die <b>config.inc.php</b> und Versuchen sie es erneut.", "", "$HTTP_SERVER_VARS[PHP_SELF]");
         //Server Daten OK !!!
         } else {

             //Passowort OK ?
             $HTTP_POST_VARS[user_pass] = md5($HTTP_POST_VARS[user_pass]);
             if (@mysql_num_rows(@mysql_query("SELECT *
                                               FROM $TB_USER
                                               WHERE id='$HTTP_POST_VARS[user_id]'
                                                 AND pass='$HTTP_POST_VARS[user_pass]'")) != 1) {
                 msg("Sie haben keine Rechte dieses Update durchzuf�hren oder ihr Passwort ist falsch.", "2", "back()");
             }

                  //kann Datei �ffnen ???
                  if ($fp = @fopen("$MAIN_PATH/config.inc.php", "a")) {
                      @fwrite($fp, "\n<?php\n");
                      @fwrite($fp, "\$TB_STYLES = \"$HTTP_POST_VARS[praefix]styles\";                                //Foren-Styles\n");
                      @fwrite($fp, "?>");
                      @fclose($fp);
                      msg("Die Konfigurations-Datei <b>config.inc.php</b> wurde gespeichert.", "2", "$HTTP_SERVER_VARS[PHP_SELF]?step=2");
                  //Fehler beim �ffnen !!!
                  } else {
                      open_table("phpForum Mitteilung", "60%"); ?>
                           Die Konfigurations-Datei <b>config.inc.php</b> konnte nicht ge&auml;ndert werden, &auml;ndern sie die Rechte (chmod) dieser Datei.
                           <table align='center'>
                                  <tr>
                                      <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                                            <input type='hidden' name='step' value='1'>
                                            <td>
                                                <input type='submit' value='Erneut versuchen'>
                                            </td>
                                      </form>
                                  </tr>
                           </table>
                           <?php
                      close_table("W�hlen sie \"Erneut versuchen\" wenn sie die Rechte der config.inc.php ge&auml; haben.");
                  }
         }
}
##################### Installation (Config-Update) ##################### ---
#
#
##################### Installation (Tabellen Inserts) ##################### +++
function inst_update() {
         include("../config.inc.php");

         $no_vars = "on";
         include("$MAIN_PATH/config.php");
         global $HTTP_SERVER_VARS, $HTTP_POST_VARS;
         $faults = 0;
         if (!db_connect()) {
             msg("Es konnte keine Verbindung zum <b>mySQL-Server</b> aufgebaut werden, &uuml;berpr&uuml;fen sie die <b>config.inc.php</b> und Versuchen sie es erneut.", "5", "$HTTP_SERVER_VARS[PHP_SELF]");
         }
         open_table("Update von Version: $VER", "100%");
              echo "<ul>";
              //datenbank update (feste SQL-Statements)
              $sql = sql($VER);
              while (list($key,$values) = each($sql)) {
                     echo "<li>Datenbank-Update von Version: $key";
                     echo "<ul>";
                     while (list($id,$query) = each($values)) {

                            if (@mysql_query($query[1])) {
                                echo "<li><b>$query[0]</b> erfolgreich";
                            } else {
                                echo "<li><b>$key[0]</b><font color='red'>nicht erfolgreich !</font>";
                                $Fehler = "on";
                            }
                     }
                     echo "</ul>";
              }

              echo "</ul>";
              //Update erfolgreich !?
              if ($faults == 0) {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='3'>
                        <center>
                                <input type='submit' value='weiter'>
                        </center>
                  </form>
                  <?php
              } else {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='2'>
                        <center>
                                <input type='submit' value='erneut versuchen'>
                        </center>
                  </form>
                  <?php
              }
         close_table();
}
##################### Installation (Tabellen Inserts) ##################### ---
#
#
##################### Installation (Forum Update) ##################### +++
function inst_update_forum() {
         include("../config.inc.php");
         $no_vars = "on";
         include("$MAIN_PATH/config.php");
         global $HTTP_SERVER_VARS, $HTTP_POST_VARS;
         $faults = 0;
         if (!db_connect()) {
             msg("Es konnte keine Verbindung zum <b>mySQL-Server</b> aufgebaut werden, &uuml;berpr&uuml;fen sie die <b>config.inc.php</b> und Versuchen sie es erneut.", "5", "$HTTP_SERVER_VARS[PHP_SELF]");
         }
         open_table("Update von Version: $VER", "100%");
              echo "<ul>";

              ### Foren Updaten
              $result_forum = mysql_query("SELECT id, name FROM $TB_FORUM");
              while ($Daten_forum = mysql_fetch_array($result_forum)) {
                     echo "<li>Update von Forum: <b>$Daten_forum[name]</b>";
                     echo "<ul>";
                     $ges_posts = 0;
                     $ges_topics = 0;
                     //Topics...
                     $result_topic = mysql_query("SELECT id FROM $TB_TOPIC WHERE forum_id='$Daten_forum[id]'");
                     while ($Daten_topic = mysql_fetch_array($result_topic)) {
                            //Posts (dieses Topics)
                            $topic_posts = mysql_num_rows(mysql_query("SELECT id FROM $TB_POST WHERE topic_id='$Daten_topic[id]'"));
                            $ges_posts = $ges_posts + $topic_posts;
                            $ges_topics++;
                            if (!@mysql_query("UPDATE $TB_TOPIC SET posts=$topic_posts-1 WHERE id='$Daten_topic[id]'")) {
                                $faults++;
                            }
                     }

                     $last_topic = mysql_fetch_array(mysql_query("SELECT id, name FROM $TB_TOPIC WHERE forum_id='$Daten_forum[id]' ORDER BY post_date DESC LIMIT 0,1"));
                     if (!@mysql_query("UPDATE $TB_FORUM SET posts='$ges_posts', topics='$ges_topics', last_topic='$last_topic[id]' WHERE id='$Daten_forum[id]'")) {
                         $faults++;
                     }

                     echo "<li>Themen: $ges_topics";
                     echo "<li>Beitr&auml;ge: $ges_posts";
                     echo "<li>letztes Thema: $last_topic[name]";
                     echo "</ul>";
              }
              echo "</ul>";
              //Update erfolgreich !?
              if ($faults == 0) {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='final'>
                        <center>
                                <input type='submit' value='weiter'>
                        </center>
                  </form>
                  <?php
              } else {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='3'>
                        <center>
                                <input type='submit' value='erneut versuchen'>
                        </center>
                  </form>
                  <?php
              }
         close_table();
}
##################### Installation (Forum Update) ##################### ---
#
#
##################### Installation (Fertigstellen) ##################### +++
function inst_final() {
         include("../config.inc.php");

         open_table("Installation (Fertig)", "100%");
                  echo "<center>Das Update vom phpForum ist nun Abgeschlossen.<br>
                                Kopieren sie nun noch die restlichen Dateien (siehe README.TXT)<br>
                                <font color='red'>
                                      L&ouml;schen sie den <u>gesamten</u> Ordner \"update\" !!!
                                </font>
                                <br>
                                Wenn sie dies getan haben k�nnen sie �ber <a href='../index.php'>diesen Link</a> auf die Startseite gelangen.
                       </center>";
         close_table();
}
##################### Installation (Fertigstellen) ##################### ---
#
#
################################################################################
############################## Installation #################################### ---
################################################################################
#
################################################################################
############################## Funktionen #################################### +++
################################################################################
#
#

function db_connect() {
         include("../config.inc.php");
         //zum Server verbinden
         if (@mysql_connect ($DB_SERVER, $DB_USER, $DB_PASS)) {
             //DB ausw�hlen
             if (@mysql_select_db ($DB_NAME)) {
                 return TRUE;

             //DB konnte nicht ausgew�hlt werden !!!
             } else {
                 return FALSE;
             }
         //konnte nicht zum Server verbinden !!!
         } else {
             return FALSE;
         }
}
#
#
##################### Open - Table (standard-tabelle) ##################### +++
function head($step="") {
         global $COLOR_TB_BACK, $COLOR_GROUP,$COLOR_ENTRIE, $COLOR_ENTRIE_dark, $COLOR_TEXT, $COLOR_TB_BACK, $COLOR_TEXT_TITLE, $COLOR_TITLE, $FONT_FACE, $COLOR_BACK, $FONT_SIZE_COMMENT, $FONT_SIZE_TITLE, $_SERVER;
         ?>
         <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
         <HTML>
         <BODY bgcolor='<?php echo $COLOR_BACK; ?>'>
               <img src='../admin/phpForum.jpg' border='0'>
               <table width='100%' cellpadding='0' cellspacing='0' border='0' align='center'>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_TB_BACK; ?>' height='1'></td>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_GROUP; ?>' height='4'></td>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_TITLE; ?>' height='10'>
                              <font size='<?php echo $FONT_SIZE_TITLE; ?>' color='<?php echo $COLOR_TEXT_TITLE; ?>'>
                                    <b><?php
                                    if ($step == "") {
                                        echo "phpForum - Update";
                                    } else {
                                        echo "phpForum - Update (".$step.")";
                                    } ?></b>
                              </font>
                          </td>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_GROUP; ?>' height='4'></td>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_TB_BACK; ?>' height='1'></td>
                      </tr>
               </table>
               <br><br>
               <?php
}
#
#
##################### Open - Table (standard-tabelle) ##################### +++
function open_table($msg, $width) {
         global $COLOR_TB_BACK, $COLOR_GROUP,$COLOR_ENTRIE, $COLOR_ENTRIE_dark, $COLOR_TEXT, $COLOR_TB_BACK, $COLOR_TEXT_TITLE, $COLOR_TITLE, $FONT_FACE, $COLOR_BACK, $FONT_SIZE_COMMENT, $FONT_SIZE_TITLE, $_SERVER;
         ?>
         <table border="0" bgcolor="<?php echo $GLOBALS[COLOR_TB_BACK]; ?>" cellpadding="4" cellspacing="1" align='center' width='<?php echo $width; ?>'>
                <tr bgcolor='<?php echo $GLOBALS[COLOR_TITLE]; ?>'>
                    <td width='100%' align='left'>
                        <FONT SIZE='<?php echo $GLOBALS[FONT_SIZE_TITLE]; ?>' FACE='<?php echo $GLOBALS[FONT_FACE]; ?>' COLOR='<?php echo $GLOBALS[COLOR_TEXT_TITLE]; ?>'>
                              <b><?php echo $msg; ?></b>
                        </font>
                    </td>
                </tr>
                <tr>
                    <td align='left' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                        <FONT SIZE='<?php echo $GLOBALS[FONT_SIZE]; ?>' FACE='<?php echo $GLOBALS[FONT_FACE]; ?>' COLOR='<?php echo $GLOBALS[COLOR_TEXT]; ?>'>
         <?php
}
##################### Open - Table (standard-tabelle) ##################### ---
#
#
##################### Close - Table (standard-tabelle) ##################### +++
function close_table($msg="") {
         ?>
                        </font>
                        <?php if ($msg != "") {
                            echo "<p><FONT SIZE='$GLOBALS[FONT_SIZE_COMMENT]'>$msg</font></p>";
                        }
                        ?>
                    </td>
                </tr>
         </table>
<?php
}
##################### Close - Table (standard-tabelle) ##################### ---
#
#
##################### Table-Header ##################### +++
function table_header($text, $width, $typ="", $extra="", $no_head="") {
         if ($no_head == "") {
             ?>
             <table border='0' bgcolor='<?php echo $GLOBALS[COLOR_TB_BACK]; ?>' cellpadding='2' cellspacing='1' width='<?php echo $width; ?>' align='center'>
             <?php
         }
         ?>
                <tr bgcolor='<?php
                    if ($typ == "") {
                        echo $GLOBALS[COLOR_GROUP];
                    } elseif ($typ == "1") {
                        echo $GLOBALS[COLOR_TITLE];
                    }
                    ?>'>
                    <td width='100%' align='left' <?php echo $extra; ?>>
                        <FONT SIZE='<?php echo $GLOBALS[FONT_SIZE_TITLE]; ?>' FACE='<?php echo $GLOBALS[FONT_FACE]; ?>' COLOR='<?php
                              if ($typ == "") {
                                  echo $GLOBALS[COLOR_TEXT];
                              } elseif ($typ == "1") {
                                  echo $GLOBALS[COLOR_TEXT_TITLE];
                              }
                              ?>'>
                              <b>
                                 <?php echo $text; ?>
                              </b>
                        </font>
                    </td>
                </tr>
         <?php
}
##################### Table-Header ##################### ---
#
#
##################### Forum Msg�s ##################### +++
function msg($text, $time="", $goto="") {

         //wenn kein php? dann php? ran h�ngen
         if ($goto == "back()") {
             $goto="javascript:history.back()";
         }
         echo "<br>";
         open_table("phpForum - Mitteilung","60%");

                     echo "<FONT SIZE='$GLOBALS[FONT_SIZE]'>$text</font>";
                     if ($goto != "") {
                         echo "<p align='center'>
                                  <a href='$goto'>
                                     <FONT SIZE='$GLOBALS[FONT_SIZE_COMMENT]'>
                                           Klicken sie hier, wenn sie nicht l&auml;nger warten wollen.<br>
                                           (oder wenn ihr Browser keine automatische Weiterleitung unterst&uuml;tzt)
                                     </font>
                                  </a>
                               </p>";
                     }
         close_table("");
         echo "<br>";
         //wenn goto �bergeben dann gehe dahin nach Zeit "time"
         if ($goto != "") {
             echo "<meta http-equiv='Refresh' content='$time;URL=$goto'>";
         }
         exit();
}
##################### Forum Msg�s ##################### ---
#
#
################################################################################
################################ Funktionen #################################### ---
################################################################################
#
#
################################################################################
############################### SQL-Query�s #################################### +++
################################################################################
function sql ($version) {
         include("../config.inc.php");
         include("../config.php");

         //dies ist die aktuell Installierte Version !!!
         switch($version) {

                case "Beta 2 Build 20020621":
                      $query["Beta 2 Build 20020621"] = array(
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (93, 7, 'MEMBERS_SORT', 'name', 'Standard-Sortierung in der Member-Liste', 'name = Benutzername<br>\r\nreg = Registrations<br>\r\npoints = Beitr�ge', 'select', 'name,reg,points');"),
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (94, 7, 'MEMBERS_ORDER', 'ASC', 'Sortier-Reihenfolge in der Member-Liste', 'ASC = Aufw&auml;hrts<br>\r\nDESC = Abw&auml;hrts', 'select', 'ASC,DESC');"),
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (96, 3, 'REG_NEW', 'on', 'Registrierungen erlauben?', 'W&auml;hlen sie hier nein wenn sich im Moment keine weiteren Benutzer im Forum registrieren d&uuml;rfen.', 'radio', '');"),
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (98, 3, 'REG_NEW_TEXT', 'Die Registrierung ist zur Zeit nicht m�glich...', 'Begr&uuml;ndung f&uuml;r Registrierungs-Stop', 'Begr�nden sie hier warum sie im Moment keine weiteren Registrierungen erlauben.', 'textarea', '');"),
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (99, 6, 'COOKIE_DOMAIN', '/', 'Cookie Pfad', 'Wenn sie mehrere phpForen auf dem selben Server / Dom�ne betreiben, m�ssen sie das relative Verzeichnisse des Boards angeben. Sonst lassen sie einfach \'/\' stehen.', 'text', '');"),
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (100, 13, 'BANNED_IP', '', 'Verbotene IP-Adressen', 'Tragen sie hier die IPs ein die keinen Zugriff auf das Forum haben sollen.<br>\r\nUm eine einzelne IP zu sperren geben sie diese vollst&auml;ndig ein, z.B. 192.168.0.1<br>\r\nUm einen Bereich von IPs zu sperren geben sie nur den Anfang der IP ein, z.B. 192.168.0<br><b>Pro Zeile nur eine IP!</b>', 'textarea', '');"),
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (101, 13, 'BANNED_NAMES', '', 'Verbotene Benutzernamen', 'Geben sie hier Benutzernamen ein, die f�r eine Registrierung unzul�ssig sind. Wenn der hier eingegebene Name ein Bestandteil des Benutzernamens ist, bekommt der Benutzer eine Fehlermeldung bei der Registrierung.<br><b>Pro Zeile nur ein Benutzername!</b>', 'textarea', '');"),
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (102, 1, 'CLOSED_BOARD', '', 'Forum geschlossen?', 'W&auml;hlen sie hier ja um das Forum Zeitweise f�r nicht Administratoren zu schliessen. Dies ist besonders f�r Foren-Updates zu empfehlen!', 'radio', '');"),
                                     array("neue Einstellung f&uuml;r den Admin hinzuf&uuml;gen - ", "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (103, 1, 'CLOSED_BOARD_TEXT', 'Das Forum ist Zeitweise geschlossen, da momentan die Foren-Software aktualisiert wird.<br>Bitte versuchen sie es sp�ter noch einmal.', 'Forum geschlossen - Begr&uuml;ndung', 'Hier k&ouml;nnen sie eine Begr&uuml;ndung f&uuml;r das geschlossene Forum angeben, diese wird den Besuchern f&uuml;r die Zeit der Schlie&szlig;ung angezeigt.', 'textarea', '');"),
                                     array("neue Gruppe zu den Einstellungen hinzugef&uuml;gen - ", "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (13, 'Zugriffskontrolle / Sicherheit');"),
                                     array("alte Einstellungen f&uuml;r den Admin l&ouml;schen - ", "DELETE FROM $TB_SETTINGS WHERE (id >= '15' AND id <= '32') OR (id='37') OR (id >= '40' AND id <= '42') OR (id = '44') OR (id = '50') OR (id >= '66' AND id <= '85')"),
                                     array("alte Gruppe f&uuml; die Einstellungen l&ouml;schen - ", "DELETE FROM $TB_SETTING_GROUP WHERE id='4' OR id='5' OR id='8' OR id='9'"),
                                     array("Tabelle $TB_CAT aktualisieren - ", "ALTER TABLE $TB_CAT MODIFY rang int(11) NULL"),
                                     array("Tabelle $TB_FORUM aktualisieren - ", "ALTER TABLE $TB_FORUM ADD topics int(11) NOT NULL, ADD posts int(11) NOT NULL, ADD last_topic int(11) NOT NULL"),
                                     array("Tabelle $TB_TOPIC aktualisieren - ", "ALTER TABLE $TB_TOPIC ADD top int(1) NOT NULL, ADD posts int(11) NOT NULL, MODIFY name varchar(100) NOT NULL"),
                                     array("Tabelle $TB_POST aktualisieren - ", "ALTER TABLE $TB_POST ADD ip varchar(15) NOT NULL"),
                                     array("Tabelle $TB_USER aktualisieren - ", "ALTER TABLE $TB_USER ADD style int(11) NOT NULL"),
                                     array("Tabelle $TB_ACCESS aktualisieren - ", "ALTER TABLE $TB_ACCESS ADD avatar char(2) NOT NULL, ADD mod_move_post char(2) NOT NULL, ADD mod_top char(2) NOT NULL, ADD admin_styles char(2) NOT NULL, CHANGE mod_move mod_move_topic char(2) NOT NULL"),
                                     array("Tabelle $TB_FORUM_ACCESS aktualisieren - ", "ALTER TABLE $TB_FORUM_ACCESS ADD mod_move_post char(2) NOT NULL, ADD mod_top char(2) NOT NULL, CHANGE mod_move mod_move_topic char(2) NOT NULL"),
                                     array("Tabelle $TB_MOD aktualisieren - ", "ALTER TABLE $TB_MOD ADD mod_move_post char(2) NOT NULL, ADD mod_top char(2) NOT NULL, CHANGE mod_move mod_move_topic char(2) NOT NULL"),
                                     array("Tabelle $TB_STYLES erstellen - ", "CREATE TABLE $TB_STYLES (
                                                                                      id int(11) NOT NULL auto_increment,
                                                                                      name varchar(50) NOT NULL default '',
                                                                                      active char(2) NOT NULL default '',
                                                                                      choice char(2) NOT NULL default 'on',
                                                                                      head_insert text NOT NULL,
                                                                                      header text NOT NULL,
                                                                                      footer text NOT NULL,
                                                                                      html_type varchar(255) NOT NULL default '',
                                                                                      body_extra varchar(255) NOT NULL default '',
                                                                                      textarea_width tinyint(4) NOT NULL default '0',
                                                                                      textarea_height tinyint(4) NOT NULL default '0',
                                                                                      default_table text NOT NULL,
                                                                                      default_tr text NOT NULL,
                                                                                      cat_table text NOT NULL,
                                                                                      cat_tr text NOT NULL,
                                                                                      table_inset text NOT NULL,
                                                                                      font_big text NOT NULL,
                                                                                      font_normal text NOT NULL,
                                                                                      font_small text NOT NULL,
                                                                                      font_fault text NOT NULL,
                                                                                      cat_one text NOT NULL,
                                                                                      cat_two text NOT NULL,
                                                                                      pic_last_post varchar(255) NOT NULL default '',
                                                                                      pic_new_post varchar(255) NOT NULL default '',
                                                                                      pic_new_topic varchar(255) NOT NULL default '',
                                                                                      pic_topic_abo varchar(255) NOT NULL default '',
                                                                                      pic_closed varchar(255) NOT NULL default '',
                                                                                      pic_pm_new varchar(255) NOT NULL default '',
                                                                                      pic_pm_readall varchar(255) NOT NULL default '',
                                                                                      pic_pm_delall varchar(255) NOT NULL default '',
                                                                                      pic_pm_reply varchar(255) NOT NULL default '',
                                                                                      pic_profile varchar(255) NOT NULL default '',
                                                                                      pic_pm varchar(255) NOT NULL default '',
                                                                                      pic_home varchar(255) NOT NULL default '',
                                                                                      pic_mail varchar(255) NOT NULL default '',
                                                                                      pic_search varchar(255) NOT NULL default '',
                                                                                      pic_quote varchar(255) NOT NULL default '',
                                                                                      pic_edit varchar(255) NOT NULL default '',
                                                                                      pic_ip varchar(255) NOT NULL default '',
                                                                                      pic_on varchar(255) NOT NULL default '',
                                                                                      pic_on_lock varchar(255) NOT NULL default '',
                                                                                      pic_off varchar(255) NOT NULL default '',
                                                                                      pic_off_lock varchar(255) NOT NULL default '',
                                                                                      pic_post_on varchar(255) NOT NULL default '',
                                                                                      pic_post_off varchar(255) NOT NULL default '',
                                                                                      pic_file varchar(255) NOT NULL default '',
                                                                                      pic_pm_status varchar(255) NOT NULL default '',
                                                                                      pic_admin_up varchar(255) NOT NULL default '',
                                                                                      pic_admin_down varchar(255) NOT NULL default '',
                                                                                      pic_admin_del varchar(255) NOT NULL default '',
                                                                                      pic_poll_l varchar(255) NOT NULL default '',
                                                                                      pic_poll_m varchar(255) NOT NULL default '',
                                                                                      pic_poll_r varchar(255) NOT NULL default '',
                                                                                      PRIMARY KEY (id)
                                                                               ) TYPE=MyISAM;"),
                                     array("Foren-Style hinzuf&uuml;gen - ", "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (1, 'phpForum.ath.cx - new', 'on', 'on', '/* Text-Allgemein */\r\n#all A:active { color: #333399; text-decoration: none; }\r\n#all A:visited { color: #333399; text-decoration: none; }\r\n#all A:hover { color: #ff0000; text-decoration: underline; }\r\n#all A:link { color: #333399; text-decoration: none; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { color: #ffffff; text-decoration: underline; }\r\n#nav A:visited { color: #ffffff; text-decoration: none; }\r\n#nav A:hover { color: #ff2222; text-decoration: underline overline; background-color:transparent; }\r\n#nav A:link { color: #ffffff; text-decoration: none; }\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: #FFFFFF;\r\n  font-family: verdana,arial,helvetica;\r\n  font-size: medium;\r\n  color: #000000;\r\n  scrollbar-face-color: #666666;\r\n  scrollbar-arrow-color: #ffffff;\r\n  scrollbar-base-color: #cccccc;\r\n  scrollbar-3d-light-color: #cccccc;\r\n  scrollbar-darkshadow-color: #cccccc;\r\n  scrollbar-highlight-color: #000000;\r\n  scrollbar-shadow-color: #cccccc;\r\n  scrollbar-track-color: #cccccc;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: white;\r\n   border-bottom: black 1px solid;\r\n   border-left: black 1px solid;\r\n   border-right: black 1px solid;\r\n   border-top: black 1px solid;\r\n}', '<div align=\'left\'><img src=\'images/title.jpg\' border=\'0\'></div>\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'#666666\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: #000000;', 'background-color: #666666;\r\ncolor: #ffffff;\r\nfont-size: x-small;', 'background-color: #000000;', 'background-color: #bbbbbb;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: #ffffff;\r\nfont-size: x-small;\r\ncolor: #000000;', 'background-color: #f1f1f1;\r\nfont-size: x-small;\r\ncolor: #000000;', 'images/last_post.gif', 'images/2_newpost.jpg', 'images/2_newtopic.jpg', 'images/abo.jpg', 'images/2_closed.jpg', 'images/2_pm_new.jpg', 'images/2_pm_readall.jpg', 'images/2_pm_delall.jpg', 'images/2_pm_reply.jpg', 'images/2_profile.jpg', 'images/2_pm.jpg', 'images/2_www.jpg', 'images/2_email.jpg', 'images/2_search.jpg', 'images/2_quote.jpg', 'images/2_edit_delete.jpg', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip.jpg');"),
                                     array("Foren-Style hinzuf&uuml;gen - ", "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (2, 'phpForum.ath.cx - old', '', 'on', '/* Text-Allgemein */\r\n#all A:active { color: #333399; text-decoration: none; }\r\n#all A:visited { color: #333399; text-decoration: none; }\r\n#all A:hover { color: #ff0000; text-decoration: underline; }\r\n#all A:link { color: #333399; text-decoration: none; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { color: #ffffff; text-decoration: underline; }\r\n#nav A:visited { color: #ffffff; text-decoration: none; }\r\n#nav A:hover { color: #ff2222; text-decoration: underline overline; background-color:transparent; }\r\n#nav A:link { color: #ffffff; text-decoration: none; }\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: #FFFFFF;\r\n  font-family: verdana,arial,helvetica;\r\n  font-size: medium;\r\n  color: #000000;\r\n  scrollbar-face-color: #666666;\r\n  scrollbar-arrow-color: #ffffff;\r\n  scrollbar-base-color: #cccccc;\r\n  scrollbar-3d-light-color: #cccccc;\r\n  scrollbar-darkshadow-color: #cccccc;\r\n  scrollbar-highlight-color: #000000;\r\n  scrollbar-shadow-color: #cccccc;\r\n  scrollbar-track-color: #cccccc;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: white;\r\n   border-bottom: black 1px solid;\r\n   border-left: black 1px solid;\r\n   border-right: black 1px solid;\r\n   border-top: black 1px solid;\r\n}', '<div align=\'left\'><img src=\'images/title.jpg\' border=\'0\'></div>\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'#666666\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: #000000;', 'background-color: #666666;\r\ncolor: #ffffff;\r\nfont-size: x-small;', 'background-color: #000000;', 'background-color: #bbbbbb;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: #ffffff;\r\nfont-size: x-small;\r\ncolor: #000000;', 'background-color: #f1f1f1;\r\nfont-size: x-small;\r\ncolor: #000000;', 'images/last_post.gif', 'images/newpost.jpg', 'images/newtopic.jpg', 'images/abo.jpg', 'images/closed.jpg', 'images/newpm.jpg', 'images/readall.jpg', 'images/delpm.jpg', 'images/replypm.jpg', 'images/profile.gif', 'images/pm.gif', 'images/home.gif', 'images/email.gif', 'images/search.gif', 'images/quote.gif', 'images/edit.gif', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip_old.jpg');"),
                                     array("Foren-Style hinzuf&uuml;gen - ", "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (3, '$TITEL_KURZ', '', 'on', '/* Text-Allgemein */\r\n#all A:active { color: $HL_TEXT_ALL_ACTIVE; text-decoration: $HL_STYLE_ALL_ACTIVE; }\r\n#all A:visited { color: $HL_TEXT_ALL_VISIT; text-decoration: $HL_STYLE_ALL_VISIT; }\r\n#all A:hover { color: $HL_TEXT_ALL_HOVER; text-decoration: $HL_STYLE_ALL_HOVER; }\r\n#all A:link { color: $HL_TEXT_ALL_LINK; text-decoration: $HL_STYLE_ALL_LINK; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { color: $HL_TEXT_NAV_ACTIV; text-decoration: $HL_STYLE_NAV_ACTIVE; }\r\n#nav A:visited { color: $HL_TEXT_NAV_VISIT ; text-decoration: $HL_STYLE_NAV_VISIT; }\r\n#nav A:hover { color: $HL_TEXT_NAV_HOVER; text-decoration: $HL_STYLE_NAV_HOVER; background-color:transparent; }\r\n#nav A:link { color: $HL_TEXT_NAV_LINK; text-decoration: $HL_STYLE_NAV_LINK; }\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: $COLOR_BACK;\r\n  font-family: $FONT_FACE;\r\n  font-size: medium;\r\n  color: $COLOR_TEXT;\r\n  scrollbar-face-color: $SCROLL_TOP;\r\n  scrollbar-arrow-color: $SCROLL_ARROW;\r\n  scrollbar-base-color: $SCROLL_BASE;\r\n  scrollbar-3d-light-color: $SCROLL_3D;\r\n  scrollbar-darkshadow-color: $SCROLL_SHADOW_DARK;\r\n  scrollbar-highlight-color: $SCROLL_KLICK;\r\n  scrollbar-shadow-color: $SCROLL_SHADOW;\r\n  scrollbar-track-color: $SCROLL_RAND;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: $STYLE_BG;\r\n   border-bottom: $STYLE_RAND $STYLE_RAND_PX solid;\r\n   border-left: $STYLE_RAND $STYLE_RAND_PX solid;\r\n   border-right: $STYLE_RAND $STYLE_RAND_PX solid;\r\n   border-top: $STYLE_RAND $STYLE_RAND_PX solid;\r\n}', '".addslashes($HEADER)."\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'$COLOR_GROUP\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'$COLOR_TITLE\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'$COLOR_GROUP\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: $COLOR_TB_BACK;', 'background-color: $COLOR_TITLE;\r\ncolor: $COLOR_TEXT_TITLE;\r\nfont-size: x-small;', 'background-color: $COLOR_TB_BACK;', 'background-color: $COLOR_GROUP;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: $COLOR_ENTRIE;\r\nfont-size: x-small;\r\ncolor: $COLOR_TEXT;', 'background-color: $COLOR_ENTRIE_dark;\r\nfont-size: x-small;\r\ncolor: $COLOR_TEXT;', 'images/last_post.gif', 'images/newpost.jpg', 'images/newtopic.jpg', 'images/abo.jpg', 'images/closed.jpg', 'images/newpm.jpg', 'images/readall.jpg', 'images/delpm.jpg', 'images/replypm.jpg', 'images/profile.gif', 'images/pm.gif', 'images/home.gif', 'images/email.gif', 'images/search.gif', 'images/quote.gif', 'images/edit.gif', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip_old.gif');"),
                                     array("Foren-Style hinzuf&uuml;gen - ", "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (4, 'dark', '', 'on', '/* Text-Allgemein */\r\n#all A:active { COLOR: #FFD700; text-decoration: none; }\r\n#all A:visited { COLOR: #FFD700; text-decoration: none; }\r\n#all A:hover { COLOR: #FFFFFF; text-decoration: underline; }\r\n#all A:link { COLOR: #FFD700; text-decoration: none; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { COLOR: #FFD700; text-decoration: underline; }\r\n#nav A:visited { COLOR: #FFD700; text-decoration: none; }\r\n#nav A:hover { COLOR: #FFFFFF; text-decoration: underline; background-color:transparent; }\r\n#nav A:link { COLOR: #FFD700; text-decoration: none; }\r\n\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: #000000;\r\n  font-family: verdana,arial,helvetica;\r\n  font-size: medium;\r\n  color: #ffffff;\r\n  scrollbar-face-color: #666666;\r\n  scrollbar-arrow-color: #ffffff;\r\n  scrollbar-base-color: #cccccc;\r\n  scrollbar-3d-light-color: #cccccc;\r\n  scrollbar-darkshadow-color: #cccccc;\r\n  scrollbar-highlight-color: #000000;\r\n  scrollbar-shadow-color: #cccccc;\r\n  scrollbar-track-color: #cccccc;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: white;\r\n   border-bottom: black 1px solid;\r\n   border-left: black 1px solid;\r\n   border-right: black 1px solid;\r\n   border-top: black 1px solid;\r\n}', '<div align=\'left\'><img src=\'images/title.jpg\' border=\'0\'></div>\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'#666666\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: #ffffff;', 'background-color: #666666;\r\ncolor: #ffffff;\r\nfont-size: x-small;', 'background-color: #000000;', 'background-color: #3F3F3F;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: #3F3F3F;\r\nfont-size: x-small;\r\ncolor: #ffffff;', 'background-color: #4F4F4F;\r\nfont-size: x-small;\r\ncolor: #ffffff;', 'images/last_post.gif', 'images/2_newpost.jpg', 'images/2_newtopic.jpg', 'images/abo.jpg', 'images/2_closed.jpg', 'images/2_pm_new.jpg', 'images/2_pm_readall.jpg', 'images/2_pm_delall.jpg', 'images/2_pm_reply.jpg', 'images/2_profile.jpg', 'images/2_pm.jpg', 'images/2_www.jpg', 'images/2_email.jpg', 'images/2_search.jpg', 'images/2_quote.jpg', 'images/2_edit_delete.jpg', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip.jpg');"),
                                     array("Foren-Style hinzuf&uuml;gen - ", "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (5, 'blue / yellow', '', 'on', '/* Text-Allgemein */\r\n#all A:active { color: #333399; text-decoration: none; }\r\n#all A:visited { color: #333399; text-decoration: none; }\r\n#all A:hover { color: #ff0000; text-decoration: underline; }\r\n#all A:link { color: #333399; text-decoration: none; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { color: #ffffff; text-decoration: underline; }\r\n#nav A:visited { color: #ffffff; text-decoration: none; }\r\n#nav A:hover { color: #ff2222; text-decoration: underline overline; background-color:transparent; }\r\n#nav A:link { color: #ffffff; text-decoration: none; }\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: #F5F5DC;\r\n  font-family: verdana,arial,helvetica;\r\n  font-size: medium;\r\n  color: #000000;\r\n  scrollbar-face-color: #666666;\r\n  scrollbar-arrow-color: #ffffff;\r\n  scrollbar-base-color: #cccccc;\r\n  scrollbar-3d-light-color: #cccccc;\r\n  scrollbar-darkshadow-color: #cccccc;\r\n  scrollbar-highlight-color: #000000;\r\n  scrollbar-shadow-color: #cccccc;\r\n  scrollbar-track-color: #cccccc;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: white;\r\n   border-bottom: black 1px solid;\r\n   border-left: black 1px solid;\r\n   border-right: black 1px solid;\r\n   border-top: black 1px solid;\r\n}', '<table bgcolor=\'#006699\' width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' align=\'center\' style=\'padding:50px\'><tr><td width=\'100%\'>\r\n\r\n<div align=\'left\'><img src=\'images/title.jpg\' border=\'0\'></div>\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'#666666\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '</td></tr></table>', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: #000000;', 'background-color: #666666;\r\ncolor: #ffffff;\r\nfont-size: x-small;', 'background-color: #000000;', 'background-color: yellow;\r\ncolor: green;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: #F0F8FF;\r\nfont-size: x-small;\r\ncolor: #000000;', 'background-color: #F5F5DC;\r\nfont-size: x-small;\r\ncolor: #000000;', 'images/last_post.gif', 'images/2_newpost.jpg', 'images/2_newtopic.jpg', 'images/abo.jpg', 'images/2_closed.jpg', 'images/2_pm_new.jpg', 'images/2_pm_readall.jpg', 'images/2_pm_delall.jpg', 'images/2_pm_reply.jpg', 'images/2_profile.jpg', 'images/2_pm.jpg', 'images/2_www.jpg', 'images/2_email.jpg', 'images/2_search.jpg', 'images/2_quote.jpg', 'images/2_edit_delete.jpg', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip.jpg');"),
                                     array("Tabelle $TB_USER aktualisieren - ", "UPDATE $TB_USER SET style='1'"),
                                     array("neue Admin-Rechte vergeben - ", "UPDATE $TB_ACCESS SET mod_move_post='on', mod_top='on', admin_styles='on' WHERE admin_settings='on'"),
                                     array("neue Moderatoren-Rechte vergeben - ", "UPDATE $TB_MOD SET mod_move_post='on', mod_top='on' WHERE mod_move_topic='on'"),
                                     array("neue Benutzer-Rechte vergeben - ", "UPDATE $TB_ACCESS SET avatar='on' WHERE edit_profil='on'"),
                                     array("neue Foren-Rechte vergeben - ", "UPDATE $TB_FORUM_ACCESS SET mod_move_post='on', mod_top='on' WHERE mod_move_topic='on'")
                      );

         }
         return $query;
#
}
################################################################################
############################### SQL-Query�s #################################### ---
################################################################################
?>
</BODY>
</HTML>
