<?php
### Kompression ### +++
ob_start();
ob_implicit_flush(0);
### Kompression ### ---

include("config.inc.php");    //Konfiguration
include("$MAIN_PATH/mainfile.php");    //Main-Function�s

        //Weiterleitungen !!!
        goto($HTTP_GET_VARS[goto]);

$time_start = getmicrotime();
#
#
##################################### CSS - Scripts <head> ##################################### +++
$userinfo = get_user_info();
$access = get_forum_perm("","");
$login = user_login();
//Style in Array packen !!!
$_style = get_style($userinfo[style]);

echo $_style[html_type]."\n";
?>
<html>
<head>
<script language='JavaScript'>
<!--
function Smilies() {
         navigation=window.open('<?php echo "http://$SITE/functions.php?action=smilies"; ?>','Smilies','height=450, width=250, toolbar=no, scrollbars=yes, resizable=no');
}
function BBCode() {
         navigation=window.open('<?php echo "http://$SITE/functions.php?action=bbcodes"; ?>','BBCodes','height=450, width=350, toolbar=no, scrollbars=yes, resizable=no');
}
function PMFenster() {
         navigation=window.open('<?php echo "http://$SITE/functions.php?action=pm_popup&$Sess_Name=$Sess"; ?>','Nachricht','height=150, width=350, toolbar=no, scrollbars=no, resizable=no');
}
//-->
</script>
<META name='KEYWORDS' content="<?php echo $META_KEYWORDS; ?>">
<META name='DESCRIPTION' content="<?php echo $META_DESCRIPTION; ?>">
<META name='AUTHOR' content='KillerGod2000'>
<META name='COPYRIGHT' content='KillerGod2000'>
<META name='ROBOTS' content='all'>
<TITLE><?php echo $TITEL; ?></title>
<?php
      echo "<STYLE type=text/css><!--";
             echo $_style[head_insert]."\n";

             ### Tabellen
             //wechselnde Hintergrundfarbe (erste)
             if ($_style[cat_one]) {
                 echo ".cat_one { $_style[cat_one] }\n";
             }
             //wechselnde Hintergrundfarbe (zweite)
             if ($_style[cat_two]) {
                 echo ".cat_two { $_style[cat_two] }\n";
             }
             //f�r Quote Tabellen
             if ($_style[table_inset]) {
                 echo ".inset_table { $_style[table_inset] }\n";
             }
             //Standard Tabellen - table
             if ($_style[default_table]) {
                 echo ".default_table { $_style[default_table] }\n";
             }
             //Standard Tabelen - tr
             if ($_style[default_tr]) {
                 echo ".default_tr { $_style[default_tr] }\n";
             }
             //Cat Tabellen - table
             if ($_style[cat_table]) {
                 echo ".cat_table { $_style[cat_table] }\n";
             }
             //Cat Tabelen - tr
             if ($_style[cat_tr]) {
                 echo ".cat_tr { $_style[cat_tr] }\n";
             }
             ### Schriften
             //gro�
             if ($_style[font_big]) {
                 echo ".font_big { $_style[font_big] }\n";
             }
             //normal
             if ($_style[font_normal]) {
                 echo ".font_normal { $_style[font_normal] }\n";
             }
             //klein
             if ($_style[font_small]) {
                 echo ".font_small { $_style[font_small] }\n";
             }
             //fehler
             if ($_style[font_fault]) {
                 echo ".font_fault { $_style[font_fault] }\n";
             }
      echo "-->\n</style>\n";
echo "</head>\n";
##################################### CSS - Scripts </head> ##################################### ---
#
#
##################################### Kopfleite <body> ##################################### +++
#
##### Wenn PM�s da dann Pop-up !!! #####
if (pm_status() >= "1" AND $userinfo[pm_popup_show] != "on" AND $userinfo[pm_popup] == "on") {
    $PM_onload = "onLoad='PMFenster()'";
}
echo "<body $PM_onload $_style[body_extra]>\n";
##### Body ##### ---
#
#
##### Benutzerdef. Header ausgeben !!! #####
//Header ausgeben ???
if (!$no_head AND !$HTTP_POST_VARS[no_head]) {

    ##### ist Admin ?
    if ($access[admin_settings] == "on" OR $access[admin_cats] == "on" OR $access[admin_forums] == "on" OR $access[admin_announcements] == "on"
        OR $access[admin_users] == "on" OR $access[admin_user_groups] == "on" OR $access[admin_user_titles] == "on" OR $access[admin_smilies] == "on"
        OR $access[admin_bbcodes] == "on" OR $access[admin_status] == "on" OR $access[admin_words] == "on") {

        $admin = TRUE;
    } else {

        $admin = FALSE;
    }

    ##### Session-String
    $_style[header] = preg_replace("/\*session\*/si", "$Sess_Name=$Sess", $_style[header]);

    ##### Status
    # Eingeloggt
    if ($login) {
        //--Benutzername
        $_style[header] = preg_replace("/\[user_name\](.*)\[\/user_name\]/si", "\\1&nbsp;$HTTP_SESSION_VARS[USER_Log]", $_style[header]);
        //--Letztes Login
        $_style[header] = preg_replace("/\[user_lastlogin\](.*)\[\/user_lastlogin\]/si", "\\1&nbsp;$HTTP_SESSION_VARS[VISIT_Log]", $_style[header]);
        //--neue Beitr�ge
        $_style[header] = preg_replace("/\[search_new\](.*)\[\/search_new\]/si", "<a href='search.php?$Sess_Name=$Sess&action=search&get=new'>\\1</a>", $_style[header]);

    # Ausgeloggt
    } else {
        //--Benutzername
        $_style[header] = preg_replace("/\[user_name\](.*)\[\/user_name\]/si", "", $_style[header]);
        //--Letztes Login
        $_style[header] = preg_replace("/\[user_lastlogin\](.*)\[\/user_lastlogin\]/si", "", $_style[header]);
        //--neue Beitr�ge
        $_style[header] = preg_replace("/\[search_new\](.*)\[\/search_new\]/si", "", $_style[header]);
    }

    ##### feste Links
    //--Beitr�ge von heute
    $_style[header] = preg_replace("/\[search_today\](.*)\[\/search_today\]/si", "<a href='search.php?$Sess_Name=$Sess&action=search&get=today'>\\1</a>", $_style[header]);


    ##### Variable Links
    # Eingeloggt
    if ($login) {
        //--Logout
        $_style[header] = preg_replace("/\[site_login\](.*)\[\*\](.*)\[\/site_login\]/si", "<a href='login.php?$Sess_Name=$Sess&action=logout'>\\1</a>", $_style[header]);
        //--Profil
        $_style[header] = preg_replace("/\[site_profile\](.*)\[\*\](.*)\[\/site_profile\]/si", "<a href='user.php?$Sess_Name=$Sess'>\\1</a>", $_style[header]);
        //--Signup
        $_style[header] = preg_replace("/\[site_signup\](.*)\[\*\](.*)\[\/site_signup\]/si", "<a href='signup.php?$Sess_Name=$Sess'>\\1</a>", $_style[header]);
        //--Suche
        $_style[header] = preg_replace("/\[site_search\](.*)\[\*\](.*)\[\/site_search\]/si", "<a href='search.php?$Sess_Name=$Sess'>\\1</a>", $_style[header]);
        //--Members
        $_style[header] = preg_replace("/\[site_members\](.*)\[\*\](.*)\[\/site_members\]/si", "<a href='members.php?$Sess_Name=$Sess'>\\1</a>", $_style[header]);
        //--Home
        $_style[header] = preg_replace("/\[site_home\](.*)\[\*\](.*)\[\/site_home\]/si", "<a href='index.php?$Sess_Name=$Sess'>\\1</a>", $_style[header]);
        //--Admin
        if ($admin) {
            $_style[header] = preg_replace("/\[site_admin\](.*)\[\*\](.*)\[\/site_admin\]/si", "<a href='admin/index.php?$Sess_Name=$Sess'>\\1</a>", $_style[header]);
        } else {
            $_style[header] = preg_replace("/\[site_admin\](.*)\[\*\](.*)\[\/site_admin\]/si", "", $_style[header]);
        }

    # Ausgeloggt
    } else {
        //--Login
        $_style[header] = preg_replace("/\[site_login\](.*)\[\*\](.*)\[\/site_login\]/si", "<a href='login.php?$Sess_Name=$Sess'>\\2</a>", $_style[header]);
        //--Profil
        $_style[header] = preg_replace("/\[site_profile\](.*)\[\*\](.*)\[\/site_profile\]/si", "<a href='user.php?$Sess_Name=$Sess'>\\2</a>", $_style[header]);
        //--Signup
        $_style[header] = preg_replace("/\[site_signup\](.*)\[\*\](.*)\[\/site_signup\]/si", "<a href='signup.php?$Sess_Name=$Sess'>\\2</a>", $_style[header]);
        //--Suche
        $_style[header] = preg_replace("/\[site_search\](.*)\[\*\](.*)\[\/site_search\]/si", "<a href='search.php?$Sess_Name=$Sess'>\\2</a>", $_style[header]);
        //--Members
        $_style[header] = preg_replace("/\[site_members\](.*)\[\*\](.*)\[\/site_members\]/si", "<a href='members.php?$Sess_Name=$Sess'>\\2</a>", $_style[header]);
        //--Home
        $_style[header] = preg_replace("/\[site_home\](.*)\[\*\](.*)\[\/site_home\]/si", "<a href='index.php?$Sess_Name=$Sess'>\\2</a>", $_style[header]);
        //--Admin
        $_style[header] = preg_replace("/\[site_admin\](.*)\[\*\](.*)\[\/site_admin\]/si", "<a href='admin/index.php?$Sess_Name=$Sess'>\\2</a>", $_style[header]);
    }


    ##### Statistik
    //--Topics
    $Daten = mySQL_num_rows(mySQL_query ("SELECT id FROM $TB_TOPIC"));
    $_style[header] = preg_replace("/\*stat_topics\*/si", $Daten, $_style[header]);

    //--Posts
    $Daten = mySQL_num_rows(mySQL_query ("SELECT id FROM $TB_POST"));
    $_style[header] = preg_replace("/\*stat_posts\*/si", $Daten, $_style[header]);

    //--Benutzer
    $Daten = mySQL_num_rows(mySQL_query ("SELECT id FROM $TB_USER"));
    $_style[header] = preg_replace("/\*stat_users\*/si", $Daten, $_style[header]);

    //--Letzter Benutzer
    $Daten = mysql_fetch_array(mySQL_query ("SELECT id, name FROM $TB_USER ORDER BY $TB_USER.id DESC LIMIT 0,1"));
    $_style[header] = preg_replace("/\*stat_lastuser\*/si", "<a href='showuser.php?$Sess_Name=$Sess&id=$Daten[id]'>$Daten[name]</a>", $_style[header]);

    ##### Ausgeben des neuen Header�s :)
    echo $_style[header];
}

##################################### Kopfleite ##################################### ---
//***Zugriff erlaubt ???
    require("auth.php");
//Zugriff erlaubt ???***
?>