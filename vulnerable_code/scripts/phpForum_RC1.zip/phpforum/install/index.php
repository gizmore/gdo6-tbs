<?php
$COLOR_TB_BACK = "#000000";
$COLOR_GROUP = "#bbbbbb";
$COLOR_ENTRIE = "#FFFFFF";
$COLOR_ENTRIE_dark = "#f1f1f1";
$COLOR_TEXT = "#000000";
$COLOR_TB_BACK = "#000000";
$COLOR_TEXT_TITLE = "#FFFFFF";
$COLOR_TITLE = "#666666";
$FONT_FACE = "verdana,arial,helvetica";
$COLOR_BACK = "white";
$FONT_SIZE_COMMENT = "1";
$FONT_SIZE_TITLE = "2";
$FONT_SIZE = "2";

@set_time_limit(0);
check_config();

switch ($HTTP_GET_VARS[step]) {
        case "":
              head("Start");
              inst_start();
              break;

        case "1":
              head("config.inc.php");
              inst_create_config();
              break;

        case "2":
              head("DB erstellen");
              inst_create_tables();
              break;

        case "3":
              head("Foren Standard");
              inst_table_insert();
              break;

        case "4":
              head("...fast Fertig");
              inst_admin();
              break;

        case "final":
              head("Fertig");
              inst_final();
              break;
}
#
#
################################################################################
############################## Installation #################################### +++
################################################################################
#
#
##################### Installation (Start) ##################### +++
function inst_start() {
         include("../config.inc.php");
         global $HTTP_SERVER_VARS;

         echo "<form method='post' action='$HTTP_SERVER_VARS[PHP_SELF]?step=1'>";
         table_header("phpForum Installation", "100%", "1", "colspan='2'");
         table_header("mySQL Server", "100%", "", "colspan='2'", "nohead"); ?>
               <tr>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Server:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier die IP des mySQL-Servers ein. (Standard ist localhost)
                       </font>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='db_server' size='30' value='<?php echo $DB_SERVER; ?>'>
                   </td>
               <tr>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Benutzername:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier den mySQL-Benutzernamen ein.
                       </font>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='db_user' size='30' value='<?php echo $DB_USER; ?>'>
                   </td>
               <tr>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Passwort:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier das Passwort f�r den mySQL-Server ein.
                       </font>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='password' name='db_pass' size='30' value='<?php echo $GLOBALS[DB_PASS]; ?>'>
                   </td>
               <tr>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Datenbank:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Hier m&uuml;ssen sie den Namen der Datenbank angeben.
                       </font>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='db_name' size='30' value='<?php echo $DB_NAME; ?>'>
                   </td>
               </tr>
         <?php table_header("Web Server", "100%", "", "colspan='2'", "nohead"); ?>
               <tr>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Server:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier die IP des Web-Servers ein.<br>
                             (nur wenn dieser nicht &uuml;bereinstimmt)
                       </font>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='domain' size='30' value='<?php echo $HTTP_SERVER_VARS["HTTP_HOST"]; ?>'>
                   </td>
               <tr>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>System-Pfad:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier den Pfad "Root" Pfad des phpForums ein.<br>
                             (nur wenn dieser nicht &uuml;bereinstimmt)
                       </font>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <?php
                       if (eregi("/install/index.php$", $HTTP_SERVER_VARS["PATH_TRANSLATED"])) {
                           $main_path = eregi_replace("/install/index.php$", "",$HTTP_SERVER_VARS["PATH_TRANSLATED"]);
                       } elseif (eregi("/index.php$", $HTTP_SERVER_VARS["PATH_TRANSLATED"])) {
                           $main_path = eregi_replace("/index.php$", "",$HTTP_SERVER_VARS["PATH_TRANSLATED"]);
                       }
                       ?>
                       <input type='text' name='main_path' size='30' value='<?php echo $main_path; ?>'>
                   </td>
               <tr>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Server-URL:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier die vollst�ndige URL des phpForums ein (ohne http://).<br>
                             (nur wenn dieser nicht &uuml;bereinstimmt)
                       </font>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <?php
                       if (eregi("/install/index.php$", $HTTP_SERVER_VARS["PHP_SELF"])) {
                           $url = eregi_replace("/install/index.php$", "",$HTTP_SERVER_VARS["PHP_SELF"]);
                       } elseif (eregi("/index.php$", $HTTP_SERVER_VARS["PHP_SELF"])) {
                           $url = eregi_replace("/index.php$", "",$HTTP_SERVER_VARS["PHP_SELF"]);
                       }
                       ?>
                       <input type='text' name='site' size='30' value='<?php echo $HTTP_SERVER_VARS["HTTP_HOST"].$url; ?>'>
                   </td>
               </tr>
         <?php table_header("Experten Einstellungen", "100%", "", "colspan='2'", "nohead"); ?>
               <tr>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Tabellen-Pr&auml;fix:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Wenn sie bereits Tabellen mit gleichen Namen in ihrer Datenbank besitzen, k&ouml;nnen sie hiermit jeder Tabelle einen Pr�fix voranstellen.
                       </font>
                   <td width='50%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='praefix' size='30'>
                   </td>
               </tr>
         </table>
         <p></p>
         <center>
                 <input type='submit' value='Einstellungen speichern'>
                 <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
         </center>
         <?php echo "</form>";
}
##################### Installation (Start) ##################### ---
#
#
##################### Installation (DB-Check) ##################### +++
function inst_create_config() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         //DB-Server Verbindung aufbauen
         if (!db_connect($HTTP_POST_VARS[db_server], $HTTP_POST_VARS[db_user], $HTTP_POST_VARS[db_pass], $HTTP_POST_VARS[db_name])) {
             msg("Es konnte keine Verbindung zum <b>mySQL-Server</b> aufgebaut werden, &uuml;berpr&uuml;fe die angegebenen Daten und Versuche es erneut.", "2", "back()");
         //Server Daten OK !!!
         } else {
                  //kann Datei �ffnen ???
                  if ($fp = @fopen("$HTTP_POST_VARS[main_path]/config.inc.php", "w")) {
                      @fwrite($fp, "<?php\n// DB - Einstellungen\n");
                      @fwrite($fp, "\$DB_SERVER = \"$HTTP_POST_VARS[db_server]\";\n");
                      @fwrite($fp, "\$DB_USER = \"$HTTP_POST_VARS[db_user]\";\n");
                      @fwrite($fp, "\$DB_PASS = \"$HTTP_POST_VARS[db_pass]\";\n");
                      @fwrite($fp, "\$DB_NAME = \"$HTTP_POST_VARS[db_name]\";\n");
                      @fwrite($fp, "\$DOMAIN = \"$HTTP_POST_VARS[domain]\";\n");
                      @fwrite($fp, "\$SITE = \"$HTTP_POST_VARS[site]\";\n");
                      @fwrite($fp, "\$MAIN_PATH = \"$HTTP_POST_VARS[main_path]\";\n");

                      @fwrite($fp, "\n// Namen der DB-Tabellen\n");
                      @fwrite($fp, "\$TB_USER = \"$HTTP_POST_VARS[praefix]users\";                                //Benutzer\n");
                      @fwrite($fp, "\$TB_STATUS = \"$HTTP_POST_VARS[praefix]status\";                             //Status des Users (Member...)\n");
                      @fwrite($fp, "\$TB_ACCESS = \"$HTTP_POST_VARS[praefix]access\";                             //Benutzergruppen\n");
                      @fwrite($fp, "\$TB_CAT = \"$HTTP_POST_VARS[praefix]categories\";                            //Kategorien\n");
                      @fwrite($fp, "\$TB_FORUM = \"$HTTP_POST_VARS[praefix]forums\";                              //Foren\n");
                      @fwrite($fp, "\$TB_TOPIC = \"$HTTP_POST_VARS[praefix]topics\";                              //Topics\n");
                      @fwrite($fp, "\$TB_POST = \"$HTTP_POST_VARS[praefix]posts\";                                //Beitr�ge\n");
                      @fwrite($fp, "\$TB_MOD = \"$HTTP_POST_VARS[praefix]forums_mods\";                           //Forum-Mods\n");
                      @fwrite($fp, "\$TB_SEARCH = \"$HTTP_POST_VARS[praefix]search\";                             //Suche\n");
                      @fwrite($fp, "\$TB_ABO = \"$HTTP_POST_VARS[praefix]topic_abo\";                             //Topic - Abo�s\n");
                      @fwrite($fp, "\$TB_AVATARS = \"$HTTP_POST_VARS[praefix]avatars\";                           //Benutzer Avatare\n");
                      @fwrite($fp, "\$TB_FILES = \"$HTTP_POST_VARS[praefix]attachements\";                        //Datei Anh�nge\n");
                      @fwrite($fp, "\$TB_SMILIES = \"$HTTP_POST_VARS[praefix]smilies\";                           //Smilies :)\n");
                      @fwrite($fp, "\$TB_MSG = \"$HTTP_POST_VARS[praefix]priv_msgs\";                             //Private Nachrichten\n");
                      @fwrite($fp, "\$TB_WORDS = \"$HTTP_POST_VARS[praefix]words\";                               //Words (F***, ...)\n");
                      @fwrite($fp, "\$TB_SESSION = \"$HTTP_POST_VARS[praefix]sessions\";                          //Sessions (Who is Online)\n");
                      @fwrite($fp, "\$TB_BBCODES = \"$HTTP_POST_VARS[praefix]bb_codes\";                          //Board Codes [b]fett[/b]\n");
                      @fwrite($fp, "\$TB_SETTINGS = \"$HTTP_POST_VARS[praefix]settings\";                         //Einstellungen\n");
                      @fwrite($fp, "\$TB_SETTING_GROUP = \"$HTTP_POST_VARS[praefix]setting_groups\";              //Einstellung�s Gruppen\n");
                      @fwrite($fp, "\$TB_FORUM_ACCESS = \"$HTTP_POST_VARS[praefix]forums_access\";                //Sonder-zugriffsrechte der Foren\n");
                      @fwrite($fp, "\$TB_POLL = \"$HTTP_POST_VARS[praefix]poll\";                                 //Umfragen (Haupttabelle)\n");
                      @fwrite($fp, "\$TB_POLL_USER = \"$HTTP_POST_VARS[praefix]poll_users\";                      //Umfragen (Benutzer die ihre Stimme schon abgegeben haben)\n");
                      @fwrite($fp, "\$TB_POLL_TEXT = \"$HTTP_POST_VARS[praefix]poll_texts\";                      //Umfragen (Auswahlm�glichkeiten)\n");
                      @fwrite($fp, "\$TB_STYLES = \"$HTTP_POST_VARS[praefix]styles\";                             //Foren-Styles\n");
                      @fwrite($fp, "?>");
                      @fclose($fp);
                      msg("Die Konfigurations-Datei <b>config.inc.php</b> wurde gespeichert.", "3", "$HTTP_SERVER_VARS[PHP_SELF]?step=2");
                  //Fehler beim �ffnen !!!
                  } else {
                      open_table("phpForum Mitteilung", "60%"); ?>
                           Die Konfigurations-Datei <b>config.inc.php</b> konnte nicht ge&auml;ndert werden, &auml;ndern sie die Rechte (chmod) dieser Datei oder &auml;ndern sie die Werte selbst.
                           <table align='center'>
                                  <tr>
                                      <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                                            <td>
                                                <input type='submit' value='Erneut versuchen'>
                                            </td>
                                      </form>
                                      <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                                            <input type='hidden' name='step' value='2'>
                                            <td>
                                                <input type='submit' value='nicht Speichern'>
                                            </td>
                                      </form>
                                  </tr>
                           </table>
                           <?php
                      close_table("W�hlen sie \"Erneut versuchen\" wenn sie die Rechte der config.inc.php ge&auml; haben, oder w&auml;hlen sie \"nicht Speichern\" um die selbst ge&auml;nderte config.inc.php zu verwenden.");
                  }
         }
}
##################### Installation (DB-Check) ##################### ---
#
#
##################### Installation (Tabellen erstellen) ##################### +++
function inst_create_tables() {
         include("../config.inc.php");
         global $HTTP_GET_VARS, $HTTP_SERVER_VARS;

         if (!db_connect()) {
             msg("Es konnte keine Verbindung zum <b>mySQL-Server</b> aufgebaut werden, &uuml;berpr&uuml;fe die angegebenen Daten und Versuche es erneut.", "5", "$HTTP_SERVER_VARS[PHP_SELF]");
         }
         open_table("Installation (Tabellen erstellen)", "100%");
              ### Tabellen l�schen
              if ($HTTP_GET_VARS[reset] == "on") {
                  echo "<b>vorhandene Tabellen l&ouml;schen</b>";
                  echo "<ul>";
                  $sql = sql("create");
                  while (list($key,$val) = each($sql)) {
                         if (@mysql_query("DROP TABLE IF EXISTS $key")) {
                             echo "<li>Tabelle: <b>".$key."</b> erfolgreich gel�scht";
                         } else {
                             echo "<li>Tabelle: <b>".$key."</b> <font color='red'>konnte nicht gel&ouml;scht werden !</font>";
                             $Fehler = "on";
                         }
                  }
                  echo "</ul>";
              }
              ### Tabellen erstellen
              echo "<b>Tabellen erstellen</b>";
              echo "<ul>";
              $sql = sql("create");
              $Fehler = "";
              while (list($key,$val) = each($sql)) {
                     if (@mysql_query("$val")) {
                         echo "<li>Tabelle: <b>".$key."</b> erfolgreich erstellt";
                     } else {
                         echo "<li>Tabelle: <b>".$key."</b> <font color='red'>konnte nicht erstellt werden !</font>";
                         $Fehler = "on";
                     }
              }
              echo "</ul>";
              if (!$Fehler) {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='3'>
                        <center>
                                <input type='submit' value='weiter'>
                        </center>
                  </form>
                  <?php
              } else {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <center>
                                <input type='submit' value='anderen Pr&auml;fix w&auml;hlen'>
                        </center>
                  </form>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='2'>
                        <input type='hidden' name='reset' value='on'>
                        <center>
                                <input type='submit' value='vorhandene Tabellen l&ouml;schen'>
                        </center>
                  </form>
                  <?php
              }
         close_table();
}
##################### Installation (Tabellen erstellen) ##################### ---
#
#
##################### Installation (Tabellen Inserts) ##################### +++
function inst_table_insert() {
         include("../config.inc.php");
         global $HTTP_GET_VARS, $HTTP_SERVER_VARS;
         $faults = 0;
         if (!db_connect()) {
             msg("Es konnte keine Verbindung zum <b>mySQL-Server</b> aufgebaut werden, &uuml;berpr&uuml;fe die angegebenen Daten und Versuche es erneut.", "5", "$HTTP_SERVER_VARS[PHP_SELF]");
         }

         open_table("Installation (Foren-Standard einrichten)", "100%");
              echo "<b>Standard Werte</b>";
              echo "<ul>";
              $querys = array("insert_access","insert_bbcodes","insert_categories","insert_forums","insert_forum_access","insert_settings_group","insert_settings","insert_smilies","insert_status","insert_styles","insert_users","insert_words");
              while (list($id, $typ) = each($querys)) {
                     $Fehler = "<li>f&uuml;r <b>".substr($typ, 7, strlen($typ))."</b> erfolgreich hinzugef&uuml;gt";
                     $sql = sql($typ);
                     while (list($key,$val) = each($sql)) {
                            if (!mysql_query($val)) {
echo mysql_error();
                                $faults++;
                                $Fehler = "<li>f&uuml;r <b>".substr($typ, 7, strlen($typ))."</b> <font color='red'>konnten nicht hinzugef&uuml;gt werden</font>";
                            }
                     }
                     echo $Fehler;
              }
              echo "</ul>";
              echo "<b>Smilies hinzuf&uuml;gen</b>";
              echo "<ul>";
              $result = mysql_query("SELECT id, name, filename FROM $TB_SMILIES WHERE filename <> ''");
              while ($Daten = mysql_fetch_array($result)) {

                     ### Datei einlesen ### +++
                     $fp=@fopen("$MAIN_PATH/install/smilies/$Daten[filename]","rb");
                         $filesize=@filesize("$MAIN_PATH/install/smilies/$Daten[filename]");
                         $filestuff=@fread($fp,$filesize);
                     @fclose($fp);
                     ### Datei einlesen ### ---
                     if (!@mysql_query("UPDATE $TB_SMILIES SET data='".addslashes($filestuff)."' WHERE id='$Daten[id]'") AND !$filestuff) {
                         $faults++;
                         echo "<li><b>".$Daten[name]."</b> <font color='red'>konnte nicht hinzugef&uuml;gt werden</font>";
                     } else {
                         echo "<li><b>".$Daten[name]."</b> erfolgreich hinzugef&uuml;gt";
                     }
              }
              echo "</ul>";
              echo "<b>Benutzer-Status Bilder hinzuf�gen</b>";
              echo "<ul>";
              $result = mysql_query("SELECT id, name, data FROM $TB_STATUS WHERE data <> ''");
              while ($Daten = mysql_fetch_array($result)) {

                     ### Datei einlesen ### +++
                     $fp=@fopen("$MAIN_PATH/install/status/$Daten[data]","rb");
                         $filesize=@filesize("$MAIN_PATH/install/status/$Daten[data]");
                         $filestuff=@fread($fp,$filesize);
                     @fclose($fp);
                     ### Datei einlesen ### ---
                     if (!@mysql_query("UPDATE $TB_STATUS SET data='".addslashes($filestuff)."' WHERE id='$Daten[id]'") AND !$filestuff) {
                         $faults++;
                         echo "<li><b>".$Daten[name]."</b> <font color='red'>konnte nicht hinzugef&uuml;gt werden</font>";
                     } else {
                         echo "<li><b>".$Daten[name]."</b> erfolgreich hinzugef&uuml;gt";
                     }
              }
              echo "</ul>";
              echo "<b>Benutzer-Gruppen Bilder hinzuf�gen</b>";
              echo "<ul>";
              $result = mysql_query("SELECT id, name, data FROM $TB_ACCESS WHERE data <> ''");
              while ($Daten = mysql_fetch_array($result)) {

                     ### Datei einlesen ### +++
                     $fp=@fopen("$MAIN_PATH/install/access/$Daten[data]","rb");
                         $filesize=@filesize("$MAIN_PATH/install/access/$Daten[data]");
                         $filestuff=@fread($fp,$filesize);
                     @fclose($fp);
                     ### Datei einlesen ### ---
                     if (!@mysql_query("UPDATE $TB_ACCESS SET data='".addslashes($filestuff)."' WHERE id='$Daten[id]'") AND !$filestuff) {
                         $faults++;
                         echo "<li><b>".$Daten[name]."</b> <font color='red'>konnte nicht hinzugef&uuml;gt werden</font>";
                     } else {
                         echo "<li><b>".$Daten[name]."</b> erfolgreich hinzugef&uuml;gt";
                     }
              }
              echo "</ul>";
              if ($faults > 0) {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='2'>
                        <input type='hidden' name='reset' value='on'>
                        <center>
                                <input type='submit' value='erneut versuchen'>
                        </center>
                  </form>
                  <?php
              } else {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='4'>
                        <center>
                                <input type='submit' value='weiter'>
                        </center>
                  </form>
                  <?php
              }
         close_table();
}
##################### Installation (Tabellen Inserts) ##################### ---
#
#
##################### Installation (Admin anlegen) ##################### +++
function inst_admin() {
         include("../config.inc.php");
         global $HTTP_GET_VARS;

         echo "<form method='post' action='$HTTP_SERVER_VARS[PHP_SELF]?step=final'>";
         table_header("phpForum Installation (Administrator einrichten)", "100%", "1", "colspan='2'");
         table_header("Administrator", "100%", "", "colspan='2'", "nohead"); ?>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Benutzername:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier ihren Benutzernamen ein, damit richten sie sich als Administrator ein.
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='user_name' size='30'>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Passwort:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier ihr Passwort ein.
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='password' name='user_pass' size='30'>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Passwort (wiederholung):</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier ihr Passwort ein (Wiederholung).
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='password' name='user_pass_repeat' size='30'>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>eMail-Adresse:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Tragen sie hier ihre eMail-Adresse ein.
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='user_email' size='30'>
                   </td>
               </tr>
         <?php table_header("Foren Einstellungen", "100%", "", "colspan='2'", "nohead"); ?>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Foren-Name:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Dies ist die Bezeichnung des Forums.
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='TITEL_KURZ' size='30' value='phpForum'>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Foren-Name (Titel-Leiste):</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             Diese Bezeichnung erscheint in der Titelleiste des Browsers.
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='TITEL' size='30' value='phpForum die Kostenlose Forum-Software'>
                   </td>
               <tr>
                   <td width='30%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE_dark]; ?>'>
                       <font size='<?php echo $GLOBALS[FONT_SIZE]; ?>'>
                             <b>Service eMail-Adresse:</b>
                       </font>
                       <br>
                       <font size='<?php echo $GLOBALS[FONT_SIZE_COMMENT]; ?>'>
                             &Uuml];ber diese eMail-Adresse werden "Service" eMails des des Forums verschickt (z.B. "Benachrichtigung bei einem neuen Beitrag").
                       </font>
                   <td width='70%' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                       <input type='text' name='SITE_ADMIN' size='30'>
                   </td>
               </tr>
         </table>
         <p></p>
         <center>
                 <input type='submit' value='Einstellungen speichern'>
                 <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
         </center>
         </form>
         <?php
}
##################### Installation (Admin anlegen) ##################### ---
#
#
##################### Installation (Fertigstellen) ##################### +++
function inst_final() {
         include("../config.inc.php");
         global $HTTP_GET_VARS, $HTTP_POST_VARS, $HTTP_SERVER_VARS;
         $faults = 0;

         if (!db_connect()) {
             msg("Es konnte keine Verbindung zum <b>mySQL-Server</b> aufgebaut werden, &uuml;berpr&uuml;fe die angegebenen Daten und Versuche es erneut.", "5", "$HTTP_SERVER_VARS[PHP_SELF]");
         }
         //Daten �berpr�fen !!!
         if (!$HTTP_POST_VARS[user_name] OR $HTTP_POST_VARS[user_pass] != $HTTP_POST_VARS[user_pass_repeat] OR !$HTTP_POST_VARS[user_email]) {
             msg("Sie m&uuml;ssen einen Benutzernamen, eMail-Adresse und ein Passwort eingeben (dieses muss wiederholt werden), &uuml;berpr&uuml;fe die angegebenen Daten und Versuche es erneut.", "2", "back()");
         }
         open_table("Installation (Fertig)", "100%");
              echo "<ul>";
              //Admin hinzuf�gen
              if (@mysql_query("INSERT INTO $TB_USER (pass, reg, name, geb, gender, job, location, homepage, email, icq, aim, yim, sign, access_id, points, last_post, last_login, pm_email, pm_popup, pm_popup_show, bbcodes_show, html_show, smilies_show, sign_show, post_email, email_show, stay_login, pm_footer, style) VALUES ('".md5($HTTP_POST_VARS[user_pass])."', NOW(), '$HTTP_POST_VARS[user_name]', '', 'm', '', '', '', '$HTTP_POST_VARS[user_email]', '', '', '', '', 3, 0, 0, NOW(), 'on', 'on', '', 'on', 'on', 'on', '', 'on', 'on', 'on', 'on', 1);")) {
                  echo "<li><b>Administrator ($HTTP_POST_VARS[user_name])</b> erfolgreich hinzugef�gt.";
              } else {
                  echo "<li><b>Administrator ($HTTP_POST_VARS[user_name])</b> <font color='red'>konnte nicht hinzugef�gt werden</font>";
                  $faults++;
              }
              //Settings updaten
              if (@mysql_query("UPDATE $TB_SETTINGS SET value='$HTTP_POST_VARS[TITEL]' WHERE id='4'")) {
                  echo "<li><b>Foren-Name</b> erfolgreich ge&auml;ndert.";
              } else {
                  echo "<li><b>Foren-Name</b> <font color='red'>konnte nicht ge�ndert werden</font>";
                  $faults++;
              }
              if (@mysql_query("UPDATE $TB_SETTINGS SET value='$HTTP_POST_VARS[TITEL_KURZ]' WHERE id='6'")) {
                  echo "<li><b>Foren-Titel</b> erfolgreich ge&auml;ndert.";
              } else {
                  echo "<li><b>Foren-Titel</b> <font color='red'>konnte nicht ge�ndert werden</font>";
                  $faults++;
              }
              if (@mysql_query("UPDATE $TB_SETTINGS SET value='$HTTP_POST_VARS[SITE_ADMIN]' WHERE id='1'")) {
                  echo "<li><b>Service eMail-Adresse</b> erfolgreich ge&auml;ndert.";
              } else {
                  echo "<li><b>Service eMail-Adresse</b> <font color='red'>konnte nicht ge�ndert werden</font>";
                  $faults++;
              }
              //Datei Uploads?
              if (!get_cfg_var("file_uploads") OR strtoupper(@get_cfg_var("upload_max_filesize")) == "0M") {
                  if (@mysql_query("UPDATE $TB_SETTINGS SET value='' WHERE id='87'")) {
                      echo "<li><b>Datei-Uploads</b> wurden erfolgreich deaktiviert da ihr Server dies nicht unterst�tzt.";
                  } else {
                      echo "<li><b>Datei-Upload</b> konnte nicht deaktiviert werden, ihr Server unterst�tzt dies nicht.";
                      $faults++;
                  }
              }
              //Site Kompression ?
              @ob_start();
              @ob_implicit_flush(0);
              echo "Test";
              $contents = @ob_get_contents();
              @ob_end_clean();
              if (!$contents OR !@gzcompress($contents)) {
                  if (@mysql_query("UPDATE $TB_SETTINGS SET value='' WHERE id='91'")) {
                      echo "<li><b>Kompression</b> musste deaktiviert werden, da ihr Server dies nicht unterst�tzt.";
                  }
              }

              echo "</ul>";

              if ($faults >= 1) {
                  ?>
                  <form action='<?php echo $HTTP_SERVER_VARS[PHP_SELF]; ?>'>
                        <input type='hidden' name='step' value='4'>
                        <center>
                                <input type='submit' value='erneut versuchen'>
                        </center>
                  </form>
                  <?php
              } else {
                  echo "<center>Die Installation vom phpForum ist nun Abgeschlossen. <font color='red'>L&ouml;schen sie nun den <u>gesamten</u> Ordner \"install\" !!!</font><br>Wenn sie dies getan haben k�nnen sie �ber <a href='../index.php'>diesen Link</a> auf die Startseite gelangen, oder <a href='../login.php'>hier</a> zum login.</center>";
              }
         close_table();
}
##################### Installation (Fertigstellen) ##################### ---
#
#
################################################################################
############################## Installation #################################### ---
################################################################################
#
################################################################################
############################## Funktionen #################################### +++
################################################################################
#
#
##################### check_config ##################### +++
function check_config() {
         $Text = "Folgende Bedingungen werden von ihren Server nicht erf�llt:<ul>";
         $faults = 0;

         //PHP-Version OK ?
         $phpver = phpversion();
         if(substr($phpver, 0, 1) < "4") {
            $Text .= "<li>Die Installierte PHP-Version: $phpver erf�llt leider nicht die Anforderungen des phpForum";
            $faults++;
         }
         //mySQL - OK ?
         if(!function_exists("mysql_connect")) {
            $Text .= "<li>MySQL Unterst�tzung in PHP";
            $faults++;
         }
         //preg - OK ?
         if(!function_exists("preg_replace")) {
            $Text .= "<li>Regul�re-Ausdr�cke (preg) Unterst�tzung in PHP";
            $faults++;
         }
         $Text .= "</ul>";

         ### Wenn Fehler dann ausgeben !!!
         if ($faults > 0) {
             msg($Text);
         }
}
##################### check_config ##################### ---
#
#
##################### db_connect ##################### +++
function db_connect($server="", $user="", $pass="", $db_name="") {
         include("../config.inc.php");

         //Server
         if (!$server) {
             $server = $DB_SERVER;
         }
         //Benutzer
         if (!$user) {
             $user = $DB_USER;
         }
         //Passwort
         if (!$pass) {
             $pass = $DB_PASS;
         }
         //Datenbank
         if (!$db_name) {
             $db_name = $DB_NAME;
         }

         //zum Server verbinden
         if (@mysql_connect ($server, $user, $pass)) {
             //DB ausw�hlen
             if (@mysql_select_db ($db_name)) {
                 return TRUE;
             //DB konnte nicht ausgew�hlt werden !!!
             } else {
                 return FALSE;
             }
         //konnte nicht zum Server verbinden !!!
         } else {
             return FALSE;
         }
}
##################### db_connect ##################### ---
#
#
##################### Open - Table (standard-tabelle) ##################### +++
function head($step="") {
         global $COLOR_TB_BACK, $COLOR_GROUP,$COLOR_ENTRIE, $COLOR_ENTRIE_dark, $COLOR_TEXT, $COLOR_TB_BACK, $COLOR_TEXT_TITLE, $COLOR_TITLE, $FONT_FACE, $COLOR_BACK, $FONT_SIZE_COMMENT, $FONT_SIZE_TITLE, $_SERVER;
         ?>
         <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
         <HTML>
         <BODY bgcolor='<?php echo $COLOR_BACK; ?>'>
               <img src='../admin/phpForum.jpg' border='0'>
               <table width='100%' cellpadding='0' cellspacing='0' border='0' align='center'>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_TB_BACK; ?>' height='1'></td>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_GROUP; ?>' height='4'></td>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_TITLE; ?>' height='10'>
                              <font size='<?php echo $FONT_SIZE_TITLE; ?>' color='<?php echo $COLOR_TEXT_TITLE; ?>'>
                                    <b><?php
                                    if ($step == "") {
                                        echo "phpForum - Installation";
                                    } else {
                                        echo "phpForum - Installation (".$step.")";
                                    } ?></b>
                              </font>
                          </td>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_GROUP; ?>' height='4'></td>
                      <tr>
                          <td bgcolor='<?php echo $COLOR_TB_BACK; ?>' height='1'></td>
                      </tr>
               </table>
               <br><br>
               <?php
}
#
#
##################### Open - Table (standard-tabelle) ##################### +++
function open_table($msg, $width) {
         global $HTTP_SERVER_VARS;
         ?>
         <table border="0" bgcolor="<?php echo $GLOBALS[COLOR_TB_BACK]; ?>" cellpadding="4" cellspacing="1" align='center' width='<?php echo $width; ?>'>
                <tr bgcolor='<?php echo $GLOBALS[COLOR_TITLE]; ?>'>
                    <td width='100%' align='left'>
                        <FONT SIZE='<?php echo $GLOBALS[FONT_SIZE_TITLE]; ?>' FACE='<?php echo $GLOBALS[FONT_FACE]; ?>' COLOR='<?php echo $GLOBALS[COLOR_TEXT_TITLE]; ?>'>
                              <b><?php echo $msg; ?></b>
                        </font>
                    </td>
                </tr>
                <tr>
                    <td align='left' bgcolor='<?php echo $GLOBALS[COLOR_ENTRIE]; ?>'>
                        <FONT SIZE='<?php echo $GLOBALS[FONT_SIZE]; ?>' FACE='<?php echo $GLOBALS[FONT_FACE]; ?>' COLOR='<?php echo $GLOBALS[COLOR_TEXT]; ?>'>
         <?php
}
##################### Open - Table (standard-tabelle) ##################### ---
#
#
##################### Close - Table (standard-tabelle) ##################### +++
function close_table($msg="") {
         ?>
                        </font>
                        <?php if ($msg != "") {
                            echo "<p><FONT SIZE='$GLOBALS[FONT_SIZE_COMMENT]'>$msg</font></p>";
                        }
                        ?>
                    </td>
                </tr>
         </table>
<?php
}
##################### Close - Table (standard-tabelle) ##################### ---
#
#
##################### Table-Header ##################### +++
function table_header($text, $width, $typ="", $extra="", $no_head="") {
         if ($no_head == "") {
             ?>
             <table border='0' bgcolor='<?php echo $GLOBALS[COLOR_TB_BACK]; ?>' cellpadding='2' cellspacing='1' width='<?php echo $width; ?>' align='center'>
             <?php
         }
         ?>
                <tr bgcolor='<?php
                    if ($typ == "") {
                        echo $GLOBALS[COLOR_GROUP];
                    } elseif ($typ == "1") {
                        echo $GLOBALS[COLOR_TITLE];
                    }
                    ?>'>
                    <td width='100%' align='left' <?php echo $extra; ?>>
                        <FONT SIZE='<?php echo $GLOBALS[FONT_SIZE_TITLE]; ?>' FACE='<?php echo $GLOBALS[FONT_FACE]; ?>' COLOR='<?php
                              if ($typ == "") {
                                  echo $GLOBALS[COLOR_TEXT];
                              } elseif ($typ == "1") {
                                  echo $GLOBALS[COLOR_TEXT_TITLE];
                              }
                              ?>'>
                              <b>
                                 <?php echo $text; ?>
                              </b>
                        </font>
                    </td>
                </tr>
         <?php
}
##################### Table-Header ##################### ---
#
#
##################### Forum Msg�s ##################### +++
function msg($text, $time="", $goto="") {

         //wenn kein php? dann php? ran h�ngen
         if ($goto == "back()") {
             $goto="javascript:history.back()";
         }
         echo "<br>";
         open_table("phpForum - Mitteilung","60%");

                     echo "<FONT SIZE='$GLOBALS[FONT_SIZE]'>$text</font>";
                     if ($goto != "") {
                         echo "<p align='center'>
                                  <a href='$goto'>
                                     <FONT SIZE='$GLOBALS[FONT_SIZE_COMMENT]'>
                                           Klicken sie hier, wenn sie nicht l&auml;nger warten wollen.<br>
                                           (oder wenn ihr Browser keine automatische Weiterleitung unterst&uuml;tzt)
                                     </font>
                                  </a>
                               </p>";
                     }
         close_table("");
         echo "<br>";
         //wenn goto �bergeben dann gehe dahin nach Zeit "time"
         if ($goto != "") {
             echo "<meta http-equiv='Refresh' content='$time;URL=$goto'>";
         }
         exit();
}
##################### Forum Msg�s ##################### ---
#
#
################################################################################
################################ Funktionen #################################### ---
################################################################################
#
#
################################################################################
############################### SQL-Query�s #################################### +++
################################################################################
function sql ($step) {
         include("../config.inc.php");
         $query = array();

         if ($step == "create") {
             $query[$TB_ACCESS] = "CREATE TABLE $TB_ACCESS (
                                          id int(10) NOT NULL auto_increment,
                                          special char(2) NOT NULL default '',
                                          data mediumtext NOT NULL,
                                          name varchar(50) NOT NULL default '',
                                          view char(2) NOT NULL default 'on',
                                          login char(2) NOT NULL default 'on',
                                          send_pm char(2) NOT NULL default 'on',
                                          edit_profil char(2) NOT NULL default 'on',
                                          avatar char(2) NOT NULL default 'on',
                                          send_mail char(2) NOT NULL default 'on',
                                          show_members char(2) NOT NULL default 'on',
                                          del_post char(2) NOT NULL default 'on',
                                          search char(2) NOT NULL default 'on',
                                          edit_post char(2) NOT NULL default 'on',
                                          new_post char(2) NOT NULL default 'on',
                                          new_topic char(2) NOT NULL default 'on',
                                          mod_openclose char(2) NOT NULL default '',
                                          mod_move_topic char(2) NOT NULL default '',
                                          mod_edit char(2) NOT NULL default '',
                                          mod_del char(2) NOT NULL default '',
                                          mod_join char(2) NOT NULL default '',
                                          mod_move_post char(2) NOT NULL default '',
                                          mod_top char(2) NOT NULL default '',
                                          admin_settings char(2) NOT NULL default '',
                                          admin_cats char(2) NOT NULL default '',
                                          admin_forums char(2) NOT NULL default '',
                                          admin_announcements char(2) NOT NULL default '',
                                          admin_users char(2) NOT NULL default '',
                                          admin_user_groups char(2) NOT NULL default '',
                                          admin_user_titles char(2) NOT NULL default '',
                                          admin_smilies char(2) NOT NULL default '',
                                          admin_bbcodes char(2) NOT NULL default '',
                                          admin_status char(2) NOT NULL default '',
                                          admin_words char(2) NOT NULL default '',
                                          admin_styles char(2) NOT NULL default '',
                                          PRIMARY KEY (id)
                                   ) TYPE=MyISAM;";

             $query[$TB_FILES] = "CREATE TABLE $TB_FILES (
                                         post_id int(11) NOT NULL default '0',
                                         name varchar(255) NOT NULL default '',
                                         data mediumtext NOT NULL,
                                         typ varchar(255) NOT NULL default '',
                                         views int(11) NOT NULL default '0',
                                         PRIMARY KEY (post_id)
                                  ) TYPE=MyISAM;";
             $query[$TB_AVATARS] = "CREATE TABLE $TB_AVATARS (
                                           user_id int(11) NOT NULL default '0',
                                           data mediumtext NOT NULL,
                                           name varchar(255) NOT NULL default '',
                                           PRIMARY KEY (user_id)
                                    ) TYPE=MyISAM;";
             $query[$TB_BBCODES] = "CREATE TABLE $TB_BBCODES (
                                           id int(11) NOT NULL auto_increment,
                                           name varchar(255) NOT NULL default '',
                                           info text NOT NULL,
                                           search varchar(255) NOT NULL default '',
                                           replacement varchar(255) NOT NULL default '',
                                           example varchar(255) NOT NULL default '',
                                           repeat char(2) NOT NULL default '',
                                           repeat_replace varchar(255) NOT NULL default '',
                                           PRIMARY KEY (id)
                                    ) TYPE=MyISAM;";
             $query[$TB_CAT] = "CREATE TABLE $TB_CAT (
                                       id int(10) NOT NULL auto_increment,
                                       name varchar(255) default NULL,
                                       show_cat char(2) NOT NULL default 'on',
                                       rang int(11) default NULL,
                                       PRIMARY KEY (id)
                                ) TYPE=MyISAM;";
             $query[$TB_FORUM] = "CREATE TABLE $TB_FORUM (
                                         id int(11) NOT NULL auto_increment,
                                         name varchar(255) NOT NULL default '',
                                         info text NOT NULL,
                                         rang int(11) NOT NULL default '0',
                                         cat_id int(11) NOT NULL default '0',
                                         show_forum char(2) NOT NULL default 'on',
                                         topics int(11) NOT NULL default '0',
                                         posts int(11) NOT NULL default '0',
                                         last_topic int(11) NOT NULL default '0',
                                         html char(2) NOT NULL default 'on',
                                         bbcodes char(2) NOT NULL default 'on',
                                         smilies char(2) NOT NULL default 'on',
                                         files char(2) NOT NULL default 'on',
                                         polls char(2) NOT NULL default 'on',
                                         options char(2) NOT NULL default 'on',
                                         PRIMARY KEY (id),
                                         KEY cat_id (cat_id)
                                  ) TYPE=MyISAM;";
             $query[$TB_FORUM_ACCESS] = "CREATE TABLE $TB_FORUM_ACCESS (
                                                forum_id int(11) NOT NULL default '0',
                                                access_id int(11) NOT NULL default '0',
                                                view char(2) NOT NULL default 'on',
                                                del_post char(2) NOT NULL default 'on',
                                                edit_post char(2) NOT NULL default 'on',
                                                new_post char(2) NOT NULL default 'on',
                                                new_topic char(2) NOT NULL default 'on',
                                                mod_openclose char(2) NOT NULL default '',
                                                mod_move_topic char(2) NOT NULL default '',
                                                mod_edit char(2) NOT NULL default '',
                                                mod_del char(2) NOT NULL default '',
                                                mod_join char(2) NOT NULL default '',
                                                mod_move_post char(2) NOT NULL default '',
                                                mod_top char(2) NOT NULL default '',
                                                PRIMARY KEY (forum_id,access_id)
                                         ) TYPE=MyISAM;";
             $query[$TB_MOD] = "CREATE TABLE $TB_MOD (
                                       forum_id int(11) NOT NULL default '0',
                                       user_id int(11) NOT NULL default '0',
                                       mod_openclose char(2) NOT NULL default 'on',
                                       mod_move_topic char(2) NOT NULL default 'on',
                                       mod_edit char(2) NOT NULL default 'on',
                                       mod_del char(2) NOT NULL default 'on',
                                       mod_join char(2) NOT NULL default 'on',
                                       mod_move_post char(2) NOT NULL default 'on',
                                       mod_top char(2) NOT NULL default 'on',
                                       PRIMARY KEY (forum_id,user_id)
                                ) TYPE=MyISAM;";
             $query[$TB_POLL] = "CREATE TABLE $TB_POLL (
                                        id int(11) NOT NULL auto_increment,
                                        name char(255) NOT NULL default '',
                                        topic_id int(10) NOT NULL default '0',
                                        date date NOT NULL default '0000-00-00',
                                        PRIMARY KEY (id)
                                 ) TYPE=MyISAM;";
             $query[$TB_POLL_TEXT] = "CREATE TABLE $TB_POLL_TEXT (
                                             id int(11) NOT NULL auto_increment,
                                             poll_id int(11) NOT NULL default '0',
                                             text char(255) NOT NULL default '',
                                             PRIMARY KEY (id)
                                      ) TYPE=MyISAM;";
             $query[$TB_POLL_USER] = "CREATE TABLE $TB_POLL_USER (
                                             text_id int(11) NOT NULL default '0',
                                             user_id int(11) NOT NULL default '0',
                                             PRIMARY KEY  (user_id,text_id)
                                      ) TYPE=MyISAM;";
             $query[$TB_POST] = "CREATE TABLE $TB_POST (
                                        id int(11) NOT NULL auto_increment,
                                        user_id varchar(255) NOT NULL default '',
                                        post_date datetime NOT NULL default '0000-00-00 00:00:00',
                                        text text NOT NULL,
                                        topic_id varchar(255) NOT NULL default '',
                                        edit varchar(255) NOT NULL default '',
                                        html char(2) NOT NULL default 'on',
                                        bbcodes char(2) NOT NULL default 'on',
                                        smilies char(2) NOT NULL default 'on',
                                        ip varchar(15) NOT NULL default '',
                                        KEY ID (id)
                                 ) TYPE=MyISAM;";
             $query[$TB_MSG] = "CREATE TABLE $TB_MSG (
                                       id int(10) NOT NULL auto_increment,
                                       from_id int(10) NOT NULL default '0',
                                       to_id int(10) NOT NULL default '0',
                                       date datetime NOT NULL default '0000-00-00 00:00:00',
                                       status int(1) default '0',
                                       name varchar(255) NOT NULL default '',
                                       text text NOT NULL,
                                       html char(2) NOT NULL default 'on',
                                       bbcodes char(2) NOT NULL default 'on',
                                       smilies char(2) NOT NULL default 'on',
                                       PRIMARY KEY (id),
                                       KEY msg_id (id),
                                       KEY to_userid (to_id)
                                ) TYPE=MyISAM;";
             $query[$TB_SEARCH] = "CREATE TABLE $TB_SEARCH (
                                          id int(11) NOT NULL auto_increment,
                                          user_id int(11) NOT NULL default '0',
                                          date datetime NOT NULL default '0000-00-00 00:00:00',
                                          name varchar(255) NOT NULL default '',
                                          sql text NOT NULL,
                                          PRIMARY KEY (id),
                                          KEY user_id (user_id)
                                   ) TYPE=MyISAM;";
             $query[$TB_SESSION] = "CREATE TABLE $TB_SESSION (
                                           sess char(255) NOT NULL default '',
                                           host char(15) NOT NULL default '0',
                                           uid int(11) NOT NULL default '0',
                                           action char(14) NOT NULL default ''
                                    ) TYPE=MyISAM;";
             $query[$TB_SETTING_GROUP] = "CREATE TABLE $TB_SETTING_GROUP (
                                                 id int(11) NOT NULL auto_increment,
                                                 name char(255) NOT NULL default '',
                                                 PRIMARY KEY (id)
                                          ) TYPE=MyISAM;";
             $query[$TB_SETTINGS] = "CREATE TABLE $TB_SETTINGS (
                                            id int(11) NOT NULL auto_increment,
                                            cid int(11) NOT NULL default '0',
                                            name varchar(255) NOT NULL default '',
                                            value text NOT NULL,
                                            titel varchar(255) NOT NULL default '',
                                            info text NOT NULL,
                                            typ varchar(255) NOT NULL default '',
                                            len varchar(255) NOT NULL default '',
                                            PRIMARY KEY (id),
                                            KEY cid (cid)
                                     ) TYPE=MyISAM;";
             $query[$TB_SMILIES] = "CREATE TABLE $TB_SMILIES (
                                           id int(11) NOT NULL auto_increment,
                                           name varchar(255) NOT NULL default '',
                                           code varchar(10) NOT NULL default '',
                                           data mediumtext NOT NULL,
                                           typ varchar(255) NOT NULL default '',
                                           filename varchar(255) NOT NULL default '',
                                           PRIMARY KEY  (id)
                                    ) TYPE=MyISAM;";
             $query[$TB_STATUS] = "CREATE TABLE $TB_STATUS (
                                          id int(11) NOT NULL auto_increment,
                                          data mediumtext NOT NULL,
                                          name char(255) NOT NULL default '',
                                          points decimal(200,0) NOT NULL default '0',
                                          PRIMARY KEY  (id)
                                   ) TYPE=MyISAM;";
             $query[$TB_STYLES] = "CREATE TABLE $TB_STYLES (
                                          id int(11) NOT NULL auto_increment,
                                          name varchar(50) NOT NULL default '',
                                          active char(2) NOT NULL default '',
                                          choice char(2) NOT NULL default 'on',
                                          head_insert text NOT NULL,
                                          header text NOT NULL,
                                          footer text NOT NULL,
                                          html_type varchar(255) NOT NULL default '',
                                          body_extra varchar(255) NOT NULL default '',
                                          textarea_width tinyint(4) NOT NULL default '0',
                                          textarea_height tinyint(4) NOT NULL default '0',
                                          default_table text NOT NULL,
                                          default_tr text NOT NULL,
                                          cat_table text NOT NULL,
                                          cat_tr text NOT NULL,
                                          table_inset text NOT NULL,
                                          font_big text NOT NULL,
                                          font_normal text NOT NULL,
                                          font_small text NOT NULL,
                                          font_fault text NOT NULL,
                                          cat_one text NOT NULL,
                                          cat_two text NOT NULL,
                                          pic_last_post varchar(255) NOT NULL default '',
                                          pic_new_post varchar(255) NOT NULL default '',
                                          pic_new_topic varchar(255) NOT NULL default '',
                                          pic_topic_abo varchar(255) NOT NULL default '',
                                          pic_closed varchar(255) NOT NULL default '',
                                          pic_pm_new varchar(255) NOT NULL default '',
                                          pic_pm_readall varchar(255) NOT NULL default '',
                                          pic_pm_delall varchar(255) NOT NULL default '',
                                          pic_pm_reply varchar(255) NOT NULL default '',
                                          pic_profile varchar(255) NOT NULL default '',
                                          pic_pm varchar(255) NOT NULL default '',
                                          pic_home varchar(255) NOT NULL default '',
                                          pic_mail varchar(255) NOT NULL default '',
                                          pic_search varchar(255) NOT NULL default '',
                                          pic_quote varchar(255) NOT NULL default '',
                                          pic_edit varchar(255) NOT NULL default '',
                                          pic_ip varchar(255) NOT NULL default '',
                                          pic_on varchar(255) NOT NULL default '',
                                          pic_on_lock varchar(255) NOT NULL default '',
                                          pic_off varchar(255) NOT NULL default '',
                                          pic_off_lock varchar(255) NOT NULL default '',
                                          pic_post_on varchar(255) NOT NULL default '',
                                          pic_post_off varchar(255) NOT NULL default '',
                                          pic_file varchar(255) NOT NULL default '',
                                          pic_pm_status varchar(255) NOT NULL default '',
                                          pic_admin_up varchar(255) NOT NULL default '',
                                          pic_admin_down varchar(255) NOT NULL default '',
                                          pic_admin_del varchar(255) NOT NULL default '',
                                          pic_poll_l varchar(255) NOT NULL default '',
                                          pic_poll_m varchar(255) NOT NULL default '',
                                          pic_poll_r varchar(255) NOT NULL default '',
                                          PRIMARY KEY (id)
                                   ) TYPE=MyISAM;";
             $query[$TB_ABO] = "CREATE TABLE $TB_ABO (
                                       topic_id int(11) NOT NULL default '0',
                                       user_id int(11) NOT NULL default '0',
                                       send_date datetime NOT NULL default '0000-00-00 00:00:00',
                                       PRIMARY KEY  (topic_id,user_id)
                                ) TYPE=MyISAM;";
             $query[$TB_TOPIC] = "CREATE TABLE $TB_TOPIC (
                                         id int(11) NOT NULL auto_increment,
                                         name varchar(100) NOT NULL default '',
                                         post_date datetime NOT NULL default '0000-00-00 00:00:00',
                                         poster_id varchar(255) NOT NULL default '',
                                         forum_id varchar(255) NOT NULL default '',
                                         posts int(11) NOT NULL default '0',
                                         top int(1) NOT NULL default '0',
                                         views int(11) NOT NULL default '0',
                                         show_topic char(2) NOT NULL default 'on',
                                         closed char(2) NOT NULL default '',
                                         PRIMARY KEY  (id)
                                  ) TYPE=MyISAM;";
             $query[$TB_USER] = "CREATE TABLE $TB_USER (
                                        id int(11) NOT NULL auto_increment,
                                        pass varchar(32) NOT NULL default '',
                                        reg date NOT NULL default '0000-00-00',
                                        name varchar(50) NOT NULL default '',
                                        geb date NOT NULL default '0000-00-00',
                                        gender char(1) NOT NULL default 'm',
                                        job varchar(255) NOT NULL default '',
                                        location varchar(255) NOT NULL default '',
                                        homepage varchar(255) NOT NULL default '',
                                        email varchar(255) NOT NULL default '',
                                        icq varchar(20) NOT NULL default '',
                                        aim varchar(255) NOT NULL default '',
                                        yim varchar(255) NOT NULL default '',
                                        sign text NOT NULL,
                                        access_id int(11) NOT NULL default '0',
                                        points int(11) NOT NULL default '0',
                                        last_post int(11) NOT NULL default '0',
                                        last_login datetime NOT NULL default '0000-00-00 00:00:00',
                                        pm_email char(2) NOT NULL default 'on',
                                        pm_popup char(2) NOT NULL default 'on',
                                        pm_popup_show char(2) NOT NULL default 'on',
                                        bbcodes_show char(2) NOT NULL default 'on',
                                        html_show char(2) NOT NULL default 'on',
                                        smilies_show char(2) NOT NULL default 'on',
                                        sign_show char(2) NOT NULL default 'on',
                                        post_email char(2) NOT NULL default 'on',
                                        email_show char(2) NOT NULL default 'on',
                                        stay_login char(2) NOT NULL default 'on',
                                        pm_footer char(2) NOT NULL default 'on',
                                        style int(11) NOT NULL default '0',
                                        PRIMARY KEY  (id)
                                 ) TYPE=MyISAM;";

             $query[$TB_WORDS] = "CREATE TABLE $TB_WORDS (
                                         id int(11) NOT NULL auto_increment,
                                         search char(255) NOT NULL default '',
                                         replacement char(255) NOT NULL default '',
                                         PRIMARY KEY  (id)
                                  ) TYPE=MyISAM;";

         } elseif ($step == "insert_access") {
                   $query[] = "INSERT INTO $TB_ACCESS (id, special, data, name, view, login, send_pm, edit_profil, avatar, send_mail, show_members, del_post, search, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top, admin_settings, admin_cats, admin_forums, admin_announcements, admin_users, admin_user_groups, admin_user_titles, admin_smilies, admin_bbcodes, admin_status, admin_words, admin_styles) VALUES (1, 'on', '', '- Gesperrt -', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');";
                   $query[] = "INSERT INTO $TB_ACCESS (id, special, data, name, view, login, send_pm, edit_profil, avatar, send_mail, show_members, del_post, search, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top, admin_settings, admin_cats, admin_forums, admin_announcements, admin_users, admin_user_groups, admin_user_titles, admin_smilies, admin_bbcodes, admin_status, admin_words, admin_styles) VALUES (2, 'on', '', 'Anonymous', 'on', 'on', '', '', '', '', 'on', '', 'on', '', 'on', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');";
                   $query[] = "INSERT INTO $TB_ACCESS (id, special, data, name, view, login, send_pm, edit_profil, avatar, send_mail, show_members, del_post, search, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top, admin_settings, admin_cats, admin_forums, admin_announcements, admin_users, admin_user_groups, admin_user_titles, admin_smilies, admin_bbcodes, admin_status, admin_words, admin_styles) VALUES (3, 'on', 'admin.gif', 'Administrator', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', '', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on');";
                   $query[] = "INSERT INTO $TB_ACCESS (id, special, data, name, view, login, send_pm, edit_profil, avatar, send_mail, show_members, del_post, search, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top, admin_settings, admin_cats, admin_forums, admin_announcements, admin_users, admin_user_groups, admin_user_titles, admin_smilies, admin_bbcodes, admin_status, admin_words, admin_styles) VALUES (4, 'on', 'co.gif', 'Co-Admin', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', '', '', '', '', '', '', '', '', '', 'on', '', '');";
                   $query[] = "INSERT INTO $TB_ACCESS (id, special, data, name, view, login, send_pm, edit_profil, avatar, send_mail, show_members, del_post, search, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top, admin_settings, admin_cats, admin_forums, admin_announcements, admin_users, admin_user_groups, admin_user_titles, admin_smilies, admin_bbcodes, admin_status, admin_words, admin_styles) VALUES (5, 'on', 'mod.gif', 'Super-Moderator', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', '', '', '', '', '', '', '', '', '', '', '', '');";
                   $query[] = "INSERT INTO $TB_ACCESS (id, special, data, name, view, login, send_pm, edit_profil, avatar, send_mail, show_members, del_post, search, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top, admin_settings, admin_cats, admin_forums, admin_announcements, admin_users, admin_user_groups, admin_user_titles, admin_smilies, admin_bbcodes, admin_status, admin_words, admin_styles) VALUES (6, '', '', 'Member', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');";
         } elseif ($step == "insert_bbcodes") {
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (1, 'Unterstrichen', 'Text unterstrichen anzeigen', '[u]\\\\1[/u]', '<u>\\\\1</u>', '[u]phpForum.ath.cx[/u]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (2, 'Fett', 'hiermit kann der Text Fett geschrieben werden', '[b]\\\\1[/b]', '<b>\\\\1</b>', '[b]phpForum.ath.cx[/b]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (3, 'Kursiv', 'Text Kursiv anzeigen', '[i]\\\\1[/i]', '<i>\\\\1</i>', '[i]phpForum.ath.cx[/i]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (4, 'Bild', '', '[img]\\\\1[/img]', '<img src=\'\\\\1\' border=\'0\'>', '[img]http://phpForum.ath.cx/phpforum.jpg[/img]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (5, 'Hyperlink (einfach)', '', '[url]\\\\1[/url]', '<a href=\'\\\\1\' target=\'_blank\'>\\\\1</a>', '[url]http://phpForum.ath.cx[/url]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (6, 'Hyperlink (erweitert)', '', '[url=\\\\1]\\\\2[/url]', '<a href=\'\\\\1\' target=\'_blank\'>\\\\2</a>', '[url=http://phpForum.ath.cx]phpForum Homepage[/url]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (7, 'Schriftart', '', '[font=\\\\1]\\\\2[/font]', '<font face=\'\\\\1\'>\\\\2</font>', '[font=arial]dieser Text ist Arial[/font]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (8, 'Schriftfarbe', '', '[color=\\\\1]\\\\2[/color]', '<font color=\'\\\\1\'>\\\\2</font>', '[color=red]dieser Text ist rot[/color]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (9, 'Schriftgr��e', '', '[size=\\\\1]\\\\2[/size]', '<font size=\'\\\\1\'>\\\\2</font>', '[size=4]dieser Text ist gr�&szlig;[/size]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (10, 'Zitat', '', '[quote]\\\\1[/quote]', '<blockquote><font face=verdana,arial,helvetica size=1>zitat:</font><hr>\\\\1<hr></blockquote>', '[quote]dieser Text wurde zitiert[/quote]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (11, 'eMail + Name', '', '[email=\\\\1]\\\\2[/email]', '<a href=\'mailto:\\\\1\'>\\\\2</a>', '[email=Christoph Roeder@gmx.net]Christoph Roeder[/email]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (12, 'eMail (einfach)', '', '[email]\\\\1[/email]', '<a href=\'mailto:\\\\1\'>\\\\1</a>', '[email]Christoph Roeder@gmx.net[/email]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (13, 'Ausrichtung', '', '[align=\\\\1]\\\\2[/align]', '<div align=\'\\\\1\'>\\\\2</div>', '[align=center]Zentriert ausgerichtet[/align]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (14, 'Quell Code', '', '[code]\\\\1[/code]', '<blockquote><font face=verdana,arial,helvetica size=1>code:</font><hr><font face=Courier New, Courier, mono>\\\\1</font><hr></blockquote>', '[code]Quellcode[/code]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (15, 'Liste (nummeriert)', '', '[list=1]\\\\1[/list=1]', '<ol>\\\\1</ol>', '[list=1][*]eins[*]zwei[/list=1]', 'on', '<li>\\\\1');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (16, 'Liste (punkte)', '', '[list=a]\\\\1[/list=a]', '<ul>\\\\1</ul>', '[list=a][*]eins[*]zwei[/list=a]', 'on', '<li>\\\\1');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (17, 'Rahmen', 'erzeugt einen Rahmen mit einer �berschrift.', '[field=\\\\1]\\\\2[/field]', '<fieldset><legend>\\\\1</legend>\\\\2</fieldset>', '[field=&Uuml;berschrift]Text[/field]', '', '');";
                   $query[] = "INSERT INTO $TB_BBCODES (id, name, info, search, replacement, example, repeat, repeat_replace) VALUES (18, 'Zitat (mit Ersteller Hinweis)', '', '[quote=\\\\1]\\\\2[/quote]', '<blockquote><font face=verdana,arial,helvetica size=1>zitat von \\\\1:</font><hr>\\\\2<hr></blockquote>', '[quote=Christoph Roeder]Zitat[/quote]', '', '');";
         } elseif ($step == "insert_categories") {
                   $query[] = "INSERT INTO $TB_CAT (id, name, show_cat, rang) VALUES (1, 'Kategorie', 'on', 1);";
         } elseif ($step == "insert_forums") {
                   $query[] = "INSERT INTO $TB_FORUM (id, name, info, rang, cat_id, show_forum, topics, posts, last_topic, html, bbcodes, smilies, files, polls, options) VALUES (1, 'Forum', 'Beschreibung', 1, 1, 'on', 0, 0, 0, 'on', 'on', 'on', 'on', 'on', 'on');";
         } elseif ($step == "insert_forum_access") {
                   $query[] = "INSERT INTO $TB_FORUM_ACCESS (forum_id, access_id, view, del_post, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top) VALUES (1, 1, '', '', '', '', '', '', '', '', '', '', '', '');";
                   $query[] = "INSERT INTO $TB_FORUM_ACCESS (forum_id, access_id, view, del_post, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top) VALUES (1, 2, 'on', '', '', 'on', '', '', '', '', '', '', '', '');";
                   $query[] = "INSERT INTO $TB_FORUM_ACCESS (forum_id, access_id, view, del_post, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top) VALUES (1, 3, 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on');";
                   $query[] = "INSERT INTO $TB_FORUM_ACCESS (forum_id, access_id, view, del_post, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top) VALUES (1, 4, 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on');";
                   $query[] = "INSERT INTO $TB_FORUM_ACCESS (forum_id, access_id, view, del_post, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top) VALUES (1, 5, 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on');";
                   $query[] = "INSERT INTO $TB_FORUM_ACCESS (forum_id, access_id, view, del_post, edit_post, new_post, new_topic, mod_openclose, mod_move_topic, mod_edit, mod_del, mod_join, mod_move_post, mod_top) VALUES (1, 6, 'on', 'on', 'on', 'on', 'on', '', '', '', '', '', '', '');";
         } elseif ($step == "insert_settings_group") {
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (1, 'Allgemeine Einstellungen');";
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (2, 'Kontakt Informationen');";
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (3, 'Benutzer- und Registrierungseinstellungen');";
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (6, 'Anmeldung & Cookies');";
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (7, 'Zahlen & Fakten');";
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (10, 'Beitr�ge & Themen');";
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (11, 'Private Nachrichten');";
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (12, 'Kompression');";
                   $query[] = "INSERT INTO $TB_SETTING_GROUP (id, name) VALUES (13, 'Zugriffskontrolle');";
         } elseif ($step == "insert_settings") {
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (1, 2, 'SITE_ADMIN', 'killergod2000@gmx.net', 'eMail-Adresse des WebMasters', '', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (4, 1, 'TITEL', 'phpForum die Kostenlose Forum-Software', 'Text der Titelleiste', 'dies ist die \"lang\"-Beschreibung des Forums f�r die Titel-Leiste', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (6, 1, 'TITEL_KURZ', 'phpForum', 'Forum Bezeichnung', 'diese Bezeichnug ist auf jeder Seite des Forums sichtbar', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (8, 10, 'ANZ_TOPIC', '5', 'Anzahl Topics pro Seite', 'Dies ist die Anzahl an Themen in einem Forum bis eine neue Seite beginnt.', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (9, 10, 'ANZ_POST', '20', 'Anzahl Posts pro Seite', 'Dies ist die Anzahl an Beitr�gen pro Seite in einem Thema bis eine neue Seite beginnt.', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (10, 7, 'ANZ_MEMBERS', '10', 'Anzahl Members pro Seite', 'Dies ist die Anzahl an Benutzern in der \"Member-Liste\" bis eine neue Seite beginnt.', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (11, 7, 'ANZ_PM', '20', 'Anzahl der PM�pro Benutzer', 'Nach �berschreiten dieses Limit�s erh�lt der Benutzer eine eMail mit dem Hinweis zum l�schen alter Nachrichten.', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (12, 7, 'PIC_X', '100', 'Maximale Avatar/Grafik Dimension (x)', 'max. Aufl�sung eines Benutzer-Bildes in der X-Achse', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (13, 7, 'PIC_Y', '100', 'Maximale Avatar/Grafik Dimension (y)', 'max. Aufl�sung eines Benutzer-Bildes in der Y-Achse', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (14, 6, 'COOKIE_TIME', '2592000', 'Cookie \"Lebensdauer\"', 'dies ist die Zeit in sec. wie lange ein Cookie g�ltig ist', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (33, 6, 'TIMEOUT', '180', 'Who is Online', 'Zeit in sec. wie lange ein Benutzer in der Liste \"Who is Online\" bleibt', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (34, 6, 'PUBLIC_BOARD', 'on', 'Forum �ffentlich ?', 'Kann man als anonymer Benutzer auf das Forum zugreifen?', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (35, 10, 'FILE_TYPES', 'jpg gif pdf doc zip txt ace rar', 'Datei Anh�nge', 'Hier k�nnen Datei-Typen angegeben werden die f�r Dateianh�nge erlaubt sind.\r\n(mit Leerzeichen trennen)', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (38, 6, 'DEFAULT_USER_GROUP', '6', '\"Standard\" Benutzergruppe', 'Dieser Benutzergruppe wird ein neu angemeldeter Benutzer zugeordnet.', 'access', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (39, 6, 'NO_LOGIN', '2', 'nicht Eingeloggt', 'Dies ist die Beutzergruppe eines nicht eingeloggten Benutzer.', 'access', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (43, 10, 'SMILIES_LIST', '10', 'Smilie Liste', 'dies ist die Anzahl der Smilies bei neuen Beitr�gen / Themen die in der \"Smilie-Liste\" angezeigt werden.<br>\r\n(0 = alle anzeigen)', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (45, 10, 'POLL_LIMIT', '10', 'Poll Antworten', 'Maximale Anzahl der Antworten bei Umfragen.', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (46, 10, 'VIEW_FORUM_RULEZ', 'on', 'Forum Regeln anzeigen', 'Ist diese Option aktiviert wird in jedem Forum / Thema dem Benutzer angezeigt welche Rechte er hat.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (47, 10, 'VIEW_FORUM_HISTORY', 'on', 'Forums \"History\" anzeigen', 'Ist diese Option aktiviert wird beim erstellen eines Beitrages eine �bersicht der letzten Antworten angezeigt.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (48, 10, 'SMILIES_ZEILE', '3', 'Smilie pro Zeile', '', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (49, 10, 'UPLOAD_SIZE', '1048576', 'max. Upload Dateigr��e', 'Die max. Dateigr��e f�r Dateien die auf den Server gespeichert werden. (Angabe in Bytes)', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (51, 7, 'ADMIN_SMILIES_ANZ', '3', 'Anzahl Smilies im Admin', 'dies ist die Anzahl an Smilies pro Zeile  im Admin-Kontrollzentrum', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (52, 2, 'META_KEYWORDS', 'Forum, PHP, mySQL, Programmieren, Kostenlos', 'Meta Suchw�rter', '', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (53, 2, 'META_DESCRIPTION', '-= phpForum - das Kostenlose Forum =-', 'Meta Beschreibung', '', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (59, 3, 'SIGN_HTML', '', 'HTML in der Signatur erlauben', '', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (60, 3, 'SIGN_BBCODES', 'on', 'Board-Codes in der Signatur erlauben', '', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (61, 3, 'SIGN_SMILIES', 'on', 'Smilies in der Signatur erlauben', '', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (62, 3, 'REG_DISCLAIMER', 'on', 'Registrierungs-Vereinbarung anzeigen', 'Ist diese Option aktiviert muss der Benutzer vor einer Registrierung die Registrierungs-Vereinbarung akzeptieren.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (63, 3, 'DISCLAIMER', 'Die Registrierung und Benutzung unserer Foren ist kostenlos! Wenn sie die hier genannten Regeln und Erkl�rungen anerkennen, klicken sie auf \"Akzeptieren\", danach k&auml;nnen sie sich registrieren. \r\n\r\nObwohl die Administratoren und Moderatoren versuchen, alle unerw�nschten Beitr�ge/Nachrichten von diesem Forum fernzuhalten, ist es f�r uns unm�glich, alle Beitr�ge/Nachrichten zu �berpr�fen. Alle Beitr�ge/Nachrichten dr�cken die Ansichten des Autors aus und nicht des Besitzer des phpForum oder <a href=\'http://phpforum.ath.cx\'>Christoph Roeder</a> (Entwickler vom phpForum) k�nnen nicht f�r den Inhalt jedes Beitrags verantwortlich gemacht werden.\r\n\r\nDurch das Klicken des Annahme Knopfes, garantieren sie, dass sie keine Nachrichten schreibst, die obsz�n, vulg�r, sexuell orientiert, abscheulich oder bedrohlich sind oder sonst gegen ein Gesetz verstossen w�rden.\r\n\r\nDer Besitzer des phpForums hat das Recht, Themen und Beitr�ge zu l�schen, zu bearbeiten, zu verschieben oder zu schliessen.', 'Registrierungs-Vereinbarung', '', 'textarea', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (87, 1, 'ALLOW_FILE_UPLOADS', 'on', 'Datei Uploads erlauben?', 'W�hlen sie hier ja um Datei-Uploads f�r  z.B. Avatare zu erlauben.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (88, 11, 'PM_BBCODES', 'on', 'Board Codes aktivieren?', 'W�hlen sie hier ja um Board Codes in PM�s zu aktivieren.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (89, 11, 'PM_SMILIES', 'on', 'Smilies aktivieren?', 'W�hlen sie hier ja um Smilies in PM�s zu aktivieren.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (90, 11, 'PM_OPTIONS', 'on', 'Optionen aktivieren?', 'W�hlen sie hier ja um die Optionen in PM�s zu aktivieren.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (91, 12, 'GZ_COMPRESS', 'on', 'Kompression aktiv?', 'Wenn sie diese Option aktivierst, wird das phpForum alle Seiten mit GZIP komprimieren um Bandbreite zu sparen. Die komprimierten Seiten werden nur an Benutzer geschickt, deren Browser HTTP 1.1 unterst�tzen. Es gibt allerdings Leistungseinbu�en aufgrund des Komprimierens. Um diese Option benutzen zu k�nnen, muss der Server PHP 4.0.1 oder h�her und die ZLIB Library haben.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (92, 12, 'GZ_LEVEL', '9', 'Kompressionslevel', '0=keine Kompression<br>\r\n9=maximale Kompression', 'list', '0-9');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (93, 7, 'MEMBERS_SORT', 'name', 'Standard-Sortierung in der Member-Liste', 'name = Benutzername<br>\r\nreg = Registrations<br>\r\npoints = Beitr�ge', 'select', 'name,reg,points');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (94, 7, 'MEMBERS_ORDER', 'ASC', 'Sortier-Reihenfolge in der Member-Liste', 'ASC = Aufw&auml;hrts<br>\r\nDESC = Abw&auml;hrts', 'select', 'ASC,DESC');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (96, 3, 'REG_NEW', 'on', 'Registrierungen erlauben?', 'W&auml;hlen sie hier nein wenn sich im Moment keine weiteren Benutzer im Forum registrieren d&uuml;rfen.', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (98, 3, 'REG_NEW_TEXT', 'Die Registrierung ist zur Zeit nicht m�glich...', 'Begr&uuml;ndung f&uuml;r Registrierungs-Stop', 'Begr�nden sie hier warum sie im Moment keine weiteren Registrierungen erlauben.', 'textarea', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (99, 6, 'COOKIE_DOMAIN', '/', 'Cookie Pfad', 'Wenn sie mehrere phpForen auf dem selben Server / Dom�ne betreiben, m�ssen sie das relative Verzeichnisse des Boards angeben. Sonst lassen sie einfach \'/\' stehen.', 'text', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (100, 13, 'BANNED_IP', '', 'Verbotene IP-Adressen', 'Tragen sie hier die IPs ein die keinen Zugriff auf das Forum haben sollen.<br>\r\nUm eine einzelne IP zu sperren geben sie diese vollst&auml;ndig ein, z.B. 192.168.0.1<br>\r\nUm einen Bereich von IPs zu sperren geben sie nur den Anfang der IP ein, z.B. 192.168.0<br><b>Pro Zeile nur eine IP!</b>', 'textarea', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (101, 13, 'BANNED_NAMES', '', 'Verbotene Benutzernamen', 'Geben sie hier Benutzernamen ein, die f�r eine Registrierung unzul�ssig sind. Wenn der hier eingegebene Name ein Bestandteil des Benutzernamens ist, bekommt der Benutzer eine Fehlermeldung bei der Registrierung.<br><b>Pro Zeile nur ein Benutzername!</b>', 'textarea', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (102, 1, 'CLOSED_BOARD', '', 'Forum geschlossen?', 'W&auml;hlen sie hier ja um das Forum Zeitweise f�r nicht Administratoren zu schliessen. Dies ist besonders f�r Foren-Updates zu empfehlen!', 'radio', '');";
                   $query[] = "INSERT INTO $TB_SETTINGS (id, cid, name, value, titel, info, typ, len) VALUES (103, 1, 'CLOSED_BOARD_TEXT', 'Das Forum ist Zeitweise geschlossen, da momentan die Foren-Software aktualisiert wird.<br>Bitte versuchen sie es sp�ter noch einmal.', 'Forum geschlossen - Begr&uuml;ndung', 'Hier k&ouml;nnen sie eine Begr&uuml;ndung f&uuml;r das geschlossene Forum angeben, diese wird den Besuchern f&uuml;r die Zeit der Schlie&szlig;ung angezeigt.', 'textarea', '');";
         } elseif ($step == "insert_smilies") {
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (1, 'Verwirt', ':confused:', 'image/gif', 'confused.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (2, 'Cool', ':cool:', 'image/gif', 'cool.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (3, 'geschockt', ':shock:', 'image/gif', 'eek.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (4, 'F*****', ':xxx:', 'image/gif', 'ficken.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (5, 'Heulen', ':heul:', 'image/gif', 'heul.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (6, 'K&uuml;ssen', ':kiss:', 'image/gif', 'kiss.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (7, 'K*****', ':kotz:', 'image/gif', 'kotz.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (8, 'Lachen', ':D', 'image/gif', 'laught.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (9, 'Verliebt', ':love:', 'image/gif', 'love.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (10, 'W�tend', ':mad:', 'image/gif', 'mad.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (11, '�berrascht', ':o', 'image/gif', 'oh.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (12, 'Ansto�en', ':prost:', 'image/gif', 'prost.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (13, 'Raketenwerfer', ':rocket:', 'image/gif', 'rocket.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (14, 'rollend', ':lol:', 'image/gif', 'roll.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (15, 'mit Augen rollen', ':rolleyes:', 'image/gif', 'rolleyes.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (16, 'Traurig', ':(', 'image/gif', 'sad.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (17, 'Smile', ':)', 'image/gif', 'smile.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (18, 'Stinken', ':p', 'image/gif', 'stink.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (19, 'zwinkern', ';)', 'image/gif', 'zwinker.gif');";
                   $query[] = "INSERT INTO $TB_SMILIES (id, name, code, typ, filename) VALUES (20, 'Schlafen', ':zzz:', 'image/gif', 'zzz.gif');";
         } elseif ($step == "insert_status") {
                   $query[] = "INSERT INTO $TB_STATUS (id, data, name, points) VALUES (1, '', 'Newbie', '0');";
                   $query[] = "INSERT INTO $TB_STATUS (id, data, name, points) VALUES (2, 'stars_1.gif', 'Junior Member', '2');";
                   $query[] = "INSERT INTO $TB_STATUS (id, data, name, points) VALUES (3, 'stars_2.gif', 'Member', '10');";
                   $query[] = "INSERT INTO $TB_STATUS (id, data, name, points) VALUES (4, 'stars_3.gif', 'hier zuhause', '50');";
                   $query[] = "INSERT INTO $TB_STATUS (id, data, name, points) VALUES (5, 'stars_g1.gif', 'Senior Member', '150');";
         } elseif ($step == "insert_styles") {
                   $query[] = "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (1, 'phpForum.ath.cx - new', 'on', 'on', '/* Text-Allgemein */\r\n#all A:active { color: #333399; text-decoration: none; }\r\n#all A:visited { color: #333399; text-decoration: none; }\r\n#all A:hover { color: #ff0000; text-decoration: underline; }\r\n#all A:link { color: #333399; text-decoration: none; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { color: #ffffff; text-decoration: underline; }\r\n#nav A:visited { color: #ffffff; text-decoration: none; }\r\n#nav A:hover { color: #ff2222; text-decoration: underline overline; background-color:transparent; }\r\n#nav A:link { color: #ffffff; text-decoration: none; }\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: #FFFFFF;\r\n  font-family: verdana,arial,helvetica;\r\n  font-size: medium;\r\n  color: #000000;\r\n  scrollbar-face-color: #666666;\r\n  scrollbar-arrow-color: #ffffff;\r\n  scrollbar-base-color: #cccccc;\r\n  scrollbar-3d-light-color: #cccccc;\r\n  scrollbar-darkshadow-color: #cccccc;\r\n  scrollbar-highlight-color: #000000;\r\n  scrollbar-shadow-color: #cccccc;\r\n  scrollbar-track-color: #cccccc;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: white;\r\n   border-bottom: black 1px solid;\r\n   border-left: black 1px solid;\r\n   border-right: black 1px solid;\r\n   border-top: black 1px solid;\r\n}', '<div align=\'left\'><img src=\'images/title.jpg\' border=\'0\'></div>\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'#666666\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: #000000;', 'background-color: #666666;\r\ncolor: #ffffff;\r\nfont-size: x-small;', 'background-color: #000000;', 'background-color: #bbbbbb;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: #ffffff;\r\nfont-size: x-small;\r\ncolor: #000000;', 'background-color: #f1f1f1;\r\nfont-size: x-small;\r\ncolor: #000000;', 'images/last_post.gif', 'images/2_newpost.jpg', 'images/2_newtopic.jpg', 'images/abo.jpg', 'images/2_closed.jpg', 'images/2_pm_new.jpg', 'images/2_pm_readall.jpg', 'images/2_pm_delall.jpg', 'images/2_pm_reply.jpg', 'images/2_profile.jpg', 'images/2_pm.jpg', 'images/2_www.jpg', 'images/2_email.jpg', 'images/2_search.jpg', 'images/2_quote.jpg', 'images/2_edit_delete.jpg', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip.jpg');";
                   $query[] = "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (2, 'phpForum.ath.cx - old', '', 'on', '/* Text-Allgemein */\r\n#all A:active { color: #333399; text-decoration: none; }\r\n#all A:visited { color: #333399; text-decoration: none; }\r\n#all A:hover { color: #ff0000; text-decoration: underline; }\r\n#all A:link { color: #333399; text-decoration: none; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { color: #ffffff; text-decoration: underline; }\r\n#nav A:visited { color: #ffffff; text-decoration: none; }\r\n#nav A:hover { color: #ff2222; text-decoration: underline overline; background-color:transparent; }\r\n#nav A:link { color: #ffffff; text-decoration: none; }\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: #FFFFFF;\r\n  font-family: verdana,arial,helvetica;\r\n  font-size: medium;\r\n  color: #000000;\r\n  scrollbar-face-color: #666666;\r\n  scrollbar-arrow-color: #ffffff;\r\n  scrollbar-base-color: #cccccc;\r\n  scrollbar-3d-light-color: #cccccc;\r\n  scrollbar-darkshadow-color: #cccccc;\r\n  scrollbar-highlight-color: #000000;\r\n  scrollbar-shadow-color: #cccccc;\r\n  scrollbar-track-color: #cccccc;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: white;\r\n   border-bottom: black 1px solid;\r\n   border-left: black 1px solid;\r\n   border-right: black 1px solid;\r\n   border-top: black 1px solid;\r\n}', '<div align=\'left\'><img src=\'images/title.jpg\' border=\'0\'></div>\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'#666666\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: #000000;', 'background-color: #666666;\r\ncolor: #ffffff;\r\nfont-size: x-small;', 'background-color: #000000;', 'background-color: #bbbbbb;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: #ffffff;\r\nfont-size: x-small;\r\ncolor: #000000;', 'background-color: #f1f1f1;\r\nfont-size: x-small;\r\ncolor: #000000;', 'images/last_post.gif', 'images/newpost.jpg', 'images/newtopic.jpg', 'images/abo.jpg', 'images/closed.jpg', 'images/newpm.jpg', 'images/readall.jpg', 'images/delpm.jpg', 'images/replypm.jpg', 'images/profile.gif', 'images/pm.gif', 'images/home.gif', 'images/email.gif', 'images/search.gif', 'images/quote.gif', 'images/edit.gif', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip.jpg');";
                   $query[] = "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (3, 'dark', '', 'on', '/* Text-Allgemein */\r\n#all A:active { COLOR: #FFD700; text-decoration: none; }\r\n#all A:visited { COLOR: #FFD700; text-decoration: none; }\r\n#all A:hover { COLOR: #FFFFFF; text-decoration: underline; }\r\n#all A:link { COLOR: #FFD700; text-decoration: none; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { COLOR: #FFD700; text-decoration: underline; }\r\n#nav A:visited { COLOR: #FFD700; text-decoration: none; }\r\n#nav A:hover { COLOR: #FFFFFF; text-decoration: underline; background-color:transparent; }\r\n#nav A:link { COLOR: #FFD700; text-decoration: none; }\r\n\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: #000000;\r\n  font-family: verdana,arial,helvetica;\r\n  font-size: medium;\r\n  color: #ffffff;\r\n  scrollbar-face-color: #666666;\r\n  scrollbar-arrow-color: #ffffff;\r\n  scrollbar-base-color: #cccccc;\r\n  scrollbar-3d-light-color: #cccccc;\r\n  scrollbar-darkshadow-color: #cccccc;\r\n  scrollbar-highlight-color: #000000;\r\n  scrollbar-shadow-color: #cccccc;\r\n  scrollbar-track-color: #cccccc;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: white;\r\n   border-bottom: black 1px solid;\r\n   border-left: black 1px solid;\r\n   border-right: black 1px solid;\r\n   border-top: black 1px solid;\r\n}', '<div align=\'left\'><img src=\'images/title.jpg\' border=\'0\'></div>\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'#666666\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: #ffffff;', 'background-color: #666666;\r\ncolor: #ffffff;\r\nfont-size: x-small;', 'background-color: #000000;', 'background-color: #3F3F3F;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: #3F3F3F;\r\nfont-size: x-small;\r\ncolor: #ffffff;', 'background-color: #4F4F4F;\r\nfont-size: x-small;\r\ncolor: #ffffff;', 'images/last_post.gif', 'images/2_newpost.jpg', 'images/2_newtopic.jpg', 'images/abo.jpg', 'images/2_closed.jpg', 'images/2_pm_new.jpg', 'images/2_pm_readall.jpg', 'images/2_pm_delall.jpg', 'images/2_pm_reply.jpg', 'images/2_profile.jpg', 'images/2_pm.jpg', 'images/2_www.jpg', 'images/2_email.jpg', 'images/2_search.jpg', 'images/2_quote.jpg', 'images/2_edit_delete.jpg', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip.jpg');";
                   $query[] = "INSERT INTO $TB_STYLES (id, name, active, choice, head_insert, header, footer, html_type, body_extra, textarea_width, textarea_height, default_table, default_tr, cat_table, cat_tr, table_inset, font_big, font_normal, font_small, font_fault, cat_one, cat_two, pic_last_post, pic_new_post, pic_new_topic, pic_topic_abo, pic_closed, pic_pm_new, pic_pm_readall, pic_pm_delall, pic_pm_reply, pic_profile, pic_pm, pic_home, pic_mail, pic_search, pic_quote, pic_edit, pic_on, pic_on_lock, pic_off, pic_off_lock, pic_post_on, pic_post_off, pic_file, pic_pm_status, pic_admin_up, pic_admin_down, pic_admin_del, pic_poll_l, pic_poll_m, pic_poll_r, pic_ip) VALUES (4, 'blue / yellow', '', 'on', '/* Text-Allgemein */\r\n#all A:active { color: #333399; text-decoration: none; }\r\n#all A:visited { color: #333399; text-decoration: none; }\r\n#all A:hover { color: #ff0000; text-decoration: underline; }\r\n#all A:link { color: #333399; text-decoration: none; }\r\n\r\n/* Text-Navigation */\r\n#nav A:active { color: #ffffff; text-decoration: underline; }\r\n#nav A:visited { color: #ffffff; text-decoration: none; }\r\n#nav A:hover { color: #ff2222; text-decoration: underline overline; background-color:transparent; }\r\n#nav A:link { color: #ffffff; text-decoration: none; }\r\n#nav { background-color: #0000FF; color: #ffffff; font-size: x-small; }\r\n\r\n/* Body-Elemente */\r\nbody {\r\n  background-color: #F5F5DC;\r\n  font-family: verdana,arial,helvetica;\r\n  font-size: medium;\r\n  color: #000000;\r\n  scrollbar-face-color: #666666;\r\n  scrollbar-arrow-color: #ffffff;\r\n  scrollbar-base-color: #cccccc;\r\n  scrollbar-3d-light-color: #cccccc;\r\n  scrollbar-darkshadow-color: #cccccc;\r\n  scrollbar-highlight-color: #000000;\r\n  scrollbar-shadow-color: #cccccc;\r\n  scrollbar-track-color: #cccccc;\r\n}\r\n\r\n/* Buttons,... */\r\nbutton,input,select,textarea,hr\r\n{\r\n   background-color: white;\r\n   border-bottom: black 1px solid;\r\n   border-left: black 1px solid;\r\n   border-right: black 1px solid;\r\n   border-top: black 1px solid;\r\n}', '<table bgcolor=\'#006699\' width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' align=\'center\' style=\'padding:50px\'><tr><td width=\'100%\'>\r\n\r\n<div align=\'left\'><img src=\'images/title.jpg\' border=\'0\'></div>\r\n<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\' align=\'center\'>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr id=\'nav\'>\r\n           <td bgcolor=\'#666666\' height=\'10\'>\r\n               <b>.: [site_login]logout[*]login[/site_login] [site_profile]profil[*][/site_profile] [site_signup][*]registrieren[/site_signup] [site_members]members[*]members[/site_members] [site_search]search[*]search[/site_search] [site_admin]admin[*][/site_admin] [site_home]home[*]home[/site_home] :.</b>\r\n           </td>\r\n       <tr>\r\n           <td bgcolor=\'#bbbbbb\' height=\'4\'></td>\r\n       <tr>\r\n           <td bgcolor=\'#000000\' height=\'1\'></td>\r\n       </tr>\r\n</table>\r\n<table width=\'100%\' border=\'0\'>\r\n       <tr>\r\n           <td align=\'left\' valign=\'bottom\'>\r\n            <span class=\'font_small\'>\r\n               [user_name]Willkommen zur&uuml;ck,&nbsp;<b>[/user_name]</b><br>\r\n               [user_lastlogin]Ihr letzer Besuch war am:[/user_lastlogin]\r\n               [search_new]<br>neue Beitr&auml;ge anzeigen[/search_new]\r\n               [search_today]<br>Beitr&auml;ge von heute anzeigen[/search_today]\r\n            </span>\r\n           <td align=\'right\' valign=\'top\'>\r\n               <span class=\'font_small\'>\r\n                     <b>*stat_topics*</b>&nbsp;Themen mit insgesamt&nbsp;<b>*stat_posts*</b>&nbsp;Beitr&auml;gen\r\n                     <br>\r\n                     Registrierte Benutzer: <b>*stat_users*</b>\r\n                     <br>\r\n                     Wir begr&uuml;&szlig;en unseren neusten Benutzer:&nbsp;*stat_lastuser*\r\n               </span>\r\n           </td>\r\n       </TR>\r\n</table>', '</td></tr></table>', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">', 'id=\'all\'', 45, 13, 'background-color: #000000;', 'background-color: #666666;\r\ncolor: #ffffff;\r\nfont-size: x-small;', 'background-color: #000000;', 'background-color: yellow;\r\ncolor: green;\r\nfont-size: x-small;', 'border-width:1px; border-style:inset; padding:4px;', 'font-size: medium;', 'font-size: x-small;', 'font-size: xx-small;', 'font-size: x-small;\r\ncolor: red;', 'background-color: #F0F8FF;\r\nfont-size: x-small;\r\ncolor: #000000;', 'background-color: #F5F5DC;\r\nfont-size: x-small;\r\ncolor: #000000;', 'images/last_post.gif', 'images/2_newpost.jpg', 'images/2_newtopic.jpg', 'images/abo.jpg', 'images/2_closed.jpg', 'images/2_pm_new.jpg', 'images/2_pm_readall.jpg', 'images/2_pm_delall.jpg', 'images/2_pm_reply.jpg', 'images/2_profile.jpg', 'images/2_pm.jpg', 'images/2_www.jpg', 'images/2_email.jpg', 'images/2_search.jpg', 'images/2_quote.jpg', 'images/2_edit_delete.jpg', 'images/on.jpg', 'images/on_lock.jpg', 'images/off.jpg', 'images/off_lock.jpg', 'images/post_on.gif', 'images/post_off.gif', 'images/file.gif', 'images/pm_status.jpg', 'images/admin_up.gif', 'images/admin_down.gif', 'images/admin_del.gif', 'images/poll_l.jpg', 'images/poll_m.jpg', 'images/poll_r.jpg', 'images/2_ip_old.jpg');";
         } elseif ($step == "insert_users") {
                   $query[] = "INSERT INTO $TB_USER (id, pass, reg, name, geb, gender, job, location, homepage, email, icq, aim, yim, sign, access_id, points, last_post, last_login, pm_email, pm_popup, pm_popup_show, bbcodes_show, html_show, smilies_show, sign_show, post_email, email_show, stay_login, pm_footer, style) VALUES (1, 'd41d8cd98f00b204e9800998ecf8427e', NOW(), 'anonymous', '0000-00-00', 'm', '', '', '', '', '', '', '', '', 2, 0, 0, NOW(), '', '', 'on', 'on', 'on', 'on', '', '', '', '', '', 1);";
         } elseif ($step == "insert_words") {
                   $query[] = "INSERT INTO $TB_WORDS (id, search, replacement) VALUES (1, 'Schei�', 'S*****');";
         }
         return $query;
#
}
################################################################################
############################### SQL-Query�s #################################### ---
################################################################################
?>
</BODY>
</HTML>
