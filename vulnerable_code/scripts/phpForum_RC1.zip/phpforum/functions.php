<?php
switch ($HTTP_GET_VARS[action]) {

        case "abo":
              include("head.php");
              if (user_login() == FALSE) {
                  msg("user", "", "");
              }
              //l�schen
              if ($HTTP_GET_VARS[op] == "del") {
                  $Fehler = topic_abo($HTTP_GET_VARS[Topic_id], "del");
                  msg($Fehler, "2", "user.php");
              //alle l�schen
              } elseif ($HTTP_GET_VARS[op] == "delall") {
                  $Fehler = topic_abo("", "delall");
                  msg($Fehler, "2", "user.php");
              //hinzuf�gen
              } elseif ($HTTP_GET_VARS[op] == "add") {
                  $Fehler = topic_abo($HTTP_GET_VARS[Topic_id], "add");
                  msg($Fehler, "2", "showtopic.php?$Sess_Name=$Sess&Topic_id=$HTTP_GET_VARS[Topic_id]&goto=lastpost");
              //als gelesen markieren
              } elseif ($HTTP_GET_VARS[op] == "read") {
                  last_login(date("Y-m-d H:i:s"));
                  msg("topic_abo_read", "2", "index.php");
              }
              break;

        case "smilies":
              include("config.inc.php"); //Konfiguration
              show_smilies();
              break;

        case "bbcodes":
              include("config.inc.php"); //Konfiguration
              show_bbcodes();
              break;

        case "smilie":
              smilie_pic($HTTP_GET_VARS[id]);
              break;

        case "status":
              status_pic($HTTP_GET_VARS[id]);
              break;

        case "access":
              access_pic($HTTP_GET_VARS[id]);
              break;

        case "goto":
              include("config.inc.php"); //Konfiguration
              include("config.php"); //Konfiguration
              if ($HTTP_GET_VARS[go]) {
                  footer_goto($HTTP_GET_VARS[go]);
              } else {
                  footer_goto($HTTP_POST_VARS[go]);
              }
              break;

        case "pm_popup":
              include("config.inc.php"); //Konfiguration
              pm_popup();
              break;

        case "member_search":
              include("config.inc.php"); //Konfiguration
              member_search($HTTP_POST_VARS[search]);
              break;

        case "mod_ip":
              include("config.inc.php"); //Konfiguration
              mod_ip($HTTP_GET_VARS[id]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function show_smilies() {
         $no_head = "1";
         include("$GLOBALS[MAIN_PATH]/head.php");         //Konfiguration
         echo "<script language=\"JavaScript\">
                       function AddSmilie(smilietext) {
                                opener.document.bbform.message.value += smilietext+\" \";
                       }
               </script>";
         echo "<TITLE>Smilies</TITLE>";
         table_header("Smilies", "100%","1","colspan='2'");
         $result = mySQL_query ("SELECT * FROM $TB_SMILIES ORDER BY name");
         while ($Daten = mysql_fetch_array ($result)) {

                ?>
                <tr class='default_tr'>
                    <td width='20%' align='center' class='cat_two'>
                        <?php echo $Daten[code]; ?>
                    <td width='30%' align='center' class='cat_one'>
                        <a href="javascript:AddSmilie('<?php echo $Daten[code]; ?>')"><img src='<?php echo "functions.php?action=smilie&id=$Daten[id]"; ?>' border='0' alt='<?php echo $Daten[name]; ?>'></a>
                    </td>
                </tr>
                <?php
         }
         echo "</table>";
}
function show_bbcodes() {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS;
         ?>
         <script language="JavaScript">
                 function insertCode() {
                          var insertCode = " "+codeform.text.value+" ";
                          opener.document.bbform.message.value += insertCode+" ";
                          insertCode = "";
                 }
         </script>
         <?php
         $no_head = "1";
         include("$GLOBALS[MAIN_PATH]/head.php");         //Konfiguration
         echo "<TITLE>Board-Codes</TITLE>";
         echo "<form name='codeform'>";

         table_header("Board-Codes", "100%");

         ### alle Codes anzeigen
         if (!$HTTP_GET_VARS[id]) {
             $result = mySQL_query ("SELECT * FROM $TB_BBCODES ORDER BY name");
             $c = 0;
             while ($Daten = mysql_fetch_array ($result)) {
                    if ($c == 1) {
                        $color = "cat_one";
                    } else {
                        $color = "cat_two";
                        $c = 0;
                    }
                    $c++;
                    ?>
                    <tr>
                        <td width='20%' class='<?php echo $color; ?>'>
                            <?php echo "<b><a href='$HTTP_SERVER_VARS[PHP_SELF]?action=bbcodes&id=$Daten[id]'>".htmlentities($Daten[name])."</a></b>"; ?>
                        </td>
                    </tr>
                    <?php
             }
             echo "</table>";

         ### nur ausgew�hlten anzeigen
         } else {
             $Daten = mysql_fetch_array(mySQL_query("SELECT * FROM $TB_BBCODES WHERE id='$HTTP_GET_VARS[id]'"));
             ?>
                   <?php table_header("Name", "100%", "1", "", "nohead"); ?>
                            <tr>
                                <td width='20%' class='cat_one'>
                                    <?php echo "<b>".htmlentities($Daten[name])."</b>"; ?>
                                </td>
                            </tr>
                   <?php if ($Daten[info]) {
                          table_header("Beschreibung", "100%", "1", "", "nohead"); ?>
                            <tr>
                                <td width='20%' class='cat_one'>
                                    <?php echo htmlentities($Daten[info]); ?>
                                </td>
                            </tr>
                   <?php }
                   if ($Daten[example]) {
                       table_header("Code Beispiel", "100%", "1", "", "nohead"); ?>
                            <tr>
                                <td width='20%' class='cat_one'>
                                    <?php echo $Daten[example]; ?>
                                    <span class='font_small'>
                                          <p><u>wird ersetzt durch:</u></p>
                                    </span>
                                    <?php echo bbcode($Daten[example], "on", "on", "", "", "on"); ?>
                                </td>
                            </tr>
                   <?php }
                      table_header("Code Wizzard", "100%", "1", "", "nohead"); ?>
                            <tr>
                                <td width='20%' class='cat_one'>
                                    In diesem Feld k&ouml;nnen sie den Board Code ganz einfach erstellen und dann in ihre Nachricht �bernehmen.
                                    <br>
                                    <textarea name='text' COLS='35' ROWS='4'><?php echo $Daten[example]; ?></textarea>
                                    <br>
                                    <input type='button' onclick="insertCode()" value='&Uuml;bernehmen'>&nbsp;<input type='reset' value='Zur&uuml;cksetzen'>
                                </td>
                            </tr>
                   </table>
             </form>
             <span class='font_normal'>
                   <?php echo "<b><a href='$HTTP_SERVER_VARS[PHP_SELF]?action=bbcodes'>[&Uuml;bersicht]</a></b>"; ?>
             </span>
             <?php
         }
}
function smilie_pic($id) {
         include("config.inc.php"); //Konfiguration
         include("config.php"); //Konfiguration

         $Daten = mysql_fetch_array(mysql_query("SELECT * FROM $TB_SMILIES WHERE $TB_SMILIES.id='$id'"));

         header ("Cache-Control: no-cache, must-revalidate");
         header ("Pragma: no-cache");
         header ("Expires: ".gmdate("D, d M Y H:i:s",time()-60) . "GMT");
         header ("Content-Disposition: filename=$Daten[filename]");
         header ("Content-Length: ".strlen($Daten[data]));
         if ($Daten[typ]) {
             header ("Content-Type: $Daten[typ]");
         } else {
             header ("Content-Type: unknown/unknown");
         }
         echo $Daten[data];
}
function status_pic($id) {
         include("config.inc.php"); //Konfiguration
         include("config.php"); //Konfiguration

         $Daten = mysql_fetch_array(mysql_query("SELECT * FROM $TB_STATUS WHERE $TB_STATUS.id='$id'"));

         header ("Cache-Control: no-cache, must-revalidate");
         header ("Pragma: no-cache");
         header ("Expires: ".gmdate("D, d M Y H:i:s",time()-60) . "GMT");
         header ("Content-Length: ".strlen($Daten[data]));
         header ("Content-Type: image/gif");
         echo $Daten[data];
}
function access_pic($id) {
         include("config.inc.php"); //Konfiguration
         include("config.php"); //Konfiguration

         $Daten = mysql_fetch_array(mysql_query("SELECT * FROM $TB_ACCESS WHERE $TB_ACCESS.id='$id'"));

         header ("Cache-Control: no-cache, must-revalidate");
         header ("Pragma: no-cache");
         header("Expires: ".gmdate("D, d M Y H:i:s",time()-60) . "GMT");
         header("Content-Length: ".strlen($Daten[data]));
         header("Content-Type: image/gif");
         echo $Daten[data];
}
function footer_goto($goto) {
         ### Goto !!!
         list ($Typ, $Text) = split ('-', $goto);
         if ($Typ AND $Text) {
             //-> Forum
             if ($Typ == 'f') {// goto Forum !!!
                 header ("Location: http://$GLOBALS[SITE]/showforum.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Forum_id=$Text");
             //-> Kategorie
             } elseif ($Typ == 'c') { // goto Categorie
                 header ("Location: http://$GLOBALS[SITE]/index.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Cat_id=$Text");
             //Standard-Seiten
             } elseif ($Typ == 'w') { // goto WebSite-Bereich (Memberliste...)
                 //-> Startseite
                 if ($Text == "home") {
                     header ("Location: http://$GLOBALS[SITE]/index.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]");
                 //-> Admin
                 } elseif ($Text == "admin") {
                     header ("Location: http://$GLOBALS[SITE]/admin/index.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]");
                 //-> Members
                 } elseif ($Text == "members") {
                     header ("Location: http://$GLOBALS[SITE]/members.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]");
                 //-> Suche
                 } elseif ($Text == "search") {
                     header ("Location: http://$GLOBALS[SITE]/search.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]");
                 //-> PM�s
                 } elseif ($Text == "private") {
                     header ("Location: http://$GLOBALS[SITE]/private.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]");
                 }
             }
             exit();
         ### Seite nicht gefunden !!!
         } else {
             $no_head = "on";
             include("head.php"); //Header
             msg("footer_list_fault", "5", "back()");
         }
}
function pm_popup() {
         $no_head = "on";
         include("head.php"); //Header
         echo "<title>- neue PM -</title>";

         $pm_anz=pm_status();
         open_table("phpForum - Mitteilung","100%");
                    echo "Sie haben $pm_anz";
                    if ($pm_anz > "1") {
                        echo " neue Nachrichten.";
                    } else {
                        echo " neue Nachricht.";
                    }
                    echo "<br> Klicken sie <a href=\"javascript:window.close()\" onClick=\"opener.location.href ='user.php?$Sess_Name=$Sess'\">hier</a> um diese anzeigen zu lassen.";
         close_table("Um dieses Fenster zu deaktivieren, m&uuml;ssen sie <a href=\"javascript:window.close()\" onClick=\"opener.location.href ='user.php?$Sess_Name=$Sess&action=settings'\">hier</a> klicken.");

         ### Fenster f�r die aktuellen PM�s deaktivieren ###
         $userinfo = get_user_info();
         mysql_query("UPDATE $GLOBALS[TB_USER] SET pm_popup_show='on' WHERE id='$userinfo[id]'");
}
function member_search($search) {
         global $HTTP_SERVER_VARS;
         $no_head = "on";
         include("head.php"); //Header
         echo "<script language=\"JavaScript\">
                       function insertName(name) {
                                opener.document.bbform.to_name.value = name;
                                opener.focus();
                                window.close();
                       }
               </script>";
         $Daten = mysql_fetch_array(mySQL_query("SELECT * FROM $TB_BBCODES WHERE id='$HTTP_GET_VARS[id]'"));
         table_header("Member suche...", "100%", "1");
         table_header("Suche", "100%", "", "", "nohead"); ?>
                       <tr>
                           <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=member_search"; ?>'>
                                 <td width='20%' class='cat_one' align='center'>
                                     <input type='text' name='search' value='<?php echo $search; ?>'>&nbsp;<input type='submit' value='suchen'>
                                 </td>
                           </form>
                       </tr>
         <?php if ($search) {
                   table_header("Ergebnis", "100%", "", "", "nohead");
                         $result = mysql_query("SELECT name FROM $GLOBALS[TB_USER] WHERE name LIKE '%$search%'");
                         ?>
                         <tr>
                             <td class='cat_one' align='center'>
                                 <select name='user'>
                                         <?php
                                         while ($Daten = mysql_fetch_array($result)) {
                                                echo "<option value='$Daten[name]'>$Daten[name]</a>";
                                         } ?>
                                        </select>
                                        &nbsp;<input TYPE='button' ONCLICK="insertName(user.options[user.selectedIndex].value)" value='OK'>
                                    </td>
                                </tr>
                                <?php
               } ?>
         </table>
         <?php
}
function mod_ip($id) {
         $no_head = "on";
         include("head.php"); //Header
         echo "<title>- IP-Adresse -</title>";

         $access = get_forum_perm("","");

         if ($access[mod_edit] == "on" OR $access[mod_del] == "on") {

             $Daten = mysql_fetch_array(mysql_query("SELECT $GLOBALS[TB_POST].ip,
                                                            $GLOBALS[TB_POST].post_date,
                                                            $GLOBALS[TB_USER].name AS user_name
                                                     FROM $GLOBALS[TB_POST], $GLOBALS[TB_USER]
                                                     WHERE $GLOBALS[TB_POST].id='$id'
                                                       AND $GLOBALS[TB_POST].user_id=$GLOBALS[TB_USER].id"));

             open_table("phpForum - Mitteilung","100%");
                         ?>
                         <table width='100%'>
                                <tr>
                                    <td class='font_normal'>
                                        <b>Benutzer:</b>
                                    <td class='font_normal'>
                                        <?php echo $Daten[user_name]; ?>
                                    </td>
                                <tr>
                                    <td class='font_normal'>
                                        <b>Beitrag vom:</b>
                                    <td class='font_normal'>
                                        <?php echo $Daten[post_date]; ?>
                                    </td>
                                <tr>
                                    <td class='font_normal'>
                                        <b>IP-Adresse:</b>
                                    <td class='font_normal'>
                                        <?php echo $Daten[ip]; ?>
                                    </td>
                                </tr>
                         </table>
                         <?php
             close_table("<a href=\"javascript:window.close()\">Fenster schliessen</a>");
         } else {
             open_table("phpForum - Mitteilung","100%");
                         echo "<br><span class='font_fault'>F&uuml;r diese Funktion haben sie keine Rechte.</span><br>";
             close_table("<a href=\"javascript:window.close()\">Fenster schliessen</a>");
         }
}
?>
