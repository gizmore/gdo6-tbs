var post_max = 10000;

var prompt_text = "Gebe einen Text ein:";
var prompt_link_text = "Gebe einen Linknamen ein (optional)";
var prompt_link_url = "Gebe die volle Adresse des Links ein";
var prompt_link_email = "Gebe eine Email Adesse ein";
var prompt_list_typ = "Um eine nummerierte Liste zu erstellen gebe '1' ein, f�r eine alphabetische 'a' f�r ein.";
var prompt_list_item = "Gebe eine Listepunkt ein.\nGebe nichts ein oder dr�cke 'Cancel' um die Liste fertigzustellen.";
// #######################################################
//# liefert den aktuell selektierten Text
function getActiveText() {
         var advtext = "";

         if (window.getSelection) {
             advtext = window.getSelection();
         } else if (document.getSelection) {
             advtext = document.getSelection();
         } else if (document.selection) {
             advtext = document.selection.createRange().text;
         }
         return advtext;
}
//# hinzuf�gen des Board-Codes
function AddCode(Code,theform) {
         if (theform == "") {
             theform = bbform;
         }
         theform.message.value+=Code
         theform.message.focus();
}
// Popup f�r "bbcode"
function bbcode(theform,bbcode,prompttext) {
         if (prompttext != "") {
             advtext = prompttext;
         } else {
             advtext = getActiveText();
         }
         inserttext = prompt(prompt_text+"\n["+bbcode+"]xxx[/"+bbcode+"]",advtext);
         if ((inserttext != null) && (inserttext != "")) {
              AddCode("["+bbcode+"]"+inserttext+"[/"+bbcode+"] ",theform);
         }
         theform.message.focus();
}
// Popup f�r "Schrift-Formatierung"
function bbfont(theform,bbvalue,thetype) {
         if (bbvalue != 0) {
             inserttext = prompt(prompt_text+"\n"+thetype,"");
             if ((inserttext != null) && (inserttext != "")) {
                  AddCode("["+thetype+"="+bbvalue+"]"+inserttext+"[/"+thetype+"] ",theform);

             }
         }
         theform.select_size.selectedIndex = 0;
         theform.select_font.selectedIndex = 0;
         theform.select_color.selectedIndex = 0;
         theform.select_align.selectedIndex = 0;
         theform.message.focus();
}
// Popup f�r "Liste"
function bblist(theform) {
         listtype = prompt(prompt_list_typ, "");
         if ((listtype == "a") || (listtype == "1")) {
              list_anf = "[list="+listtype+"]\n";
              list_end = "[/list="+listtype+"] ";
         } else {
              list_anf = "[list]\n";
              list_end = "[/list] ";
         }
         list_entry = "anf";
         list_values = "";
         while ((list_entry != "") && (list_entry != null)) {
                 list_entry = prompt(prompt_list_item, "");
                 if ((list_entry != "") && (list_entry != null)) {
                      list_values = list_values+"[*]"+list_entry+"\n";
                 }
         }
         AddCode(list_anf+list_values+list_end,theform);
         theform.message.focus();
}
// Popup f�r "benannten Link"
function bbnamed(theform,thetype) {
         link_text = prompt(prompt_link_text,"");
         if (thetype == "URL") {
             prompt_text = prompt_link_url;
             advtext = "http://";
         } else {
             prompt_text = prompt_link_email;
             advtext = "";
         }

         link_url = prompt(prompt_text,advtext);
         if ((link_url != null) && (link_url != "")) {
              if ((link_text != null) && (link_text != "")) {
                   AddCode("["+thetype+"="+link_url+"]"+link_text+"[/"+thetype+"] ",theform);
              } else {
                   AddCode("["+thetype+"]"+link_url+"[/"+thetype+"] ",theform);
              }
         }
}
// Smilies :)
function bbsmilie(thesmilie) {
        AddCode(" "+thesmilie+" ","");
}
// Nachricht nicht leer ?!
function validate(theform) {
         if (theform.message.value=="") {
             alert("Nachrichtfeld mu� ausgef�llt werden!");
             return false;
         } else if (theform.message.value.length > post_max) {
             alert("Deine Nachricht ist zu lang. Bitte reduziere deine Nachricht auf "+post_max+" Zeichen. Momentan ist sie "+theform.message.value.length+" Zeichen lang.");
             return false;
         } else {
             return true;
         }
}
function checklength(theform) {
         if (theform.message.value != "") {
             message = "Die maximale Grenze liegt bei "+post_max+" Zeichen.";
         } else {
             message = "";
         }
         alert("Deine Nachricht ist "+theform.message.value.length+" Zeichen lang. "+message);
}