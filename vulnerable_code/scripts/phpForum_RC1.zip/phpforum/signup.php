<?php
     $ACCESS_PAGE = "public";
     include("head.php");        //Header mit Bild, Suchen...
echo "<br>";

switch ($HTTP_POST_VARS[action]) {

        case "":
              if ($REG_DISCLAIMER == "on" AND $HTTP_POST_VARS[ok] != "1" AND $REG_NEW == "on") {
                  disclaimer();
              } elseif ($HTTP_POST_VARS[ok] == "1" OR $REG_DISCLAIMER != "on" AND $REG_NEW == "on") {
                  form();
              } elseif (!$REG_NEW) {
                  echo "<br>";
                  open_table("phpForum - Mitteilung","60%");
                       echo $REG_NEW_TEXT;
                  close_table("");
                  echo "<p>&nbsp;</p>";
              }
              break;

        case "save":
              save();
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
#
#
##################### Disclaimer ##################### +++
function disclaimer() {
         global $HTTP_SERVER_VARS;
         open_table("$GLOBALS[TITEL_KURZ] Regeln", "100%");
                     ?>
                     <FORM method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
                           <input type='hidden' name='ok' VALUE='1'>
                           <?php
                           echo bbcode($GLOBALS[DISCLAIMER], "on", "on", "on", "", "on");
                           ?>
                           <p align='center'>
                           <input type='submit' VALUE='Akzeptieren'>
                           </p>
                     </FORM>
                     <FORM action='<?php echo "index.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
                           <p align='center'>
                           <input type='submit' VALUE='Ablehnen'>
                           </p>
                     </FORM>
                     <?php
         close_table();
         echo "<br>";
}
##################### Disclaimer ##################### ---
#
#
##################### Formular ##################### +++
function form() {
         global $HTTP_SERVER_VARS;
         ?>
         <form name='bbform' method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
               <input type='hidden' name='action' VALUE='save'>
                 <?php table_header("$GLOBALS[TITEL_KURZ] Registrierung:", "100%", "", "colspan='2'");
                 ### zur Reg. wichtig ###
                 table_header("Erforderliche Informationen:", "100%", "1", "colspan='2'", "nohead"); ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Benutzername:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='name' maxlength='50' size='30'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>eMail-Adresse:</b><br>
                                <span class='font_small'>
                                      Bitte gene sie eine g&uuml;ltige eMail-Adresse an. Sie erh&auml;lten ihr Passwort &uuml;ber diese eMail-Adresse.
                                </span>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='email' maxlength='255' size='30'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>eMail-Adresse wiederholen:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='email_repeat' maxlength='255' size='30'>
                            </td>
                        </tr>
                        <?php
                 ### Zus�tzliche Informationen ###
                 table_header("Freiwillige Informationen:", "100%", "1", "colspan='2'", "nohead"); ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Geburtstag:</b>
                            <td width='50%' class='cat_one'>
                                <table border='0'>
                                       <tr>
                                           <td align='center'>
                                               <span class='font_small'>
                                                     Tag
                                               </span>
                                           <td align='center'>
                                               <span class='font_small'>
                                                     Monat
                                               </span>
                                           <td align='center'>
                                               <span class='font_small'>
                                                     Jahr
                                               </span>
                                           </td>
                                       <tr>
                                           <td>
                                               <select name='geb_tag'>
                                                       <option VALUE=''></option>
                                                       <?php
                                                       for ($n=1; $n <= 31; $n++) {
                                                            echo "<option value='$n'>$n</option>";
                                                       }
                                                       ?>
                                               </select>
                                           <td>
                                               <select name='geb_monat'>
                                                       <option VALUE=''></option>
                                                       <option VALUE='1'>Januar</option>
                                                       <option VALUE='2'>Februar</option>
                                                       <option VALUE='3'>M&auml;rz</option>
                                                       <option VALUE='4'>April</option>
                                                       <option VALUE='5'>Mai</option>
                                                       <option VALUE='6'>Juni</option>
                                                       <option VALUE='7'>Juli</option>
                                                       <option VALUE='8'>August</option>
                                                       <option VALUE='9'>September</option>
                                                       <option VALUE='10'>Oktober</option>
                                                       <option VALUE='11'>November</option>
                                                       <option VALUE='12'>Dezember</option>
                                               </select>
                                           <td>
                                               <input type='text' name='geb_jahr' maxlength='4' size='4'>
                                           </td>
                                       </tr>
                                </table>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Geschlecht:</b>
                            <td width='50%' class='cat_one'>
                                <select name='gender'>
                                        <option value='m'>m&auml;nnlich</option>
                                        <option value='w'>weiblich</option>
                                </select>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Homepage:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='homepage' value='' maxlength='255' size='30'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>ICQ Nummer:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='icq' maxlength='20' size='10'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Yahoo Messenger Name:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='yim' maxlength='255' size='30'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>AOL Instant Messenger Name:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='aim' maxlength='255' size='30'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Beruf:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='job' maxlength='255' size='30'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Wohnort:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='location' maxlength='255' size='30'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Signatur:</b><br>
                                <span class='font_small'>
                                      Die Signatur ist optional und wird am Ende Ihrer Beitr&auml;ge angezeigt (falls sie dies aktivieren).<br><br>
                                      <?php
                                      echo "HTML Code ist ";
                                            if ($GLOBALS[SIGN_HTML] == "on") { echo "AN"; } else { echo "AUS"; }
                                      echo "<br><a href=\"javascript:onclick=BBCode()\">Board Code</a> ist ";
                                            if ($GLOBALS[SIGN_BBCODES] == "on") { echo "AN"; } else { echo "AUS"; }
                                      echo "<br><a href=\"javascript:onclick=Smilies()\">Smilies</a> sind ";
                                            if ($GLOBALS[SIGN_SMILIES] == "on") { echo "AN"; } else { echo "AUS"; }
                                      ?>
                                </span>
                            </td>
                            <td width='50%' class='cat_one'>
                                <textarea cols='37' rows='5' name='message'></textarea>
                            </td>
                        </tr>
                 </table>
                 <p></p>
                 <center>
                         <input type='submit' value='Registrieren'>
                         <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
                 </center>
             </form>
<?php
}
##################### Formular ##################### ---
#
#
##################### Save ##################### +++
function save() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;
         ### Alle wichtigen Daten richtig angegeben ?
         if (!$HTTP_POST_VARS[name] OR !$HTTP_POST_VARS[email] OR !$HTTP_POST_VARS[email_repeat] OR $HTTP_POST_VARS[email] != $HTTP_POST_VARS[email_repeat]) {
             msg("signup_fault", "5", "$HTTP_SERVER_VARS[PHP_SELF]");
         }

         ### Gesperrter Benutzername ?
         $split_names = split("\n", trim($GLOBALS[BANNED_NAMES]));
         foreach ($split_names AS $key => $name) {
                  if (preg_match("/.*$name.*/", $HTTP_POST_VARS["name"]) AND $name) {
                      msg("signup_fault","2","$HTTP_SERVER_VARS[PHP_SELF]");
                  }
         }

         ### Existiert dieser Benutzer schon ?
         if(mysql_num_rows(mysql_query("SELECT * FROM $GLOBALS[TB_USER] WHERE name LIKE '".$HTTP_POST_VARS[name]."'")) >= 1) {
            msg("signup_exist", "2", "$HTTP_SERVER_VARS[PHP_SELF]");
         }
         // Homepage mit http versehen
         if (substr(strtolower($HTTP_POST_VARS[homepage]), 0, 7) != "http://" AND $HTTP_POST_VARS[homepage] != "") {
             $HTTP_POST_VARS[homepage] = "http://" . $HTTP_POST_VARS[homepage];
         }

         //Passwort erstellen
         mt_srand((double)microtime()*1000000);
         $Pass = mt_rand(1000000000,2000000000);
         //Passwort verschl�sseln
         $Pass_crypt = md5($Pass);
         //Insert erfolgreich ?
         if (mysql_query("INSERT INTO $GLOBALS[TB_USER] (pass, reg, name, email, geb, gender, homepage, icq, yim, aim, job, location, sign, access_id, last_login)
                          VALUES ('$Pass_crypt',CURDATE(),'$HTTP_POST_VARS[name]','$HTTP_POST_VARS[email]','$HTTP_POST_VARS[geb_jahr]-$HTTP_POST_VARS[geb_monat]-$HTTP_POST_VARS[geb_tag]',
                                  '$HTTP_POST_VARS[gender]','$HTTP_POST_VARS[homepage]','$HTTP_POST_VARS[icq]','$HTTP_POST_VARS[yim]','$HTTP_POST_VARS[aim]','$HTTP_POST_VARS[job]',
                                  '$HTTP_POST_VARS[location]','$HTTP_POST_VARS[message]','$GLOBALS[DEFAULT_USER_GROUP]',NOW())")) {
             $id = mysql_insert_id();
             // eMail mit Passwort schicken
             @mail("$HTTP_POST_VARS[email]", "$GLOBALS[TITEL_KURZ] - Anmeldung", "Hallo!\n\nVielen Dank f�r die Registration bei $GLOBALS[TITEL_KURZ] (http://$GLOBALS[SITE]/index.php)\nIhre Registrierung war erfolgreich. Sie ben�tigen die folgenden Informationen, um neue Beitr�ge in unserem Forum schreiben zu k�nnen.\n\nBenutzername: $HTTP_POST_VARS[name]\nKennwort: $Pass\nIhre eMail-Adresse lautet: $HTTP_POST_VARS[email]\n\nSie k�nnen das Passwort und weitere Einstellungen nach dem einloggen in Ihrem Profil �ndern.\n\nGruss,\nIhr $GLOBALS[TITEL_KURZ] Board Team\n\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\nN�tzliche Links:\n\nIhr Profil:\nhttp://$GLOBALS[SITE]/user.php\n\nneue Beitr�ge suchen:\nhttp://$GLOBALS[SITE]/search.php?action=search&get=new", "From: $GLOBALS[TITEL_KURZ] <$GLOBALS[SITE_ADMIN]>\nReturn-Path: <$GLOBALS[SITE_ADMIN]>");
             $Fehler = "signup";
             $goto = "index.php";
         } else {
             $Fehler = "signup_fault";
             $goto = "back()";
         }
         msg($Fehler, "3", $goto);
}
##################### Save ##################### +++
#
#
footer();
?>