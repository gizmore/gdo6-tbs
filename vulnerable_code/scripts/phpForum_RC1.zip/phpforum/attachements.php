<?php
         include("config.inc.php");
         include("$GLOBALS[MAIN_PATH]/config.php");

         $Daten = mysql_fetch_array(mysql_query("SELECT * FROM $TB_FILES WHERE post_id='$HTTP_GET_VARS[id]'"));
         mysql_query("UPDATE $TB_FILES SET views=views+1 WHERE post_id='$HTTP_GET_VARS[id]'");
         header("Cache-control: max-age=60");
         header("Expires: " . gmdate("D, d M Y H:i:s",time()+60) . "GMT");
         header("Content-disposition: filename=$Daten[name]");
         header("Content-Length: ".strlen($Daten[data]));
         if ($Daten[typ]) {
             header("Content-type: $Daten[typ]");
         } else {
             header("Content-type: unknown/unknown");
         }
         echo $Daten[data];
?>
