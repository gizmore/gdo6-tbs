<?php
        include("head.php");            //Header mit Bild, Suchen...
echo "<br>";
$userinfo = get_user_info($HTTP_GET_VARS[id]);
$user_perm = get_forum_perm("", $userinfo[id]);

table_header("Profil von $userinfo[name]", "80%","" , "colspan='2'"); ?>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Bild:</b>
           <td width='70%' class='cat_one'>
               <?php echo avatar($userinfo[id]); ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Name:</b>
           <td width='60%' class='cat_one'>
               <?php echo $userinfo[name]; ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Geburtstag:</b>
           <td width='70%' class='cat_one'>
               <?php
               if ($userinfo[geb] != "0000-00-00") {
                   echo $userinfo[geb];
               }
               ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Beitr&auml;ge:</b>
           <td width='70%' class='cat_one'>
               <?php echo $userinfo[points]; ?> (<?php echo status_name($userinfo[id]); ?>)&nbsp;<?php echo status_stars($userinfo[id]); ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>letzer Beitrag:</b>
           <td width='70%' class='cat_one'>
               <?php
               $Daten_last_topic = mysql_fetch_array(mysql_query("SELECT $TB_TOPIC.name, $TB_TOPIC.id
                                                                  FROM $TB_TOPIC, $TB_POST
                                                                  WHERE $TB_POST.id='$userinfo[last_post]'
                                                                    AND $TB_POST.topic_id=$TB_TOPIC.id"));
               echo "<a href='showtopic.php?$Sess_Name=$Sess&Topic_id=".$Daten_last_topic[id]."&goto=lastpost'>".$Daten_last_topic[name]."</a>";
               ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>letzer Besuch:</b>
           <td width='70%' class='cat_one'>
               <?php echo $userinfo[last_login]; ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Registriert seit:</b>
           <td width='70%' class='cat_one'>
               <?php echo $userinfo[reg]; ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Homepage:</b>
           <td width='70%' class='cat_one'>
               <?php
               if ($userinfo[homepage] != ""){
                   echo "<a href='$userinfo[homepage]' target='_blank'>$userinfo[homepage]</a>";
               }
               ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>ICQ Nummer:</b>
           <td width='70%' class='cat_one'>
               <?php
               if ($userinfo[icq] != "") {
                   echo "$userinfo[icq]&nbsp;<a href='http://wwp.icq.com/scripts/search.dll?to=$userinfo[icq]'><img src='http://wwp.icq.com/scripts/online.dll?icq=$userinfo[icq]&img=5' border='0'></a>";
               }
               ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>AOL Instant Messenger:</b>
           <td width='70%' class='cat_one'>
               <?php echo $userinfo[aim]; ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Yahoo Instant Messenger:</b>
           <td width='70%' class='cat_one'>
               <?php echo $userinfo[yim]; ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Kontakt:</b>
           <td width='70%' class='cat_one'>
               <a href='<?php echo "search.php?$Sess_Name=$Sess&action=search&get=user&search=$userinfo[id]"; ?>'>nach <i>Beitr&auml;gen</i> von <?php echo $userinfo[name]; ?> suchen...</a>
               <?php
               if ($user_perm[send_pm] == "on") {
                   ?>
                   <br>
                   <a href='<?php echo "private.php?$Sess_Name=$Sess&action=new&user_id=$userinfo[id]"; ?>'>eine <i>PM</i> an <?php echo $userinfo[name]; ?> schicken...</a>
                   <?php
               }
               if ($userinfo[email_show] == "on") {
                   ?>
                   <br>
                   <a href='<?php echo "mail.php?$Sess_Name=$Sess&id=$userinfo[id]"; ?>'><?php echo $userinfo[name]; ?> eine <i>E-Mail</i> schreiben...</a>
                   <?php
               }
               ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Wohnort:</b>
           <td width='70%' class='cat_one'>
               <?php echo $userinfo[location]; ?>
           </td>
       <tr>
           <td width='30%' class='cat_two'>
               <b>Beruf:</b>
           <td width='70%' class='cat_one'>
               <?php echo $userinfo[job]; ?>
           </td>
       </tr>
</table>
<?php
echo "<br>";
footer_list();
footer();
?>