<?php
        include("head.php");        //Header mit Bild, Suchen...
        echo "<br>";

        ### Benutzer-Rechte
        $Daten = mysql_fetch_object(mySQL_query ("SELECT $TB_TOPIC.forum_id
                                                  FROM $TB_TOPIC
                                                  WHERE $TB_TOPIC.id='$HTTP_POST_VARS[Topic_id]'"));
                 $forum_id=$Daten->forum_id;
        $perm = get_forum_perm($forum_id, "");

        switch ($HTTP_POST_VARS[action]) {

                case "openclose":
                      if ($perm[mod_openclose] == "on") {
                          mod_openclose($HTTP_POST_VARS[Topic_id]);
                      } else {
                          msg("user", "2", "back()");
                      }
                      break;

                case "top":
                      if ($perm[mod_top] == "on") {
                          mod_top($HTTP_POST_VARS[Topic_id]);
                      } else {
                          msg("user", "2", "back()");
                      }
                      break;

                case "move_topic":
                      if ($perm[mod_move_topic] == "on") {
                          mod_move_topic($HTTP_POST_VARS[Topic_id]);
                      } else {
                          msg("user", "2", "back()");
                      }
                      break;

                case "move_post":
                      if ($perm[mod_move_post] == "on") {
                          mod_move_post($HTTP_POST_VARS[Topic_id]);
                      } else {
                          msg("user", "2", "back()");
                      }
                      break;

                case "edit":
                      if ($perm[mod_edit] == "on") {
                          mod_edit($HTTP_POST_VARS[Topic_id]);
                      } else {
                          msg("user", "2", "back()");
                      }
                      break;

                case "delete":
                      if ($perm[mod_del] == "on") {
                          mod_del($HTTP_POST_VARS[Topic_id]);
                      } else {
                          msg("user", "2", "back()");
                      }
                      break;

                case "join":
                      if ($perm[mod_join] == "on") {
                          mod_join($HTTP_POST_VARS[Topic_id]);
                      } else {
                          msg("user", "2", "back()");
                      }
                      break;
        }
###############################################################################
############################### Funktionen ####################################
###############################################################################
#
#
##################### open / close ##################### +++
function mod_openclose($topic) {
         $Daten = mysql_fetch_array (mySQL_query ("SELECT closed FROM $GLOBALS[TB_TOPIC] WHERE id='$topic'"));

         ### �ffnen
         if ($Daten[closed] == "on") {
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET closed='' WHERE id='$topic'");
             $Fehler="mod_open";
         ### schlie�en
         } else {
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET closed='on' WHERE id='$topic'");
             $Fehler="mod_close";
         }
         msg($Fehler, "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$topic&goto=lastpost");
}
##################### open / close ##################### ---
#
#
##################### top / untop ##################### +++
function mod_top($topic) {
         $Daten = mysql_fetch_array (mySQL_query("SELECT top FROM $GLOBALS[TB_TOPIC] WHERE id='$topic'"));

         ### top
         if (!$Daten[top]) {
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET top='1' WHERE id='$topic'");
             $Fehler="mod_top";
         ### untop
         } else {
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET top='0' WHERE id='$topic'");
             $Fehler="mod_untop";
         }
         msg($Fehler, "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$topic&goto=lastpost");
}
##################### top / untop ##################### ---
#
#
##################### move topic ##################### +++
function mod_move_topic($topic) {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         if (!$HTTP_POST_VARS[move_to]) {
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
             <input type='hidden' name='action' value='move_topic'>
             <input type='hidden' name='Topic_id' value='<?php echo $topic; ?>'>
             <?php open_table("Thema verschieben", "70%"); ?>
             Bitte w&auml;hlen sie das Forum aus, in welches dieses Thema verschoben werden soll.<br>
             <p align='center'>
                     <?php
                     $forum = mysql_fetch_array(mysql_query("SELECT forum_id FROM $GLOBALS[TB_TOPIC] WHERE id='$topic'"));
                     echo "<input type='hidden' name='forum_id' value='$forum[forum_id]'>";
                     ?>
                <select name='move_to'>
                     <?php
                     $result = mySQL_query ("SELECT $GLOBALS[TB_FORUM].id, $GLOBALS[TB_FORUM].name
                                             FROM $GLOBALS[TB_FORUM], $GLOBALS[TB_CAT]
                                             WHERE $GLOBALS[TB_FORUM].show_forum='on'
                                               AND $GLOBALS[TB_CAT].id=$GLOBALS[TB_FORUM].cat_id
                                               AND $GLOBALS[TB_CAT].show_cat='on'
                                               AND $GLOBALS[TB_FORUM].id <> '$forum[forum_id]'
                                             ORDER BY $GLOBALS[TB_FORUM].name");
                     while ($Daten = mysql_fetch_array ($result)) {

                            echo "<option value='$Daten[id]' ";
                            if ($Daten[id] == $forum[forum_id]) {
                                echo "SELECTED";
                            }
                            echo ">$Daten[name]</option>";
                     }
                     ?>
                </select>
                <input type='submit' value='verschieben'>
             </p>
             <?php
             close_table();
             echo "</form>";
         } else {
             //Thema verschieben
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET forum_id='$HTTP_POST_VARS[move_to]' WHERE id='$topic'");

             //altes Forum
             $posts = mysql_fetch_array(mysql_query("SELECT posts FROM $GLOBALS[TB_TOPIC] WHERE id='$topic'"));
             $last_topic = mysql_fetch_array(mysql_query("SELECT id FROM $GLOBALS[TB_TOPIC]
                                                          WHERE forum_id='$HTTP_POST_VARS[forum_id]'
                                                          ORDER BY post_date DESC
                                                          LIMIT 0,1"));
             $posts[posts]++;
             mysql_query("UPDATE $GLOBALS[TB_FORUM] SET topics=topics-1, last_topic='$last_topic[id]', posts=posts-$posts[posts] WHERE id='$HTTP_POST_VARS[forum_id]'");

             //neues Forum updaten
             mysql_query("UPDATE $GLOBALS[TB_FORUM] SET topics=topics+1, posts=posts+$posts[posts] WHERE id='$HTTP_POST_VARS[move_to]'");

             msg("mod_move_topic", "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$topic");
         }
}
##################### move topic ##################### ---
#
#
##################### move post ##################### +++
function mod_move_post($topic) {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         ### Formular anzeigen (Post - auswahl)
         if (!is_array($HTTP_POST_VARS[posts]) AND !$HTTP_POST_VARS[new_topic]) {

             $result = mySQL_query ("SELECT $GLOBALS[TB_POST].id,
                                            $GLOBALS[TB_POST].text,
                                            $GLOBALS[TB_USER].name,
                                            $GLOBALS[TB_USER].name AS user_name
                                     FROM $GLOBALS[TB_POST], $GLOBALS[TB_USER], $GLOBALS[TB_TOPIC]
                                     WHERE $GLOBALS[TB_TOPIC].id='$topic'
                                       AND $GLOBALS[TB_POST].topic_id=$GLOBALS[TB_TOPIC].id
                                       AND $GLOBALS[TB_POST].user_id=$GLOBALS[TB_USER].id
                                     ORDER BY $GLOBALS[TB_POST].post_date ASC");
             echo "<form method='post' action='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]'>";
             echo "<input type='hidden' name='action' value='move_post'>";
             echo "<input type='hidden' name='Topic_id' value='$topic'>";
                table_header("Beitr&auml;ge verschieben", "70%", "", "colspan='3'");
                    $n = 1;
                    $i = 1;
                    while ($Daten = mysql_fetch_array ($result)) {

                           if ($n == "2") {
                               $n = 0;
                               $color = "class='cat_one'";
                           } else {
                               $color = "class='cat_two'";
                           }
                           ?>
                           <tr>
                               <td width='20%' <?php echo $color; ?>>
                                   <span class='font_small'>
                                         <?php echo $Daten[name]; ?>
                                   </span>
                               <td width='75%' valign='top' <?php echo $color; ?>>
                                   <span class='font_small'>
                                         <?php echo bbcode($Daten[text], "on", "", "", "on", "", ""); ?>
                                   </span>
                               <td width='75%' align='center' valign='top' <?php echo $color; ?>>
                                   <?php if ($i >= 2) { ?>
                                          <input type='checkbox' name='posts[]' VALUE='<?php echo $Daten[id]; ?>'>
                                   <?php } ?>
                               </td>
                           </tr>
                           <?php
                           $n++;
                           $i++;
                    } ?>
                </table>
                <p></p>
                <center>
                        <input type='submit' value='ausw&auml;hlen'>
                        <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
                </center>
             </form>
             <?php

         ### Themen Suche / neues Thema
         } elseif (is_array($HTTP_POST_VARS[posts]) AND !$HTTP_POST_VARS[typ]) {
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
                   <input type='hidden' name='action' value='move_post'>
                   <input type='hidden' name='Topic_id' value='<?php echo $topic; ?>'>
                   <?php
                   while (list($key, $val) = each($HTTP_POST_VARS[posts])) {
                          echo "<input type='hidden' name='posts[]' value='$val'>\n";
                   }
                   table_header("Beitr&auml;ge verschieben", "70%", "", "colspan='3'"); ?>
                         <tr>
                             <td width='5%' align='center' class='cat_two'>
                                 <input type='radio' name='typ' value='new' checked>
                             <td width='50%' class='cat_one'>
                                 <b>neues Thema erstellen:</b><br>
                                 <span class='font_small'>
                                       Geben sie hier einen Namen f�r das neue Thema ein.
                                 </span>
                             <td width='45%' class='cat_two'>
                                 <input type='text' name='new_topic' size='30' MAXLENGTH='100'>
                             </td>
                         <tr>
                             <td width='5%' align='center' class='cat_two'>
                                 &nbsp;
                             <td width='50%' class='cat_one'>
                                 <b>Forum f&uuml;r neues Thema:</b><br>
                                 <span class='font_small'>
                                       W&auml;hlen sie hier ein Forum f�r das neue Thema.
                                 </span>
                             <td width='45%' class='cat_two'>
                                 <select name='forum_id'>
                                         <?php
                                         $result = mysql_query("SELECT id, name FROM $GLOBALS[TB_FORUM] WHERE show_forum='on' ORDER BY name");
                                         while ($Daten = mysql_fetch_array($result)) {
                                                echo "<option value='$Daten[id]'>$Daten[name]";
                                         }
                                         ?>
                                 </select>
                             </td>
                         <tr>
                             <td width='5%' align='center' class='cat_two'>
                                 <input type='radio' name='typ' value='move'>
                             <td width='50%' class='cat_one'>
                                 <b>in vorhandenes Thema verschieben:</b><br>
                                 <span class='font_small'>
                                       Geben sie den Namen eines vorhandenen Thema�s ein.
                                 </span>
                             <td width='45%' class='cat_two'>
                                 <input type='text' name='move_topic' size='30' MAXLENGTH='100'>
                             </td>
                         </tr>
                   </table>
                   <p></p>
                   <center>
                           <input type='submit' value='weiter'>
                           <input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
                   </center>
                   <?php
             echo "</form>";

         ### neues Thema erstellen
         } elseif (is_array($HTTP_POST_VARS[posts]) AND $HTTP_POST_VARS[typ] == "new" AND $HTTP_POST_VARS[new_topic]) {
             $old_forum = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_TOPIC].forum_id
                                                          FROM $GLOBALS[TB_TOPIC], $GLOBALS[TB_POST]
                                                          WHERE $GLOBALS[TB_TOPIC].id=$GLOBALS[TB_POST].topic_id
                                                            AND $GLOBALS[TB_POST].id='".$HTTP_POST_VARS[posts][0]."'"));
             //Topic erstellen
             $poster = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_USER].id
                                                          FROM $GLOBALS[TB_POST], $GLOBALS[TB_USER]
                                                          WHERE $GLOBALS[TB_POST].user_id=$GLOBALS[TB_USER].id
                                                            AND $GLOBALS[TB_POST].id='".$HTTP_POST_VARS[posts][0]."'"));

             mysql_query("INSERT INTO $GLOBALS[TB_TOPIC] (name, post_date, poster_id, forum_id, posts, show_topic, closed)
                          VALUES ('".htmlentities($HTTP_POST_VARS[new_topic])."',NOW(),'$poster[id]','$HTTP_POST_VARS[forum_id]','".count($HTTP_POST_VARS[posts])."'-1,'on','')");
             $topic_id = mysql_insert_id();
             //Post�s verschieben
             while (list($key, $val) = each($HTTP_POST_VARS[posts])) {
                    mysql_query("UPDATE $GLOBALS[TB_POST] SET topic_id='$topic_id' WHERE id='$val'");
             }
             //altes Topic aupdaten
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET posts=posts-".count($HTTP_POST_VARS[posts])." WHERE id='$topic'");


             //nicht gleiches Forum
             if ($HTTP_POST_VARS[forum_id] != $old_forum[forum_id]) {
                 //altes Forum
                 mysql_query("UPDATE $GLOBALS[TB_FORUM] SET posts=posts-".count($HTTP_POST_VARS[posts])." WHERE $GLOBALS[TB_FORUM].id='$old_forum[forum_id]'");
                 //neues Forum
                 mysql_query("UPDATE $GLOBALS[TB_FORUM] SET posts=posts+".count($HTTP_POST_VARS[posts]).", topics=topics+1, last_topic='$topic_id' WHERE $GLOBALS[TB_FORUM].id='$HTTP_POST_VARS[forum_id]'");

             //gleiches Forum
             } elseif ($HTTP_POST_VARS[forum_id] == $old_forum[forum_id]) {
                 //neues Forum
                 mysql_query("UPDATE $GLOBALS[TB_FORUM] SET topics=topics+1 WHERE $GLOBALS[TB_FORUM].id='$HTTP_POST_VARS[forum_id]'");
             }
             msg("mod_move_post_new", "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$topic_id");

         ### Themen Liste (verschieben)
         } elseif (is_array($HTTP_POST_VARS[posts]) AND $HTTP_POST_VARS[move_topic] AND $HTTP_POST_VARS[typ] == "move" AND !$HTTP_POST_VARS[save]) {
             $result = mySQL_query ("SELECT $GLOBALS[TB_TOPIC].id,
                                            $GLOBALS[TB_TOPIC].name
                                     FROM $GLOBALS[TB_TOPIC], $GLOBALS[TB_FORUM], $GLOBALS[TB_CAT]
                                     WHERE $GLOBALS[TB_TOPIC].forum_id=$GLOBALS[TB_FORUM].id
                                       AND $GLOBALS[TB_FORUM].show_forum='on'
                                       AND $GLOBALS[TB_CAT].id=$GLOBALS[TB_FORUM].cat_id
                                       AND $GLOBALS[TB_TOPIC].name LIKE '%$HTTP_POST_VARS[move_topic]%'
                                       AND $GLOBALS[TB_TOPIC].id <> $topic");
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
                   <input type='hidden' name='action' value='move_post'>
                   <input type='hidden' name='typ' value='move'>
                   <input type='hidden' name='save' value='ok'>
                   <input type='hidden' name='Topic_id' value='<?php echo $topic; ?>'>
                   <?php
                   while (list($key, $val) = each($HTTP_POST_VARS[posts])) {
                          echo "<input type='hidden' name='posts[]' value='$val'>\n";
                   }
                   open_table("Beitr&auml;ge verschieben", "70%"); ?>
                        <p align='center'>
                           Beitr&auml;ge verschieben nach:<br><br>
                           <select name='move_topic'>
                                   <?php
                                   while ($Daten = mysql_fetch_array($result)) {
                                          echo "<option value='$Daten[id]'>$Daten[name]";
                                   }
                                   ?>
                           </select>
                           <br><br>
                           <input type='submit' value='verschieben'>&nbsp;
                           <input type='button' value='nicht verschieben' ONCLICK="javascript:location.href('<?php echo "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$topic"; ?>')">
                        </p>
                        <?php
                   close_table();
             echo "</form>";

         ### Beitr�ge in das Thema verschieben
         } elseif (is_array($HTTP_POST_VARS[posts]) AND $HTTP_POST_VARS[typ] == "move" AND $HTTP_POST_VARS[move_topic] AND $HTTP_POST_VARS[save]) {
             $old_forum = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_TOPIC].forum_id
                                                          FROM $GLOBALS[TB_TOPIC], $GLOBALS[TB_POST]
                                                          WHERE $GLOBALS[TB_TOPIC].id=$GLOBALS[TB_POST].topic_id
                                                            AND $GLOBALS[TB_POST].id='".$HTTP_POST_VARS[posts][0]."'"));
             $new_forum = mysql_fetch_array(mysql_query("SELECT forum_id
                                                         FROM $GLOBALS[TB_TOPIC]
                                                         WHERE $GLOBALS[TB_TOPIC].id='$HTTP_POST_VARS[move_topic]'"));
             //Post�s verschieben
             while (list($key, $val) = each($HTTP_POST_VARS[posts])) {
                    mysql_query("UPDATE $GLOBALS[TB_POST] SET topic_id='$HTTP_POST_VARS[move_topic]', post_date=NOW() WHERE id='$val'");
             }
             //altes Topic aupdaten
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET posts=posts-".count($HTTP_POST_VARS[posts])." WHERE id='$topic'");
             //neues Topic aupdaten
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET posts=posts+".count($HTTP_POST_VARS[posts])." WHERE id='$HTTP_POST_VARS[move_topic]'");

             //nicht gleich
             if ($old_forum[forum_id] != $new_forum[forum_id]) {
                 //altes Forum
                 mysql_query("UPDATE $GLOBALS[TB_FORUM] SET posts=posts-".count($HTTP_POST_VARS[posts])." WHERE $GLOBALS[TB_FORUM].id='$old_forum[forum_id]'");
                 //neues Forum
                 mysql_query("UPDATE $GLOBALS[TB_FORUM] SET posts=posts+".count($HTTP_POST_VARS[posts])." WHERE $GLOBALS[TB_FORUM].id='$new_forum[forum_id]'");
             }
             msg("mod_move_post_move", "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$HTTP_POST_VARS[move_topic]");
         }
}
##################### move post ##################### ---
#
#
##################### edit ##################### +++
function mod_edit($topic) {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         if (!$HTTP_POST_VARS[name]) {
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
             <input type='hidden' name='action' value='edit'>
             <input type='hidden' name='Topic_id' value='<?php echo $topic; ?>'>
             <?php open_table("Thema bearbeiten", "100%"); ?>
             In diesem Textfeld kann der neue Titel des Thema bestimmt werden.<br>
             <p align='center'>
                <?php
                $topic_name = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_TOPIC].name
                                                              FROM $GLOBALS[TB_TOPIC]
                                                              WHERE $GLOBALS[TB_TOPIC].id='$topic'"));
                ?>
                <input type='text' name='name' size='30' MAXLENGTH='100' VALUE='<?php echo $topic_name[name]; ?>'>
                <input type='submit' value='umbenennen'>
             </p>
             <?php
             close_table("");
             echo "</form>";
         } else {
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET name='".htmlentities($HTTP_POST_VARS[name])."' WHERE id='$topic'");
             msg("mod_edit", "2", "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$topic");
         }
}
##################### edit ##################### ---
#
#
##################### delete ##################### +++
function mod_del($topic) {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         $topic_daten = mysql_fetch_array(mySQL_query ("SELECT $GLOBALS[TB_TOPIC].name, $GLOBALS[TB_TOPIC].forum_id
                                                       FROM $GLOBALS[TB_TOPIC]
                                                       WHERE $GLOBALS[TB_TOPIC].id='$topic'"));
         if (!$HTTP_POST_VARS[ok]) {
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
             <input type='hidden' name='action' value='delete'>
             <input type='hidden' name='ok' value='1'>
             <input type='hidden' name='Topic_id' value='<?php echo $topic; ?>'>
             <?php open_table("Thema l&ooml;schen", "100%"); ?>
             Soll das Thema <b><?php echo $topic_daten[name]; ?></b> wirklich gel�scht werden?<br>
             <p align='center'>
                <input type='submit' value='l&ouml;schen'>&nbsp;
                <input type='button' value='nicht l&ouml;schen' ONCLICK='javascript:history.back()'>
             </p>
             <?php
             close_table("");
             echo "</form>";
         } else {
             del_topic($topic);
             msg("mod_del", "2", "showforum.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Forum_id=$topic_daten[forum_id]");
         }
}
##################### delete ##################### ---
#
#
##################### join ##################### +++
function mod_join($topic) {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         $topic_daten = mysql_fetch_array(mySQL_query ("SELECT *
                                                       FROM $GLOBALS[TB_TOPIC]
                                                       WHERE $GLOBALS[TB_TOPIC].id='$topic'"));
         # Themen-Name eingeben
         if (!$HTTP_POST_VARS[topic_name] AND !$HTTP_POST_VARS[topic_join]) {
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
                   <input type='hidden' name='action' value='join'>
                   <input type='hidden' name='Topic_id' value='<?php echo $topic; ?>'>
                   <?php open_table("Thema verschieben", "70%"); ?>
                           Bitte geben Sie den Namen des Themas ein in welches: "<b><?php echo $topic_daten[name]; ?></b>" verschoben werden soll.<br>
                           <p align='center'>
                              <input type='text' name='topic_name' size='20' MAXLENGTH='100'>
                              <input type='submit' value='Thema suchen'>
                           </p>
                   <?php close_table("");
             echo "</form>";

         # Themen-Liste anzeigen
         } elseif ($HTTP_POST_VARS[topic_name] AND !$HTTP_POST_VARS[topic_join]) {
             $result = mySQL_query ("SELECT $GLOBALS[TB_TOPIC].id,
                                            $GLOBALS[TB_TOPIC].name
                                     FROM $GLOBALS[TB_TOPIC], $GLOBALS[TB_FORUM], $GLOBALS[TB_CAT]
                                     WHERE $GLOBALS[TB_TOPIC].forum_id=$GLOBALS[TB_FORUM].id
                                       AND $GLOBALS[TB_FORUM].show_forum='on'
                                       AND $GLOBALS[TB_CAT].id=$GLOBALS[TB_FORUM].cat_id
                                       AND $GLOBALS[TB_TOPIC].name LIKE '%$HTTP_POST_VARS[topic_name]%'
                                       AND $GLOBALS[TB_TOPIC].id <> '$topic_daten[id]'");
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]"; ?>'>
             <input type='hidden' name='action' value='join'>
             <input type='hidden' name='Topic_id' value='<?php echo $topic; ?>'>
             <?php open_table("Thema verschieben", "70%"); ?>
                     <p align='center'>
                        <b><?php echo $topic_daten[name]; ?></b> verschieben nach:<br><br>
                        <select name='topic_join'>
                                <?php
                                while ($Daten = mysql_fetch_array($result)) {
                                       echo "<option value='$Daten[id]'>$Daten[name]";
                                }
                                ?>
                        </select>
                        <br><br>
                        <input type='submit' value='verschieben'>&nbsp;
                        <input type='button' value='nicht verschieben' ONCLICK="javascript:location.href('<?php echo "showtopic.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Topic_id=$topic"; ?>')">
                     </p>
                     <?php
             close_table();
             echo "</form>";

         # Thema verschieben
         } elseif (!$HTTP_POST_VARS[topic_name] AND $HTTP_POST_VARS[topic_join]) {
             $new_topic = mysql_fetch_array(mySQL_query ("SELECT forum_id
                                                          FROM $GLOBALS[TB_TOPIC]
                                                          WHERE $GLOBALS[TB_TOPIC].id='$HTTP_POST_VARS[topic_join]'"));
             //Post�s verschieben
             mysql_query("UPDATE $GLOBALS[TB_POST] SET $GLOBALS[TB_POST].topic_id='$HTTP_POST_VARS[topic_join]', $GLOBALS[TB_POST].post_date=NOW() WHERE $GLOBALS[TB_POST].topic_id='$topic'");
             //altes Topic l�schen
             del_topic($topic);
             //neues Topic updaten
             mysql_query("UPDATE $GLOBALS[TB_TOPIC] SET posts=posts+($topic_daten[posts]+1) WHERE $GLOBALS[TB_TOPIC].id='$HTTP_POST_VARS[topic_join]'");

             //Foren updaten wenn nicht gleiche Forum
             if ($topic_daten[forum_id] != $new_topic[forum_id]) {
                 //altes Forum
                 mysql_query("UPDATE $GLOBALS[TB_FORUM] SET posts=posts-($topic_daten[posts]+1) WHERE $GLOBALS[TB_FORUM].id='$topic_daten[forum_id]'");
                 //neues Forum
                 mysql_query("UPDATE $GLOBALS[TB_FORUM] SET posts=posts+($topic_daten[posts]+1) WHERE $GLOBALS[TB_FORUM].id='$new_topic[forum_id]'");
             }
             msg("mod_join", "2", "showtopic.php?Topic_id=$HTTP_POST_VARS[topic_join]");

         }
}
##################### join ##################### ---

echo "<br><br>";
footer();
?>