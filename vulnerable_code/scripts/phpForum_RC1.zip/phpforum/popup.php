<?php
        include("config.inc.php");    //Konfiguration
        $no_head = "on";
        include("head.php");    //Konfiguration
        echo "<title>- neue PM -</title>";

        $pm_anz=pm_status();
        open_table("phpForum - Mitteilung","100%");
                    echo "Sie haben $pm_anz";
                    if ($pm_anz > "1") {
                        echo " neue Nachrichten.";
                    } else {
                        echo " neue Nachricht.";
                    }
                    echo "<br> Klicken sie <a href=\"javascript:window.close()\" onClick=\"opener.location.href ='user.php?$Sess_Name=$Sess'\">hier</a> um diese anzeigen zu lassen.";
        close_table("Um dieses Fenster zu deaktivieren, m&uuml;ssen sie <a href=\"javascript:window.close()\" onClick=\"opener.location.href ='user.php?$Sess_Name=$Sess&action=settings'\">hier</a> klicken.");

        ### Fenster f�r die aktuellen PM�s deaktivieren ###
        $userinfo = get_user_info();
        mysql_query("UPDATE $TB_USER SET pm_popup_show='on' WHERE id='$userinfo[id]'");
?>