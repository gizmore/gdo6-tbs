<?php
  $ACCESS_PAGE = "index";
  include("head.php");        //Header mit Bild, Suchen...
################################################################################
?>
<BR>
<table border='0' cellpadding='2' cellspacing='1' width='100%' class='default_table'>
       <tr class='default_tr'>
           <td width='2%'>
               &nbsp;
           <td width='54%'>
               <B>Forum</B>
           <td width='6%' NOWRAP align='center'>
               <b>Themen</b>
           <td width='6%' NOWRAP align='center'>
               <b>Beitr&auml;ge</b>
           <td width='15%' NOWRAP align='center'>
               <b>Letzter Beitrag</b>
           <td width='15%' NOWRAP align='center'>
               <B>Moderator</B>
           </td>
       </tr>
<?php
################################################################################
############################ Hier geht�s los ################################### +++
################################################################################
#
#
######################### Kategorien ########################
if ($HTTP_GET_VARS[Cat_id]) {
    $where_cid="AND $TB_CAT.id='$HTTP_GET_VARS[Cat_id]'";
}
$result_cat = mySQL_query ("SELECT * FROM $TB_CAT WHERE $TB_CAT.show_cat='on' $where_cid ORDER BY $TB_CAT.rang");
while ($Daten_cat = mysql_fetch_array ($result_cat)) {
       ?>
       <tr class='cat_tr'>
           <td width='100%' valign='top' colspan="6">
               <?php
               //in einer Kategorie !
               if ($where_cid != "") {
                   echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess'><b>$TITEL_KURZ</b></a>&nbsp;:&nbsp;<b>$Daten_cat[name]</b>";
               //auf der Startseite !
               } else {
                   echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&Cat_id=$Daten_cat[id]'><b>$Daten_cat[name]</b></a>";
               }
               ?>
           </td>
       </tr>
       <?php
       ######################### Foren ########################
       $result_forum = mySQL_query ("SELECT * FROM $TB_FORUM WHERE $TB_FORUM.cat_id='$Daten_cat[id]' AND $TB_FORUM.show_forum='on' ORDER BY $TB_FORUM.rang");
       while ($Daten_forum = mysql_fetch_array ($result_forum)) {
              ?>
              <tr>
                  <td width='2%' class='cat_tr'>
                      <?php echo forum_new($Daten_forum[id]); ?>
                  <td width='54%' class='cat_one'>
                      <a href='<?php echo "showforum.php?$Sess_Name=$Sess&Forum_id=$Daten_forum[id]"; ?>'><b><?php echo $Daten_forum[name]; ?></b></a>
                      <br>
                      <span class='font_small'>
                            <?php echo $Daten_forum[info]; ?>
                      </span>
                  <td width='6%' align='center' class='cat_two'>
                            <b><?php echo $Daten_forum[topics]; ?></b>
                  <td width='6%' align='center' class='cat_one'>
                            <b><?php echo $Daten_forum[posts]; ?></b>
                  <td width='15%' align='center' class='cat_two'>
                      <span class='font_small'>
                            <?php
                            $last_topic = last_topic($Daten_forum[last_topic]);
                            if ($last_topic[topic_name]) {
                                echo "<a href='showtopic.php?$Sess_Name=$Sess&Topic_id=$Daten_forum[last_topic]&goto=lastpost' title='Gehe zum letzten Beitrag'><b>".substr($last_topic[topic_name],0,20)."</b>...</a>";
                            } else {
                                echo "N/A";
                            }
                            if ($last_topic[user_id]) {
                                echo "<br>von&nbsp;<a href='showuser.php?$Sess_Name=$Sess&id=$last_topic[user_id]'>$last_topic[user_name]</a>";
                            } else {
                                echo "<br>N/A";
                            }
                            if ($last_topic[post_date]) {
                                echo "<br>am&nbsp;$last_topic[post_date]";
                            }
                            ?>
                      </span>
                  <td width='15%' align='center' class='cat_one'>
                      <span class='font_small'>
                            <?php
                            //Mod herausbekommen (id)
                            $result_mod = mySQL_query ("SELECT $TB_USER.name, $TB_MOD.user_id
                                                        FROM $TB_MOD, $TB_USER
                                                        WHERE $TB_MOD.forum_id='$Daten_forum[id]'
                                                          AND $TB_MOD.user_id=$TB_USER.id");
                            while($Daten_mod = mysql_fetch_array ($result_mod)) {
                                  echo "<a href='showuser.php?$Sess_Name=$Sess&id=$Daten_mod[user_id]'>
                                           $Daten_mod[name]
                                        </a><br>";
                            }
                            ?>
                      </span>
                  </td>
              </tr>
              <?php
       }
}
echo "</tr>";
who_is_online();
echo "</table>";
################################################################################
############################## Hier ist Ende ################################### ---
################################################################################
echo "<br>";
echo "<div align='right' class='font_normal'>
           <a href='functions.php?$Sess_Name=$Sess&action=abo&op=read'>[alle Themen als gelesen markieren]</a>
      </div>";
footer_list();
footer();
?>