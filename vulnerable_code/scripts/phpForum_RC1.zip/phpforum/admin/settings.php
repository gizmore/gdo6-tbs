<?php
    include("head.php");
auth("admin_settings");
?>
<h3 class='font_big'>Einstellungen...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "edit":
              edit();
              break;

        case "save":
              save();

}
#################################################################
######################### Funktionen ############################
#################################################################
function edit() {
         global $HTTP_SERVER_VARS, $_style;
         ?>
         <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <?php
               table_header("Einstellungen bearbeiten...", "100%", "", "colspan='2'");
               ?>
                  <tr>
                      <td width='30%' class='cat_one' colspan='2'>
                          <?php
                          $result =mysql_query("SELECT *
                                                FROM $GLOBALS[TB_SETTING_GROUP]
                                                ORDER BY $GLOBALS[TB_SETTING_GROUP].name ASC");
                          while ($Daten=mysql_fetch_array($result)) {
                                 echo "<b>-</b>&nbsp;<a href='#$Daten[id]'>$Daten[name]</a><br>\n";
                          }
                          ?>
                      </td>
                  </tr>
                  <?php
               $result =mysql_query("SELECT *
                                     FROM $GLOBALS[TB_SETTING_GROUP]
                                     ORDER BY $GLOBALS[TB_SETTING_GROUP].name ASC");
               while ($Daten=mysql_fetch_array($result)) {

                      table_header("<a name='$Daten[id]'>$Daten[name]:", "100%", "1", "colspan=2", "nohead");
                      $result_settings = mysql_query ("SELECT *
                                                       FROM $GLOBALS[TB_SETTINGS]
                                                       WHERE $GLOBALS[TB_SETTINGS].cid='$Daten[id]'
                                                       ORDER BY $GLOBALS[TB_SETTINGS].titel ASC");
                      while ($Daten_settings = mysql_fetch_array($result_settings)) {
                             ?>
                             <tr>
                                 <td width='50%' class='cat_two' valign='top'>
                                     <b><?php echo $Daten_settings[titel]; ?>:</b>
                                     <br>
                                     <span class='font_small'>
                                           <?php echo $Daten_settings[info]; ?>
                                     </span>
                                 <td width='50%' class='cat_one'>
                                     <?php
                                     switch ($Daten_settings[typ]) {

                                             case "text":
                                                   echo "<input type='text' name='new$Daten_settings[name]' value='".htmlentities($Daten_settings[value])."' size='30'>";
                                                   break;

                                             case "textarea":
                                                   echo "<textarea name='new$Daten_settings[name]' cols='40' rows='6'>".htmlentities($Daten_settings[value])."</textarea>";
                                                   break;

                                             case "radio":
                                                   echo "<span class='font_normal'>";
                                                   if ($Daten_settings[value] == "on") {
                                                       echo "<input type='radio' name='new$Daten_settings[name]' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                                       echo "<input type='radio' name='new$Daten_settings[name]' value=''>&nbsp;nein";
                                                   } else {
                                                       echo "<input type='radio' name='new$Daten_settings[name]' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                                       echo "<input type='radio' name='new$Daten_settings[name]' value='' checked>&nbsp;nein";
                                                   }
                                                   echo "</span>";
                                                   break;

                                             case "select":
                                                   echo "<select name='new$Daten_settings[name]'>";
                                                   $len = split (",", $Daten_settings[len]);
                                                   while (list($id, $val) = each($len)) {
                                                          echo "<option value=\"$val\"";
                                                          if ($Daten_settings[value] == $val) {
                                                              echo " selected";
                                                          }
                                                          echo ">$val</option>";
                                                   }
                                                   echo "</select>";
                                                   echo $val;
                                                   break;

                                             case "access":
                                                   echo "<select name='new$Daten_settings[name]'>";
                                                   $result_access = mysql_query("SELECT * FROM $GLOBALS[TB_ACCESS] ORDER BY name");
                                                   while ($Daten_access = mysql_fetch_array($result_access)) {
                                                          echo "<option value='$Daten_access[id]'";
                                                          if ($Daten_settings[value] == $Daten_access[id]) {
                                                              echo " selected";
                                                          }
                                                          echo ">$Daten_access[name]</option>";
                                                   }
                                                   echo "</select>";
                                                   break;

                                             case "list":
                                                   list($start, $end) = split ("-", $Daten_settings[len]);
                                                   echo "<select name='new$Daten_settings[name]'>";
                                                   for ($n=$start; $n <= $end ; $n++) {
                                                          echo "<option value=\"$n\"";
                                                          if ($Daten_settings[value] == $n) {
                                                              echo " selected";
                                                          }
                                                          echo ">$n</option>";
                                                   }
                                                   echo "</select>";
                                                   break;
                                     } //Switch ende
                                     ?>
                                 </td>
                             </tr>
                             <?php
                      } //Settings
         } //Setting_groups
         ?>
         </table>
         <br>
         <center>
                 <input type='submit' value='�ndern'>&nbsp;<input type='reset' name='Reset' value='Zur&uuml;cksetzen'>
         </center>
</form>
<?php
}

function save() {
         global $HTTP_POST_VARS;
         $result = mysql_query ("SELECT *
                                 FROM $GLOBALS[TB_SETTINGS]");

         while ($Daten = mysql_fetch_array($result)) {
                $name=$Daten[name];
                $query = "UPDATE $GLOBALS[TB_SETTINGS] SET value='".$HTTP_POST_VARS["new$name"]."' WHERE name='$name'";
                if (mysql_query($query)) {
                    $Fehler="ja";
                } else {
                    $Fehler="nein";
                }
         }
         if ($Fehler == "ja") {
             msg("settings", "2", "admin.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]");
         } else {
             msg("settings_fault", "2", "back()");
         }
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>