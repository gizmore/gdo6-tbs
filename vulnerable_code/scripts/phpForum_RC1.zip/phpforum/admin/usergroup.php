<?php
include("head.php");
auth("admin_user_groups");
?>
<h3 class='font_big'>Benutzergruppen...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "add":
              addedit();
              break;

        case "liste":
              liste();
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id]);
              break;

        case "save":
              save();
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($id="") {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post' <?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { echo "enctype='multipart/form-data'"; } ?> action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <input type='hidden' name='id' VALUE='<?php echo $id; ?>'>
               <input type='hidden' name='save' VALUE='<?php
                      if ($id == "") {
                          echo "add'>";
                          $typ = "hinzuf�gen";
                      } else {
                          echo "edit'>";
                          $typ = "bearbeiten";
                          $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                                  FROM $GLOBALS[TB_ACCESS]
                                                                  WHERE $GLOBALS[TB_ACCESS].id='$id'"));
                      }
               table_header("Benutzergruppe $typ...", "100%", "", "colspan='2'"); ?>
                     <tr>
                         <td width='30%' class='cat_one' colspan='2'>
                             <b>-</b>&nbsp;<a href='#all'>Allgemein</a><br>
                             <b>-</b>&nbsp;<a href='#diverses'>Diverses</a><br>
                             <b>-</b>&nbsp;<a href='#postings'>Themen / Beitr�ge</a><br>
                             <b>-</b>&nbsp;<a href='#mod'>Moderation</a><br>
                             <b>-</b>&nbsp;<a href='#admin'>Administration</a>
                         </td>
                     </tr>
               <?php table_header("<a name='all'>Allgemein:", "100%", "1", "colspan='2'", "nohead"); ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Name:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' name='name' value="<?php echo $Daten[name]; ?>" maxlenght='50' size='30'>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf sich Einloggen?:</b>
                                <br>
                                <span class='font_small'>
                                      w&auml;hlen sie hier nein um allen Benutzern dieser Gruppe das Login zu verweigern.
                                </span>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[login] == "on") {
                                    echo "<input type='radio' name='login' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='login' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='login' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='login' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>keine Bewertung dieses Benutzers:</b>
                                <br>
                                <span class='font_small'>
                                      Wenn sie diese Option aktivieren wird dieser Benutzer nicht mit den Benutzer-Titeln bewertet. (f�r Mod�s und Admin�s sinnvoll)
                                </span>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[special] == "on") {
                                    echo "<input type='radio' name='special' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='special' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='special' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='special' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>aktuelles Bewertungs-Bild:</b>
                                <br>
                                <span class='font_small'>
                                      Wenn sie hier ein Bild ausw&auml;hlen wird bei diesem Benutzer nur dieses Bild f�r den Status angezeigt. (f�r Mod�s und Admin�s sinnvoll)
                                </span>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[data]) {
                                    echo "<img src='../functions.php?action=access&id=$Daten[id]' border='0'><br><br>";
                                    echo "<input type='checkbox' name='pic_del'>&nbsp;l�schen<br>";
                                }
                                ?>
                            </td>
                        <?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>lokale Datei:</b>
                                <br>
                                <span class='font_small'>
                                   Hier k&ouml;nnen sie ein Bild von ihrer Festplatte ausw&auml;hlen.
                                </span>
                            <td width='50%' class='cat_one'>
                                <input type='file' name='userfile'>
                            </td>
                        <?php } ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Datei auf dem Server:</b>
                                <br>
                                <span class='font_small'>
                                      Diese Dateien liegen im phpForum Verzeichnis <b>upload</b>,<br>
                                      sie k&ouml;nnen weitere mit einem FTP-Programm hochladen.
                                </span>
                            <td width='50%' class='cat_one'>
                                <?php upload_liste("upload"); ?>
                            </td>
                        </tr>
               <?php table_header("<a name='diverses'>Diverses:", "100%", "1", "colspan='2'", "nohead"); ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf PM�s senden?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[send_pm] == "on") {
                                    echo "<input type='radio' name='send_pm' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='send_pm' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='send_pm' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='send_pm' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf sein Profil bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[edit_profil] == "on") {
                                    echo "<input type='radio' name='edit_profil' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='edit_profil' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='edit_profil' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='edit_profil' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Avatare verwenden?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[avatar] == "on") {
                                    echo "<input type='radio' name='avatar' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='avatar' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='avatar' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='avatar' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf eMails mit dem eMail-Formular senden?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[send_mail] == "on") {
                                    echo "<input type='radio' name='send_mail' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='send_mail' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='send_mail' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='send_mail' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf die Member Liste sehen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[show_members] == "on") {
                                    echo "<input type='radio' name='show_members' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='show_members' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='show_members' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='show_members' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf die Suche benutzen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[search] == "on") {
                                    echo "<input type='radio' name='search' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='search' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='search' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='search' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        </tr>
               <?php table_header("<a name='postings'>Themen / Beitr�ge:", "100%", "1", "colspan='2'", "nohead"); ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen / Beitr�ge ansehen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[view] == "on") {
                                    echo "<input type='radio' name='view' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='view' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='view' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='view' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf neue Beitr�ge erstellen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[new_post] == "on") {
                                    echo "<input type='radio' name='new_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='new_post' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='new_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='new_post' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf neue Themen erstellen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[new_topic] == "on") {
                                    echo "<input type='radio' name='new_topic' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='new_topic' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='new_topic' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='new_topic' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf eigene Beitr�ge bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[edit_post] == "on") {
                                    echo "<input type='radio' name='edit_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='edit_post' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='edit_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='edit_post' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf eigene Themen / Beitr�ge l�schen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[del_post] == "on") {
                                    echo "<input type='radio' name='del_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='del_post' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='del_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='del_post' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        </tr>
               <?php table_header("<a name='mod'>Moderation:", "100%", "1", "colspan='2'", "nohead"); ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen �ffnen / schlie�en?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_openclose] == "on") {
                                    echo "<input type='radio' name='mod_openclose' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_openclose' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_openclose' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_openclose' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen festhalten / l&ouml;sen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_top] == "on") {
                                    echo "<input type='radio' name='mod_top' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_top' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_top' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_top' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen verschieben?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_move_topic] == "on") {
                                    echo "<input type='radio' name='mod_move_topic' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_move_topic' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_move_topic' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_move_topic' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Beitr&auml;ge verschieben?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_move_post] == "on") {
                                    echo "<input type='radio' name='mod_move_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_move_post' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_move_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_move_post' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf andere Themen / Beitr�ge bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_edit] == "on") {
                                    echo "<input type='radio' name='mod_edit' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_edit' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_edit' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_edit' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf andere Themen / Beitr�ge l�schen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_del] == "on") {
                                    echo "<input type='radio' name='mod_del' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_del' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_del' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_del' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen zusammen f�hren?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_join] == "on") {
                                    echo "<input type='radio' name='mod_join' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_join' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_join' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_join' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        </tr>
               <?php table_header("<a name='admin'>Administration", "100%", "1", "colspan='2'", "nohead"); ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Einstellungen �ndern?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_settings] == "on") {
                                    echo "<input type='radio' name='admin_settings' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_settings' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_settings' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_settings' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Kategorien bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_cats] == "on") {
                                    echo "<input type='radio' name='admin_cats' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_cats' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_cats' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_cats' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Foren / Moderatoren bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_forums] == "on") {
                                    echo "<input type='radio' name='admin_forums' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_forums' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_forums' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_forums' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Benutzer bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_users] == "on") {
                                    echo "<input type='radio' name='admin_users' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_users' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_users' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_users' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Benutzergruppen bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_user_groups] == "on") {
                                    echo "<input type='radio' name='admin_user_groups' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_user_groups' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_user_groups' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_user_groups' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Benutzertitel bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_user_titles] == "on") {
                                    echo "<input type='radio' name='admin_user_titles' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_user_titles' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_user_titles' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_user_titles' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Smilies bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_smilies] == "on") {
                                    echo "<input type='radio' name='admin_smilies' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_smilies' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_smilies' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_smilies' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Board-Codes bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_bbcodes] == "on") {
                                    echo "<input type='radio' name='admin_bbcodes' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_bbcodes' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_bbcodes' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_bbcodes' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Zensierte W&ouml;rter bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_words] == "on") {
                                    echo "<input type='radio' name='admin_words' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_words' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_words' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_words' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Status des Forums einsehen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_status] == "on") {
                                    echo "<input type='radio' name='admin_status' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_status' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_status' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_status' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Styles des Forums bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[admin_styles] == "on") {
                                    echo "<input type='radio' name='admin_styles' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_styles' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='admin_styles' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='admin_styles' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='<?php echo $typ; ?>'>
                       <input type='reset' name='Reset' value='Zur�cksetzen'>
               </center>
         </form>
         <?php
}
function liste() {
         global $HTTP_SERVER_VARS, $_style;
         table_header("Benutzergruppen bearbeiten...", "100%", "", "colspan='4'"); ?>
               <tr class='default_tr'>
                   <td width='40%'>
                       <B>name</B>
                   <td width='20%' align='center'>
                       <B>benutzer</B>
                   <td width='30%' align='center'>
                       <b>optionen</b>
                   <td width='10%' align='center'>
                       <b>l�schen</b>
                   </td>
               </tr>
               <?php
               $result = mySQL_query ("SELECT * FROM $GLOBALS[TB_ACCESS] ORDER BY $GLOBALS[TB_ACCESS].name ASC");
               while ($Daten = mysql_fetch_array ($result)) {
                      ?>
                      <tr>
                          <td width='40%' class='cat_two'>
                              <b><?php echo $Daten[name]; ?></b>
                          <td width='20%' align='center' class='cat_two'>
                              <?php
                              $Daten_user = mysql_fetch_array(mysql_query("SELECT COUNT(id) AS anz
                                                                           FROM $GLOBALS[TB_USER]
                                                                           WHERE $GLOBALS[TB_USER].access_id='$Daten[id]'"));
                              echo $Daten_user[anz];
                              ?>
                          <td width='30%' align='center' class='cat_one'>
                              <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]"; ?>' title='<?php echo "\"".htmlentities($Daten[name], ENT_QUOTES)."\""; ?> bearbeiten'>[bearbeiten]</a>
                              <a href='<?php echo "user.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result&access_id=$Daten[id]"; ?>' title='Benutzer der Gruppe: <?php echo "\"".htmlentities($Daten[name], ENT_QUOTES)."\""; ?> suchen'>[Benutzer suchen]</a>
                          <td width='10%' align='center' class='cat_one'>
                              <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]"; ?>'><img src='<?php echo "../".$_style[pic_admin_del]; ?>' border='0' alt='<?php echo "\"".htmlentities($Daten[name], ENT_QUOTES)."\" l&ouml;schen"; ?>'></a>
                          </td>
                      </tr>
                      <?php
               }
               ?>
         </table>
         <?php
}
function del ($id) {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS, $HTTP_POST_VARS;
         # Formular
         if (!$HTTP_POST_VARS[ok]) {
             ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id"; ?>'>
                   <input type='hidden' name='ok' value='1'>
                   <?php open_table("Benutzergruppe l�schen", "70%"); ?>
                           <table width='100%'>
                                  <tr class='cat_one'>
                                      <td align='left' width='50%'>
                                          <b>Benutzergruppe #<?php echo $id; ?> l�schen?:</b>
                                      <td align='left' width='50%'>
                                          <input type='radio' name='del' value='1'>&nbsp;ja&nbsp;
                                          <input type='radio' name='del' value='' checked>&nbsp;nein&nbsp;
                                      </td>
                                  <tr class='cat_one'>
                                      <td align='left' width='50%'>
                                          <b>neue Benutzergruppe:</b>
                                          <br>
                                          <span class='font_small'>
                                                hier muss eine neue Benutzergruppe f�r die vorhandenen Benutzer dieser Gruppe gew�hlt werden
                                          </span>
                                      <td align='left' width='50%'>
                                          <select name='access_id'>
                                                  <?php
                                                  $result = mysql_query("SELECT *
                                                                         FROM $GLOBALS[TB_ACCESS]
                                                                         WHERE $GLOBALS[TB_ACCESS].id <> $id
                                                                         ORDER BY $GLOBALS[TB_ACCESS].name");
                                                  while ($Daten = mysql_fetch_array($result)) {
                                                         echo "<option value='$Daten[id]'";
                                                         if ($Daten[id] == $GLOBALS[DEFAULT_USER_GROUP]) { echo " selected"; } echo ">$Daten[name]</option>\n";
                                                  }
                                                  ?>
                                          </select>
                                      </td>
                                  </tr>
                           </table>
                           <p align='center'>
                              <input type='submit' value='l�schen'>
                           </p>
                           <?php
                   close_table();
             echo "</form>";

         # wirklich l�schen !
         } elseif ($HTTP_POST_VARS[ok] == "1") {

             if ($HTTP_POST_VARS[del] == "1") {
                 //benutzergruppe l�schen
                 mySQL_query ("DELETE FROM $GLOBALS[TB_ACCESS]
                               WHERE $GLOBALS[TB_ACCESS].id='$id'");
                //Foren Berechtigung entfernen
                 mysql_query ("DELETE FROM $GLOBALS[TB_FORUM_ACCESS]
                               WHERE access_id='$id'");
                 //alte Benutzer der Gruppe in die neue verschieben
                 mysql_query ("UPDATE $GLOBALS[TB_USER]
                               SET access_id=$HTTP_POST_VARS[access_id]
                               WHERE access_id='$id'");
                 $Fehler = "usergroup_del";
             } else {
                 $Fehler = "goto";
             }
             msg($Fehler, "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
         }
}
function save() {
         global $HTTP_POST_FILES, $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         ### hinzuf�gen
         if ($HTTP_POST_VARS[save] == "add") {

             //Inserts
             $result = mysql_query ("SELECT *
                                     FROM $GLOBALS[TB_ACCESS]");
             $num = mysql_num_fields($result) - 1;
             $value = "";
             $input = "";
             for ($n=1; $n <= $num; $n++) {
                  $name = mysql_field_name($result, $n);
                  $input .= "$name, ";
                  $value .= "'$HTTP_POST_VARS[$name]',";
             }
             $inputs = eregi_replace(", $", "", $input);
             $values = eregi_replace(",$", "", $value);

             if (mysql_query("INSERT INTO $GLOBALS[TB_ACCESS] ($inputs) VALUES ($values)")) {
                $Fehler = "usergroup_add";
                $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
                $id = mysql_insert_id();
                ### Foren - Berechtigungen erstellen ###
                $result = mysql_query("SELECT * FROM $GLOBALS[TB_FORUM]");
                while ($Daten = mysql_fetch_array($result)) {
                        @mysql_query("INSERT INTO $GLOBALS[TB_FORUM_ACCESS] VALUES ('$Daten[id]','$id','$HTTP_POST_VARS[view]','$HTTP_POST_VARS[del_post]','$HTTP_POST_VARS[edit_post]','$HTTP_POST_VARS[new_post]','$HTTP_POST_VARS[new_topic]',
                                     '$HTTP_POST_VARS[mod_openclose]','$HTTP_POST_VARS[mod_move_topic]','$HTTP_POST_VARS[mod_edit]','$HTTP_POST_VARS[mod_del]','$HTTP_POST_VARS[mod_join]','$HTTP_POST_VARS[mod_move_post]','$HTTP_POST_VARS[mod_top]')");
                }
             } else {
                $Fehler = "usergroup_add_fault";
                $goto = "back()";
             }

         ### bearbeiten
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             $result = mysql_query ("SELECT *
                                     FROM $GLOBALS[TB_ACCESS]");
             $num = mysql_num_fields($result) - 1;
             for ($n=1; $n <= $num; $n++) {
                  $name = mysql_field_name($result, $n);
                  if ($name != "data") {
                      $value .= "$GLOBALS[TB_ACCESS].$name='$HTTP_POST_VARS[$name]', ";
                  }
             }
             $values = eregi_replace(", $", "", $value);
             $id = $HTTP_POST_VARS[id];
             if (mysql_query("UPDATE $GLOBALS[TB_ACCESS] SET $values WHERE $GLOBALS[TB_ACCESS].id='$id'")) {
                 $Fehler = "usergroup_edit";
                 $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
             } else {
                 $Fehler = "usergroup_edit_fault";
                 $goto = "back()";
             }
         }
         ### Datei einlesen ### +++
         //per Upload
         if ($HTTP_POST_FILES[userfile][size] > 0) {
             $fp=fopen($HTTP_POST_FILES[userfile][tmp_name],"rb");
                 $filestuff=fread($fp,$HTTP_POST_FILES[userfile][size]);
             fclose($fp);
             mysql_query("UPDATE $GLOBALS[TB_ACCESS] SET data='".addslashes($filestuff)."' WHERE id='$id'");

         //vom Dateisystem
         } elseif ($HTTP_POST_VARS[sysfile]) {
             ### Datei einlesen ### +++
             $fp=fopen("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]","rb");
                 $filestuff=fread($fp,filesize("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]"));
             fclose($fp);
             mysql_query("UPDATE $GLOBALS[TB_ACCESS] SET data='".addslashes($filestuff)."' WHERE id='$id'");

         //Bild l�schen
         } elseif ($HTTP_POST_VARS[pic_del] == "on") {
             mysql_query("UPDATE $GLOBALS[TB_ACCESS] SET data='' WHERE id='$id'");
         }
         ### Datei einlesen ### ---
         msg($Fehler, "2", $goto);
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>