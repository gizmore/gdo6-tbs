<?php
include("head.php");

$userinfo = get_user_info("");
$Daten = mysql_fetch_array(mysql_query("SELECT * FROM $TB_ACCESS WHERE $TB_ACCESS.id='$userinfo[access_id]'"));

//Bild
echo "<a href='admin.php?$Sess_Name=$Sess' target='home'><img src='phpForum.jpg' border='0' alt='Kontrollzentrum'></a>";
echo "<br><br>";
#
### Einstellungen ### +++
if ($Daten[admin_settings] == "on") {
        open_table("Einstellungen", "100%");
        ?>
                <a href='<?php echo "settings.php?$Sess_Name=$Sess&action=edit"; ?>' target='home'>�ndern</a>
        <?php
        close_table("");
        echo "<br>";
        open_table("Backup", "100%");
        ?>
                <a href='<?php echo "backup.php?$Sess_Name=$Sess&action=backup"; ?>' target='home'>erstellen</a>&nbsp;|&nbsp;
                <a href='<?php echo "backup.php?$Sess_Name=$Sess&action=restore"; ?>' target='home'>wiederherstellen</a>
        <?php
        close_table("");
        echo "<br>";
}
### Einstellungen ### ---
#
#
### Styles ### +++
if ($Daten[admin_styles] == "on") {
        open_table("Foren Styles", "100%");
        ?>
                <a href='<?php echo "styles.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "styles.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>&nbsp;|&nbsp;
                <a href='<?php echo "styles.php?$Sess_Name=$Sess&action=upload"; ?>' target='home'>hochladen</a>
        <?php
        close_table("");
        echo "<br><hr><br>";
}
### Styles ### ---
#
#
### Kategorien ### +++
if ($Daten[admin_cats] == "on") {
        open_table("Kategorien", "100%");
        ?>
                <a href='<?php echo "cat.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "cat.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>
        <?php
        close_table("");
        echo "<br>";
}
### Kategorien ### ---
#
#
### Foren ### +++
if ($Daten[admin_forums] == "on") {
        open_table("Foren", "100%");
        ?>
                <a href='<?php echo "forum.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "forum.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>&nbsp;|&nbsp;
                <a href='<?php echo "forum_access.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>berechtigungen</a>
        <?php
        close_table("");
        echo "<br>";
}
### Foren ### ---
#
#
### Foren ### +++
if ($Daten[admin_forums] == "on") {
        open_table("Moderatoren", "100%");
        ?>
                <a href='<?php echo "forum_mod.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "forum_mod.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>
        <?php
        close_table("");
        echo "<br><hr><br>";
}
### Foren ### ---
#
#
### Ank�ndigungen ### ---
#
#
### Benutzer ### +++
if ($Daten[admin_users] == "on") {
        open_table("Benutzer", "100%");
        ?>
                <a href='<?php echo "user.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "user.php?$Sess_Name=$Sess&action=search"; ?>' target='home'>suchen</a>&nbsp;|&nbsp;
                <a href='<?php echo "user.php?$Sess_Name=$Sess&action=mail"; ?>' target='home'>eMail an Benutzer</a>
        <?php
        close_table("");
        echo "<br>";
}
### Benutzer ### ---
#
#
### Benutzergruppen ### +++
if ($Daten[admin_user_groups] == "on") {
        open_table("Benutzergruppen", "100%");
        ?>
                <a href='<?php echo "usergroup.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "usergroup.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>
        <?php
        close_table("");
        echo "<br>";
}
### Benutzergruppen ### ---
#
#
### Benutzer-Titel ### +++
if ($Daten[admin_user_titles] == "on") {
        open_table("Benutzer-Titel", "100%");
        ?>
                <a href='<?php echo "user_titles.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "user_titles.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>
        <?php
        close_table("");
        echo "<br><hr><br>";
}
### Benutzer-Titel ### ---
#
#
### Smilies ### +++
if ($Daten[admin_smilies] == "on") {
        open_table("Smilies", "100%");
        ?>
                <a href='<?php echo "smilies.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "smilies.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>
        <?php
        close_table("");
        echo "<br>";
}
### Smilies ### ---
#
#
### BB-Codes ### +++
if ($Daten[admin_bbcodes] == "on") {
        open_table("Board Codes", "100%");
        ?>
                <a href='<?php echo "bbcodes.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "bbcodes.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>&nbsp;|&nbsp;
                <a href='<?php echo "bbcodes.php?$Sess_Name=$Sess&action=test"; ?>' target='home'>testen</a>
        <?php
        close_table("");
        echo "<br>";
}
### BB-Codes ### ---
#
#
### Words ### +++
if ($Daten[admin_words] == "on") {
        open_table("Zensierte W�rter", "100%");
        ?>
                <a href='<?php echo "words.php?$Sess_Name=$Sess&action=add"; ?>' target='home'>hinzuf�gen</a>&nbsp;|&nbsp;
                <a href='<?php echo "words.php?$Sess_Name=$Sess&action=liste"; ?>' target='home'>bearbeiten</a>
        <?php
        close_table("");
        echo "<br>";
}
### Words ### ---
#
#
### Statistiken ### +++
if ($Daten[admin_status] == "on") {
        echo "<hr><br>";
        open_table("Statistiken", "100%");
        ?>
                <a href='<?php echo "admin.php?$Sess_Name=$Sess&action=status"; ?>' target='home'>anzeigen</a>
        <?php
        close_table("");
}
### Statistiken ### ---
#
#
gz_site();
?>