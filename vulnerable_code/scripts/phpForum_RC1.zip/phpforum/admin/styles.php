<?php
#include("head.php");
if ($HTTP_GET_VARS[action] != "download") {
    include("head.php");
    echo "<h3 class='font_big'>Foren Styles...</h3>";
} else {
    include("../config.inc.php");
    include("../mainfile.php");
    include("functions.php");
}
auth("admin_styles");

switch ($HTTP_GET_VARS[action]) {

        case "liste":
              liste();
              break;

        case "add":
              addedit("", "add");
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id], "edit");
              break;

        case "copy":
              addedit($HTTP_GET_VARS[id], "copy");
              break;

        case "save":
              save();
              break;

        case "activate":
              activate($HTTP_GET_VARS[id], TRUE);
              break;

        case "deactivate":
              activate($HTTP_GET_VARS[id], FALSE);
              break;

        case "setdefault":
              set_default($HTTP_POST_VARS["default"]);
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;

        case "upload":
              upload_form();
              break;

        case "download":
              style_download($HTTP_GET_VARS[id]);
              break;

        case "insert_upload":
              //per Upload
              if ($HTTP_POST_FILES[local_file][size] > 0) {
                  if (style_upload($HTTP_POST_FILES[local_file][tmp_name])) {
                      msg("admin_styles_upload", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=liste");
                  } else {
                      msg("admin_styles_upload_fault");
                  }
              //vom Server
              } elseif ($HTTP_POST_VARS[server_file]) {
                  if (style_upload($GLOBALS[MAIN_PATH]."/".$HTTP_POST_VARS[server_file])) {
                      msg("admin_styles_upload", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=liste");
                  } else {
                      msg("admin_styles_upload_fault");
                  }
              //per Link
              } elseif ($HTTP_POST_VARS[link_file]) {
                  if (style_upload($HTTP_POST_VARS[link_file])) {
                      msg("admin_styles_upload", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=liste");
                  } else {
                      msg("admin_styles_upload_fault");
                  }
              //Fehler
              } else {
                  msg("admin_styles_upload_file");
              }
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($id="", $mode) {
         global $HTTP_SERVER_VARS, $HTTP_POST_VARS, $_style;
         ?>
         <script language="JavaScript">
                 function StyleText(text) {
                          styleform.header.value += " "+text;
                          styleform.header.focus();
                 }
                 function StylePopup(LinkTyp) {
                          link_login = prompt("Geben sie hier den Text f�r einen Eingeloggten Benutzer an.","");

                          link_logout = prompt("Geben sie hier den Text f�r einen Ausgeloggten Benutzer an.","");

                          if ((link_login != "") || (link_logout != "")) {
                              styleform.header.value += " ["+LinkTyp+"]"+link_login+"[*]"+link_logout+"[/"+LinkTyp+"] ";
                              styleform.header.focus();

                          } else {
                              styleform.header.focus();
                          }
                 }
                 function StyleStatusPopup(LinkTyp) {
                          link = prompt("Geben sie hier den Text ein der vor dem gew�hlten Status stehen soll.","");

                          if (link != "") {
                              styleform.header.value += " ["+LinkTyp+"]"+link+"[/"+LinkTyp+"] ";
                              styleform.header.focus();

                          } else {
                              styleform.header.focus();
                          }
                 }
         </script>
         <form name='styleform' method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
                   <input type='hidden' name='save' VALUE='<?php
                   ### hinzuf�gen
                   if ($mode == "add") {
                       echo "add'>";
                       $typ = "hinzuf�gen";
                   ### bearbeiten
                   } elseif ($mode == "edit") {
                       echo "edit'>";
                       $typ = "bearbeiten";
                       echo "<input type='hidden' name='id' VALUE='$id'>";
                       $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                               FROM $GLOBALS[TB_STYLES]
                                                               WHERE $GLOBALS[TB_STYLES].id='$id'"));
                   ### kopieren
                   } elseif ($mode == "copy") {
                       echo "copy'>";
                       $typ = "kopieren";
                       $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                               FROM $GLOBALS[TB_STYLES]
                                                               WHERE $GLOBALS[TB_STYLES].id='$id'"));
                       $Daten[name] = $Daten[name]." copy";
                   }
                   table_header("Forum Style $typ...", "100%", "", "colspan='2'");
                         table_header("Allgemeines / HTML", "100%", "1", "colspan='2'", "nohead"); ?>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Style-Name:</b>
                                     <td width='60%' class='cat_one'>
                                         <input type='text' name='name' value="<?php echo htmlentities($Daten[name], ENT_QUOTES); ?>" maxlength='50' size='30'>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Style w&auml;hlbar?:</b><br>
                                         <span class='font_small'>
                                               W&auml;hlen sie hier ja damit Benutzer diesen Foren-Style ausw&auml;hlen k&ouml;nnen.
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <?php
                                         if ($Daten[choice] == "on") {
                                             echo "<input type='radio' name='choice' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                             echo "<input type='radio' name='choice' value=''>&nbsp;nein";
                                         } else {
                                             echo "<input type='radio' name='choice' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                             echo "<input type='radio' name='choice' value='' checked>&nbsp;nein";
                                         }
                                         ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>HTML-Typ:</b>
                                     <td width='60%' class='cat_one'>
                                         <input type='text' name='html_type' value='<?php echo htmlentities($Daten[html_type], ENT_QUOTES); ?>' maxlength='255' size='50'>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>extra Body Attribute:</b><br>
                                         <span class='font_small'>
                                               Hier k&ouml;nnen sie extra Attribute definieren, die in den &lt;Body&gt; - Tag geschrieben werden.&nbsp;z.B.: <b>class='meineKlasse'</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <input type='text' name='body_extra' value='<?php echo htmlentities($Daten[body_extra], ENT_QUOTES); ?>' maxlength='255' size='50'>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>phpForum - Kopf:</b><br><br>
                                         <span class='font_small'>
                                               Hier k�nnen sie Banner und die Foren-Navigation definieren.<br><br>
                                               HTML Code ist <b>AN</b><br><br>
                                               <b>Foren-Navigation:</b><br>
                                                  <a href="javascript:StylePopup('site_login')"><b>Login / Logout</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StylePopup('site_profile')"><b>Profil</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StylePopup('site_search')"><b>Suche</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StylePopup('site_members')"><b>Benutzer-Liste</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StylePopup('site_home')"><b>Startseite</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StylePopup('site_signup')"><b>Registrieren</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StylePopup('site_admin')"><b>Administration</b></a><br><br>
                                               <b>Foren-Statistik:</b><br>
                                                  <a href="javascript:StyleText('*stat_topics*')"><b>Themen</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StyleText('*stat_posts*')"><b>Beitr&auml;ge</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StyleText('*stat_users*')"><b>Benutzer</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StyleText('*stat_lastuser*')"><b>letzer reg. Benutzer</b></a><br><br>
                                               <b>Benutzer Status:</b><br>
                                                  <a href="javascript:StyleStatusPopup('user_name')"><b>Benutzername</b></a>&nbsp;|&nbsp;
                                                  <a href="javascript:StyleStatusPopup('user_last_login')"><b>letztes Login</b></a><br><br>
                                               <b>Hyperlinks:</b><br>
                                                  <a href="javascript:StyleText('*session*')"><b>Session-String</b></a>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='header' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' WRAP='soft'><?php echo htmlentities($Daten[header], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>phpForum - Fuss:</b><br><br>
                                         <span class='font_small'>
                                               Hier k�nnen sie Banner usw. f&uuml;r die Fusszeile des Forums definieren.<br><br>
                                               HTML Code ist <b>AN</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='footer' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' WRAP='soft'><?php echo htmlentities($Daten[footer], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Message-Box breite:</b><br>
                                         <span class='font_small'>
                                               Geben sie hier die Breite der Textfelder f�r Nachrichten ein.
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <input type='text' name='textarea_width' value='<?php echo htmlentities($Daten[textarea_width], ENT_QUOTES); ?>'>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Message-Box h&ouml;he:</b><br>
                                         <span class='font_small'>
                                               Geben sie hier die H&ouml;he der Textfelder f�r Nachrichten ein.
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <input type='text' name='textarea_height' value='<?php echo htmlentities($Daten[textarea_height], ENT_QUOTES); ?>'>
                                     </td>
                                 </tr>
                                 <?php
                         table_header("Allegemeine / Tabellen Stylesheets", "100%", "1", "colspan='2'", "nohead"); ?>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Allgemeines:</b><br><br>
                                         <span class='font_small'>
                                               In diesem Feld sind nur allgemeine Style-Stylesheet Angaben, wie z.B. f&uuml;r Hyperlinks erlaubt.<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='head_insert' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' WRAP='soft'><?php echo htmlentities($Daten[head_insert], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Standard Tabellenkopf:</b><br><br>
                                         <span class='font_small'>
                                               In diesem Feld k&ouml;nnen sie die CSS Eigenschaften f�r den Standard Tabellenkopf definieren.<br>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='default_table' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[default_table], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Standard Tabellenkopf (erste zeile):</b><br><br>
                                         <span class='font_small'>
                                               In diesem Feld k&ouml;nnen sie die CSS Eigenschaften f�r den Standard Tabellenkopf definieren.<br>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='default_tr' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[default_tr], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Kategorie Tabellenkopf:</b><br><br>
                                         <span class='font_small'>
                                               In diesem Feld k&ouml;nnen sie die CSS Eigenschaften f�r den Kategorie Tabellenkopf definieren.<br>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='cat_table' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[cat_table], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Kategorie Tabellenkopf (erste zeile):</b><br><br>
                                         <span class='font_small'>
                                               In diesem Feld k&ouml;nnen sie die CSS Eigenschaften f�r den Kategorie Tabellenkopf definieren.<br>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='cat_tr' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[cat_tr], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Vorschau in der Suche:</b><br><br>
                                         <span class='font_small'>
                                               In diesem Feld k&ouml;nnen sie die CSS Eigenschaften f�r die Vorschau in der Suche definieren.<br>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='table_inset' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[table_inset], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>erste wechselnde Spalte:</b><br><br>
                                         <span class='font_small'>
                                               In diesem Feld k&ouml;nnen sie die CSS Eigenschaften f�r die erste wechselnde Spalte einer Tabelle definieren.<br>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='cat_one' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[cat_one], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>zweite wechselnde Spalte:</b><br><br>
                                         <span class='font_small'>
                                               In diesem Feld k&ouml;nnen sie die CSS Eigenschaften f�r die zweite wechselnde Spalte einer Tabelle definieren.<br>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='cat_two' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[cat_two], ENT_QUOTES); ?></textarea>
                                     </td>
                                 </tr>
                                 <?php
                         table_header("Text Stylesheets", "100%", "1", "colspan='2'", "nohead"); ?>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>gro&szlig;er Text:</b><br><br>
                                         <span class='font_small'>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='font_big' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[font_big], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>normaler Text:</b><br><br>
                                         <span class='font_small'>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='font_normal' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[font_normal], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>kleiner Text:</b><br><br>
                                         <span class='font_small'>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='font_small' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[font_small], ENT_QUOTES); ?></textarea>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Fehlermeldungs Text:</b><br><br>
                                         <span class='font_small'>
                                               Es sind nur CSS-Eigenschaften erlaubt, keine neuen Klassen !<br><br>
                                               HTML Code ist <b>AUS</b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <textarea name='font_fault' cols='45' rows='6' WRAP='soft'><?php echo htmlentities($Daten[font_fault], ENT_QUOTES); ?></textarea>
                                     </td>
                                 </tr>
                                 <?php
                         table_header("Grafiken", "100%", "1", "colspan='2'", "nohead"); ?>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>neuen Beitrag erstellen:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_new_post", $Daten[pic_new_post]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>neues Thema erstellen:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_new_topic", $Daten[pic_new_topic]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Thema geschlossen:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_closed", $Daten[pic_closed]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>neue PM erstellen:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_pm_new", $Daten[pic_pm_new]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>alle PMs als gelesen markieren:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_pm_readall", $Daten[pic_pm_readall]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>alle PMs l&ouml;schen:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_pm_delall", $Daten[pic_pm_delall]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>PM beantworten:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_pm_reply", $Daten[pic_pm_reply]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Navigation - Profil:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_profile", $Daten[pic_profile]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Navigation - PM:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_pm", $Daten[pic_pm]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Navigation - Homepage:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_home", $Daten[pic_home]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Navigation - eMail:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_mail", $Daten[pic_mail]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Navigation - Suche:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_search", $Daten[pic_search]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Navigation - Zitieren:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_quote", $Daten[pic_quote]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Navigation - bearbeiten / l&ouml;schen:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_edit", $Daten[pic_edit]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Navigation - IP-Adresse:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_ip", $Daten[pic_ip]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>neues Thema:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_on", $Daten[pic_on]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>geschlossenes neues Thema:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_on_lock", $Daten[pic_on_lock]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>altes Thema:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_off", $Daten[pic_off]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>geschlossenes altes Thema:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_off_lock", $Daten[pic_off_lock]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>neuer Beitrag:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_post_on", $Daten[pic_post_on]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>alter Beitrag:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_post_off", $Daten[pic_post_off]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>zum letzen Beitrag:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_last_post", $Daten[pic_last_post]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Themen Abo:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_topic_abo", $Daten[pic_topic_abo]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Dateianhang:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_file", $Daten[pic_file]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>PM - Status:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_pm_status", $Daten[pic_pm_status]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Admin - nach oben:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_admin_up", $Daten[pic_admin_up]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Admin - nach unten:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_admin_down", $Daten[pic_admin_down]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Admin - l&ouml;schen:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_admin_del", $Daten[pic_admin_del]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Umfragen - linker Rand:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_poll_l", $Daten[pic_poll_l]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Umfragen - variable mitte:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_poll_m", $Daten[pic_poll_m]); ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Umfragen - rechter Rand:</b>
                                     <td width='60%' class='cat_one'>
                                         <?php upload_liste("images", "pic_poll_r", $Daten[pic_poll_r]); ?>
                                     </td>
                                 </tr>
                   </table>
                   <p></p>
                   <center>
                           <input type='submit' value='<?php echo $typ; ?>'>
                           <input type='reset' name='Reset' value='Zur�cksetzen'>
                   </center>
             </form>
             <?php
}
function liste() {
         global $HTTP_SERVER_VARS, $_style;
         echo "<form method='post' action='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=setdefault'>";
         table_header("Forum Styles bearbeiten...", "100%", "", "colspan='5'"); ?>
                       <tr class='default_tr'>
                           <td width='10%' align='center'>
                               <B>standard</B>
                           <td width='30%'>
                               <B>name</B>
                           <td width='10%' align='center'>
                               <B>benutzer</B>
                           <td width='40%' align='center'>
                               <B>optionen</B>
                           <td width='10%' align='center'>
                               <b>l�schen</B>
                       </tr>
                       <?php
                       $result = mySQL_query ("SELECT * FROM $GLOBALS[TB_STYLES] ORDER BY $GLOBALS[TB_STYLES].name ASC");
                       while ($Daten = mysql_fetch_array ($result)) {
                              ?>
                              <tr>
                                  <td width='10%' class='cat_two' align='center'>
                                      <input type='radio' value='<?php echo $Daten[id]; ?>' name='default'<?php if ($Daten[active] == "on") { echo " checked"; } ?>>
                                  <td width='30%' class='cat_one'>
                                      <b><?php echo $Daten[name]; ?></b>
                                  <td width='10%' class='cat_two' align='center'>
                                      <?php
                                      echo mysql_num_rows(mysql_query("SELECT id FROM $GLOBALS[TB_USER] WHERE style=$Daten[id]"));
                                      ?>
                                  <td width='40%' align='center' class='cat_two'>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]' title='&quot;".htmlentities($Daten[name], ENT_QUOTES)."&quot; bearbeiten'"; ?>>[bearbeiten]</a>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=copy&id=$Daten[id]' title='&quot;".htmlentities($Daten[name], ENT_QUOTES)."&quot; kopieren'"; ?>>[kopieren]</a>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=download&id=$Daten[id]' title='Style: &quot;".htmlentities($Daten[name], ENT_QUOTES)."&quot; herunterladen'"; ?>>[herunterladen]</a>
                                      <?php
                                      // DE-Aktivieren
                                      if ($Daten[choice] == "on") {
                                          echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=deactivate&id=$Daten[id]' title='&quot;".htmlentities($Daten[name], ENT_QUOTES)."&quot; deaktivieren'>[deaktivieren]</a>";
                                      // Aktivieren
                                      } else {
                                          echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=activate&id=$Daten[id]' title='&quot;".htmlentities($Daten[name], ENT_QUOTES)."&quot; aktivieren'>[aktivieren]</a>";
                                      }
                                      ?>
                                  <td width='10%' align='center' class='cat_one'>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]"; ?>'><img src='<?php echo "../".$_style[pic_admin_del]; ?>' border='0' alt='<?php echo "\"".htmlentities($Daten[name], ENT_QUOTES)."\""; ?> l�schen'></a>
                                  </td>
                              </tr>
                              <?php
                       }
                       ?>
         </table>
         <br>
         <input type='submit' value='&uuml;bernehmen'>
         </form>
         <?php
}
function activate($id, $activate) {
         global $HTTP_SERVER_VARS;

         ### aktivieren
         if ($activate) {
             //w�hlbar machen
             mysql_query("UPDATE $GLOBALS[TB_STYLES] SET choice='on' WHERE id='$id'");
         ### de - aktivieren
         } elseif (!$activate) {
             //default-Style den Benutzer geben die diesen gew�hlt hatten...
             $Daten = mysql_fetch_array(mysql_query("SELECT id FROM $GLOBALS[TB_STYLES] WHERE active='on'"));
             if ($Daten[id] != $id) {
                 //unw�hlbar machen
                 mysql_query("UPDATE $GLOBALS[TB_STYLES] SET choice='' WHERE id='$id'");
                 mysql_query("UPDATE $GLOBALS[TB_USER] SET style='$Daten[id]' WHERE style='$id'");
             }
         }
         msg("admin_styles_edit", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
function set_default($id) {
         global $HTTP_SERVER_VARS;

         mysql_query("UPDATE $GLOBALS[TB_STYLES] SET active=''");
         mysql_query("UPDATE $GLOBALS[TB_STYLES] SET active='on', choice='on' WHERE id='$id'");
         msg("admin_styles_default", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
function del ($id) {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS;

         ### Formular
         if (!$HTTP_GET_VARS[ok]) {
             open_table("Foren-Style l�schen", "50%");
                         echo "Das Foren-Style #$id wirklich l�schen ?";
                         echo " [<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id&ok=1'>ja</a> / <a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste'>nein</a>]";
             close_table("Wenn Sie dieses Foren-Style l�schen wird allen Benutzern dieses Styles das Standard Style zugeordnet.");
         ### l�schen !!!
         } elseif ($HTTP_GET_VARS[ok] == "1") {

             $Daten = mysql_fetch_array(mysql_query("SELECT id FROM $GLOBALS[TB_STYLES] WHERE active='on'"));
             //nur wenn nicht default :)
             if ($Daten[id] != $id) {
                 mysql_query("UPDATE $GLOBALS[TB_USER] SET style='$Daten[id]' WHERE style='$id'");
                 mysql_query("DELETE FROM $GLOBALS[TB_STYLES] WHERE id='$id'");
             }
             msg("admin_styles_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
         }
}
function save() {
         global $HTTP_POST_FILES, $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         ### hinzuf�gen / kopieren
         if ($HTTP_POST_VARS[save] == "add" OR $HTTP_POST_VARS[save] == "copy") {
             $result = mysql_query ("SELECT *
                                     FROM $GLOBALS[TB_STYLES]");
             $num = mysql_num_fields($result) - 1;
             $value = "";
             $input = "";
             for ($n=1; $n <= $num; $n++) {
                  $name = mysql_field_name($result, $n);
                  if ($name != "active") {
                      $input .= "$name, ";
                      $value .= "'$HTTP_POST_VARS[$name]',";
                  }
             }
             $inputs = eregi_replace(", $", "", $input);
             $values = eregi_replace(",$", "", $value);

             if ($HTTP_POST_VARS[save] == "add") {
                 $Fehler = "admin_styles_add";
             } else {
                 $Fehler = "admin_styles_copy";
             }
             $query = "INSERT INTO $GLOBALS[TB_STYLES] ($inputs) VALUES ($values)";

         ### bearbeiten
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             $result = mysql_query ("SELECT *
                                     FROM $GLOBALS[TB_STYLES]");
             $num = mysql_num_fields($result) - 1;
             for ($n=1; $n <= $num; $n++) {
                  $name = mysql_field_name($result, $n);
                  if ($name != "active") {
                      $value .= "$GLOBALS[TB_STYLES].$name='$HTTP_POST_VARS[$name]', ";
                  }
             }
             $values = eregi_replace(", $", "", $value);

             $query = "UPDATE $GLOBALS[TB_STYLES] SET $values WHERE $GLOBALS[TB_STYLES].id='$HTTP_POST_VARS[id]'";
             $Fehler = "admin_styles_edit";
         }

         ### Query ausf�hren
         if (mysql_query($query)) {
             $goto="$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
         } else {
             $Fehler="admin_styles_fault";
             $goto="back()";
         }
         msg($Fehler, "2", $goto);
}
function upload_form() {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post'<?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { echo "enctype='multipart/form-data'"; } ?> action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=insert_upload"; ?>'>
               <?php table_header("Forum Style hochladen...", "100%", "", "colspan='2'");
                     if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>lokale Datei:</b><br>
                             <span class='font_small'>
                                   W&auml;hlen sie hier eine Datei von ihrer Festplatte aus.
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='file' name='local_file'>
                         </td>
                     <?php } ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Link zu einem Style:</b><br>
                             <span class='font_small'>
                                   Hier k�nnen sie einen Link zu einem Style auf einem anderen Server angeben.<br>
                                   z.B. http://phpforum.ath.cx/home/download/style.php?id=1
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='link_file' size='40'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Datei auf dem Server:</b><br>
                             <span class='font_small'>
                                   W&auml;hlen sie hier eine Datei aus dem Verzeichnis <b>upload</b> vom Server aus, wenn Datei-Uploads deaktiviert sind.<br>
                                   Diese m&uuml;ssen sie mit einem FTP-Programm hochladen.
                             </span>
                         <td width='50%' class='cat_one'>
                             <?php upload_liste("upload", "server_file", "", ".style"); ?>
                         </td>
                     </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='hochladen'>
                       <input type='reset' value='Zur&uuml;cksetzen'>
               </center>
         </form>
         <?php
}
function style_download($id) {

         ### Abfrage
         $Daten = mysql_fetch_array(mysql_query("SELECT * FROM $GLOBALS[TB_STYLES] WHERE id='$id'"), MYSQL_ASSOC);

         ### Insert erstellen
         $values = "";
         $fields = "";
         $query .= "INSERT INTO \$GLOBALS[TB_STYLES] (";

         //Values erstellen
         while(list($col, $var) = each($Daten)) {
               if ($col != "id" AND $col != "active") {
                   $fields .= $col.",";
                   $values .= "'".mysql_escape_string($var)."',";
               }
         }
         $fields = substr($fields, 0, strlen($fields)-1);
         $values = substr($values, 0, strlen($values)-1);

         $query .= $fields.") VALUES (".$values.");\n";

         header("Cache-control: max-age=60");
         header("Expires: ".gmdate("D, d M Y H:i:s",time()+60)."GMT");
         header("Content-disposition: filename=Style_".preg_replace("/(\\|\/|:|\?|\"|<|>|\||\/|\ )*/", "", $Daten[name]).".style");
         header("Content-type: unknown/unknown");
         echo $query;
}
function style_upload($file) {

         $string = file($file);

         $table = preg_replace("/(.*)\\\$GLOBALS\[TB_([_A-Z]*)\](.*)/", "TB_\\2", trim($string[0]));
         $sql = preg_replace("/\\\$GLOBALS\[TB_([_A-Z]*)\]/", "$GLOBALS[$table]", trim($string[0]));
         if (substr($sql, 0, 1) != "#" AND $sql) {
             if (!mysql_query($sql)) {
                 return FALSE;
                 break;
             }
         } else {
             return FALSE;
         }
         return TRUE;
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>