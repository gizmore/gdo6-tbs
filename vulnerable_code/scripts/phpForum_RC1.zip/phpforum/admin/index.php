<?php
include("../config.inc.php");
include("../mainfile.php");

### Zugriff erlaubt ???
    $userinfo = get_user_info("");
    $Daten = mysql_fetch_array(mysql_query("SELECT * FROM $TB_ACCESS WHERE $TB_ACCESS.id='$userinfo[access_id]'"));
if ($Daten[admin_settings] == "on"
    OR $Daten[admin_cats] == "on"
    OR $Daten[admin_forums] == "on"
    OR $Daten[admin_announcements] == "on"
    OR $Daten[admin_users] == "on"
    OR $Daten[admin_user_groups] == "on"
    OR $Daten[admin_user_titles] == "on"
    OR $Daten[admin_smilies] == "on"
    OR $Daten[admin_bbcodes] == "on"
    OR $Daten[admin_status] == "on"
    OR $Daten[admin_words] == "on"
    OR $Daten[admin_styles] == "on") {
    ?>
    <HTML>
    <head>
          <title><?php echo $TITEL_KURZ; ?> - Admin</title>
          <frameset cols="250,*">
                    <frame src="<?php echo "admin_nav.php?$Sess_Name=$Sess"; ?>" name="nav" scrolling="AUTO" frameborder="0">
          <frameset rows="40,*">
                    <frame src="<?php echo "admin_head.php?$Sess_Name=$Sess"; ?>" name="head" scrolling="NO" frameborder="0">
                    <frame src="<?php echo "admin.php?$Sess_Name=$Sess"; ?>" name="home" scrolling="YES" frameborder="0">
          </frameset>
          </frameset>
    </head>
    </html>
    <?php
} else {
    header("Location: ../index.php");
    exit();
}
### Zugriff erlaubt ???
?>