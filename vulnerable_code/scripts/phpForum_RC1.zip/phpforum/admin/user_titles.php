<?php
include("head.php");
auth("admin_user_titles");
?>
<h3 class='font_big'>Benutzer-Titel...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "add":
              addedit();
              break;

        case "liste":
              liste();
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id]);
              break;

        case "save":
              save();
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($id="") {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post' <?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { echo "enctype='multipart/form-data'"; } ?> action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <input type='hidden' name='id' VALUE='<?php echo $id; ?>'>
               <input type='hidden' name='save' VALUE='<?php
               if ($id == "") {
                   echo "add'>";
                   $typ = "hinzuf&uuml;gen";
               } else {
                   echo "edit'>";
                   $typ = "bearbeiten";
                   $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                           FROM $GLOBALS[TB_STATUS]
                                                           WHERE $GLOBALS[TB_STATUS].id='$id'"));
               }

               table_header("Benutzer-Titel $typ", "100%", "", "colspan='2'"); ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Name:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='name' value="<?php echo $Daten[name]; ?>" maxlenght='255' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Punkte:</b>
                             <br>
                             <span class='font_small'>
                                   dies ist die mind. Punktanzahl um in diesen Benutzer-Titel zu erhalten
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='points' value="<?php echo $Daten[points]; ?>" maxlenght='200' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>aktuelles Bewertungs-Bild:</b>
                             <br>
                             <span class='font_small'>
                                   Wenn sie hier ein Bild ausw&auml;hlen wird bei diesem Benutzer dieses Bild f�r den Status angezeigt.
                             </span>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[data] != "") {
                                 echo "<img src='../functions.php?action=status&id=$Daten[id]' border='0'><br><br>";
                                 echo "<input type='checkbox' name='pic_del'>&nbsp;l&ouml;schen<br>";
                             }
                             ?>
                         </td>
                     <?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>lokale Datei:</b><br>
                             <span class='font_small'>
                                   Hier k&ouml;nnen sie ein Bild von ihrer Festplatte ausw&auml;hlen.
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='file' name='userfile'>
                         </td>
                     <?php } ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Datei auf dem Server:</b><br>
                             <span class='font_small'>
                                   Diese Dateien liegen im phpForum Verzeichnis <b>upload</b>,<br>
                                   sie k&ouml;nnen weitere mit einem FTP-Programm hochladen.
                             </span>
                         <td width='50%' class='cat_one'>
                             <?php upload_liste("upload"); ?>
                         </td>
                     </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='<?php echo $typ; ?>'>
                       <input type='reset' name='Reset' value='Zur�cksetzen'>
               </center>
         </form>
         <?php
}
function liste() {
         global $HTTP_SERVER_VARS, $_style;
         table_header("Benutzer-Titel bearbeiten...", "100%", "", "colspan='4'"); ?>
                       <tr class='default_tr'>
                           <td width='40%'>
                               <B>Name</B>
                           <td width='20%' align='center'>
                               <B>mind. Beitr&auml;ge</B>
                           <td width='30%' align='center'>
                               <b>optionen</b>
                           <td width='10%' align='center'>
                               <b>l�schen</b>
                           </td>
                       </tr>
                       <?php
                       $result = mySQL_query ("SELECT * FROM $GLOBALS[TB_STATUS] ORDER BY $GLOBALS[TB_STATUS].points ASC");
                       while ($Daten = mysql_fetch_array ($result)) {
                              ?>
                              <tr>
                                  <td width='40%' class='cat_two'>
                                      <b><?php echo $Daten[name]; ?></b>
                                  <td width='20%' align='center' class='cat_two'>
                                      <?php echo $Daten[points]; ?>
                                  <td width='30%' align='center' class='cat_one'>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]"; ?>' title='<?php echo "\"".htmlentities($Daten[name], ENT_QUOTES)."\""; ?> bearbeiten'>[bearbeiten]</a>
                                      <a href='<?php echo "user.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result&access_id=*&points_more=$Daten[points]"; ?>' title='Benutzer mit mind. <?php echo $Daten[points]; ?> Beitr&auml;gen suchen'>[Benutzer suchen]</a>
                                  <td width='10%' align='center' class='cat_one'>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]"; ?>'><img src='<?php echo "../".$_style[pic_admin_del]; ?>' border='0' alt='"<?php echo "\"$Daten[name]\" l�schen"; ?>'></a>
                                  </td>
                              </tr>
                              <?php
                       }
                       ?>
         </table>
         <?php
}
function save() {
         global $HTTP_POST_FILES, $HTTP_SERVER_VARS, $HTTP_POST_VARS;

         ### Speichern
         //hinzuf�gen
         if ($HTTP_POST_VARS[save] == "add") {
             mysql_query("INSERT INTO $GLOBALS[TB_STATUS] (name, points) VALUES ('$HTTP_POST_VARS[name]','$HTTP_POST_VARS[points]')");
             //id bekommen
             $HTTP_POST_VARS[id]=mysql_insert_id();
             $Fehler = "status_add";
             $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";

         //bearbeiten
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             mysql_query("UPDATE $GLOBALS[TB_STATUS]
                          SET name='$HTTP_POST_VARS[name]',
                              points='$HTTP_POST_VARS[points]'
                          WHERE $GLOBALS[TB_STATUS].id='$HTTP_POST_VARS[id]'");
             $Fehler = "status_edit";
             $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
         }

         ### Datei einlesen ### +++
         //per Upload
         if ($HTTP_POST_FILES[userfile][size] > 0) {
             $fp=fopen($HTTP_POST_FILES[userfile][tmp_name],"rb");
                 $filestuff=fread($fp,$HTTP_POST_FILES[userfile][size]);
             fclose($fp);
             mysql_query("UPDATE $GLOBALS[TB_STATUS] SET data='".addslashes($filestuff)."' WHERE id='$HTTP_POST_VARS[id]'");

         //vom Dateisystem
         } elseif ($HTTP_POST_VARS[sysfile]) {
             $fp=fopen("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]","rb");
                 $filestuff=fread($fp,filesize("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]"));
             fclose($fp);
             mysql_query("UPDATE $GLOBALS[TB_STATUS] SET data='".addslashes($filestuff)."' WHERE id='$HTTP_POST_VARS[id]'");

         //Bild l�schen
         } elseif ($HTTP_POST_VARS[pic_del] == "on") {
             mysql_query("UPDATE $GLOBALS[TB_STATUS] SET data='' WHERE id='$HTTP_POST_VARS[id]'");
         }
         msg($Fehler, "2", $goto);
}
function del ($id) {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS;
         //Formular
         if (!$HTTP_GET_VARS[ok]) {
             open_table("Benutzer-Titel l�schen", "50%");
                         echo "Den Benutzer-Titel #$id wirklich l�schen ?";
                         echo "[<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id&ok=1'>ja</a> / <a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste'>nein</a>]";
             close_table("");

         //l�schen
         } elseif ($HTTP_GET_VARS[ok] == "1") {
             mySQL_query ("DELETE FROM $GLOBALS[TB_STATUS] WHERE $GLOBALS[TB_STATUS].id='$id'");
             msg("status_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
         }
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>