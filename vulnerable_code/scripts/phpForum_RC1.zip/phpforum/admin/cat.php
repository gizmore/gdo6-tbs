<?php
include_once("head.php");
auth("admin_cats");
?>
<h3 class='font_big'>Kategorien...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "liste":
              liste();
              break;

        case "add":
              addedit();
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id]);
              break;

        case "save":
              save();
              break;

        case "up":
              up($HTTP_GET_VARS[id]);
              break;

        case "down":
              down($HTTP_GET_VARS[id]);
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;

        case "activate":
              activate($HTTP_GET_VARS[id],"yes");
              break;

        case "deactivate":
              activate($HTTP_GET_VARS[id],"no");
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($id="") {
         global $HTTP_SERVER_VARS;
         ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
                   <input type='hidden' name='id' VALUE='<?php echo $id; ?>'>
                   <input type='hidden' name='save' VALUE='<?php
                   if ($id == "") {
                       echo "add'>";
                       $typ = "hinzuf�gen";
                   } else {
                       echo "edit'>";
                       $typ = "bearbeiten";
                       $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                               FROM $GLOBALS[TB_CAT]
                                                               WHERE $GLOBALS[TB_CAT].id='$id'"));
                   }
                   table_header("Kategorie $typ...", "50%", "", "colspan='2'"); ?>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>Name:</b>
                              <td width='60%' class='cat_one'>
                                  <INPUT TYPE='text' name='name' SIZE='30' MAXLENGTH='255' value='<?php echo htmlentities($Daten[name], ENT_QUOTES) ?>'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>Aktiv:</b>
                              <td width='60%' class='cat_one'>
                                  <?php
                                  echo "<input type='radio' name='show_cat' value='on' ";
                                  if ($Daten[show_cat] == "on") { echo "checked"; }
                                  echo ">&nbsp;ja&nbsp;&nbsp;";

                                  echo "<input type='radio' name='show_cat' value='' ";
                                  if ($Daten[show_cat] != "on") { echo "checked"; }
                                  echo ">&nbsp;nein&nbsp;&nbsp;";
                                  ?>
                              </td>
                          </tr>
                   </table>
                   <br>
                   <center>
                           <input type='submit' value='<?php echo $typ; ?>'>&nbsp;<input type='reset' value='Zur&uuml;cksetzen'>
                   </center>

             </form>
         <?php
}
function liste() {
         global $HTTP_SERVER_VARS, $_style;
         table_header("Kategorien bearbeiten...", "100%", "", "colspan='5'"); ?>
                       <tr class='default_tr'>
                           <td width='40%'>
                               <B>name</B>
                           <td width='5%' align='center'>
                               <b>rang</B>
                           <td width='15%' align='center'>
                               <b>hoch / runter</B>
                           <td width='30%' align='center'>
                               <b>optionen</B>
                           <td width='10%' align='center'>
                               <b>l�schen</B>
                           </td>
                       </tr>
                       <?php
                       $result = mySQL_query ("SELECT * FROM $GLOBALS[TB_CAT] ORDER BY $GLOBALS[TB_CAT].rang ASC");
                       $max = mysql_num_rows ($result);
                       while ($Daten = mysql_fetch_array ($result)) {
                              ?>
                              <tr>
                                  <td width='40%' class='cat_two'>
                                      <b><?php echo $Daten[name]; ?></b>
                                  <td align='center' width='5%' class='cat_one'>
                                      <?php echo $Daten[rang]; ?>
                                  <td align='center' width='15%' class='cat_two'>
                                      <?php
                                      ### UP ###
                                      if ($Daten[rang] > "1") {
                                          echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=up&id=$Daten[id]'><img src='../$_style[pic_admin_up]' border='0' alt='\"".htmlentities($Daten[name], ENT_QUOTES)."\" nach oben'></a>&nbsp;&nbsp;";
                                      }
                                      ### DOWN ###
                                      if ($Daten[rang] < $max) {
                                          echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=down&id=$Daten[id]'><img src='../$_style[pic_admin_down]' border='0' alt='\"".htmlentities($Daten[name], ENT_QUOTES)."\" nach unten'></a>";
                                      }
                                      ?>
                                  <td width='20%' align='center' class='cat_one'>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]"; ?>' title='<?php echo "\"".htmlentities($Daten[name], ENT_QUOTES)."\""; ?> umbenennen'>[bearbeiten]</a>
                                      <?php
                                      ### DE-Aktivieren ###
                                      if ($Daten[show_cat] == "on") {
                                          echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=deactivate&id=$Daten[id]' title='\"".htmlentities($Daten[name], ENT_QUOTES)."\" deaktivieren'>[deaktivieren]</a>";
                                      ### Aktivieren ###
                                      } else {
                                          echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=activate&id=$Daten[id]' title='\"".htmlentities($Daten[name], ENT_QUOTES)."\" aktivieren'>[aktivieren]</a>";
                                      }
                                      ?>
                                  <td width='10%' align='center' class='cat_two'>
                                      <?php
                                      echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]'><img src='../$_style[pic_admin_del]' border='0' alt='\"".htmlentities($Daten[name], ENT_QUOTES)."\" l�schen'></a>";
                                      ?>
                                  </td>
                                  <?php
                       }
                       ?>
                       </tr>
         </table>
         <?php
}
function del ($id) {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS;
         if (!$HTTP_GET_VARS[ok]) {
             open_table("Kategorie l�schen", "50%");
                         echo "Die Kategorie #$id wirklich l�schen ?";
                         echo " [<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id&ok=1'>ja</a> / <a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste'>nein</a>]";
             close_table("");
         } elseif ($HTTP_GET_VARS[ok] == "1") {

             # forums.id bekommen
             $result_forum = mySQL_query ("SELECT $GLOBALS[TB_FORUM].id
                                           FROM $GLOBALS[TB_FORUM]
                                           WHERE $GLOBALS[TB_FORUM].cat_id='$id'");
             while ($Daten_forum = mysql_fetch_array ($result_forum)) {

                    # Themen
                    $result_topic = mySQL_query ("SELECT $GLOBALS[TB_TOPIC].id
                                                  FROM $GLOBALS[TB_TOPIC]
                                                  WHERE $GLOBALS[TB_TOPIC].forum_id='$Daten_forum[id]'");
                    while ($Daten_topic = mysql_fetch_array ($result_topic)) {

                           # Datei-Anh�nge
                           $result_post = mySQL_query ("SELECT $GLOBALS[TB_POST].id
                                                        FROM $GLOBALS[TB_POST]
                                                        WHERE $GLOBALS[TB_POST].topic_id='$Daten_topic[id]'");
                           while ($Daten_post = mysql_fetch_array ($result_post)) {
                                  mysql_query("DELETE FROM $GLOBALS[TB_FILES]
                                               WHERE $GLOBALS[TB_FILES].post_id='$Daten_post[id]'");
                           }

                           # Umfragen
                           $result_poll = mySQL_query ("SELECT $GLOBALS[TB_POLL].id
                                                        FROM $GLOBALS[TB_POLL]
                                                        WHERE $GLOBALS[TB_POLL].topic_id='$Daten_topic[id]'");
                           while ($Daten_poll = mysql_fetch_array ($result_poll)) {
                                  # Umfragen-Texte l�schen
                                  $result_poll_texts = mySQL_query ("SELECT $GLOBALS[TB_POLL_TEXT].id
                                                                     FROM $GLOBALS[TB_POLL_TEXT]
                                                                     WHERE $GLOBALS[TB_POLL_TEXT].poll_id='$Daten_poll[id]'");
                                  while ($Daten_poll_texts = mysql_fetch_array ($result_poll_texts)) {
                                         //Text l�schen
                                         mysql_query("DELETE FROM $GLOBALS[TB_POLL_TEXT]
                                                      WHERE $GLOBALS[TB_POLL_TEXT].id='$Daten_poll_texts[id]'");
                                         //Benutzer voteing l�schen
                                         mysql_query("DELETE FROM $GLOBALS[TB_POLL_USER]
                                                      WHERE $GLOBALS[TB_POLL_USER].text_id='$Daten_poll_texts[id]'");
                                  }
                                  mysql_query("DELETE FROM $GLOBALS[TB_POLL]
                                               WHERE $GLOBALS[TB_POLL].id='$Daten_poll[id]'");
                           }
                           # Themen-Abo�s l�schen
                           mySQL_query ("DELETE FROM $GLOBALS[TB_ABO]
                                         WHERE $GLOBALS[TB_ABO].topic_id='$Daten_topic[id]'");
                           # Beitr�ge l�schen
                           mySQL_query ("DELETE FROM $GLOBALS[TB_POST]
                                         WHERE $GLOBALS[TB_POST].topic_id='$Daten_topic[id]'");
                    }

                    # Themen l�schen
                    mySQL_query ("DELETE FROM $GLOBALS[TB_TOPIC]
                                  WHERE $GLOBALS[TB_TOPIC].forum_id='$Daten_forum[id]'");
                    # Forum l�schen
                    mySQL_query ("DELETE FROM $GLOBALS[TB_FORUM]
                                  WHERE $GLOBALS[TB_FORUM].id='$Daten_forum[id]'");
                    # Moderatoren l�schen
                    mySQL_query ("DELETE FROM $GLOBALS[TB_MOD]
                                  WHERE $GLOBALS[TB_MOD].forum_id='$Daten_forum[id]'");
                    # Zugriffsrechte l�schen
                    mySQL_query ("DELETE FROM $GLOBALS[TB_FORUM_ACCESS]
                                  WHERE $GLOBALS[TB_FORUM_ACCESS].forum_id='$Daten_forum[id]'");
             }
             # Rang der nachfolgenden Lategorien �ndern
             $cat = mysql_fetch_array(mysql_query("SELECT rang FROM $GLOBALS[TB_CAT] WHERE id='$id'"));
             mySQL_query ("UPDATE $GLOBALS[TB_CAT]
                           SET rang=rang-1
                           WHERE $GLOBALS[TB_CAT].rang > '$cat[rang]'");
             # Kategorie l�schen
             mysql_query("DELETE FROM $GLOBALS[TB_CAT]
                          WHERE $GLOBALS[TB_CAT].id='$id'");

             msg("cat_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
         }
}
function up($id) {
         global $HTTP_SERVER_VARS;
         $hoch = mysql_fetch_array (mySQL_query("SELECT id, rang FROM $GLOBALS[TB_CAT] WHERE $GLOBALS[TB_CAT].id='$id'"));

         if ($hoch[rang] > "1") {

             $rang_davor=$hoch[rang]-1;
             $davor = mysql_fetch_array (mySQL_query ("SELECT id FROM $GLOBALS[TB_CAT] WHERE $GLOBALS[TB_CAT].rang='$rang_davor'"));

             mysql_query("UPDATE $GLOBALS[TB_CAT] SET rang='$hoch[rang]' WHERE id='$davor[id]'");
             mysql_query("UPDATE $GLOBALS[TB_CAT] SET rang='$rang_davor' WHERE id='$hoch[id]'");
             $Fehler="cat_edit";

         } else {
             $Fehler="cat_edit_false";
         }
         msg($Fehler, "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");

}
function down($id) {
         global $HTTP_SERVER_VARS;
         $runter = mysql_fetch_array (mySQL_query ("SELECT * FROM $GLOBALS[TB_CAT] WHERE $GLOBALS[TB_CAT].id='$id'"));
         $max = mysql_num_rows (mySQL_query ("SELECT * FROM $GLOBALS[TB_CAT]"));

         if ($runter[rang] < $max) {

             $rang_danach=$runter[rang]+1;
             $danach = mysql_fetch_array (mySQL_query("SELECT id FROM $GLOBALS[TB_CAT] WHERE $GLOBALS[TB_CAT].rang='$rang_danach'"));

             mysql_query("UPDATE $GLOBALS[TB_CAT] SET rang='$runter[rang]' WHERE id='$danach[id]'");
             mysql_query("UPDATE $GLOBALS[TB_CAT] SET rang='$rang_danach' WHERE id='$runter[id]'");
             $Fehler="cat_edit";

          } else {
             $Fehler="cat_edit_false";
          }
          msg($Fehler, "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
function activate($id, $activate) {
         global $HTTP_SERVER_VARS;

         if ($activate == "yes") {
             $query = "UPDATE $GLOBALS[TB_CAT] SET show_cat='on' WHERE id='$id'";
         } elseif ($activate == "no") {
             $query = "UPDATE $GLOBALS[TB_CAT] SET show_cat='' WHERE id='$id'";
         }
         mysql_query($query);
         msg("cat_edit", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
function save() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         //hinzuf�gen
         if ($HTTP_POST_VARS[save] == "add") {
             $query = "INSERT INTO $GLOBALS[TB_CAT] (name, show_cat) VALUES ('$HTTP_POST_VARS[name]','$HTTP_POST_VARS[show_cat]')";
             if (mysql_query($query)) {
                 $id=mysql_insert_id();
                 $rang=mysql_num_rows(mysql_query("SELECT id FROM $GLOBALS[TB_CAT]"));

                 if (mysql_query("UPDATE $GLOBALS[TB_CAT] SET rang='$rang' WHERE id='$id'")) {
                     $Fehler="cat_add";
                 }
             } else {
                 $Fehler="cat_add_fault";
             }

         //bearbeiten
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             $query = "UPDATE $GLOBALS[TB_CAT] SET name='$HTTP_POST_VARS[name]', show_cat='$HTTP_POST_VARS[show_cat]' WHERE id='$HTTP_POST_VARS[id]'";
             if (mysql_query($query)) {
                 $Fehler="cat_edit";
             } else {
                 $Fehler="cat_edit_fault";
             }
         }
         msg("$Fehler", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>