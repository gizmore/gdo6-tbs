<?php
### Kompression ### +++
ob_start();
ob_implicit_flush(0);
### Kompression ### ---

include("../config.inc.php");    //Konfiguration
include("$MAIN_PATH/mainfile.php");    //Main-Function�s
include("$MAIN_PATH/admin/functions.php");       //Funktionen


    $userinfo = get_user_info();
##################################### CSS - Scripts <head> ##################################### +++
//Style in Array packen !!!
$_style = get_style($userinfo[style]);

echo $_style[html_type]."\n";
?>
<html>
<head>
<script language='JavaScript'>
<!--
function Smilies() {
         navigation=window.open("<?php echo "http://$SITE/functions.php?action=smilies"; ?>",'Smilies',',height=450, scrollbars, width=250');
}
function BBCode() {
         navigation=window.open("<?php echo "http://$SITE/functions.php?action=bbcodes"; ?>",'BBCodes',',height=450, scrollbars, width=350');
}
//-->
</script>
<META name='KEYWORDS' content="<?php echo $META_KEYWORDS; ?>">
<META name='DESCRIPTION' content="<?php echo $META_DESCRIPTION; ?>">
<META name='AUTHOR' content='KillerGod2000'>
<META name='COPYRIGHT' content='KillerGod2000'>
<META name='ROBOTS' content='all'>
<TITLE><?php echo $TITEL; ?></title>
<?php
      echo "<STYLE type=text/css><!--";
             echo $_style[head_insert]."\n";

             ### Tabellen
             //wechselnde Hintergrundfarbe (erste)
             if ($_style[cat_one]) {
                 echo ".cat_one { $_style[cat_one] }\n";
             }
             //wechselnde Hintergrundfarbe (zweite)
             if ($_style[cat_two]) {
                 echo ".cat_two { $_style[cat_two] }\n";
             }
             //f�r Quote Tabellen
             if ($_style[table_inset]) {
                 echo ".inset_table { $_style[table_inset] }\n";
             }
             //Standard Tabellen - table
             if ($_style[default_table]) {
                 echo ".default_table { $_style[default_table] }\n";
             }
             //Standard Tabelen - tr
             if ($_style[default_tr]) {
                 echo ".default_tr { $_style[default_tr] }\n";
             }
             //Cat Tabellen - table
             if ($_style[cat_table]) {
                 echo ".cat_table { $_style[cat_table] }\n";
             }
             //Cat Tabelen - tr
             if ($_style[cat_tr]) {
                 echo ".cat_tr { $_style[cat_tr] }\n";
             }
             ### Schriften
             //gro�
             if ($_style[font_big]) {
                 echo ".font_big { $_style[font_big] }\n";
             }
             //normal
             if ($_style[font_normal]) {
                 echo ".font_normal { $_style[font_normal] }\n";
             }
             //klein
             if ($_style[font_small]) {
                 echo ".font_small { $_style[font_small] }\n";
             }
             //fehler
             if ($_style[font_fault]) {
                 echo ".font_fault { $_style[font_fault] }\n";
             }
      echo "-->\n</style>\n";
echo "</head>\n";
echo "<body $_style[body_extra]>";
##################################### CSS - Scripts </head> ##################################### ---
?>