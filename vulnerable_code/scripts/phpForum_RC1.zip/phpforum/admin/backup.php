<?php
if ($HTTP_GET_VARS[action] != "create_backup") {
    include("head.php");
    echo "<h3 class='font_big'>Backup...</h3>";
} else {
    include("../config.inc.php");
    include("../mainfile.php");
    include("functions.php");
}
auth("admin_settings");

//Script-Zeitlimit
@set_time_limit (0);
/*
//Tabellen in einen Array packen
if (!$HTTP_POST_FILES[tables]) {
    $tables = array("\$GLOBALS[TB_USER]" => $GLOBALS[TB_USER], "\$GLOBALS[TB_STATUS]" => $GLOBALS[TB_STATUS],
                    "\$GLOBALS[TB_ACCESS]" => $GLOBALS[TB_ACCESS], "\$GLOBALS[TB_CAT]" => $GLOBALS[TB_CAT],
                    "\$GLOBALS[TB_FORUM]" => $GLOBALS[TB_FORUM], "\$GLOBALS[TB_TOPIC]" => $GLOBALS[TB_TOPIC],
                    "\$GLOBALS[TB_POST]" => $GLOBALS[TB_POST], "\$GLOBALS[TB_MOD]" => $GLOBALS[TB_MOD],
                    "\$GLOBALS[TB_SEARCH]" => $GLOBALS[TB_SEARCH], "\$GLOBALS[TB_ABO]" => $GLOBALS[TB_ABO],
                    "\$GLOBALS[TB_AVATARS]" => $GLOBALS[TB_AVATARS], "\$GLOBALS[TB_FILES]" => $GLOBALS[TB_FILES],
                    "\$GLOBALS[TB_SMILIES]" => $GLOBALS[TB_SMILIES], "\$GLOBALS[TB_MSG]" => $GLOBALS[TB_MSG],
                    "\$GLOBALS[TB_WORDS]" => $GLOBALS[TB_WORDS], "\$GLOBALS[TB_SESSION]" => $GLOBALS[TB_SESSION],
                    "\$GLOBALS[TB_BBCODES]" => $GLOBALS[TB_BBCODES], "\$GLOBALS[TB_SETTINGS]" => $GLOBALS[TB_SETTINGS],
                    "\$GLOBALS[TB_SETTING_GROUP]" => $GLOBALS[TB_SETTING_GROUP], "\$GLOBALS[TB_FORUM_ACCESS]" => $GLOBALS[TB_FORUM_ACCESS],
                    "\$GLOBALS[TB_POLL]" => $GLOBALS[TB_POLL], "\$GLOBALS[TB_POLL_USER]" => $GLOBALS[TB_POLL_USER],
                    "\$GLOBALS[TB_POLL_TEXT]" => $GLOBALS[TB_POLL_TEXT], "\$GLOBALS[TB_STYLES]" => $GLOBALS[TB_STYLES]);
}
*/

switch ($HTTP_GET_VARS[action]) {

        case "":
              form();
              break;

        case "backup":
              backup_form();
              break;

        case "restore":
              restore_form();
              break;

        case "create_backup":
              if (!$HTTP_POST_VARS[tables]) {
                  header("Location: $HTTP_SERVER_VARS[PHP_SELF]?$Sess_Name=$Sess&action=backup");
                  exit();
              }
              $tables = dump_backup($HTTP_POST_VARS[tables]);
              $query = dump_create($tables).dump_insert($tables);
              dump_download($query);
              break;

        case "restore_backup":
              if ($HTTP_POST_FILES[local_file][size] > 0) {
                  if (dump_restore($HTTP_POST_FILES[local_file][tmp_name])) {
                      msg("admin_backup_restore");
                  } else {
                      msg("admin_backup_restore_fault");
                  }
              } elseif ($HTTP_POST_VARS[server_file]) {
                  if (dump_restore($GLOBALS[MAIN_PATH]."/".$HTTP_POST_VARS[server_file])) {
                      msg("admin_backup_restore");
                  } else {
                      msg("admin_backup_restore_fault");
                  }
              } else {
                  msg("admin_backup_restore_file");
              }
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function backup_form() {
         global $HTTP_SERVER_VARS;
         echo "<script language=\"JavaScript\">
                       function SelectOptions(checkit, the_select) {
                                var selectObject = document.backup.elements[the_select];
                                var selectCount  = selectObject.length;

                                for (var i = 0; i < selectCount; i++) {
                                     selectObject.options[i].selected = checkit;
                                }
                       }
                       function SelectDefault(the_select) {
                                var selectObject = document.backup.elements[the_select];

                                SelectOptions(false,'tables[]');
                                selectObject.options[0].selected = true;
                       }
              </script>";
              ?>
             <form name='backup' method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=create_backup"; ?>'>
                   <?php
                   table_header("Backup...", "100%", "", "colspan='2'");
                   table_header("erstellen", "100%", "1", "colspan='2'", "nohead"); ?>
                                 <tr>
                                     <td width='40%' class='cat_two' valign='top'>
                                         <b>Backup bereiche:</b><br><br>
                                         <span class='font_small'>
                                               W&auml;hlen sie "phpForum Grundpaket" um alle wichtigen zur Daten zu sichern.<br>Wenn sie ein vollst�ndiges Backup w�nschen, m&uuml;ssen sie alle Felder markieren. (empfohlen)<br><br>
                                               <b><a href="#checkall" onclick="SelectOptions(true, 'tables[]')">vollst&auml;ndiges Backup</a>&nbsp;|&nbsp;<a href="#checkmin" onclick="SelectDefault('tables[]')">minimales Backup</a></b>
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <select name='tables[]' multiple size='11'>
                                                 <option value='default' selected>phpForum Grundpaket</option>
                                                 <option value='files' selected>Dateianh�nge</option>
                                                 <option value='avatars' selected>Avatare</option>
                                                 <option value='bb_codes' selected>Board-Codes</option>
                                                 <option value='mods' selected>Moderatoren</option>
                                                 <option value='polls' selected>Umfragen</option>
                                                 <option value='priv_msgs' selected>Private Nachrichten</option>
                                                 <option value='search' selected>Suchergebnisse</option>
                                                 <option value='smilies' selected>Smilies</option>
                                                 <option value='topic_abo' selected>Abonnierte Themen</option>
                                                 <option value='words' selected>Zensierte W&ouml;rter</option>
                                         </select>
                                     </td>
                                 </tr>
                   </table>
                   <p></p>
                   <center>
                           <input type='submit' value='erstellen'>
                   </center>
             </form>
             <?php
}
function restore_form() {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post'<?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { echo "enctype='multipart/form-data'"; } ?> action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=restore_backup"; ?>'>
               <?php table_header("Backup...", "100%", "", "colspan='2'");
               table_header("wiederherstellen", "100%", "1", "colspan='2'", "nohead");
               if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>lokale Datei:</b><br>
                             <span class='font_small'>
                                   W&auml;hlen sie hier eine Datei von ihrer Festplatte aus.
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='file' name='local_file'>
                         </td>
                     <?php } ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Datei auf dem Server:</b><br>
                             <span class='font_small'>
                                   W&auml;hlen sie hier eine Datei aus dem Verzeichnis <b>upload</b> vom Server aus, wenn Datei-Uploads deaktiviert sind.<br>
                                   Diese m&uuml;ssen sie mit einem FTP-Programm hochladen.
                             </span>
                         <td width='50%' class='cat_one'>
                             <?php upload_liste("upload", "server_file", "", ".bak"); ?>
                         </td>
                     </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='wiederherstellen'>
               </center>
         </form>
         <?php
}
function dump_backup($tables) {

         //default
         if (in_array("default", $tables)) {
             $return = array("\$GLOBALS[TB_ACCESS]" => $GLOBALS[TB_ACCESS], "\$GLOBALS[TB_CAT]" => $GLOBALS[TB_CAT],
                             "\$GLOBALS[TB_FORUM]" => $GLOBALS[TB_FORUM], "\$GLOBALS[TB_FORUM_ACCESS]" => $GLOBALS[TB_FORUM_ACCESS],
                             "\$GLOBALS[TB_POST]" => $GLOBALS[TB_POST], "\$GLOBALS[TB_SETTINGS]" =>$GLOBALS[TB_SETTINGS],
                             "\$GLOBALS[TB_SETTING_GROUP]" => $GLOBALS[TB_SETTING_GROUP], "\$GLOBALS[TB_STYLES]" => $GLOBALS[TB_STYLES],
                             "\$GLOBALS[TB_STATUS]" => $GLOBALS[TB_STATUS], "\$GLOBALS[TB_TOPIC]" => $GLOBALS[TB_TOPIC],
                             "\$GLOBALS[TB_USER]" => $GLOBALS[TB_USER]);
         }
         //files
         if (in_array("files", $tables)) {
             $return["\$GLOBALS[TB_FILES]"] = $GLOBALS[TB_FILES];
         }
         //avatars
         if (in_array("avatars", $tables)) {
             $return["\$GLOBALS[TB_AVATARS]"] = $GLOBALS[TB_AVATARS];
         }
         //bb_codes
         if (in_array("bb_codes", $tables)) {
             $return["\$GLOBALS[TB_BBCODES]"] = $GLOBALS[TB_BBCODES];
         }
         //mods
         if (in_array("mods", $tables)) {
             $return["\$GLOBALS[TB_MOD]"] = $GLOBALS[TB_MOD];
         }
         //polls
         if (in_array("polls", $tables)) {
             $return["\$GLOBALS[TB_POLL]"] = $GLOBALS[TB_POLL];
             $return["\$GLOBALS[TB_POLL_USER]"] = $GLOBALS[TB_POLL_USER];
             $return["\$GLOBALS[TB_POLL_TEXT]"] = $GLOBALS[TB_POLL_TEXT];
         }
         //priv_msgs
         if (in_array("priv_msgs", $tables)) {
             $return["\$GLOBALS[TB_MSG]"] = $GLOBALS[TB_MSG];
         }
         //search
         if (in_array("search", $tables)) {
             $return["\$GLOBALS[TB_SEARCH]"] = $GLOBALS[TB_SEARCH];
         }
         //smilies
         if (in_array("smilies", $tables)) {
             $return["\$GLOBALS[TB_SMILIES]"] = $GLOBALS[TB_SMILIES];
         }
         //topic_abo
         if (in_array("topic_abo", $tables)) {
             $return["\$GLOBALS[TB_ABO]"] = $GLOBALS[TB_ABO];
         }
         //words
         if (in_array("words", $tables)) {
             $return["\$GLOBALS[TB_WORDS]"] = $GLOBALS[TB_WORDS];
         }
         return $return;
}
###############################################################################
function dump_create($tables, $drop=TRUE) {

         //Alle Tabellen durchgehen
         foreach ($tables AS $tab_name => $tab_val) {

                ### Abfrage
                $result = mysql_query("DESCRIBE ".$tab_val);

                ### Delete Table
                if ($drop == TRUE) {
                    $query .= "DROP TABLE IF EXISTS $tab_name;\n";
                }

                ### Create Table
                $query .= "CREATE TABLE $tab_name (";
                $indexes = "";
                $primary = "";


                while ($Daten = mysql_fetch_array($result)) {
                       //Name + Typ
                       $query .= $Daten["Field"]." ".$Daten["Type"];

                       //Null / Not Null
                       if ($Daten["Null"] == "YES") {
                           $query .= " NULL";
                       } else {
                           $query .= " NOT NULL";
                       }

                       //Default
                       $query .= " default '".$Daten["Default"]."'";

                       //Extra
                       $query .= " ".$Daten["Extra"].", ";

                       //Prim�r
                       if ($Daten["Key"] == "PRI") {
                           $primary .= $Daten["Field"].",";
                       //Index
                       } elseif ($Daten["Key"] == "MUL") {
                           $indexes .= $Daten["Field"].",";
                       }
                }

                //Komma "killen"
                $query = substr($query, 0, strlen($query)-2);

                //Prim�rschl�ssel ?
                if ($primary) {
                    $query .= ",PRIMARY KEY (".substr($primary, 0, strlen($primary)-1).")";
                }
                //Index ?
                if ($indexes) {
                    $query .= ",INDEX (".substr($indexes, 0, strlen($indexes)-1).")";
                }

                $query .= ");\n";
         }
         return $query;
}
function dump_insert($tables, $delete=TRUE) {

         //Alle Tabellen durchgehen
         foreach ($tables AS $tab_name => $tab_val) {

                ### Abfrage
                $result = mysql_query("SELECT * FROM ".$tab_val);

                ### Delete from ...
                if ($delete == TRUE) {
                    $query .= "DELETE FROM $tab_name;\n";
                }

                ### Insert into (felder)
                while($Daten = mysql_fetch_array($result, MYSQL_ASSOC)) {
                      $values = "";
                      $fields = "";

                      $query .= "INSERT INTO $tab_name (";

                      //Values erstellen
                      while(list($col, $var) = each($Daten)) {
                            $fields .= $col.",";
                            $values .= "'".mysql_escape_string($var)."',";
                      }
                      $fields = substr($fields, 0, strlen($fields)-1);
                      $values = substr($values, 0, strlen($values)-1);

                      $query .= $fields.") VALUES (".$values.");\n";
                }
         }
         return $query;
}
function dump_download($string) {

         header("Cache-control: max-age=60");
         header("Expires: ".gmdate("D, d M Y H:i:s",time()+60)."GMT");
         header("Content-disposition: filename=Backup_".date("Y-m-d").".bak");
         header("Content-type: unknown/unknown");
         echo $string;
}
function dump_restore($file) {

         $string = file($file);
         foreach($string AS $key => $val) {
                 $table = preg_replace("/(.*)\\\$GLOBALS\[TB_([_A-Z]*)\](.*)/", "TB_\\2", trim($val));
                 $sql = preg_replace("/\\\$GLOBALS\[TB_([_A-Z]*)\]/", "$GLOBALS[$table]", trim($val));
                 if (substr($sql, 0, 1) != "#" AND $sql) {
                     if (!mysql_query($sql)) {
                         return FALSE;
                         break;
                     }
                 }
         }
         return TRUE;
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>