<?php
include("head.php");
if (!$HTTP_GET_VARS[action]) {

    ?>
    <br>
    <h3>Willkommen im phpForum Administratoren-Kontrollzentrum</h3>
    <span class='font_normal'>
          Diese Software wurde entwickelt von <a href='mailto:killergod2000@gmx.net'>Christoph Roeder</a>.
          <br><br>
          Hier k&ouml;nnen sie alle Einstellungen ihres phpForums konfigurieren. Bitte w&auml;hlen sie auf der linken Seite aus, was sie konfigurieren m&ouml;chten.
    </span>
    <?php
        echo "<P>&nbsp;</P>";
        member_search();
        echo "<P>&nbsp;</P>";
        copyright();
} else {

    switch ($HTTP_GET_VARS[action]) {
            case "status":
                  auth("admin_status");
                      forum_status();
                  break;
    }
}
gz_site();
?>