<?php
################################################################################
################################# Funktionen ###################################
################################################################################
#
########### Men� - Funktionen ########## +++
function forum_status() {
         echo "<h3>Statistiken...</h3>";
         table_header("Forum Status", "50%"); ?>
               <tr>
                   <td align='center' width='100%' class='cat_one'>
                       <table width='100%' cellpadding='1' cellspacing='0' >
                              <tr class='cat_one'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_CAT]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Kategorien:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_two'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_FORUM]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Foren:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_one'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT user_id FROM $GLOBALS[TB_MOD]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Moderatoren:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_two'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_TOPIC]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Themen:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_one'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_POST]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Beitr�ge:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_two'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_USER]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Benutzer:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_one'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_ACCESS]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Benutzergruppen:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_two'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_STATUS]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Benutzer-Titel:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_one'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_SMILIES]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Smilies:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_two'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_BBCODES]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Board Codes:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_one'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_WORDS]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Zensierte W&ouml;rter:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              <tr class='cat_two'>
                                  <td width='90%'>
                                      <?php $max=mysql_num_rows(mySQL_query ("SELECT id FROM $GLOBALS[TB_STYLES]")); ?>
                                      <span class='font_normal'><b>-&nbsp;</b>Foren-Styles:</span>
                                  <td width='10%' align='right'>
                                      <span class='font_normal'><b><?php echo $max; ?></b></span>
                                  </td>
                              </tr>
                       </table>
                   </td>
               </tr>
         </table>
         <?php
}
function member_search() {
         ?>
         <form method='post' action='<?php echo "user.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result"; ?>'>
               <input type='hidden' name='access_id' VALUE='*'>
               <?php
               open_table("Member-Suche", "50%");
                           ?>
                           <p>Suche nach Benutzern deren Name folgendes enth&auml;lt.</p>
                           <CENTER>
                                   <input type='text' name='name' SIZE='20' MAXLENGTH='255'>&nbsp;&nbsp;
                                   <INPUT TYPE='submit' VALUE='suchen'>
                           </CENTER>
                           <?php
               close_table("");
               ?>
         </form>
         <?php
}
########### Men� - Funktionen ########## ---
#
#
##################### access ##################### +++
function auth($typ) {

         $userinfo = get_user_info();
         $Daten = mysql_fetch_array(mysql_query("SELECT * FROM $GLOBALS[TB_ACCESS] WHERE $GLOBALS[TB_ACCESS].id='$userinfo[access_id]'"));

         if ($Daten[$typ] != "on") {
             msg("user");
         }
}
##################### access ##################### ---
#
#
##################### Copyright ##################### +++
function copyright() {
         table_header("phpForum Entwickler & Mitarbeiter", "70%", "1", "colspan='2'");
               ?>
                <tr class='default_tr'>
                    <td width='20%' align='left' class='cat_two'>
                        <span class='font_normal'>
                              Entwickler:
                        </span>
                    <td width='80%' align='left' class='cat_one'>
                        <span class='font_normal'>
                              <a href='mailto:killergod2000@gmx.net'>Christoph Roeder</a> (<a href='http://phpforum.ath.cx' target='_blank'>Homepage</a>)
                        </span>
                    </td>
                <tr>
                    <td width='20%' align='left' class='cat_two' valign='top'>
                        <span class='font_normal'>
                              Beta Tester:
                        </span>
                    <td width='80%' align='left' class='cat_one' valign='top'>
                        <span class='font_normal'>
                              <a href='mailto:webmaster@PowerFly.de'>Christian Morhard</a> (<a href='http://www.DU-Clan.com' target='_blank'>Homepage</a>),&nbsp;<a href='mailto:webmaster@matze202.de'>Matthias Berndt</a> (<a href='http://www.matze202.de' target='_blank'>Homepage</a>)
                        </span>
                    </td>
                </tr>
         </table>
<?php
}
##################### Copyright ##################### ---
#
#
################################################################################
################################# Funktionen ###################################
################################################################################
?>