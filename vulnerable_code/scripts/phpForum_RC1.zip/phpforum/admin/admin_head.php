<?php
include("head.php");
?>
<table width='100%'>
       <tr>
           <td align='left'>
               <span class='font_normal'>
                     <a href='http://phpforum.ath.cx' target='_blank'>phpForum</a> by <b><a href='mailto:KillerGod2000@gmx.net'>Christoph Roeder</a></b>
               </span>
           <td align='right'>
               <span class='font_normal'>
                     <a href='<?php echo "../index.php?$Sess_Name=$Sess"; ?>' target='_top'><b>zum Foren-Index</b></a>
               </span>
           </td>
       </tr>
</table>
<?php
gz_site();
?>