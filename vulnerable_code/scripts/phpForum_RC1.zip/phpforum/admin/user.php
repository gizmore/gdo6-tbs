<?php
include("head.php");
auth("admin_users");
?>
<h3 class='font_big'>Benutzer...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "search":
              search();
              break;

        case "result":
              result($HTTP_GET_VARS[search], $HTTP_GET_VARS[get]);
              break;

        case "add":
              addedit("");
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id]);
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;

        case "save":
              save();
              break;

        case "mail":
              mailall();
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function search() {
         include("$GLOBALS[MAIN_PATH]/config.php");
         global $Sess_Name, $Sess, $HTTP_SERVER_VARS;
         ?>
         <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result"; ?>'>
               <?php table_header("n�tzliche Links...", "100%", "", "colspan='2'"); ?>
                        <tr>
                            <td width='30%' class='cat_one' colspan='2'>
                                <b>-</b>&nbsp;<a href='<?php echo "user.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result&get=all"; ?>'>Alle Benutzer anzeigen</a><br>
                                <b>-</b>&nbsp;<a href='<?php echo "user.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result&get=best"; ?>'>Die aktivsten Benutzer anzeigen</a><br>
                                <b>-</b>&nbsp;<a href='<?php echo "user.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=result&get=today"; ?>'>heute aktive Benutzer anzeigen</a><br>
                            </td>
                        </tr>
               <?php table_header("Suche...", "100%", "1", "colspan='2'", "nohead"); ?>
                        <tr>
                            <td width='40%' class='cat_two'>
                                <b>Benutzergruppe:</b>
                            <td width='60%' class='cat_one'>
                                <select name='access_id'>
                                        <option value='*'>### Alle Benutzergruppen ###</option>
                                        <?php
                                        $result = mySQL_query ("SELECT *
                                                                FROM $TB_ACCESS
                                                                ORDER BY name ASC");
                                        while($Daten = mysql_fetch_array ($result)) {
                                              echo "<option value='$Daten[id]'>$Daten[name]</option>";
                                        }
                                        ?>
                                </select>
                            </td>
                        <tr>
                            <td width='40%' class='cat_two'>
                                <b>Benutzername enth�lt:</b>
                            <td width='60%' class='cat_one'>
                                <input type='text' name='name' size='30' maxlength='255'>
                              </td>
                        <tr>
                            <td width='40%' class='cat_two'>
                                <b>Geburtstag:</b>
                                <br>
                                <span class='font_small'>
                                      Format: jjjj-mm-tt (0 f�r heute)
                                </span>
                            <td width='60%' class='cat_one'>
                                <input type='text' name='geb' size='30' maxlength='10'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>eMail-Adresse enth�lt:</b>
                              <td width='60%' class='cat_one'>
                                  <input type='text' name='email' size='30' maxlength='255'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>Homepage enth�lt:</b>
                              <td width='60%' class='cat_one'>
                                  <input type='text' name='homepage' size='30' maxlength='255'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>registriert vor:</b>
                                  <br>
                                  <span class='font_small'>
                                        Format: jjjj-mm-tt hh:mm:ss (0 f�r heute)
                                  </span>
                              <td width='60%' class='cat_one'>
                                  <input type='text' name='signup_less' size='30' maxlength='19'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>registriert nach:</b>
                                  <br>
                                  <span class='font_small'>
                                        Format: jjjj-mm-tt hh:mm:ss
                                  </span>
                              <td width='60%' class='cat_one'>
                                  <input type='text' name='signup_more' size='30' maxlength='19'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>letzer Besuch vor:</b>
                                  <br>
                                  <span class='font_small'>
                                        Format: jjjj-mm-tt hh:mm:ss (0 f�r heute)
                                  </span>
                              <td width='60%' class='cat_one'>
                                  <input type='text' name='last_login_less' size='30' maxlength='19'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>letzer Besuch nach:</b>
                                  <br>
                                  <span class='font_small'>
                                        Format: jjjj-mm-tt hh:mm:ss
                                  </span>
                              <td width='60%' class='cat_one'>
                                  <input type='text' name='last_login_more' size='30' maxlength='19'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>Anzahl der Beitr�ge gr��er als:</b>
                              <td width='60%' class='cat_one'>
                                  <input type='text' name='points_more' size='30' maxlength='255'>
                              </td>
                          <tr>
                              <td width='40%' class='cat_two'>
                                  <b>Anzahl der Beitr�ge kleiner als:</b>
                              <td width='60%' class='cat_one'>
                                  <input type='text' name='points_less' size='30' maxlength='255'>
                              </td>
                          </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='Suchen'>
                       <input type='reset' name='Reset' value='Zur�cksetzen'>
               </center>
         </form>
         <?php
}
function result($search, $get="") {
         global $HTTP_GET_VARS, $HTTP_POST_VARS, $HTTP_SERVER_VARS, $_style;

         ### SQL-Statement "basteln" ###
         switch ($HTTP_GET_VARS[get]) {

                 //Standard - Suche
                 case "":
                       $query = "SELECT $GLOBALS[TB_USER].*
                                 FROM $GLOBALS[TB_USER]
                                 WHERE ";
                       //Benutzername enth�lt
                       if ($HTTP_POST_VARS[name] OR $HTTP_GET_VARS[name]) {
                           $query .= "$GLOBALS[TB_USER].name LIKE '%$HTTP_POST_VARS[name]$HTTP_GET_VARS[name]%' AND ";
                       }
                       //Geburtstag am ...
                       if ($HTTP_POST_VARS[geb] OR $HTTP_GET_VARS[geb]) {
                           if ($HTTP_POST_VARS[geb] == "0" OR $HTTP_GET_VARS[geb] == "0") {
                               $query .= "TO_DAYS($GLOBALS[TB_USER].geb) = TO_DAYS(NOW()) AND ";
                           } else {
                               $query .= "TO_DAYS($GLOBALS[TB_USER].geb) = TO_DAYS('$HTTP_POST_VARS[geb]$HTTP_GET_VARS[geb]') AND ";
                           }
                       }
                       //eMail enth�lt
                       if ($HTTP_POST_VARS[email] OR $HTTP_GET_VARS[email]) {
                           $query .= "$GLOBALS[TB_USER].email LIKE '%$HTTP_POST_VARS[email]$HTTP_GET_VARS[email]%' AND ";
                       }
                       //Homepage enth�lt
                       if ($HTTP_POST_VARS[homepage] OR $HTTP_GET_VARS[homepage]) {
                           $query .= "$GLOBALS[TB_USER].homepage LIKE '%$HTTP_POST_VARS[homepage]$HTTP_GET_VARS[homepage]%' AND ";
                       }
                       //registriert vor
                       if ($HTTP_POST_VARS[signup_less] OR $HTTP_GET_VARS[signup_less]) {
                           if ($HTTP_POST_VARS[signup_less] == "0" OR $HTTP_GET_VARS[signup_less] == "0") {
                               $query .= "DATE_FORMAT($GLOBALS[TB_USER].reg,'%Y%m%d%H%i%s') < DATE_FORMAT(NOW(),'%Y%m%d%H%i%s') AND ";
                           } else {
                               $query .= "DATE_FORMAT($GLOBALS[TB_USER].reg,'%Y%m%d%H%i%s') < DATE_FORMAT('$HTTP_POST_VARS[signup_less]$HTTP_GET_VARS[signup_less]','%Y%m%d%H%i%s') AND ";
                           }
                       }
                       //registriert nach
                       if ($HTTP_POST_VARS[signup_more] OR $HTTP_GET_VARS[signup_more]) {
                           $query .= "DATE_FORMAT($GLOBALS[TB_USER].reg,'%Y%m%d%H%i%s') > DATE_FORMAT('$HTTP_POST_VARS[signup_more]$HTTP_GET_VARS[signup_more]','%Y%m%d%H%i%s') AND ";
                       }
                       //letzer Besuch vor
                       if ($HTTP_POST_VARS[last_login_less] OR $HTTP_GET_VARS[last_login_less]) {
                           if ($HTTP_POST_VARS[last_login_less] == "0" OR $HTTP_GET_VARS[last_login_less] == "0") {
                               $query .= "TO_DAYS($GLOBALS[TB_USER].last_login) < TO_DAYS(NOW()) AND ";
                           } else {
                               $query .= "TO_DAYS($GLOBALS[TB_USER].last_login) < TO_DAYS('$HTTP_POST_VARS[last_login_less]$HTTP_GET_VARS[last_login_less]') AND ";
                           }
                       }
                       //letzer Besuch nach
                       if ($HTTP_POST_VARS[last_login_more] OR $HTTP_GET_VARS[last_login_more]) {
                           if ($HTTP_POST_VARS[last_login_more] == "0" OR $HTTP_GET_VARS[last_login_more] == "0") {
                               $query .= "TO_DAYS($GLOBALS[TB_USER].last_login) > TO_DAYS(NOW()) AND ";
                           } else {
                               $query .= "TO_DAYS($GLOBALS[TB_USER].last_login) > TO_DAYS('$HTTP_POST_VARS[last_login_more]$HTTP_GET_VARS[last_login_more]') AND ";
                           }
                       }
                       //Anzahl der Beitr�ge gr��er als
                       if ($HTTP_POST_VARS[points_more] OR $HTTP_GET_VARS[points_more]) {
                           $query .= "$GLOBALS[TB_USER].points > '$HTTP_POST_VARS[points_more]$HTTP_GET_VARS[points_more]' AND ";
                       }
                       //Anzahl der Beitr�ge kleiner als
                       if ($HTTP_POST_VARS[points_less] OR $HTTP_GET_VARS[points_less]) {
                           $query .= "$GLOBALS[TB_USER].points < '$HTTP_POST_VARS[points_less]$HTTP_GET_VARS[points_less]' AND ";
                       }
                       //Benutzergruppe
                       if ($HTTP_POST_VARS[access_id] != "*" AND $HTTP_GET_VARS[access_id] != "*") {
                           $query .= "$GLOBALS[TB_USER].access_id='$HTTP_POST_VARS[access_id]$HTTP_GET_VARS[access_id]' ";
                       } else {
                           $query .= "$GLOBALS[TB_USER].access_id <> '' ";
                       }
                       //sortierung !
                       $query .= "ORDER BY $GLOBALS[TB_USER].name ";
                       break;

                 //Alle anzeigen
                 case "all":
                       $query = "SELECT *
                                 FROM $GLOBALS[TB_USER]
                                 ORDER BY name ";
                       break;

                 //Besten 5
                 case "best":
                       $query = "SELECT *
                                 FROM $GLOBALS[TB_USER]
                                 ORDER BY points DESC ";
                       break;

                 //heute Aktive Benutzer
                 case "today":
                       $query = "SELECT *
                                 FROM $GLOBALS[TB_USER]
                                 WHERE TO_DAYS(last_login) = TO_DAYS(NOW())
                                 ORDER BY name ";
                       break;

         }
         ######### ANZ - Limit ##### +++
         $Limit_anz = mySQL_num_rows(mySQL_query ($query));
         //wenn keine Page �bergeben wurde
         if (!$HTTP_GET_VARS[Page]) {
             $HTTP_GET_VARS[Page]="1";
         }
         //f�r die LIMIT
         if ($Limit_anz > $GLOBALS[ANZ_MEMBERS]) {
             $p=$HTTP_GET_VARS[Page]-1;
             $L_AB=$GLOBALS[ANZ_MEMBERS]*$p;
         }
         //f�r die LIMIT
         if ($L_AB < "0") {
             $L_AB="0";
         }
         $query .= "LIMIT $L_AB,$GLOBALS[ANZ_MEMBERS]";
         ######### ANZ - Limit ##### ---

         ###*** Seiten Navigation ***
         echo "<div align='right'>".navi("$HTTP_POST_VARS[Page]$HTTP_GET_VARS[Page]", $Limit_anz, $GLOBALS[ANZ_MEMBERS], "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=$HTTP_GET_VARS[action]&get=$get&access_id=$HTTP_POST_VARS[access_id]$HTTP_GET_VARS[access_id]&name=$HTTP_POST_VARS[name]$HTTP_GET_VARS[name]&geb=$HTTP_POST_VARS[geb]$HTTP_GET_VARS[geb]&email=$HTTP_POST_VARS[email]$HTTP_GET_VARS[email]&homepage=$HTTP_POST_VARS[homepage]$HTTP_GET_VARS[homepage]&signup_less=$HTTP_POST_VARS[signup_less]$HTTP_GET_VARS[signup_less]&signup_more=$HTTP_POST_VARS[signup_more]$HTTP_GET_VARS[signup_more]&last_login_less=$HTTP_POST_VARS[last_login_less]$HTTP_GET_VARS[last_login_less]&last_login_more=$HTTP_POST_VARS[last_login_more]$HTTP_GET_VARS[last_login_more]&points_less=$HTTP_POST_VARS[points_less]$HTTP_GET_VARS[points_less]&points_more=$HTTP_POST_VARS[points_more]$HTTP_GET_VARS[points_more]")."</div>";
         ###*** Seiten Navigation ***
         table_header("Benutzersuche...", "100%", "", "colspan='5'"); ?>
               <tr class='default_tr'>
                   <td width='20%' align='center'>
                       <b>name</b>
                   <td width='25%' align='center'>
                       <b>kontakt</b>
                   <td width='10%' align='center'>
                       <b>beitr�ge</b>
                   <td width='35%' align='center'>
                       <b>optionen</b>
                   <td width='10%' align='center'>
                       <b>l�schen</b>
                   </td>
               </tr>
               <?php

         $result = mysql_query($query);
         while($Daten = mysql_fetch_array ($result)) {
               ?>
               <tr>
                   <td width='20%' class='cat_two'>
                       <a href='<?php echo "../showuser.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=$Daten[id]"; ?>'><?php echo $Daten[name]; ?></a>
                   <td width='25%' class='cat_two'>
                       <?php
                       $user_perm = get_forum_perm("", $Daten[id]);
                       //--E-Mail--
                       echo "<a href='../mail.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&id=$Daten[id]'><img src='../$_style[pic_mail]' border='0' alt='eine E-Mail an $Daten[name] schicken'></a>&nbsp;&nbsp;\n";
                       //--PM--
                       if ($user_perm[send_pm] == "on") {
                           echo "<a href='../private.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=new&user_id=$Daten[id]'><img src='../$_style[pic_pm]' border='0' alt='$Daten[name] eine PM schicken'></a>&nbsp;&nbsp;\n";
                       }
                       //--Homepage--
                       if ($Daten[homepage]) {
                           echo "<a href='$Daten[homepage]' target='_blank'><img src='../$_style[pic_home]' border='0' alt='Homepage von $Daten[name] anzeigen'></a>&nbsp;&nbsp;\n";
                       }
                       echo "<a href='../search.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=search&get=user&search=$Daten[id]'><img src='../$_style[pic_search]' border='0' alt='Beitr�ge von $Daten[name] suchen'></a>&nbsp;&nbsp;\n";
                       //--ICQ--
                       if ($Daten[icq]) {
                           echo "<a href='http://wwp.icq.com/scripts/search.dll?to=$Daten[icq]'><img src='http://wwp.icq.com/scripts/online.dll?icq=$Daten[icq]&img=5' border='0' width='18' height='18' alt='$Daten[name] zur ICQ-Kontaktliste hinzuf&uuml;gen'></a>&nbsp;&nbsp;\n";
                       }
                       ?>
                   <td width='10%' align='center' class='cat_one'>
                       <?php echo $Daten[points]; ?>
                   <td width='35%' class='cat_one' align='center'>
                       <?php
                       echo "<a href='user.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]' title='Profil von: &quot;".htmlentities($Daten[name], ENT_QUOTES)."&quot; bearbeiten'>[bearbeiten]</a>&nbsp;";
                       echo "<a href='../mailpass.php?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&Name=$Daten[name]&action=sendpass' title='&quot;".htmlentities($Daten[name], ENT_QUOTES)."&quot; ein neues Passwort senden'>[Passwort senden]</a>";
                       ?>
                   <td width='10%' align='center' class='cat_two'>
                       <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]"; ?>'><img src='<?php echo "../".$_style[pic_admin_del]; ?>' border='0' alt='<?php echo "&quot;".htmlentities($Daten[name], ENT_QUOTES)."&quot; l&ouml;schen"; ?>'></a>
                   </td>
               </tr>
               <?php
         }
         echo "</table>";
         ###*** Seiten Navigation ***
         echo "<div align='right'>".navi("$HTTP_POST_VARS[Page]$HTTP_GET_VARS[Page]", $Limit_anz, $GLOBALS[ANZ_MEMBERS], "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=$HTTP_GET_VARS[action]&get=$get&access_id=$HTTP_POST_VARS[access_id]$HTTP_GET_VARS[access_id]&name=$HTTP_POST_VARS[name]$HTTP_GET_VARS[name]&geb=$HTTP_POST_VARS[geb]$HTTP_GET_VARS[geb]&email=$HTTP_POST_VARS[email]$HTTP_GET_VARS[email]&homepage=$HTTP_POST_VARS[homepage]$HTTP_GET_VARS[homepage]&signup_less=$HTTP_POST_VARS[signup_less]$HTTP_GET_VARS[signup_less]&signup_more=$HTTP_POST_VARS[signup_more]$HTTP_GET_VARS[signup_more]&last_login_less=$HTTP_POST_VARS[last_login_less]$HTTP_GET_VARS[last_login_less]&last_login_more=$HTTP_POST_VARS[last_login_more]$HTTP_GET_VARS[last_login_more]&points_less=$HTTP_POST_VARS[points_less]$HTTP_GET_VARS[points_less]&points_more=$HTTP_POST_VARS[points_more]$HTTP_GET_VARS[points_more]")."</div>";
         ###*** Seiten Navigation ***
}
function addedit($id="") {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post' name='bbform' <?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { echo "enctype='multipart/form-data'"; } ?> action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <input type='hidden' name='id' VALUE='<?php echo $id; ?>'>
               <input type='hidden' name='save' VALUE='<?php
               if (!$id) {
                   echo "add'>";
                   $typ = "hinzuf�gen";
                   $text = "Benutzer $typ...";
               } else {
                   echo "edit'>";
                   $typ = "bearbeiten";
                   $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                           FROM $GLOBALS[TB_USER]
                                                           WHERE $GLOBALS[TB_USER].id='$id'"));
                   $text = "$Daten[name] $typ...";
               }
               table_header($text, "100%", "", "colspan='2'"); ?>
                     <tr>
                         <td width='30%' colspan='2' class='cat_one'>
                             <b>-</b>&nbsp;<a href='#reg'>Erforderliche Informationen</a><br>
                             <b>-</b>&nbsp;<a href='#adv'>Zus�tzliche Informationen</a><br>
                             <b>-</b>&nbsp;<a href='#settings'>Einstellungen</a><br>
                         </td>
                     </tr>
                     <?php
               ### zur Reg. wichtig ###
               table_header("<a name='reg'>Erforderliche Informationen:", "100%", "1", "colspan='2'", "nohead");
                     ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Benutzergruppe:</b>
                         <td width='50%' class='cat_one'>
                             <select name='access_id'><?php
                                     $result = mySQL_query ("SELECT *
                                                             FROM $GLOBALS[TB_ACCESS]
                                                             ORDER BY $GLOBALS[TB_ACCESS].name ASC");
                                     while ($Daten_access = mysql_fetch_array ($result)) {
                                            echo "<option value='$Daten_access[id]'";
                                            if ($Daten[access_id] == $Daten_access[id]) { echo " selected"; }
                                            echo ">$Daten_access[name]</option>\n";
                                     }
                                     ?>
                             </select>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Benutzername:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='name' value="<?php echo $Daten[name]; ?>" maxlength='50' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>eMail-Adresse:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='email' value="<?php echo $Daten[email]; ?>" maxlength='255' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Passwort:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($id) {
                                 echo "<input type='checkbox' name='pass_edit' value='on'>&nbsp;&auml;ndern?<br>";
                             }
                             echo "<input type='text' name='pass' maxlength='32' size='30'>";
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Registriert seit:</b>
                             <br>
                             <span class='font_small'>
                                   Format: jjjj-mm-tt
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='reg' value="<?php
                                    if (!$id) {
                                        echo date("Y-m-d");
                                    } else {
                                        echo $Daten[reg];
                                    } ?>" maxlength='10' size='10'>
                         </td>
                     </tr>
                     <?php
               ### Zus�tzliche Informationen ###
               table_header("<a name='adv'>Zus�tzliche Informationen:", "100%", "1", "colspan='2'", "nohead"); ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Geburtstag:</b><br>
                             <span class='font_small'>
                                   Format: jjjj-mm-tt
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='geb' value="<?php echo $Daten[geb]; ?>" maxlength='10' size='10'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Homepage:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='homepage' value="<?php echo $Daten[homepage]; ?>" maxlength='255' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Punkte:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='points' value="<?php echo $Daten[points]; ?>" maxlength='11' size='10'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Geschlecht:</b>
                         <td width='50%' class='cat_one'>
                             <select name='gender'>
                                     <?php
                                     if ($Daten[gender] == "m") {
                                         echo "<option value='m' selected>m�nnlich</option>";
                                         echo "<option value='w'>weiblich</option>";
                                     } else {
                                         echo "<option value='m'>m�nnlich</option>";
                                         echo "<option value='w' selected>weiblich</option>";
                                     }
                                     ?>
                             </select>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Beruf:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='job' value="<?php echo $Daten[job]; ?>" maxlength='255' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Wohnort:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='location' value="<?php echo $Daten[location]; ?>" maxlength='255' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>ICQ Nummer:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='icq' value="<?php echo $Daten[icq]; ?>" maxlength='20' size='10'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Yahoo Instant Messenger:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='yim' value="<?php echo $Daten[yim]; ?>" maxlength='255' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>AOL Instant Messenger:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='aim' value="<?php echo $Daten[aim]; ?>" maxlength='255' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Letzes Login:</b>
                             <br>
                             <span class='font_small'>
                                   Format: jjjj-mm-tt hh:mm:ss
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='last_login' value="<?php
                                    if (!$id) {
                                        echo date("Y-m-d");
                                    } else {
                                        echo $Daten[last_login];
                                    } ?>" maxlength='19' size='20'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>aktuelles Benutzerbild:</b>
                             <br>
                             <span class='font_small'>
                                   Format: jpg / gif<br>
                                   max. Aufl&ouml;sung: <?php echo $GLOBALS[PIC_X]."x".$GLOBALS[PIC_Y]; ?> Pixel
                             </span>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($typ == "bearbeiten" AND $avatar = avatar($Daten[id])) {
                                 echo $avatar."<br><br>";
                                 echo "<input type='checkbox' name='pic_del' value='on'>&nbsp;l&ouml;schen?<br>";
                             }
                             ?>
                         </td>
                     <?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>lokale Datei:</b><br>
                             <span class='font_small'>
                                   Hier k&ouml;nnen sie ein Bild von ihrer Festplatte ausw&auml;hlen.
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='file' name='userfile'>
                         </td>
                     <?php } ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Datei auf dem Server:</b><br>
                             <span class='font_small'>
                                   Diese Dateien liegen im phpForum Verzeichnis <b>upload</b>,<br>
                                   sie k&ouml;nnen weitere mit einem FTP-Programm hochladen.
                             </span>
                         <td width='50%' class='cat_one'>
                             <?php upload_liste("upload"); ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Signatur:</b>
                             <br>
                             <span class='font_small'>
                                   <?php
                                   echo "HTML Code ist ";
                                        if ($SIGN_HTML == "on") { echo "AN"; } else { echo "AUS"; }
                                   echo "<br><a href=\"javascript:onclick=BBCode()\">Board Code</a> ist ";
                                        if ($SIGN_BBCODES == "on") { echo "AN"; } else { echo "AUS"; }
                                   echo "<br><a href=\"javascript:onclick=Smilies()\">Smilies</a> sind ";
                                        if ($SIGN_SMILIES == "on") { echo "AN"; } else { echo "AUS"; }
                                   ?>
                             </span>
                         <td width='50%' class='cat_one'>
                             <textarea cols='37' rows='5' name='message'><?php echo $Daten[sign]; ?></textarea>
                         </td>
                     </tr>
                     <?php
               ### Einstellungen ###
               table_header("<a name='settings'>Einstellungen:", "100%", "1", "colspan='2'", "nohead"); ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>"Automatischer Login"?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[stay_login] == "on") {
                                 echo "<input type='radio' name='stay_login' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='stay_login' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='stay_login' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='stay_login' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>"eMail Benachrichtigung" standardm�ssig aktivieren ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[post_email] == "on") {
                                 echo "<input type='radio' name='post_email' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='post_email' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='post_email' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='post_email' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>eMail-Adresse verstecken ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[email_show] == "on") {
                                 echo "<input type='radio' name='email_show' value=''>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='email_show' value='on' checked>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='email_show' value='' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='email_show' value='on'>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>eMail Benachrichtigung f�r Private Nachrichten ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[pm_email] == "on") {
                                 echo "<input type='radio' name='pm_email' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='pm_email' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='pm_email' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='pm_email' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Pop-up Benachrichtung f�r PN aktivieren ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[pm_popup] == "on") {
                                 echo "<input type='radio' name='pm_popup' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='pm_popup' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='pm_popup' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='pm_popup' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Status f�r PN aktivieren ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[pm_footer] == "on") {
                                 echo "<input type='radio' name='pm_footer' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='pm_footer' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='pm_footer' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='pm_footer' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Board-Codes aktivieren ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[bbcodes_show] == "on") {
                                 echo "<input type='radio' name='bbcodes_show' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='bbcodes_show' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='bbcodes_show' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='bbcodes_show' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>HTML-Code aktivieren ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[html_show] == "on") {
                                 echo "<input type='radio' name='html_show' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='html_show' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='html_show' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='html_show' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Smilies aktivieren ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[smilies_show] == "on") {
                                 echo "<input type='radio' name='smilies_show' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='smilies_show' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='smilies_show' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='smilies_show' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>eigene Signatur anzeigen ?:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[sign_show] == "on") {
                                 echo "<input type='radio' name='sign_show' value='on' checked>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='sign_show' value=''>&nbsp;nein";
                             } else {
                                 echo "<input type='radio' name='sign_show' value='on'>&nbsp;ja&nbsp;";
                                 echo "<input type='radio' name='sign_show' value='' checked>&nbsp;nein";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Pers&ouml;nlicher Foren - Style:</b>
                         <td width='50%' class='cat_one'>
                             <select name='style'><?php
                                     $result = mySQL_query ("SELECT *
                                                             FROM $GLOBALS[TB_STYLES]
                                                             ORDER BY $GLOBALS[TB_STYLES].name ASC");
                                     while ($Daten_style = mysql_fetch_array ($result)) {
                                            echo "<option value='$Daten_style[id]'";
                                            //gew�hlt ?
                                            if ($Daten[style] == $Daten_style[id]) { echo " selected"; }

                                            echo ">$Daten_style[name]";
                                            // Default ?
                                            if ($Daten_style[active] == "on") {
                                                echo " (default)";
                                            }
                                            echo "</option>\n";
                                     }
                                     ?>
                             </select>
                         </td>
                     </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='<?php echo $typ; ?>'>
                       <input type='reset' name='Reset' value='Zur�cksetzen'>
               </center>
         </form>
         <?php
}
function save() {
         global $HTTP_POST_FILES, $HTTP_POST_VARS, $HTTP_SERVER_VARS;
         // Pr�fen ob alle wichtigen Daten angegeben wurden
         if (!$HTTP_POST_VARS[email] OR !$HTTP_POST_VARS[name] OR !$HTTP_POST_VARS[reg]) {
             msg("eingabe_fault", "2", "back()");
         }
         //User schon vorhanden ? (hinzuf�gen)
         if ($HTTP_POST_VARS[save] == "add") {
             if (mysql_num_rows(mysql_query("SELECT * FROM $GLOBALS[TB_USER] WHERE name LIKE '$HTTP_POST_VARS[name]'")) > 0) {
                 msg("signup_exist", "2", "back()");
             }
         //User schon vorhanden ? (bearbeiten)
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             if (mysql_num_rows(mysql_query("SELECT * FROM $GLOBALS[TB_USER] WHERE name LIKE '$HTTP_POST_VARS[name]' AND id <> '$HTTP_POST_VARS[id]'")) > 0) {
                 msg("signup_exist", "2", "back()");
             }
         }
         // Homepage mit http versehen
         if(substr(strtolower($HTTP_POST_VARS[homepage]), 0, 7) != "http://" AND $HTTP_POST_VARS[homepage]) {
            $HTTP_POST_VARS[homepage] = "http://".$HTTP_POST_VARS[homepage];
         }
         // Passwort verschl�sseln
         $HTTP_POST_VARS[pass] = md5($HTTP_POST_VARS[pass]);

         ### hinzuf�gen
         if ($HTTP_POST_VARS[save] == "add") {
             $query = "INSERT INTO $GLOBALS[TB_USER] (pass, reg, name, geb, gender, job, location,
                       homepage, email, icq, aim, yim, sign, access_id, points, last_post,
                       last_login, pm_email, pm_popup, pm_popup_show, bbcodes_show, html_show, smilies_show,
                       sign_show, post_email, email_show, stay_login, pm_footer, style)
                       VALUES ('$HTTP_POST_VARS[pass]','$HTTP_POST_VARS[reg]','$HTTP_POST_VARS[name]',
                               '$HTTP_POST_VARS[geb]','$HTTP_POST_VARS[gender]','$HTTP_POST_VARS[job]',
                               '$HTTP_POST_VARS[location]','$HTTP_POST_VARS[homepage]','$HTTP_POST_VARS[email]',
                               '$HTTP_POST_VARS[icq]','$HTTP_POST_VARS[aim]','$HTTP_POST_VARS[yim]',
                               '$HTTP_POST_VARS[message]','$HTTP_POST_VARS[access_id]','$HTTP_POST_VARS[points]',
                               '$HTTP_POST_VARS[last_post]','$HTTP_POST_VARS[last_login]','$HTTP_POST_VARS[pm_email]',
                               '$HTTP_POST_VARS[pm_popup]','on','$HTTP_POST_VARS[bbcodes_show]','$HTTP_POST_VARS[html_show]',
                               '$HTTP_POST_VARS[smilies_show]','$HTTP_POST_VARS[sign_show]','$HTTP_POST_VARS[post_email]',
                               '$HTTP_POST_VARS[email_show]','$HTTP_POST_VARS[stay_login]','$HTTP_POST_VARS[pm_footer]','$HTTP_POST_VARS[style]')";
             $Fehler = "user_add";
         ### bearbeiten
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             $query = "UPDATE $GLOBALS[TB_USER]
                       SET ";
                       if ($HTTP_POST_VARS[pass_edit] == "on") {
                           $query .= "pass='$HTTP_POST_VARS[pass]',";
                       }
                       $query .= "reg='$HTTP_POST_VARS[reg]',
                           name='$HTTP_POST_VARS[name]',
                           geb='$HTTP_POST_VARS[geb]',
                           gender='$HTTP_POST_VARS[gender]',
                           job='$HTTP_POST_VARS[job]',
                           location='$HTTP_POST_VARS[location]',
                           homepage='$HTTP_POST_VARS[homepage]',
                           email='$HTTP_POST_VARS[email]',
                           icq='$HTTP_POST_VARS[icq]',
                           aim='$HTTP_POST_VARS[aim]',
                           yim='$HTTP_POST_VARS[yim]',
                           sign='$HTTP_POST_VARS[message]',
                           access_id='$HTTP_POST_VARS[access_id]',
                           points='$HTTP_POST_VARS[points]',
                           last_post='$HTTP_POST_VARS[last_post]',
                           last_login='$HTTP_POST_VARS[last_login]',
                           pm_email='$HTTP_POST_VARS[pm_email]',
                           pm_popup='$HTTP_POST_VARS[pm_popup]',
                           bbcodes_show='$HTTP_POST_VARS[bbcodes_show]',
                           html_show='$HTTP_POST_VARS[html_show]',
                           smilies_show='$HTTP_POST_VARS[smilies_show]',
                           sign_show='$HTTP_POST_VARS[sign_show]',
                           post_email='$HTTP_POST_VARS[post_email]',
                           email_show='$HTTP_POST_VARS[email_show]',
                           stay_login='$HTTP_POST_VARS[stay_login]',
                           pm_footer='$HTTP_POST_VARS[pm_footer]',
                           style='$HTTP_POST_VARS[style]'
                       WHERE id='$HTTP_POST_VARS[id]'";
             $Fehler = "user_edit";
         }

         ### Query ausf�hren
         if (mysql_query($query)) {
             $goto="$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=search";
             if ($HTTP_POST_VARS[save] == "add") {
                 $id=mysql_insert_id();
             } elseif ($HTTP_POST_VARS[save] == "edit") {
                 $id=$HTTP_POST_VARS[id];
             }
             ### Datei einlesen ### +++
             //per Upload
             if ($HTTP_POST_FILES[userfile][size] > 0) {
                 $filename = $HTTP_POST_FILES[userfile][name];
                 $filetyp = $HTTP_POST_FILES[userfile][type];
                 $Typ = GetImageSize ($HTTP_POST_FILES[userfile][tmp_name]);
                 if ($Typ[0] <= $GLOBALS[PIC_X] AND $Typ[1] <= $GLOBALS[PIC_Y] AND $Typ[2] <= "2" AND (strtolower(substr($filename, -4)) == ".gif" OR strtolower(substr($filename, -4)) == ".jpg")) {
                     $fp=fopen($HTTP_POST_FILES[userfile][tmp_name],"rb");
                     $filestuff=fread($fp,$HTTP_POST_FILES[userfile][size]);
                     fclose($fp);
                     ### alte Avatare des Users l�schen ### +++
                     mysql_query("DELETE FROM $GLOBALS[TB_AVATARS] WHERE user_id='$id'");
                     mysql_query("INSERT INTO $GLOBALS[TB_AVATARS] (user_id, data, name)
                                  VALUES ('$id','".addslashes($filestuff)."','$filename')");
                 }
             //vom Dateisystem
             } elseif ($HTTP_POST_VARS[sysfile]) {
                 $filename = basename($HTTP_POST_VARS[sysfile]);
                 $filetyp = "image/";
                 $Typ = GetImageSize ("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]");
                 if ($Typ[0] <= $GLOBALS[PIC_X] AND $Typ[1] <= $GLOBALS[PIC_Y] AND $Typ[2] <= "2") {
                     $fp=fopen("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]","rb");
                         $filesize=filesize("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]");
                         $filestuff=fread($fp,$filesize);
                     fclose($fp);
                     ### alte Avatare des Users l�schen ### +++
                     mysql_query("DELETE FROM $GLOBALS[TB_AVATARS] WHERE user_id='$id'");
                     mysql_query("INSERT INTO $GLOBALS[TB_AVATARS] (user_id, data, name)
                                  VALUES ('$id','".addslashes($filestuff)."','$filename')");
                 }
             } elseif ($HTTP_POST_VARS[pic_del] == "on") {
                 mysql_query("DELETE FROM $GLOBALS[TB_AVATARS] WHERE user_id='$id'");
             }
             ### Datei einlesen ### ---
         } else {
             $Fehler="profile_fault";
             $goto="back()";
         }
         // Nachricht
         msg($Fehler, "2", $goto);
}
function del ($id) {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS;
         ### Formular
         if (!$HTTP_GET_VARS[ok]) {
             open_table("Benutzer l�schen", "50%");
                         echo "Den Benutzer #$id wirklich l�schen ?";
                         echo " [<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id&ok=1'>ja</a> / <a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=search'>nein</a>]";
             close_table("Wenn Sie den Benutzer l�schen werden alle Daten des Benutzers gel�scht, dazu z�hlen auch alle Beitr�ge des Benutzers.");
         ### l�schen !!!
         } elseif ($HTTP_GET_VARS[ok] == "1") {

             //Benutzer l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_USER]
                           WHERE $GLOBALS[TB_USER].id='$id'");
             //Avatar l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_AVATARS]
                           WHERE $GLOBALS[TB_AVATARS].user_id='$id'");
             //Such-Ergebnisse l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_SEARCH]
                           WHERE $GLOBALS[TB_SEARCH].user_id='$id'");
             //PM�s l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_MSG]
                           WHERE $GLOBALS[TB_MSG].from_id='$id'
                              OR $GLOBALS[TB_MSG].to_id='$id'");
             //Topic_abo�s l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_ABO]
                           WHERE $GLOBALS[TB_ABO].user_id='$id'");
             //Moderator l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_MOD]
                           WHERE $GLOBALS[TB_MOD].user_id='$id'");
             #Themen l�schen
             $result_topic = mySQL_query ("SELECT $GLOBALS[TB_TOPIC].id
                                           FROM $GLOBALS[TB_TOPIC]
                                           WHERE $GLOBALS[TB_TOPIC].poster_id='$id'");
             while ($Daten_topic = mysql_fetch_array ($result_topic)) {
                    #Beitr�ge des Thema�s l�schen
                    $result_post = mySQL_query ("SELECT $GLOBALS[TB_POST].id
                                                 FROM $GLOBALS[TB_POST]
                                                 WHERE $GLOBALS[TB_POST].topic_id='$Daten_topic[id]'");
                    while ($Daten_post = mysql_fetch_array ($result_post)) {
                           //Anh�nge l�schen
                           mysql_query("DELETE FROM $GLOBALS[TB_FILES]
                                        WHERE $GLOBALS[TB_FILES].post_id='$Daten_post[id]'");
                    }
                    //Beitr�ge l�schen
                    mySQL_query ("DELETE FROM $GLOBALS[TB_POST]
                                  WHERE $GLOBALS[TB_POST].topic_id='$Daten_topic[id]'");

                    #Umfragen l�schen
                    $result_poll = mySQL_query ("SELECT $GLOBALS[TB_POLL].id
                                                 FROM $GLOBALS[TB_POLL]
                                                 WHERE $GLOBALS[TB_POLL].topic_id='$Daten_topic[id]'");
                    while ($Daten_poll = mysql_fetch_array ($result_poll)) {
                           $result_poll_text = mySQL_query ("SELECT $GLOBALS[TB_POLL_TEXT].id
                                                             FROM $GLOBALS[TB_POLL_TEXT]
                                                             WHERE $GLOBALS[TB_POLL_TEXT].poll_id='$Daten_poll[id]'");
                           while ($Daten_poll_text = mysql_fetch_array ($result_poll_text)) {
                                  //Umfragen-Benutzer l�schen
                                  mysql_query("DELETE FROM $GLOBALS[TB_POLL_USER]
                                               WHERE $GLOBALS[TB_POLL_USER].text_id='$Daten_poll_text[id]'");
                           }
                           //Umfragen-Texte l�schen
                           mysql_query("DELETE FROM $GLOBALS[TB_POLL_TEXT]
                                        WHERE $GLOBALS[TB_POLL_TEXT].poll_id='$Daten_poll[id]'");
                    }
                    //Umfragen l�schen
                    mySQL_query ("DELETE FROM $GLOBALS[TB_POLL]
                                  WHERE $GLOBALS[TB_POLL].topic_id='$Daten_topic[id]'");
             }
             //Themen l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_TOPIC]
                           WHERE $TB_TOPIC.poster_id='$id'");
             //Beitr�ge l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_POST]
                           WHERE $GLOBALS[TB_POST].user_id='$id'");

             msg("user_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=search");
         }
}
function mailall() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS, $HTTP_GET_VARS, $_style;
         echo "<script language=\"JavaScript\">
                       function AddText(text) {
                                mailform.message.value += \" \"+text;
                                mailform.message.focus();
                       }
               </script>";
         if (!$HTTP_GET_VARS[ok]) {
             ?>
             <form name='mailform' method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=mail&ok=1"; ?>'>
                   <?php table_header("eMail an phpForum Benutzer senden...", "100%", "", "colspan='2'");
                   table_header("Nachricht:", "100%", "1", "colspan='2'", "nohead"); ?>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>Wirklich senden:</b>
                                 <br>
                                 <span class='font_small'>
                                       W�hlen sie hier ja zum senden oder nein um sich eine Liste der Empf�nger anzeigen zu lassen.
                                 </span>
                             <td width='60%' class='cat_one'>
                                 <input type='radio' name='send' value ='on'>&nbsp;ja&nbsp;
                                 <input type='radio' name='send' value ='' checked>&nbsp;nein
                             </td>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>Betreff:</b>
                             <td width='60%' class='cat_one'>
                                 <input type='text' name='subject' size='60' maxlength='255' tabindex='1'>
                             </td>
                         <tr>
                             <td width='40%' valign='top' class='cat_two'>
                                 <b>Nachricht:</b>
                                 <br><br>
                                 <span class='font_small'>
                                       In der Nachricht k&ouml;nnen sie <a href="javascript:AddText('*name*')"><b>*name*</b></a> , <a href="javascript:AddText('*id*')"><b>*id*</b></a> , <a href="javascript:AddText('*email*')"><b>*email*</b></a> , <a href="javascript:AddText('*forum_url*')"><b>*forum_url*</b></a> und <a href="javascript:AddText('*admin_email*')"><b>*admin_email*</b></a> benutzen um z.B. die Benutzer mit ihren Namen an zu sprechen.
                                 </span>
                             <td width='60%' class='cat_one'>
                                 <textarea name='message' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' WRAP='soft' tabindex='2'><?php echo htmlentities($HTTP_POST_VARS[message]); ?></textarea>
                             </td>
                         </tr>
                   <?php table_header("Empf�nger:", "100%", "1", "colspan='2'", "nohead"); ?>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>Benutzergruppe:</b>
                             <td width='60%' class='cat_one'>
                                 <select name='access_id' tabindex='3'>
                                         <option value='*'>### Alle Benutzergruppen ###</option>
                                         <?php
                                         $result = mySQL_query ("SELECT *
                                                                 FROM $GLOBALS[TB_ACCESS]
                                                                 ORDER BY name ASC");
                                         while($Daten = mysql_fetch_array ($result)) {
                                               echo "<option value='$Daten[id]'>$Daten[name]</option>";
                                         }
                                         ?>
                                 </select>
                             </td>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>Benutzername enth�lt:</b>
                             <td width='60%' class='cat_one'>
                                 <input type='text' name='name' size='30' maxlength='255' tabindex='4'>
                             </td>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>eMail-Adresse enth�lt:</b>
                             <td width='60%' class='cat_one'>
                                 <input type='text' name='email' size='30' maxlength='255' tabindex='5'>
                             </td>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>Signatur enth�lt:</b>
                             <td width='60%' class='cat_one'>
                                 <input type='text' name='sign' size='30' maxlength='255' tabindex='6'>
                             </td>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>letzer Besuch vor:</b>
                                 <br>
                                 <span class='font_small'>
                                       Format: jjjj-mm-tt hh:mm:ss (0 f�r heute)
                                 </span>
                             <td width='60%' class='cat_one'>
                                 <input type='text' name='last_login_less' size='30' maxlength='19' tabindex='7'>
                             </td>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>letzer Besuch nach:</b>
                                 <br>
                                 <span class='font_small'>
                                       Format: jjjj-mm-tt hh:mm:ss
                                 </span>
                             <td width='60%' class='cat_one'>
                                 <input type='text' name='last_login_more' size='30' maxlength='19' tabindex='8'>
                             </td>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>Anzahl der Beitr�ge gr��er als:</b>
                             <td width='60%' class='cat_one'>
                                 <input type='text' name='points_more' size='30' maxlength='255' tabindex='9'>
                             </td>
                         <tr>
                             <td width='40%' class='cat_two'>
                                 <b>Anzahl der Beitr�ge kleiner als:</b>
                             <td width='60%' class='cat_one'>
                                 <input type='text' name='points_less' size='30' maxlength='255' tabindex='10'>
                             </td>
                         </tr>
                   </table>
                   <p></p>
                   <center>
                           <input type='submit' value='Absenden' tabindex='11'>
                           <input type='reset' name='Reset' value='Zur&uuml;cksetzen' tabindex='12'>
                   </center>
             </form>
             <?php
         } elseif ($HTTP_GET_VARS[ok]) {

             //nicht alle Felder ausgef�llt
             if(!$HTTP_POST_VARS[subject] OR !$HTTP_POST_VARS[message]) {
                msg("eingabe_fault", "2", "back()");
             }

             ### SQL-Statement "basteln" ###
             $query = "SELECT $GLOBALS[TB_USER].*
                       FROM $GLOBALS[TB_USER]
                       WHERE ";
             //Benutzergruppe
             if ($HTTP_POST_VARS[access_id] != "*") {
                 $query .= "$GLOBALS[TB_USER].access_id='$HTTP_POST_VARS[access_id]' AND ";
             } else {
                 $query .= "$GLOBALS[TB_USER].access_id <> '' AND ";
             }
             //Benutzername enth�lt
             if ($HTTP_POST_VARS[name]) {
                 $query .= "$GLOBALS[TB_USER].name LIKE '%$HTTP_POST_VARS[name]%' AND ";
             }
             //eMail enth�lt
             if ($HTTP_POST_VARS[email]) {
                 $query .= "$GLOBALS[TB_USER].email LIKE '%$HTTP_POST_VARS[email]%' AND ";
             }
             //Signatur enth�lt
             if ($HTTP_POST_VARS[sign]) {
                 $query .= "$GLOBALS[TB_USER].sign LIKE '%$HTTP_POST_VARS[sign]%' AND ";
             }
             //letzer Besuch vor
             if ($HTTP_POST_VARS[last_login_less]) {
                 if ($HTTP_POST_VARS[last_login_less] == "0") {
                     $query .= "TO_DAYS($GLOBALS[TB_USER].last_login) < TO_DAYS(NOW()) AND ";
                 } else {
                     $query .= "TO_DAYS($GLOBALS[TB_USER].last_login) < TO_DAYS('$HTTP_POST_VARS[last_login_less]') AND ";
                 }
             }
             //letzer Besuch nach
             if ($HTTP_POST_VARS[last_login_more]) {
                 if ($HTTP_POST_VARS[last_login_more] == "0") {
                     $query .= "TO_DAYS($GLOBALS[TB_USER].last_login) > TO_DAYS(NOW()) AND ";
                 } else {
                     $query .= "TO_DAYS($GLOBALS[TB_USER].last_login) > TO_DAYS('$HTTP_POST_VARS[last_login_more]') AND ";
                 }
             }
             //Anzahl der Beitr�ge gr��er als
             if ($HTTP_POST_VARS[points_more]) {
                 $query .= "$GLOBALS[TB_USER].points > '$HTTP_POST_VARS[points_more]' AND ";
             }
             //Anzahl der Beitr�ge kleiner als
             if ($HTTP_POST_VARS[points_less]) {
                 $query .= "$GLOBALS[TB_USER].points < '$HTTP_POST_VARS[points_less]' AND ";
             }
             //und nicht !!! an die ohne eMail - Addy
             $query .= "$GLOBALS[TB_USER].email <> ''";


             ### eMail�s verschicken ###
             echo "<p>&nbsp;</p>";
             open_table("eMail an phpForum Benutzer senden... ", "50%");
                  $result = mysql_query($query);
                  $send_anz = mysql_num_rows($result);

                  ### anzahl zu sendender eMail�s
                  echo "Diese eMail ";
                  if ($HTTP_POST_VARS[send] == "on") {
                      echo "wurde";
                  } else {
                      echo "w&uuml;rde";
                      $extra = " werden";
                  }
                  echo " an <b>".$send_anz."</b> Benutzer gesendet$extra.";
                  echo "<ul>";
                  $faults = 0;
                  while ($Daten = mysql_fetch_array($result)) {

                         ### Besondere Zeichen ersetzen ### +++
                         $message = stripslashes($HTTP_POST_VARS[message]);
                         // \*id\*
                         $message = eregi_replace("\*id\*", $Daten[id], $message);
                         // \*name\*
                         $message = eregi_replace("\*name\*", $Daten[name], $message);
                         // \*email\*
                         $message = eregi_replace("\*email\*", $Daten[email], $message);
                         // \*forum_url\*
                         $message = eregi_replace("\*forum_url\*", "http://".$GLOBALS[SITE], $message);
                         // \*admin_email\*
                         $message = eregi_replace("\*admin_email\*", $GLOBALS[SITE_ADMIN], $message);
                         ### Besondere Zeichen ersetzen ### ---
                         #
                         ### wirklich senden ? ### +++
                         if ($HTTP_POST_VARS[send] == "on") {
                             if (!@mail($Daten[email], $HTTP_POST_VARS[subject], $message, "From: $GLOBALS[TITEL_KURZ] <$GLOBALS[SITE_ADMIN]>\nReturn-Path: <$GLOBALS[SITE_ADMIN]>")) {
                                 echo "<li><span class='font_fault'>$Daten[name] ($Daten[email])</span>";
                                 $faults++;
                             }
                         } else {
                             echo "<li>$Daten[name] ($Daten[email])";
                         }
                         ### wirklich senden ? ### +++
                  }
                  echo "</ul>";
                  ### nicht gesendet
                  echo "<span class='font_fault'><b>".$faults."</b>";
                  if ($HTTP_POST_VARS[send] == "on") {
                      echo " konnten";
                  } else {
                      echo " k&ouml;nnten";
                  }
                  echo " davon nicht gesendet werden.</span>";
             close_table();
             if (!$HTTP_POST_VARS[send]) {
                 ?>
                 <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=mail&ok=1"; ?>'>
                   <input type='hidden' name='send' value='on'>
                   <input type='hidden' name='subject' value='<?php echo htmlentities($HTTP_POST_VARS[subject]); ?>'>
                   <input type='hidden' name='message' value='<?php echo stripslashes(htmlentities($HTTP_POST_VARS[message])); ?>'>
                   <input type='hidden' name='access_id' value='<?php echo $HTTP_POST_VARS[access_id]; ?>'>
                   <input type='hidden' name='name' value='<?php echo $HTTP_POST_VARS[name]; ?>'>
                   <input type='hidden' name='email' value='<?php echo $HTTP_POST_VARS[email]; ?>'>
                   <input type='hidden' name='sign' value='<?php echo $HTTP_POST_VARS[sign]; ?>'>
                   <input type='hidden' name='last_login_less' value='<?php echo $HTTP_POST_VARS[last_login_less]; ?>'>
                   <input type='hidden' name='last_login_more' value='<?php echo $HTTP_POST_VARS[last_login_more]; ?>'>
                   <input type='hidden' name='points_less' value='<?php echo $HTTP_POST_VARS[points_less]; ?>'>
                   <input type='hidden' name='points_more' value='<?php echo $HTTP_POST_VARS[points_more]; ?>'>
                   <center>
                           <input type='submit' value='jetzt senden'>
                   </center>
                 </form>
                 <?php
             }
}
####################################### Nachricht senden ################################ ---
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>