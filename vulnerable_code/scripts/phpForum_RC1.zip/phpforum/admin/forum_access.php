<?php
include("head.php");
auth("admin_forums");
?>
<h3 class='font_big'>Foren Zugriffsberechtigung...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "liste":
              liste();
              break;

        case "edit":
              edit($HTTP_GET_VARS[forum_id], $HTTP_GET_VARS[access_id]);
              break;

        case "save":
              save();
              break;

        case "default":
              set_default($HTTP_GET_VARS[forum_id], $HTTP_GET_VARS[access_id]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function edit($forum_id, $access_id) {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <input type='hidden' name='forum_id' VALUE='<?php echo $forum_id; ?>'>
               <input type='hidden' name='access_id' VALUE='<?php echo $access_id; ?>'>
               <?php
               $Daten = mysql_fetch_array(mysql_query("SELECT $GLOBALS[TB_FORUM_ACCESS].*,
                                                              $GLOBALS[TB_FORUM].name AS forum_name,
                                                              $GLOBALS[TB_ACCESS].name AS access_name
                                                       FROM $GLOBALS[TB_FORUM_ACCESS], $GLOBALS[TB_ACCESS], $GLOBALS[TB_FORUM]
                                                       WHERE $GLOBALS[TB_FORUM_ACCESS].forum_id='$forum_id'
                                                         AND $GLOBALS[TB_FORUM_ACCESS].access_id='$access_id'
                                                         AND $GLOBALS[TB_ACCESS].id=$GLOBALS[TB_FORUM_ACCESS].access_id
                                                         AND $GLOBALS[TB_FORUM].id=$GLOBALS[TB_FORUM_ACCESS].forum_id"));
               table_header("Zugriffsberechtigung der Gruppe \"$Daten[access_name]\" im Forum \"$Daten[forum_name]\" bearbeiten...", "100%", "", "colspan='2'");
                            table_header("Themen / Beitr�ge", "100%", "1", "colspan='2'", "nohead"); ?>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf Themen / Beitr�ge ansehen?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[view] == "on") {
                                              echo "<input type='radio' name='view' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='view' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='view' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='view' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf neue Beitr�ge erstellen?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[new_post] == "on") {
                                              echo "<input type='radio' name='new_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='new_post' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='new_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='new_post' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf neue Themen erstellen?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[new_topic] == "on") {
                                              echo "<input type='radio' name='new_topic' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='new_topic' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='new_topic' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='new_topic' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf eigene Beitr�ge bearbeiten?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[edit_post] == "on") {
                                              echo "<input type='radio' name='edit_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='edit_post' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='edit_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='edit_post' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf eigene Themen / Beitr�ge l�schen?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[del_post] == "on") {
                                              echo "<input type='radio' name='del_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='del_post' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='del_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='del_post' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  </tr>
                            <?php table_header("Moderation", "100%", "1", "colspan='2'", "nohead"); ?>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf Themen �ffnen / schlie�en?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[mod_openclose] == "on") {
                                              echo "<input type='radio' name='mod_openclose' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_openclose' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='mod_openclose' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_openclose' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf Themen festhalten / l&ouml;sen?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[mod_top] == "on") {
                                              echo "<input type='radio' name='mod_top' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_top' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='mod_top' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_top' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf Themen verschieben?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[mod_move_topic] == "on") {
                                              echo "<input type='radio' name='mod_move_topic' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_move_topic' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='mod_move_topic' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_move_topic' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf Beitr&auml;ge verschieben?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[mod_move_post] == "on") {
                                              echo "<input type='radio' name='mod_move_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_move_post' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='mod_move_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_move_post' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf andere Themen / Beitr�ge bearbeiten?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[mod_edit] == "on") {
                                              echo "<input type='radio' name='mod_edit' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_edit' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='mod_edit' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_edit' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf andere Themen / Beitr�ge l�schen?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[mod_del] == "on") {
                                              echo "<input type='radio' name='mod_del' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_del' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='mod_del' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_del' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  <tr>
                                      <td width='50%' class='cat_two'>
                                          <b>darf Themen zusammenf�hren?:</b>
                                      <td width='50%' class='cat_one'>
                                          <?php
                                          if ($Daten[mod_join] == "on") {
                                              echo "<input type='radio' name='mod_join' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_join' value=''>&nbsp;nein";
                                          } else {
                                              echo "<input type='radio' name='mod_join' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                              echo "<input type='radio' name='mod_join' value='' checked>&nbsp;nein";
                                          }
                                          ?>
                                      </td>
                                  </tr>
                            </table>
                            <p></p>
                            <center>
                                    <input type='submit' value='bearbeiten'>
                                    <input type='reset' name='Reset' value='Zur�cksetzen'>
                            </center>
         </form>
         <?php
}
function liste() {
         global $HTTP_SERVER_VARS;
         table_header("Forenberechtigungen bearbeiten...", "100%", "", "colspan='2'"); ?>
                  <tr class='cat_tr'>
                      <td width='30%' class='cat_one' colspan='2'>
                          <?php
                          $result = mysql_query("SELECT *
                                                 FROM $GLOBALS[TB_FORUM]
                                                 ORDER BY $GLOBALS[TB_FORUM].name ASC");
                          while ($Daten=mysql_fetch_array($result)) {
                                 echo "<b>-</b>&nbsp;<a href='#$Daten[id]'>$Daten[name]</a><br>";
                          }
                          ?>
                      </td>
                  </tr>
                  <?php
         $result = mysql_query("SELECT *
                                FROM $GLOBALS[TB_FORUM]
                                ORDER BY $GLOBALS[TB_FORUM].name ASC");
         while ($Daten=mysql_fetch_array($result)) {

                table_header("<a name='$Daten[id]'>$Daten[name]:", "100%", "1", "colspan='2'", "nohead"); ?>
                         <?php
                         $result_settings = mysql_query ("SELECT $GLOBALS[TB_FORUM_ACCESS].access_id, $GLOBALS[TB_ACCESS].name
                                                          FROM $GLOBALS[TB_FORUM_ACCESS], $GLOBALS[TB_ACCESS]
                                                          WHERE $GLOBALS[TB_FORUM_ACCESS].forum_id=$Daten[id]
                                                            AND $GLOBALS[TB_FORUM_ACCESS].access_id=$GLOBALS[TB_ACCESS].id
                                                          ORDER BY $GLOBALS[TB_ACCESS].name");
                         while ($Daten_settings = mysql_fetch_array($result_settings)) {
                                ?>
                                <tr>
                                    <td width='50%' class='cat_two'>
                                        <b><?php echo $Daten_settings[name]; ?>:</b>
                                    <td width='50%' class='cat_one'>
                                        <?php
                                        echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&forum_id=$Daten[id]&access_id=$Daten_settings[access_id]'>[bearbeiten]</a>&nbsp;";
                                        if (!is_standard($Daten[id], $Daten_settings[access_id])) {
                                            echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=default&forum_id=$Daten[id]&access_id=$Daten_settings[access_id]' title='Standard - Einstellungen der \"$Daten_settings[name]\" - Benutzergruppe �bernehmen'>[Standard]</a>";
                                        } else {
                                            echo "[Standard]";
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                         } //Benutzergruppen
         } //Foren
         echo "</table>";
}
function save() {
         global $HTTP_SERVER_VARS, $HTTP_POST_VARS;

         $result = mysql_query ("SELECT *
                                 FROM $GLOBALS[TB_FORUM_ACCESS]");
         $num = mysql_num_fields($result) - 1;
         for ($n=2; $n <= $num; $n++) {
              $name = mysql_field_name($result, $n);
              $value .= "$GLOBALS[TB_FORUM_ACCESS].$name='$HTTP_POST_VARS[$name]', ";
         }
         $values = eregi_replace(", $", "", $value);

         $query = "UPDATE $GLOBALS[TB_FORUM_ACCESS] SET $values WHERE $GLOBALS[TB_FORUM_ACCESS].forum_id='$HTTP_POST_VARS[forum_id]' AND $GLOBALS[TB_FORUM_ACCESS].access_id='$HTTP_POST_VARS[access_id]'";

         if (mysql_query($query)) {
             $Fehler = "forum_access_edit";
             $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
         } else {
             $Fehler = "forum_access_edit_fault";
             $goto = "back()";
         }
         msg($Fehler, "2", $goto);
}
function set_default($forum_id, $access_id) {
         global $HTTP_SERVER_VARS;
         $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                 FROM $GLOBALS[TB_ACCESS]
                                                 WHERE $GLOBALS[TB_ACCESS].id='$access_id'"));
         $query = "UPDATE $GLOBALS[TB_FORUM_ACCESS]
                   SET $GLOBALS[TB_FORUM_ACCESS].view = '$Daten[view]',
                       $GLOBALS[TB_FORUM_ACCESS].del_post = '$Daten[del_post]',
                       $GLOBALS[TB_FORUM_ACCESS].edit_post = '$Daten[edit_post]',
                       $GLOBALS[TB_FORUM_ACCESS].new_post = '$Daten[new_post]',
                       $GLOBALS[TB_FORUM_ACCESS].new_topic = '$Daten[new_topic]',
                       $GLOBALS[TB_FORUM_ACCESS].mod_openclose = '$Daten[mod_openclose]',
                       $GLOBALS[TB_FORUM_ACCESS].mod_move_topic = '$Daten[mod_move_topic]',
                       $GLOBALS[TB_FORUM_ACCESS].mod_edit = '$Daten[mod_edit]',
                       $GLOBALS[TB_FORUM_ACCESS].mod_del = '$Daten[mod_del]',
                       $GLOBALS[TB_FORUM_ACCESS].mod_join = '$Daten[mod_join]',
                       $GLOBALS[TB_FORUM_ACCESS].mod_move_post = '$Daten[mod_move_post]',
                       $GLOBALS[TB_FORUM_ACCESS].mod_top = '$Daten[mod_top]'
                   WHERE $GLOBALS[TB_FORUM_ACCESS].forum_id='$forum_id'
                     AND $GLOBALS[TB_FORUM_ACCESS].access_id='$access_id'";
         mysql_query($query);
         msg("forum_access_default", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
function is_standard($forum_id, $access_id) {
         $result = mysql_query ("SELECT $GLOBALS[TB_ACCESS].id, $GLOBALS[TB_FORUM_ACCESS].forum_id
                                 FROM $GLOBALS[TB_FORUM_ACCESS], $GLOBALS[TB_ACCESS]
                                 WHERE $GLOBALS[TB_FORUM_ACCESS].view = $GLOBALS[TB_ACCESS].view
                                   AND $GLOBALS[TB_FORUM_ACCESS].del_post = $GLOBALS[TB_ACCESS].del_post
                                   AND $GLOBALS[TB_FORUM_ACCESS].edit_post = $GLOBALS[TB_ACCESS].edit_post
                                   AND $GLOBALS[TB_FORUM_ACCESS].new_post = $GLOBALS[TB_ACCESS].new_post
                                   AND $GLOBALS[TB_FORUM_ACCESS].new_topic = $GLOBALS[TB_ACCESS].new_topic
                                   AND $GLOBALS[TB_FORUM_ACCESS].mod_openclose = $GLOBALS[TB_ACCESS].mod_openclose
                                   AND $GLOBALS[TB_FORUM_ACCESS].mod_move_topic = $GLOBALS[TB_ACCESS].mod_move_topic
                                   AND $GLOBALS[TB_FORUM_ACCESS].mod_edit = $GLOBALS[TB_ACCESS].mod_edit
                                   AND $GLOBALS[TB_FORUM_ACCESS].mod_del = $GLOBALS[TB_ACCESS].mod_del
                                   AND $GLOBALS[TB_FORUM_ACCESS].mod_join = $GLOBALS[TB_ACCESS].mod_join
                                   AND $GLOBALS[TB_FORUM_ACCESS].mod_move_post = $GLOBALS[TB_ACCESS].mod_move_post
                                   AND $GLOBALS[TB_FORUM_ACCESS].mod_top = $GLOBALS[TB_ACCESS].mod_top
                                   AND $GLOBALS[TB_FORUM_ACCESS].forum_id='$forum_id'
                                   AND $GLOBALS[TB_FORUM_ACCESS].access_id='$access_id'
                                   AND $GLOBALS[TB_ACCESS].id=$GLOBALS[TB_FORUM_ACCESS].access_id");
         if (mysql_num_rows($result) == "1") {
             return TRUE;
         } else {
             return FALSE;
         }
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>