<?php
include("head.php");
auth("admin_bbcodes");
?>
<h3 class='font_big'>Board Codes...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "add":
              addedit();
              break;

        case "liste":
              liste();
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id]);
              break;

        case "save":
              save();
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;

        case "test":
              bb_test();
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($id="") {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <input type='hidden' name='id' VALUE='<?php echo $id; ?>'>
               <input type='hidden' name='save' VALUE='<?php
               if ($id == "") {
                   echo "add'>";
                   $typ = "hinzuf�gen";
               } else {
                   echo "edit'>";
                   $typ = "bearbeiten";
                   $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                           FROM $GLOBALS[TB_BBCODES]
                                                           WHERE $GLOBALS[TB_BBCODES].id='$id'"));
               }
               table_header("Board Code $typ...", "100%", "", "colspan='2'"); ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Name:</b>
                             <br>
                             <span class='font_small'>
                                   eine kurze Beschreibung...
                             </span>
                         <td width='50%' class='cat_one'>
                             <INPUT TYPE='text' name='name' SIZE='45' MAXLENGTH='255' value="<?php echo htmlentities($Daten[name]); ?>">
                         </td>
                     <tr>
                         <td width='50%' valign='top' class='cat_two'>
                             <b>Info:</b>
                             <br>
                             <span class='font_small'>
                                   eine Ausf�hrliche Beschreibung
                             </span>
                         <td width='50%' class='cat_one'>
                             <TEXTAREA NAME='info' COLS='35' ROWS='5'><?php echo htmlentities($Daten[info]); ?></TEXTAREA>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Board Code Beispiel:</b>
                             <br>
                             <span class='font_small'>
                                   z.B.: [b]fett[/b]
                             </span>
                         <td width='50%' class='cat_one'>
                             <INPUT TYPE='text' name='example' SIZE='45' MAXLENGTH='255' value="<?php echo htmlentities($Daten[example]); ?>">
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Code Tag:</b>
                             <br>
                             <span class='font_small'>
                                   siehe Beschreibung unten.
                             </span>
                         <td width='50%' class='cat_one'>
                             <INPUT TYPE='text' name='search' SIZE='45' MAXLENGTH='255' value="<?php echo htmlentities($Daten[search]); ?>">
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>HTML-Code der diesen ersetzt:</b>
                             <br>
                             <span class='font_small'>
                                   siehe Beschreibung unten.
                             </span>
                         <td width='50%' class='cat_one'>
                             <INPUT TYPE='text' name='replacement' SIZE='45' MAXLENGTH='255' value="<?php echo htmlentities($Daten[replacement]); ?>">
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Wiederholungen:</b>
                             <br>
                             <span class='font_small'>
                                   siehe Beschreibung unten.
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='radio' name='repeat' value='on'<?php if ($Daten[repeat] == "on") { echo " checked"; } ?>>&nbsp;ja&nbsp;&nbsp;
                             <input type='radio' name='repeat' value=''<?php if ($Daten[repeat] != "on") { echo "checked"; } ?>>&nbsp;nein&nbsp;&nbsp;
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>HTML-Code f�r diese Wiederholungen:</b>
                             <br>
                             <span class='font_small'>
                                   siehe Beschreibung unten.
                             </span>
                         <td width='50%' class='cat_one'>
                             <INPUT TYPE='text' name='repeat_replace' SIZE='45' MAXLENGTH='255' value="<?php echo htmlentities($Daten[repeat_replace]); ?>">
                         </td>
                     </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='<?php echo $typ; ?>'>
                       <input type='reset' name='Reset' value='Zur�cksetzen'>
               </center>
         </form>

         <h3 class='font_big'>Erkl�rungen:</h3>
             <fieldset>
                       <legend>Code Tag</legend>
                               <p class='font_normal'>
                                  Dies ist der vollst�ndige Text f�r den Board Code. z.B.: [b]\1[/b]<br>
                                  <b>Parameter:</b> ein Backshlash "\" mit einer Zahl dahinter "\1" bedeutet das dies die erste stelle ist wo der Benutzer etwas eingeben muss. (von 1 bis ...)
                               </p>
             </fieldset>
             <br>
             <fieldset>
                       <legend>HTML-Code der diesen ersetzt</legend>
                               <p class='font_normal'>
                                  Dies ist der vollst�ndige Text f�r den HTML Code der den Board Code ersetzt. z.B.: &lt;b&gt;\1&lt;/b&gt;<br>
                                  <b>Parameter:</b> die vorher in den Code Tag definierten Parameter m�ssen nun an die richtige stelle in den HTML-Code eingesetzt werden.
                               </p>
             </fieldset>
             <br>
             <fieldset>
                       <legend>Wiederholungen</legend>
                               <p class='font_normal'>
                                  Wenn sie hier ja w&auml;hlen, kann dieser Board Code mehrere Wiederholungen in einem Code Tag haben. z.B.: eine Liste &lt;ol&gt;<b>&lt;li&gt;eins&lt;li&gt;zwei</b>&lt;/ol&gt;
                               </p>
             </fieldset>
             <br>
             <fieldset>
                       <legend>HTML-Code f�r diese Wiederholungen</legend>
                               <p class='font_normal'>
                                  Dies ist der HTML Code der im Code Tag den Board Code ersetzt. z.B.: &lt;b&gt;\1&lt;/b&gt;<br>
                                  <b>Parameter:</b> die vorher in den Code Tag definierten Parameter m�ssen nun an die richtige stelle in den HTML-Code eingesetzt werden.
                               </p>
             </fieldset>
         <?php
}
function liste() {
         global $HTTP_SERVER_VARS;
         $result = mysql_query("SELECT *
                                FROM $GLOBALS[TB_BBCODES]
                                ORDER BY $GLOBALS[TB_BBCODES].name ASC");
         table_header("Board Codes bearbeiten:", "100%", "", "colspan='2'"); ?>
                      <tr class='default_tr'>
                          <td width='70%'>
                              <B>Board Code</B>
                          <td width='30%' align='center'>
                              <b>optionen</b>
                          </td>
                      </tr>
                      <?php
                      while ($Daten=mysql_fetch_array($result)) {
                             ?>
                             <tr>
                                 <td class='cat_two'>
                                     <?php echo "<b>$Daten[name]:</b>"; ?>
                                     <br>
                                     <span class='font_small'>
                                           <b>z.B.:</b>&nbsp;&nbsp;<?php echo $Daten[example]; ?>
                                     </span>
                                 <td width='30%' align='center' class='cat_one'>
                                     <?php
                                     echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]'>[bearbeiten]</a>&nbsp;";
                                     echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]'>[l�schen]</a>";
                                     ?>
                                 </td>
                             </tr>
                             <?php
                      }
                      ?>
         </table>
         <?php
}
function save() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         //hinzuf�gen
         if ($HTTP_POST_VARS[save] == "add") {
             $query = "INSERT INTO $GLOBALS[TB_BBCODES] (name, info, search, replacement, example, repeat, repeat_replace)
                       VALUES ('$HTTP_POST_VARS[name]','$HTTP_POST_VARS[info]','$HTTP_POST_VARS[search]','$HTTP_POST_VARS[replacement]',
                               '$HTTP_POST_VARS[example]','$HTTP_POST_VARS[repeat]','$HTTP_POST_VARS[repeat_replace]')";
             $Fehler = "bbcodes_add";
         //bearbeiten
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             $query = "UPDATE $GLOBALS[TB_BBCODES]
                       SET name='$HTTP_POST_VARS[name]', info='$HTTP_POST_VARS[info]', search='$HTTP_POST_VARS[search]',
                           replacement='$HTTP_POST_VARS[replacement]', example='$HTTP_POST_VARS[example]',
                           repeat='$HTTP_POST_VARS[repeat]', repeat_replace='$HTTP_POST_VARS[repeat_replace]'
                       WHERE $GLOBALS[TB_BBCODES].id='$HTTP_POST_VARS[id]'";
             $Fehler = "bbcodes_edit";
         }

         if (mysql_query($query)) {
                 $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
             } else {
                 $goto = "back()";
             }
         msg($Fehler, "2", $goto);
}
function del ($id) {
         global $HTTP_GET_VARS, $HTTP_SERVER_VARS;
         if ($HTTP_GET_VARS[ok] != "1") {
             open_table("Board Code l�schen", "50%");
                         echo "Den Board Code #$id wirklich l�schen ?";
                         echo " [<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id&ok=1'>ja</a> / <a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste'>nein</a>]";
             close_table("");
         } elseif ($HTTP_GET_VARS[ok] == "1") {
             //l�schen !!!
             mySQL_query ("DELETE FROM $GLOBALS[TB_BBCODES]
                           WHERE $GLOBALS[TB_BBCODES].id='$id'");
             msg("bbcodes_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
         }
}
function bb_test() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS, $_style;

         //slashes entfernen
         $message = stripslashes($HTTP_POST_VARS[message]);
         ?>
         <form name='bbform' METHOD='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=test"; ?>'>
               <?php table_header("Board Codes testen:", "100%", "", "colspan='2'"); ?>
                        <tr>
                            <td width='30%' valign='top' class='cat_two'>
                                <b>Test-Feld:</b>
                                <br>
                                <span class='font_small'>
                                      Hier k&ouml;nnen sie alle <a href="javascript:BBCode()">Board Codes</a> und <a href=javascript:Smilies()>Smilies</a> auf ihre Funktionsweise testen.
                                </span>
                            <td width='70%' class='cat_one'>
                                <textarea name='message' cols='<?php echo $_style[textarea_width]; ?>' rows='<?php echo $_style[textarea_height]; ?>' WRAP='soft'><?php echo $message; ?></textarea>
                            </td>
                        <tr>
                            <td width='30%' valign='top' class='cat_two'>
                                <b>Optionen:</b>
                            <td width='70%' class='cat_one'>
                                <input type="checkbox" name="bbcodes" value='on'<?php if ($HTTP_POST_VARS[bbcodes] == "on") { echo " CHECKED"; } ?>>
                                <span class='font_small'>
                                      <b>Board-Codes aktivieren ?</b>
                                </span>
                                <br>
                                <input type="checkbox" name="html" value='on'<?php if ($HTTP_POST_VARS[html] == "on") { echo " CHECKED"; } ?>>
                                <span class='font_small'>
                                      <b>HTML-Code aktivieren ?</b>
                                </span>
                                <br>
                                <input type="checkbox" name="smilies" value='on'<?php if ($HTTP_POST_VARS[smilies] == "on") { echo " CHECKED"; } ?>>
                                <span class='font_small'>
                                      <b>Grafische Smilies aktivieren ?</b>
                                </span>
                            </td>
                        <tr>
                            <td width='30%' valign='top' class='cat_two'>
                                <b>Ausgabe:</b>
                            <td width='70%' valign='top' class='cat_one'>
                                <?php
                                echo bbcode($message, $HTTP_POST_VARS[bbcodes], $HTTP_POST_VARS[html], $HTTP_POST_VARS[smilies], "", "on");
                                ?>
                            </td>
                        </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='Code testen'>
                       <input type='reset' name='Reset' value='Zur�cksetzen'>
               </center>
         </form>
         <?php
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>