<?php
include("head.php");
auth("admin_smilies");
?>
<h3 class='font_big'>Smilies...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "add":
              addedit();
              break;

        case "liste":
              liste();
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id]);
              break;

        case "save":
              save();
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($id="") {
         global $HTTP_SERVER_VARS;
         ?>
         <form method='post'<?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { echo "enctype='multipart/form-data'"; } ?> action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <input type='hidden' name='id' VALUE='<?php echo $id; ?>'>
               <input type='hidden' name='save' VALUE='<?php
                      if ($id == "") {
                          echo "add'>";
                          $typ = "hinzuf�gen";
                      } else {
                          echo "edit'>";
                          $typ = "bearbeiten";
                          $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                                  FROM $GLOBALS[TB_SMILIES]
                                                                  WHERE $GLOBALS[TB_SMILIES].id='$id'"));
                      }
               table_header("Smilie $typ", "100%", "", "colspan='2'"); ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Name:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             echo "<input type='text' name='name' value=\"$Daten[name]\" maxlenght='255' size='30'>";
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>aktuelles Smilie:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             if ($Daten[data]) {
                                 echo "<img src='../functions.php?action=smilie&id=$Daten[id]' border='0'>";
                             }
                             ?>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Code der ersetzt wird:</b>
                         <td width='50%' class='cat_one'>
                             <?php
                             echo "<input type='text' name='code' value=\"$Daten[code]\" maxlenght='255' size='30'>";
                             ?>
                         </td>
                     <?php if ($GLOBALS[ALLOW_FILE_UPLOADS] == "on") { ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>lokale Datei:</b><br>
                             <span class='font_small'>
                                   Hier k&ouml;nnen sie ein Bild ausw&auml;hlen welches den Code ersetzen soll,<br>
                                   dieses k&ouml;nnen sie von ihrer Festplatte ausw&auml;hlen.
                             </span>
                         <td width='50%' class='cat_one'>
                             <input type='file' name='userfile'>
                         </td>
                     <?php } ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Datei auf dem Server:</b><br>
                             <span class='font_small'>
                                   Diese Dateien liegen im phpForum Verzeichnis <b>upload</b>,<br>
                                   sie k&ouml;nnen weitere mit einem FTP-Programm hochladen.
                             </span>
                         <td width='50%' class='cat_one'>
                             <?php upload_liste("upload"); ?>
                         </td>
                     </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='<?php echo $typ; ?>'>
                       <input type='reset' name='Reset' value='Zur�cksetzen'>
               </center>
         </form>
         <?php
}
function liste() {
         global $HTTP_SERVER_VARS;

         $result = mysql_query("SELECT *
                                FROM $GLOBALS[TB_SMILIES]
                                ORDER BY $GLOBALS[TB_SMILIES].name ASC");
         $anz=mysql_num_rows($result);
         $n=0;
         $i=0;
         $width = 100 / $GLOBALS[ADMIN_SMILIES_ANZ];

         table_header("Smilies bearbeiten", "100%");
               ?>
               <tr class='cat_one'>
                   <td>
                       <table border='0' align='center' cellpadding='0' cellspacing='0' width='100%' class='cat_one'>
                              <tr class='cat_one'>
                                  <?php
                                  while ($Daten=mysql_fetch_array($result)) {

                                         if ($i == 0) {
                                             $color="class='cat_one'";
                                         } else {
                                             $color="class='cat_two'";
                                         }
                                         ?>
                                         <td width='<?php echo ceil($width)."%"; ?>' nowrap align='center' <?php echo $color; ?>>
                                             <?php echo $Daten[name]; ?>
                                             <br><br>
                                             <img src='<?php echo "../functions.php?action=smilie&id=$Daten[id]"; ?>' border='0'>
                                             &nbsp;
                                             <b><?php echo $Daten[code]; ?></b>
                                             <br>
                                             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]"; ?>'>[bearbeiten]</a>&nbsp;
                                             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]"; ?>'>[l�schen]</a>
                                         </td>
                                         <?php
                                         $n++;
                                         //neue Zeile !!!
                                         if ($n >= $GLOBALS[ADMIN_SMILIES_ANZ]) {
                                             $n=0;
                                             if ($i == 0) {
                                                 $i=1;
                                             } else {
                                                 $i=0;
                                             }
                                             echo "<tr $color>";
                                         }
                                  }
                                  for ($n= $n+1; $n <= $GLOBALS[ADMIN_SMILIES_ANZ]; $n++) {
                                       echo "<td width='".ceil($width)."%' nowrap align='center' $color>
                                             &nbsp;
                                             </td>";
                                  }
                                  ?>
                              </tr>
                       </table>
                   </td>
               </tr>
         </table>
         <?php
}
function save() {
         global $HTTP_POST_FILES, $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         ### Datei einlesen ### +++
         //per Upload
         if ($HTTP_POST_FILES[userfile][size] > 0) {
             $filename = $HTTP_POST_FILES[userfile][name];
             $filetyp = $HTTP_POST_FILES[userfile][type];
             $fp=fopen($HTTP_POST_FILES[userfile][tmp_name],"rb");
                 $filestuff=fread($fp,$HTTP_POST_FILES[userfile][size]);
             fclose($fp);
         //vom Dateisystem
         } elseif ($HTTP_POST_VARS[sysfile]) {
             $filename = basename($HTTP_POST_VARS[sysfile]);
             $filetyp = "image/";
             $fp=fopen("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]","rb");
                 $filesize=filesize("$GLOBALS[MAIN_PATH]/$HTTP_POST_VARS[sysfile]");
                 $filestuff=fread($fp,$filesize);
             fclose($fp);
         }
         ### Datei einlesen ### ---
         #
         #
         ### hinzuf�gen
         if ($HTTP_POST_VARS[save] == "add") {
             mysql_query("INSERT INTO $GLOBALS[TB_SMILIES] (name, code, data, typ, filename)
                          VALUES ('$HTTP_POST_VARS[name]','$HTTP_POST_VARS[code]','".addslashes($filestuff)."','$filetyp','$filename')");
             $HTTP_POST_VARS[id]=mysql_insert_id();
             $Fehler = "smilie_add";
             $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";

         ### bearbeiten
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             if ($filestuff){ //Datei ausgew�hlt ???
                 mysql_query("UPDATE $GLOBALS[TB_SMILIES]
                              SET name='$HTTP_POST_VARS[name]',
                                  code='$HTTP_POST_VARS[code]',
                                  data='".addslashes($filestuff)."',
                                  typ='$filetyp',
                                  filename='$filename'
                              WHERE $GLOBALS[TB_SMILIES].id='$HTTP_POST_VARS[id]'");
             } else {
                 mysql_query("UPDATE $GLOBALS[TB_SMILIES]
                              SET name='$HTTP_POST_VARS[name]',
                                  code='$HTTP_POST_VARS[code]'
                              WHERE $GLOBALS[TB_SMILIES].id='$HTTP_POST_VARS[id]'");
             }
             $Fehler = "smilie_edit";
             $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
         }
         ### Message ausgeben
         msg($Fehler, "2", $goto);
}
function del ($id) {
         global $HTTP_GET_VARS, $HTTP_SERVER_VARS;

         if (!$HTTP_GET_VARS[ok]) {
             open_table("Smilie l�schen", "50%");
                         echo "Das Smilie #$id wirklich l�schen ?";
                         echo " [<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id&ok=1'>ja</a> / <a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste'>nein</a>]";
             close_table("");

         } elseif ($HTTP_GET_VARS[ok] == "1") {
             //Smilie l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_SMILIES]
                           WHERE $GLOBALS[TB_SMILIES].id='$id'");
             msg("smilie_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
         }
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>