<?php
include("head.php");
auth("admin_words");
?>
<h3 class='font_big'>Zensierte W&ouml;rter...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "liste":
              liste();
              break;

        case "add":
              addedit();
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id]);
              break;

        case "save":
              save();
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($id="") {
         include("$GLOBALS[MAIN_PATH]/config.php");
         global $Sess_Name, $Sess, $HTTP_SERVER_VARS;
         ?>
         <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <input type='hidden' name='id' VALUE='<?php echo $id; ?>'>
               <input type='hidden' name='save' VALUE='<?php
                      if (!$id) {
                          echo "add'>";
                          $typ = "hinzuf�gen";
                      } else {
                          echo "edit'>";
                          $typ = "bearbeiten";
                          $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                                  FROM $GLOBALS[TB_WORDS]
                                                                  WHERE $GLOBALS[TB_WORDS].id='$id'"));
                      }
               table_header("Zensiertes Wort $typ", "100%", "", "colspan='2'"); ?>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Wort:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='search' value="<?php echo $Daten[search]; ?>" maxlenght='255' size='30'>
                         </td>
                     <tr>
                         <td width='50%' class='cat_two'>
                             <b>Zensiert:</b>
                         <td width='50%' class='cat_one'>
                             <input type='text' name='replacement' value="<?php echo $Daten[replacement]; ?>" maxlenght='255' size='30'>
                         </td>
                     </tr>
               </table>
               <p></p>
               <center>
                       <input type='submit' value='<?php echo $typ; ?>'>
                       <input type='reset' name='Reset' value='Zur�cksetzen'>
               </center>
         </form>
         <?php
}
function liste() {
         global $HTTP_SERVER_VARS, $_style;
         table_header("Zensierte W&ouml;rter bearbeiten...", "100%", "", "colspan='4'"); ?>
                       <tr class='default_tr'>
                           <td width='30%'>
                               <B>wort</B>
                           <td width='30%'>
                               <B>zensiert</B>
                           <td width='30%' align='center'>
                               <b>optionen</b>
                           <td width='10%' align='center'>
                               <b>l�schen</B>
                           </td>
                       </tr>
                       <?php
                       $result = mySQL_query ("SELECT * FROM $GLOBALS[TB_WORDS] ORDER BY $GLOBALS[TB_WORDS].search ASC");
                       while ($Daten = mysql_fetch_array ($result)) {
                              ?>
                              <tr>
                                  <td width='30%' class='cat_two'>
                                      <b><?php echo $Daten[search]; ?></b>
                                  <td width='30%' class='cat_one'>
                                      <b><?php echo $Daten[replacement]; ?></b>
                                  <td width='30%' align='center' class='cat_two'>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]"; ?>'>[bearbeiten]</a>
                                  <td width='10%' align='center' class='cat_one'>
                                      <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]"; ?>'><img src='<?php echo "../".$_style[pic_admin_del]; ?>' border='0' alt='<?php echo "\"$Daten[name]\""; ?> l�schen'></a>
                                  </td>
                              </tr>
                              <?php
                       }
                       ?>
         </table>
         <?php
}
function del ($id) {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS;
         ### Formular
         if ($HTTP_GET_VARS[ok] != "1") {
             open_table("Forum l�schen", "50%");
                         echo "Das \"Zensierte Wort\" #$id wirklich l�schen ?";
                         echo " [<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id&ok=1'>ja</a> / <a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste'>nein</a>]";
             close_table();
         ### l�schen !!!
         } elseif ($HTTP_GET_VARS[ok] == "1") {

             mysql_query("DELETE FROM $GLOBALS[TB_WORDS]
                          WHERE $GLOBALS[TB_WORDS].id='$id'");

             msg("words_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
         }
}
function save() {
         global $HTTP_SERVER_VARS, $HTTP_POST_VARS;
          //add
          if ($HTTP_POST_VARS[save] == "add") {
              $query = "INSERT INTO $GLOBALS[TB_WORDS] (search, replacement)
                        VALUES ('$HTTP_POST_VARS[search]','$HTTP_POST_VARS[replacement]')";
              $Fehler="words_add";
          //edit
          } elseif ($HTTP_POST_VARS[save] == "edit") {
              $query = "UPDATE $GLOBALS[TB_WORDS]
                        SET search='$HTTP_POST_VARS[search]',
                            replacement='$HTTP_POST_VARS[replacement]'
                        WHERE id=$HTTP_POST_VARS[id]";
              $Fehler="words_edit";
          }
          mysql_query($query);
          msg($Fehler, "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>