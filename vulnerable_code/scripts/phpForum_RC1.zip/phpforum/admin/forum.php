<?php
include("head.php");
auth("admin_forums");
?>
<h3 class='font_big'>Foren...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "liste":
              liste();
              break;

        case "add":
              addedit();
              break;

        case "edit":
              addedit($HTTP_GET_VARS[id]);
              break;

        case "save":
              save();
              break;

        case "up":
              up($HTTP_GET_VARS[id]);
              break;

        case "down":
              down($HTTP_GET_VARS[id]);
              break;

        case "activate":
              activate($HTTP_GET_VARS[id],"yes");
              break;

        case "deactivate":
              activate($HTTP_GET_VARS[id],"no");
              break;

        case "del":
              del($HTTP_GET_VARS[id]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($id="") {
         global $HTTP_SERVER_VARS, $HTTP_POST_VARS;
         ?>
             <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
                   <input type='hidden' name='id' VALUE='<?php echo $id; ?>'>
                   <input type='hidden' name='save' VALUE='<?php
                   ### hinzuf�gen
                   if ($id == "") {
                       echo "add'>";
                       $typ = "hinzuf�gen";
                   ### bearbeiten
                   } else {
                       echo "edit'>";
                       $typ = "bearbeiten";
                       $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                               FROM $GLOBALS[TB_FORUM]
                                                               WHERE $GLOBALS[TB_FORUM].id='$id'"));
                   }
                   table_header("Forum $typ...", "100%", "", "colspan='2'"); ?>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Forum aktiv:</b>
                                         <br>
                                         <span class='font_small'>
                                               soll dieses Forum angezeigt werden?
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <?php
                                         echo "<input type='radio' name='show_forum' value='on' ";
                                               if ($Daten[show_forum] == "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;ja&nbsp;&nbsp;";
                                         echo "<input type='radio' name='show_forum' value='' ";
                                               if ($Daten[show_forum] != "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;nein&nbsp;&nbsp;";
                                         ?>
                                     </td>
                                 <tr>
                                     <td width='30%' class='cat_two'>
                                         <b>Kategorie:</b>
                                     <td width='70%' class='cat_one'>
                                         <select name='cat_id'>
                                                 <?php
                                                 $result = mySQL_query ("SELECT *
                                                                         FROM $GLOBALS[TB_CAT]
                                                                         ORDER BY $GLOBALS[TB_CAT].name ASC");
                                                 while ($Daten_cat = mysql_fetch_array ($result)) {
                                                        echo "<option value='$Daten_cat[id]' ";
                                                              if ($Daten_cat[id] == $Daten[cat_id]) {
                                                                  echo "selected";
                                                              }
                                                              echo ">$Daten_cat[name]</option>\n";
                                                 }
                                                 ?>
                                         </select>
                                     </td>
                                 <tr>
                                     <td width='30%' class='cat_two'>
                                         <b>Name:</b>
                                     <td width='70%' class='cat_one'>
                                         <INPUT TYPE='text' name='name' SIZE='45' MAXLENGTH='255' value="<?php echo $Daten[name]; ?>">
                                     </td>
                                 <tr>
                                     <td width='30%' class='cat_two'>
                                         <b>Beschreibung:</b>
                                         <br>
                                         <span class='font_small'>
                                               Hier k&ouml;nnen sie das Forums kurz beschreiben.
                                         </span>
                                     <td width='70%' class='cat_one'>
                                         <TEXTAREA NAME='info' COLS='35' ROWS='3'><?php echo htmlentities($Daten[info]); ?></TEXTAREA>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>HTML-Code aktivieren:</b>
                                         <br>
                                         <span class='font_small'>
                                               Soll HTML-Code in Beitr�gen erlaubt sein?
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <?php
                                         echo "<input type='radio' name='html' value='on' ";
                                               if ($Daten[html] == "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;ja&nbsp;&nbsp;";
                                         echo "<input type='radio' name='html' value='' ";
                                               if ($Daten[html] != "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;nein&nbsp;&nbsp;";
                                         ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Board-Code aktivieren:</b>
                                         <br>
                                         <span class='font_small'>
                                               Soll Board-Code in Beitr�gen erlaubt sein?
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <?php
                                         echo "<input type='radio' name='bbcodes' value='on' ";
                                               if ($Daten[bbcodes] == "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;ja&nbsp;&nbsp;";
                                         echo "<input type='radio' name='bbcodes' value='' ";
                                               if ($Daten[bbcodes] != "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;nein&nbsp;&nbsp;";
                                         ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Smilies aktivieren:</b>
                                         <br>
                                         <span class='font_small'>
                                               Sollen Smilies in Beitr�gen erlaubt sein?
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <?php
                                         echo "<input type='radio' name='smilies' value='on' ";
                                               if ($Daten[smilies] == "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;ja&nbsp;&nbsp;";
                                         echo "<input type='radio' name='smilies' value='' ";
                                               if ($Daten[smilies] != "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;nein&nbsp;&nbsp;";
                                         ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Anh�nge aktivieren:</b>
                                         <br>
                                         <span class='font_small'>
                                               D�rfen Dateien Beitr�gen angeh�gt werden?
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <?php
                                         echo "<input type='radio' name='files' value='on' ";
                                               if ($Daten[files] == "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;ja&nbsp;&nbsp;";
                                         echo "<input type='radio' name='files' value='' ";
                                               if ($Daten[files] != "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;nein&nbsp;&nbsp;";
                                         ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Umfragen aktivieren:</b>
                                         <br>
                                         <span class='font_small'>
                                               D�rfen Umfragen erstellt werden?
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <?php
                                         echo "<input type='radio' name='polls' value='on' ";
                                               if ($Daten[polls] == "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;ja&nbsp;&nbsp;";
                                         echo "<input type='radio' name='polls' value='' ";
                                               if ($Daten[polls] != "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;nein&nbsp;&nbsp;";
                                         ?>
                                     </td>
                                 <tr>
                                     <td width='40%' class='cat_two'>
                                         <b>Optionen anzeigen:</b>
                                         <br>
                                         <span class='font_small'>
                                               W�hle hier ja um die Optionen an zu zeigen?
                                         </span>
                                     <td width='60%' class='cat_one'>
                                         <?php
                                         echo "<input type='radio' name='options' value='on' ";
                                               if ($Daten[options] == "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;ja&nbsp;&nbsp;";
                                         echo "<input type='radio' name='options' value='' ";
                                               if ($Daten[options] != "on") {
                                                   echo "checked";
                                               }
                                               echo ">&nbsp;nein&nbsp;&nbsp;";
                                         ?>
                                     </td>
                                 </tr>
                   </table>
                   <p></p>
                   <center>
                           <input type='submit' value='<?php echo $typ; ?>'>
                           <input type='reset' name='Reset' value='Zur�cksetzen'>
                   </center>
             </form>
             <?php
}
function liste() {
         global $HTTP_SERVER_VARS, $_style;
         table_header("Forum bearbeiten...", "100%", "", "colspan='6'"); ?>
                       <tr class='default_tr'>
                           <td width='50%'>
                               <B>name</B>
                           <td width='5%' align='center'>
                               <B>rang</B>
                           <td width='15%' align='center'>
                               <B>hoch / runter</B>
                           <td width='20%' align='center'>
                               <b>optionen</b>
                           <td width='10%' align='center'>
                               <b>l�schen</B>
                       </tr>
                       <?php
                       //Kategorie anzeigen
                       $result_cat = mySQL_query ("SELECT $GLOBALS[TB_CAT].*
                                                   FROM $GLOBALS[TB_CAT], $GLOBALS[TB_FORUM]
                                                   WHERE $GLOBALS[TB_FORUM].cat_id=$GLOBALS[TB_CAT].id
                                                   GROUP BY $GLOBALS[TB_CAT].id
                                                   ORDER BY $GLOBALS[TB_CAT].rang ASC");
                       while ($Daten_cat = mysql_fetch_array ($result_cat)) {
                              table_header("$Daten_cat[name]", "100%", "2", "colspan='6'", "nohead");
                              //Forum anzeigen
                              $result = mySQL_query ("SELECT * FROM $GLOBALS[TB_FORUM] WHERE $GLOBALS[TB_FORUM].cat_id='$Daten_cat[id]' ORDER BY $GLOBALS[TB_FORUM].rang ASC");
                              $max = mysql_num_rows ($result);
                              while ($Daten = mysql_fetch_array ($result)) {
                                     ?>
                                     <tr>
                                         <td width='50%' class='cat_two'>
                                             <b><?php echo $Daten[name]; ?></b><br>
                                             <span class='font_small'>
                                                   <?php echo $Daten[info]; ?>
                                             </span>
                                         <td align='center' width='5%' class='cat_two'>
                                             <?php echo $Daten[rang]; ?>
                                         <td align='center' width='15%' class='cat_one'>
                                             <?php
                                             ### UP ###
                                             if ($Daten[rang] > "1") {
                                                 echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=up&id=$Daten[id]'><img src='../$_style[pic_admin_up]' border='0' alt='\"$Daten[name]\" nach oben'></a>&nbsp;&nbsp;";
                                             }
                                             ### DOWN ###
                                             if ($Daten[rang] < $max) {
                                                 echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=down&id=$Daten[id]'><img src='../$_style[pic_admin_down]' border='0' alt='\"$Daten[name]\" nach unten'></a>";
                                             }
                                             ?>
                                         <td width='30%' align='center' class='cat_two'>
                                             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&id=$Daten[id]"; ?>' title='<?php echo "\"".htmlentities($Daten[name], ENT_QUOTES)."\""; ?> bearbeiten'>[bearbeiten]</a>
                                             <?php
                                             ### DE-Aktivieren ###
                                             if ($Daten[show_forum] == "on") {
                                                 echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=deactivate&id=$Daten[id]' title='\"".htmlentities($Daten[name], ENT_QUOTES)."\" deaktivieren'>[deaktivieren]</a>";
                                             ### Aktivieren ###
                                             } else {
                                                 echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=activate&id=$Daten[id]' title='\"".htmlentities($Daten[name], ENT_QUOTES)."\" aktivieren'>[aktivieren]</a>";
                                             }
                                             ?>
                                         <td width='10%' align='center' class='cat_one'>
                                             <a href='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$Daten[id]"; ?>'><img src='<?php echo "../".$_style[pic_admin_del]; ?>' border='0' alt='<?php echo "\"".htmlentities($Daten[name], ENT_QUOTES)."\""; ?> l�schen'></a>
                                         </td>
                                     </tr>
                                     <?php
                              }
                       }
                       ?>
         </table>
         <?php
}
function activate($id, $activate) {
         global $HTTP_SERVER_VARS;

         if ($activate == "yes") {
             $query = "UPDATE $GLOBALS[TB_FORUM] SET show_forum='on' WHERE id='$id'";
         } elseif ($activate == "no") {
             $query = "UPDATE $GLOBALS[TB_FORUM] SET show_forum='' WHERE id='$id'";
         }
         mysql_query($query);
         msg("forum_edit", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
function up($id) {
         global $HTTP_SERVER_VARS;
         $hoch = mysql_fetch_array (mySQL_query("SELECT id, cat_id, rang FROM $GLOBALS[TB_FORUM] WHERE $GLOBALS[TB_FORUM].id='$id'"));
         if ($hoch[rang] > "1") {

             $rang_davor=$hoch[rang]-1;
             $davor = mysql_fetch_array (mySQL_query("SELECT id FROM $GLOBALS[TB_FORUM] WHERE $GLOBALS[TB_FORUM].rang='$rang_davor' AND cat_id='$hoch[cat_id]'"));
             mysql_query("UPDATE $GLOBALS[TB_FORUM] SET rang='$hoch[rang]' WHERE id='$davor[id]'");
             mysql_query("UPDATE $GLOBALS[TB_FORUM] SET rang='$rang_davor' WHERE id='$hoch[id]'");
             $Fehler="forum_edit";

         } else {
             $Fehler="forum_edit_false";
         }
         msg($Fehler, "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");

}
function down($id) {
         global $HTTP_SERVER_VARS;
         $runter = mysql_fetch_array (mySQL_query("SELECT id, rang, cat_id FROM $GLOBALS[TB_FORUM] WHERE $GLOBALS[TB_FORUM].id='$id'"));
         $max = mysql_num_rows (mySQL_query("SELECT id FROM $GLOBALS[TB_FORUM] WHERE cat_id='$runter[cat_id]'"));
         if ($runter[rang] < $max) {

             $rang_danach=$runter[rang]+1;
             $danach = mysql_fetch_array (mySQL_query ("SELECT * FROM $GLOBALS[TB_FORUM] WHERE $GLOBALS[TB_FORUM].rang='$rang_danach' AND cat_id='$runter[cat_id]'"));
             mysql_query("UPDATE $GLOBALS[TB_FORUM] SET rang='$runter[rang]' WHERE id='$danach[id]'");
             mysql_query("UPDATE $GLOBALS[TB_FORUM] SET rang='$rang_danach' WHERE id='$runter[id]'");
            $Fehler="cat_edit";

         } else {
            $Fehler="cat_edit_false";
         }
         msg($Fehler, "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
function del ($id) {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS;

         ### Formular
         if (!$HTTP_GET_VARS[ok]) {
             open_table("Forum l�schen", "50%");
                         echo "Das Forum #$id wirklich l�schen ?";
                         echo " [<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&id=$id&ok=1'>ja</a> / <a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste'>nein</a>]";
             close_table("Wenn Sie das Forum l�schen werden alle Themen, Beitr�ge und Umfragen in diesem Forum mit gel�scht.");
         ### l�schen !!!
         } elseif ($HTTP_GET_VARS[ok] == "1") {

             # topics.id bekommen
             $result_topic = mySQL_query ("SELECT $GLOBALS[TB_TOPIC].id
                                           FROM $GLOBALS[TB_TOPIC]
                                           WHERE $GLOBALS[TB_TOPIC].forum_id='$id'");
             while ($Daten_topic = mysql_fetch_array ($result_topic)) {

                    # Datei-Anh�nge l�schen
                    $result_post = mySQL_query ("SELECT $GLOBALS[TB_POST].id
                                                 FROM $GLOBALS[TB_POST]
                                                 WHERE $GLOBALS[TB_POST].topic_id='$Daten_topic[id]'");
                    while ($Daten_post = mysql_fetch_array ($result_post)) {
                           mysql_query("DELETE FROM $GLOBALS[TB_FILES]
                                        WHERE $GLOBALS[TB_FILES].post_id='$Daten_post[id]'");
                    }

                    # Umfragen l�schen
                    $result_poll = mySQL_query ("SELECT $GLOBALS[TB_POLL].id
                                                 FROM $GLOBALS[TB_POLL]
                                                 WHERE $GLOBALS[TB_POLL].topic_id='$Daten_topic[id]'");
                    while ($Daten_poll = mysql_fetch_array ($result_poll)) {
                           # Umfragen-Texte l�schen
                           $result_poll_texts = mySQL_query ("SELECT $GLOBALS[TB_POLL_TEXT].id
                                                              FROM $GLOBALS[TB_POLL_TEXT]
                                                              WHERE $GLOBALS[TB_POLL_TEXT].poll_id='$Daten_poll[id]'");
                           while ($Daten_poll_texts = mysql_fetch_array ($result_poll_texts)) {
                                  //Text l�schen
                                  mysql_query("DELETE FROM $GLOBALS[TB_POLL_TEXT]
                                               WHERE $GLOBALS[TB_POLL_TEXT].id='$Daten_poll_texts[id]'");
                                  //Benutzer voteing l�schen
                                  mysql_query("DELETE FROM $GLOBALS[TB_POLL_USER]
                                               WHERE $GLOBALS[TB_POLL_USER].text_id='$Daten_poll_texts[id]'");
                           }
                           mysql_query("DELETE FROM $GLOBALS[TB_POLL]
                                        WHERE $GLOBALS[TB_POLL].id='$Daten_poll[id]'");
                    }
                    # Themen-Abo�s l�schen
                    mySQL_query ("DELETE FROM $GLOBALS[TB_ABO]
                                  WHERE $GLOBALS[TB_ABO].topic_id='$Daten_topic[id]'");
                    # Beitr�ge l�schen
                    mySQL_query ("DELETE FROM $GLOBALS[TB_POST]
                                  WHERE $GLOBALS[TB_POST].topic_id='$Daten_topic[id]'");
             }
             # Themen l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_TOPIC]
                           WHERE $GLOBALS[TB_TOPIC].forum_id='$id'");
             # Rang der nachfolgenden Foren �ndern
             $forum = mysql_fetch_array(mysql_query("SELECT rang, cat_id FROM $GLOBALS[TB_FORUM] WHERE id='$id'"));
             mySQL_query ("UPDATE $GLOBALS[TB_FORUM]
                           SET rang=rang-1
                           WHERE $GLOBALS[TB_FORUM].rang > '$forum[rang]'
                             AND cat_id='$forum[cat_id]'");
             # Forum l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_FORUM]
                           WHERE $GLOBALS[TB_FORUM].id='$id'");
             # Moderatoren l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_MOD]
                           WHERE $GLOBALS[TB_MOD].forum_id='$id'");
             # Zugriffsrechte l�schen
             mySQL_query ("DELETE FROM $GLOBALS[TB_FORUM_ACCESS]
                           WHERE $GLOBALS[TB_FORUM_ACCESS].forum_id='$id'");

             msg("forum_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
         }
}
function save() {
         global $HTTP_POST_VARS, $HTTP_SERVER_VARS;

         ### add
         if ($HTTP_POST_VARS[save] == "add") {
             //rang errechnen !!!
             $rang = mysql_fetch_array(mysql_query("SELECT MAX(rang)+1 AS max FROM $GLOBALS[TB_FORUM] WHERE cat_id='$HTTP_POST_VARS[cat_id]'"));
             if (!$rang[max]) {
                 $rang[max] = 1;
             }
             $query = "INSERT INTO $GLOBALS[TB_FORUM] (name, info, rang, cat_id, show_forum, html, bbcodes, smilies, files, polls, options)
                       VALUES ('$HTTP_POST_VARS[name]','$HTTP_POST_VARS[info]','$rang[max]','$HTTP_POST_VARS[cat_id]',
                               '$HTTP_POST_VARS[show_forum]','$HTTP_POST_VARS[html]','$HTTP_POST_VARS[bbcodes]',
                               '$HTTP_POST_VARS[smilies]','$HTTP_POST_VARS[files]','$HTTP_POST_VARS[polls]','$HTTP_POST_VARS[options]')";
             $Fehler="forum_add";
         ### edit
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             $query = "UPDATE $GLOBALS[TB_FORUM]
                       SET name='$HTTP_POST_VARS[name]',
                           info='$HTTP_POST_VARS[info]',
                           cat_id='$HTTP_POST_VARS[cat_id]',
                           show_forum='$HTTP_POST_VARS[show_forum]',
                           html='$HTTP_POST_VARS[html]',
                           bbcodes='$HTTP_POST_VARS[bbcodes]',
                           smilies='$HTTP_POST_VARS[smilies]',
                           files='$HTTP_POST_VARS[files]',
                           polls='$HTTP_POST_VARS[polls]',
                           options='$HTTP_POST_VARS[options]'
                       WHERE id=$HTTP_POST_VARS[id]";
             $Fehler="forum_edit";
         }
         if (mysql_query($query)) {
             ### Foren berechtigungen hinzuf�gen (nur wenn Forum hinzugef�gt)
             if ($HTTP_POST_VARS[save] == "add") {
                 $HTTP_POST_VARS[id]=mysql_insert_id();
                 $result = mysql_query("SELECT * FROM $GLOBALS[TB_ACCESS]");
                 while ($Daten = mysql_fetch_array($result)) {
                        mysql_query("INSERT INTO $GLOBALS[TB_FORUM_ACCESS] VALUES ('$HTTP_POST_VARS[id]','$Daten[id]','$Daten[view]','$Daten[del_post]','$Daten[edit_post]','$Daten[new_post]','$Daten[new_topic]',
                                     '$Daten[mod_openclose]','$Daten[mod_move_topic]','$Daten[mod_edit]','$Daten[mod_del]','$Daten[mod_join]','$Daten[mod_move_post]','$Daten[mod_top]')");
                 }
             }
             $goto="$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
         } else {
             $Fehler="forum_add_fault";
             $goto="back()";
         }
         msg($Fehler, "2", $goto);
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>