<?php
include("head.php");
auth("admin_forums");
?>
<h3 class='font_big'>Moderatoren...</h3>
<?php
switch ($HTTP_GET_VARS[action]) {

        case "add":
              addedit();
              break;

        case "liste":
              liste();
              break;

        case "edit":
              addedit($HTTP_GET_VARS[forum_id], $HTTP_GET_VARS[user_id]);
              break;

        case "save":
              save();
              break;

        case "del":
              del_mod($HTTP_GET_VARS[forum_id], $HTTP_GET_VARS[user_id]);
              break;

        case "default":
              set_default($HTTP_GET_VARS[forum_id], $HTTP_GET_VARS[user_id]);
              break;
}
#################################################################
######################### Funktionen ############################
#################################################################
function addedit($forum_id="", $user_id="") {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS;

         if ($user_id) {
             $userinfo = get_user_info($user_id);
         }
         ?>
         <form method='post' action='<?php echo "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=save"; ?>'>
               <input type='hidden' name='save' VALUE='<?php
                       if ($HTTP_GET_VARS[action] == "add") {
                           echo "add'>";
                           $typ = "hinzuf�gen";
                       } elseif ($HTTP_GET_VARS[action] == "edit") {
                           echo "edit'>";
                           echo "<input type='hidden' name='user_id' VALUE='$userinfo[id]'>";
                           $typ = "bearbeiten";
                           $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                                   FROM $GLOBALS[TB_MOD]
                                                                   WHERE $GLOBALS[TB_MOD].forum_id='$forum_id'
                                                                     AND $GLOBALS[TB_MOD].user_id='$user_id'"));
                       }
                       table_header("Moderator $typ...", "100%", "", "colspan='2'"); ?>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Forum:</b>
                            <td width='50%' class='cat_one'>
                                <select name='forum_id'>
                                        <?php
                                        $result = mysql_query("SELECT id, name
                                                               FROM $GLOBALS[TB_FORUM]
                                                               WHERE show_forum='on'
                                                               ORDER BY name");
                                        while ($forum = mysql_fetch_array($result)) {
                                               echo "<option value='$forum[id]'";
                                               if ($forum_id == $forum[id]) {
                                                   echo "selected";
                                               }
                                               echo ">$forum[name]</option>\n";
                                        }
                                        ?>
                                </select>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>Benutzername:</b>
                            <td width='50%' class='cat_one'>
                                <input type='text' size='30' maxlenght='255' name='user_name' value="<?php echo $userinfo[name]; ?>">
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen &ouml;ffnen / schlie&szlig;en?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_openclose] == "on") {
                                    echo "<input type='radio' name='mod_openclose' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_openclose' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_openclose' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_openclose' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen festhalten / l&ouml;sen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_top] == "on") {
                                    echo "<input type='radio' name='mod_top' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_top' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_top' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_top' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen verschieben?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_move_topic] == "on") {
                                    echo "<input type='radio' name='mod_move_topic' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_move_topic' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_move_topic' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_move_topic' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Beitr&auml;ge verschieben?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_move_post] == "on") {
                                    echo "<input type='radio' name='mod_move_post' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_move_post' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_move_post' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_move_post' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf andere Themen / Beitr�ge bearbeiten?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_edit] == "on") {
                                    echo "<input type='radio' name='mod_edit' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_edit' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_edit' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_edit' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf andere Themen / Beitr�ge l�schen?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_del] == "on") {
                                    echo "<input type='radio' name='mod_del' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_del' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_del' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_del' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        <tr>
                            <td width='50%' class='cat_two'>
                                <b>darf Themen zusammen f�hren?:</b>
                            <td width='50%' class='cat_one'>
                                <?php
                                if ($Daten[mod_join] == "on") {
                                    echo "<input type='radio' name='mod_join' value='on' checked>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_join' value=''>&nbsp;nein";
                                } else {
                                    echo "<input type='radio' name='mod_join' value='on'>&nbsp;ja&nbsp;&nbsp;";
                                    echo "<input type='radio' name='mod_join' value='' checked>&nbsp;nein";
                                }
                                ?>
                            </td>
                        </tr>
                 </table>
                 <p></p>
                 <center>
                         <input type='submit' value='<?php echo $typ; ?>'>
                         <input type='reset' name='Reset' value='Zur�cksetzen'>
                 </center>
             </form>
         <?php
}
function liste() {
         global $HTTP_SERVER_VARS;

         table_header("Moderatoren bearbeiten...", "100%", "", "colspan='2'"); ?>
                  <tr class='cat_tr'>
                      <td width='30%' class='cat_one' colspan='2'>
                          <?php
                          $result =mysql_query("SELECT $GLOBALS[TB_FORUM].*
                                                FROM $GLOBALS[TB_FORUM], $GLOBALS[TB_MOD]
                                                WHERE $GLOBALS[TB_FORUM].id=$GLOBALS[TB_MOD].forum_id
                                                GROUP BY $GLOBALS[TB_FORUM].id
                                                ORDER BY $GLOBALS[TB_FORUM].name ASC");
                          while ($Daten=mysql_fetch_array($result)) {
                                 echo "<b>-</b>&nbsp;<a href='#$Daten[id]'>$Daten[name]</a><br>";
                          }
                          ?>
                      </td>
                  </tr>
                  <?php
         $result = mysql_query("SELECT $GLOBALS[TB_FORUM].*
                                FROM $GLOBALS[TB_FORUM], $GLOBALS[TB_MOD]
                                WHERE $GLOBALS[TB_FORUM].id=$GLOBALS[TB_MOD].forum_id
                                GROUP BY $GLOBALS[TB_FORUM].id
                                ORDER BY $GLOBALS[TB_FORUM].name ASC");
         while ($Daten=mysql_fetch_array($result)) {

                table_header("<a name='$Daten[id]'>$Daten[name]:", "100%", "1", "colspan='2'", "nohead");
                       $result_user = mysql_query ("SELECT $GLOBALS[TB_USER].*, $GLOBALS[TB_ACCESS].name AS access_name
                                                    FROM $GLOBALS[TB_MOD], $GLOBALS[TB_USER], $GLOBALS[TB_ACCESS]
                                                    WHERE $GLOBALS[TB_MOD].forum_id='$Daten[id]'
                                                      AND $GLOBALS[TB_MOD].user_id=$GLOBALS[TB_USER].id
                                                      AND $GLOBALS[TB_ACCESS].id=$GLOBALS[TB_USER].access_id");
                       while ($Daten_user = mysql_fetch_array($result_user)) {
                       ?>
                       <tr>
                           <td width='50%' class='cat_two'>
                               <b><?php echo $Daten_user[name]; ?></b>
                          <td width='50%' class='cat_one'>
                              <?php
                              echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=edit&forum_id=$Daten[id]&user_id=$Daten_user[id]'>[bearbeiten]</a>&nbsp;";
                              echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=del&forum_id=$Daten[id]&user_id=$Daten_user[id]'>[l&ouml;schen]</a>&nbsp;";
                              if (!is_standard($Daten[id], $Daten_user[id])) {
                                  echo "<a href='$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=default&forum_id=$Daten[id]&user_id=$Daten_user[id]' title='Standard - Einstellungen der \"$Daten_user[access_name]\" - Benutzergruppe �bernehmen'>[Standard]</a>";
                              } else {
                                  echo "[Standard]";
                              }
                              ?>
                          </td>
                       </tr>
                       <?php
                       } //Benutzer
         } //Foren
         echo "</table>";
}
function save() {
         global $HTTP_SERVER_VARS, $HTTP_GET_VARS, $HTTP_POST_VARS;

         $new_user_id = user_id($HTTP_POST_VARS[user_name]);

         //hinzuf�gen
         if ($HTTP_POST_VARS[save] == "add") {
             $query = "INSERT INTO $GLOBALS[TB_MOD] VALUES ('$HTTP_POST_VARS[forum_id]','$new_user_id','$HTTP_POST_VARS[mod_openclose]','$HTTP_POST_VARS[mod_move_topic]','$HTTP_POST_VARS[mod_edit]','$HTTP_POST_VARS[mod_del]','$HTTP_POST_VARS[mod_join]','$HTTP_POST_VARS[mod_move_post]','$HTTP_POST_VARS[mod_top]')";
             $Fehler="forum_mod_add";
         //bearbeiten
         } elseif ($HTTP_POST_VARS[save] == "edit") {
             $query = "UPDATE $GLOBALS[TB_MOD]
                       SET forum_id='$HTTP_POST_VARS[forum_id]',
                           user_id='$new_user_id',
                           mod_openclose='$HTTP_POST_VARS[mod_openclose]',
                           mod_move_topic='$HTTP_POST_VARS[mod_move_topic]',
                           mod_edit='$HTTP_POST_VARS[mod_edit]',
                           mod_del='$HTTP_POST_VARS[mod_del]',
                           mod_join='$HTTP_POST_VARS[mod_join]',
                           mod_move_post='$HTTP_POST_VARS[mod_move_post]',
                           mod_top='$HTTP_POST_VARS[mod_top]'
                       WHERE $GLOBALS[TB_MOD].forum_id='$HTTP_POST_VARS[forum_id]'
                         AND $GLOBALS[TB_MOD].user_id='$HTTP_POST_VARS[user_id]'";
             $Fehler="forum_mod_edit";
         }
         //benutzer nicht vorhanden ?!
         if (!$new_user_id) {
             $Fehler .= "_fault";
             msg($Fehler, "2", "back()");
         }

         //erstellen / update
         if (mysql_query($query)) {
             $goto = "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste";
         } else {
             $Fehler .= "_fault";
             $goto = "back()";
         }
         msg($Fehler, "2", $goto);
}
function set_default($forum_id, $user_id) {
         global $HTTP_SERVER_VARS;
         $userinfo = get_user_info($user_id);
         $Daten = mysql_fetch_array(mysql_query("SELECT *
                                                 FROM $GLOBALS[TB_ACCESS]
                                                 WHERE $GLOBALS[TB_ACCESS].id='$userinfo[access_id]'"));
         mysql_query("UPDATE $GLOBALS[TB_MOD]
                      SET $GLOBALS[TB_MOD].mod_openclose = '$Daten[mod_openclose]',
                          $GLOBALS[TB_MOD].mod_move_topic = '$Daten[mod_move_topic]',
                          $GLOBALS[TB_MOD].mod_edit = '$Daten[mod_edit]',
                          $GLOBALS[TB_MOD].mod_del = '$Daten[mod_del]',
                          $GLOBALS[TB_MOD].mod_join = '$Daten[mod_join]',
                          $GLOBALS[TB_MOD].mod_move_post = '$Daten[mod_move_post]',
                          $GLOBALS[TB_MOD].mod_top = '$Daten[mod_top]'
                      WHERE $GLOBALS[TB_MOD].forum_id='$forum_id'
                     AND $GLOBALS[TB_MOD].user_id='$user_id'");

         msg("forum_mod_default", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
function is_standard($forum_id, $user_id) {
         $userinfo = get_user_info($user_id);
         $result = mysql_query ("SELECT $GLOBALS[TB_ACCESS].id
                                 FROM $GLOBALS[TB_MOD], $GLOBALS[TB_ACCESS]
                                 WHERE $GLOBALS[TB_MOD].mod_openclose = $GLOBALS[TB_ACCESS].mod_openclose
                                   AND $GLOBALS[TB_MOD].mod_move_topic = $GLOBALS[TB_ACCESS].mod_move_topic
                                   AND $GLOBALS[TB_MOD].mod_edit = $GLOBALS[TB_ACCESS].mod_edit
                                   AND $GLOBALS[TB_MOD].mod_del = $GLOBALS[TB_ACCESS].mod_del
                                   AND $GLOBALS[TB_MOD].mod_join = $GLOBALS[TB_ACCESS].mod_join
                                   AND $GLOBALS[TB_MOD].mod_move_post = $GLOBALS[TB_ACCESS].mod_move_post
                                   AND $GLOBALS[TB_MOD].mod_top = $GLOBALS[TB_ACCESS].mod_top
                                   AND $GLOBALS[TB_MOD].forum_id='$forum_id'
                                   AND $GLOBALS[TB_MOD].user_id='$user_id'
                                   AND $GLOBALS[TB_ACCESS].id='$userinfo[access_id]'");
         if (mysql_num_rows($result) == "1") {
             return TRUE;
         } else {
             return FALSE;
         }
}
function del_mod($forum_id, $user_id) {
         global $HTTP_SERVER_VARS;

         mysql_query("DELETE FROM $GLOBALS[TB_MOD]
                      WHERE $GLOBALS[TB_MOD].forum_id='$forum_id'
                        AND $GLOBALS[TB_MOD].user_id='$user_id'");
         msg("forum_mod_del", "2", "$HTTP_SERVER_VARS[PHP_SELF]?$GLOBALS[Sess_Name]=$GLOBALS[Sess]&action=liste");
}
#################################################################
######################### Funktionen ############################
#################################################################
gz_site();
?>