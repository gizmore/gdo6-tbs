--------------->]IS-shoutv2[<-------------------

Copyright//

>1< PLease leave the link back to inlineshots at the bottom of the shoutbox on

installation//

>1< Upload everything
>2< Set the CHMOD properties of the folder /data/ and everything inside it to (777)
>3< Load up http://www.your-domain.com/shout_directroy/install.htm
>4< Once installation is complete delete both install.htm and install.php 

support//

>1< contact inlineshots@msn.com
>2< load up http://www.inlineshots.com/support