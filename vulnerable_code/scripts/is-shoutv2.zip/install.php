<?
if ($path != "") 
{ 
$data = "data/config.txt";
$df = fopen($data, "w");
fwrite($df, '<? 
$script_path = "');
fwrite($df, "$path");
fwrite($df, '";
$datafolder = "data/";
$datadir = $script_path + $datafolder;
?>' );
fclose($df);
echo("installed script path<br>"); 
}
else { echo ("couldnt install script path please make sure data/ has a CHMOD value of (777)"); exit(); }
if($templ != "")
{
$dataa = "data/temp.txt";
$dff = fopen($dataa, "w");
fwrite($dff, '<? 
$temp = "');
fwrite($dff, "$templ");
fwrite($dff, '";
?>' );
fclose($dff);
echo("installed template path<br>");
}
else
{
echo("go back and enter a template path!");
exit(); }
if($adminpass != "")
{
$dataaa = "data/admin.php";
$dfff = fopen($dataaa, "w");
fwrite($dfff, '<? 
$admin = "');
fwrite($dfff, "$adminpass");
fwrite($dfff, '";
?>' );
fclose($dfff);
echo("installed Admin password<br>");
}
else
{
echo("go back and enter a admin panel password!");
exit(); }
?>
<br>well done your shoutbox script is installed sucessfully!
