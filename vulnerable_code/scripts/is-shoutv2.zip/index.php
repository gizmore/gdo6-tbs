<? 
include ("data/config.txt");
include ("data/temp.txt");
?><link rel="stylesheet" type="text/css" href="<?php echo $temp ; ?>/style.css">
<? 
$data = "install.htm";
$data2 = "install.php";
if ( file_exists($data) || file_exists($data2)  )
{
echo("You must delete the install.htm and install.php files from your main shout directory before using your shoutbox");
exit();
}
else
{
?>

<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style><p>
<table width="100%"  border="1" cellspacing="0" class="posttable">
  <tr>
    <td height="32" background="<? echo $temp ; ?>/images/bg.gif"> <? include ("$temp/header.tpl"); ?></td>
  </tr>
  <tr>
    <td><? include ("post.php"); ?></td>
  </tr>
  
</table>
</p>
<table width="100%"  border="1" cellspacing="0" class="posts">
<tr>
    <td class="sticky"><? include ("data/sticky.txt"); ?></td>
  </tr>
  <tr>
    <td><? include ("data/posts.txt"); ?></td>
  </tr>

</table>
</p>
<table width="100%"  border="0" cellspacing="0" class="links">
  <tr>
    <td><? include ("$temp/footer.tpl"); ?>
    <br>
    script made by <a href="http://inlineshots.com"><strong>inlineshots </strong></a></td>
  </tr>
</table>
<? } ?>