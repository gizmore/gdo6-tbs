<link rel="stylesheet" type="text/css" href="$temp/style.css">
  <?
  $message = str_replace(":)","<img src='smileys/smiling.gif'>",$message);
$message = str_replace(":(","<img src='smileys/sad.gif'>",$message);
$message = str_replace(":P","<img src='smileys/tongue.gif'>",$message);
$message = str_replace(":D","<img src='smileys/grin.gif'>",$message);
  include("./data/temp.txt");
$dataf = "./data/posts.txt";
 $message = stripslashes($message);
 $namee = stripslashes($namee);
 $url = stripslashes($url);
 $df = fopen($dataf, "a");
 if ($message != "")
 {
 fwrite($df, "
 
 <!-- START POST -->
<!-- posted by the ip " . $REMOTE_ADDR . " -->
<table width='100%'  border='0' cellspacing='0'>
  <tr class='details'>
    <td><img src='$temp/images/post.gif'><a href='$url'>$nom</a><span></span></td>
  </tr>
  <tr>
    <td class='message'>$message </td>
  </tr>
</table>
<!-- END POST -->


");
fclose($df);
echo("message posted! <a href='index.php' >view</a>");
}
else{

?>
please go back and enter a message! <? } ?>