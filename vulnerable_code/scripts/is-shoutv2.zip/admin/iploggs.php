

<link rel="stylesheet" type="text/css" href="$temp/style.css">
<?php 
include("./../data/temp.txt"); ?>

<TABLE WIDTH=480 BORDER=0 align="center" CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD COLSPAN=3><div align="center">welcome to the admin section login sucessfull!!! </div></TD>
	</TR>
	<TR>
		<TD width="4" ROWSPAN=5>&nbsp;			</TD>
		<TD width="457">			<img src="temp/images/logo.gif" width=457 height=65 alt=""></TD>
		<TD width="19" ROWSPAN=5>&nbsp;			</TD>
	</TR>
	<TR>
		<TD background="temp/images/bg.gif"><? include ("temp/links.tpl"); ?>	</TD>
	</TR>
	<TR>
		<TD>download this file<br>
		  <a href="./../data/posts.txt">iploggs
	      </a>
		  <p><br>
		 
	 </p>
      </TD>
	</TR>
	<TR>
		<TD background="temp/images/bg.gif"><div align="center">script made by <a href="http://inlineshots.com">inlineshots&copy;</a> <a href="http://inlineshots.info/support/index.php?id=shoutv2">support </a></div></TD>
	</TR>
	<TR>
		<TD>&nbsp;			</TD>
	</TR>
</TABLE>
<br>
