<form name="pp" method="post" action="admin.php"> 
<table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td><div align="center">password:
          <input type="password" name="pass">
    </div></td>
  </tr>
  <tr>
    <td><div align="center">
      <input type="submit" value="Log In">
    </div></td>
  </tr>
</table>
</form>