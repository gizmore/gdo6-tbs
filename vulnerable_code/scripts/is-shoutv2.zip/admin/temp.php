

<link rel="stylesheet" type="text/css" href="$temp/style.css">
<?php 
include("./../data/temp.txt"); ?>

<TABLE WIDTH=480 BORDER=0 align="center" CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD COLSPAN=3><div align="center">welcome to the admin section login sucessfull!!! </div></TD>
	</TR>
	<TR>
		<TD width="4" ROWSPAN=5>&nbsp;			</TD>
		<TD width="457">			<img src="temp/images/logo.gif" width=457 height=65 alt=""></TD>
		<TD width="19" ROWSPAN=5>&nbsp;			</TD>
	</TR>
	<TR>
		<TD background="temp/images/bg.gif"><? include ("temp/links.tpl"); ?>	</TD>
	</TR>
	<TR>
		<TD><? include("./../data/temp.txt"); ?>
         <iframe src="./../data/temp.txt" scrolling="no" width="100%" height="75" frameborder="0"></iframe>
         <p><br>

		 please create a template using the structure found in templates/default and then upload it all to templates/your template name then just edit data/temp.txt<br>
		 
	 </p>
         </TD>
	</TR>
	<TR>
		<TD background="temp/images/bg.gif"><div align="center">script made by <a href="http://inlineshots.com">inlineshots&copy;</a> <a href="http://inlineshots.info/support/index.php?id=shoutv2">support </a></div></TD>
	</TR>
	<TR>
		<TD>&nbsp;			</TD>
	</TR>
</TABLE>
<br>
