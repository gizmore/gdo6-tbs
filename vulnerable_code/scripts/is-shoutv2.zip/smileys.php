<script type="text/javascript" >
function addsmiley(code)
{
var pretext = document.post.message.value;
this.code = code;
document.post.message.value = pretext + code;
}
</script>
<img src="smileys/smiling.gif" width="20" height="20" border="0" style="cursor:pointer;border:0" onClick="addsmiley(':)')"> <img src="smileys/sad.gif" width="20" height="20" border="0" style="cursor:pointer;border:0" onClick="addsmiley(':(')"> <img src="smileys/tongue.gif" width="20" height="20" border="0" style="cursor:pointer;border:0" onClick="addsmiley(':P')">
<img src="smileys/grin.gif" width="20" height="20" border="0" style="cursor:pointer;border:0" onClick="addsmiley(':D')">