<script type="text/javascript" >
function addsmiley(code)
{
var pretext = document.post.message.value;
this.code = code;
document.post.message.value = pretext + code;
}
</script>
<form method="post" action="shout.php" name="post">
  <table width="100%"  border="0" cellspacing="0">
    <tr>
      <td class="posttable">Name 
        <input name="nom" type="text" id="nom" class="form"></td>
    </tr>
    <tr>
      <td class="posttable">Url        
      <input name="url" type="text" id="url" class="form"></td>
    </tr>
    <tr>
      <td class="posttable">Message 
        <input name="message" type="text" id="message" class="form">
      <br>
      <? include("smileys.php"); ?></td>
    </tr>
    <tr>
      <td><input name="shout!" type="submit" id="shout!" value="Shout!">      </td>
    </tr>
  </table>
</form>

