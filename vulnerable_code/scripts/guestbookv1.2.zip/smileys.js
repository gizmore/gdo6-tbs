
<!--
function addsmiley(code)
{
var pretext = document.guestbook.message.value;
              this.code = code;
              document.guestbook.message.value = pretext + code;
}
//-->


