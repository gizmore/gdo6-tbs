
<form name="form1" method="post" action="">
  <input name="message" type="text" id="message">
</form>
<?

$message = str_replace(":mad:","<img src='smileys/mad.gif'>",$message);
$message = str_replace(":)","<img src='smileys/smiling.gif'>",$message);
$message = str_replace(":(","<img src='smileys/sad.gif'>",$message);


?>