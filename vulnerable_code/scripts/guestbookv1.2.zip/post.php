<?php
//where shout data is stored must be CHOMDED to 777
$dataf = "posts.txt";
//max length of input
$length = 500;
$comments = 1000;


if (!$name)
{ $name = "Anonymous"; }
else $name .= ":";
if (!$email)
{ $email = "Hidden"; }
else $email .= ":";
if (!$url)
{ $url = "None"; }
else $url .= ":";


$message = str_replace(":mad:","<img src='smileys/mad.gif'>",$message);
$message = str_replace(":)","<img src='smileys/smiling.gif'>",$message);
$message = str_replace(":(","<img src='smileys/sad.gif'>",$message);
$message = str_replace("fuck","****",$message);
$message = str_replace("bitch","****",$message);
$message = str_replace("asshole","****",$message);
$message = str_replace("cunt","****",$message);
$message = str_replace("bullshit","****",$message);
$message = str_replace("shit","****",$message);
$message = stripslashes($message);
$comfile = file($dataf);

if ($message != "") {$df = fopen ($dataf, "w");
$message = stripslashes($message);fwrite ($df, "<table width='100%' border='1' cellspacing='0' bordercolor='#000000'>
  <tr>
    <td width='51'><strong>name</strong></td>
    <td width='928'>$name</td>
  </tr>
  <tr>
    <td><strong>email</strong></td>
    <td><i><a href='mailto:$email'>$email</a></i></td>
  </tr>
  <tr>
    <td><strong>website</strong></td>
    <td><a href='$url' target='_blank'>$url</a></td>
  </tr>
  <tr height='100%'>
    <td><strong>message</strong></td>
    <td>$message</td>
  </tr>
</table>
<br>");
for ($i = 0; $i < $comments; $i++) {fwrite ($df, $comfile[$i]);}fclose($df);}
Header("Location: $HTTP_REFERER");
?>


