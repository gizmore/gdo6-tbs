upload all files and CHOMD posts.txt to 777 

if you have any problems then please contact http://inlineshots.info