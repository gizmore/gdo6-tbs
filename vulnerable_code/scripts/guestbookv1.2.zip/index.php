<HEAD>
<script type="text/javascript" src="smileys.js"></script>
<title>::INLINESHOTS.INFO-GUESBOOK SCRIPT::</title></HEAD><table width="100%" border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="432"><form name="guestbook" action="post.php" method="post">
      <p>name
          <input name="name" type="text" id="name">
          <br>
    email
    <input name="email" type="text" id="email">
    <br>
    web
    <input name="url" type="text" id="url">
    <br>
    <br>
    <strong>smileys::<span class="style2"> <img src="smileys/smiling.gif" alt=":)" width="15" height="15" style="cursor:pointer;border:0" onClick="addsmiley(':)')" /></span> | <img src="smileys/sad.gif" width="15" height="15" style="cursor:pointer;border:0" onClick="addsmiley(':(')"> | <img src="smileys/mad.gif" width="15" height="15" style="cursor:pointer;border:0" onClick="addsmiley(':mad:')"> </strong><br>
    message::<br>
    <textarea name="message" id="message"></textarea>
      </p>
      <p>
        <input type="submit" name="Submit" value="Submit">
        <input type="reset" name="Reset" value="Reset">
      </p>
    </form></td>
  </tr>
</table>
<br>
<table width="100%" border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td class="style3"><em><strong>Entries</strong></em>::</td>
  </tr>
  <tr>
    <td><? include("posts.txt"); ?></td>
  </tr>
</table>
<p><br>
</p>
<p>&nbsp;</p>
