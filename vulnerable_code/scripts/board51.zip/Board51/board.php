<?php

/* board #51 1.1a
   by Daniel Zahn
   parts of forum51 v2.6b
   started in September 2002
   LL&PYD laforge */

//-------------------------------------------------------------------------------VARCONTAINER

//GET CONFIG AND SAMPLE IN ARRAY "CONFIG"
  $config = array();
  $getconfig= fopen("boarddata/data/config.idx","r");
  while (!feof($getconfig)){ $value = fgets($getconfig,1000);
  $wert = trim($value);
  array_push($config,$wert); }
  fclose ($getconfig);

  //STANDARD VARIABLES
  $time    = time();
  $ip      = $REMOTE_ADDR;
//-------------------------------------------------------------------------------END

//-------------------------------------------------------------------------------ONLINE COUNTER
$ff1 = "boarddata/data/file.txt"; $ff2 = "boarddata/data/temp.txt"; $ip = $REMOTE_ADDR; $time = time(); $delay = 300;
if (file_exists($ff1)) { sync($ff1,$ff2,$ip,$time,$delay,$o_key); } else { $first = fopen($ff1,"w");
fwrite($first,$time.";".$ip."\n");
//$online = 1;
//output($online,$o_key);
}
function sync($ff1,$ff2,$ip,$time,$delay,$o_key)
{
 $save = fopen($ff2,"a+");
 $proof = fopen($ff1,"r");
 while ($line = fgetcsv($proof, 1000, ";")) {$row = count($line); for ($i=1; $i<$row; $i++)
 {
 if ($line[1]<>$ip) { if ($line[0]>$time-$delay) { fwrite($save,$line[0].";".$line[1]."\n"); } }
 } }
 fwrite ($save,$time.";".$ip."\n");
 fclose($proof);
 fclose($save);
 @unlink($ff1);
 @rename($ff2,$ff1);
 @unlink($ff2);
}
//-------------------------------------------------------------------------------END


//-------------------------------------------------------------------------------AFFAIRS
if ($selfdestruct=="YES")   {$vars="1"; selfdestruct($mycookie,$usercookie,$config);}
if ($func=="selfdestruct")  {$vars="1"; if ($mycookie<>2) { echo "NO ACCESS ALLOWED";}else{echo "<META http-equiv='Refresh' content='0; url=$config[53]error.php?func=selfdestruct'>";}}
if ($func=="hndlforum")     {$vars="1"; hndlforum($mycookie,$usercookie,$config,$forum); }
if ($func==$config[24])     {$vars="1"; save_edit_forum($mycookie,$usercookie,$config,$forum,$theme,$nfo,$status);}
if ($func=="editforum")     {$vars="1"; edit_forum($mycookie,$usercookie,$config,$forum);}
if ($func=="delforum")      {$vars="1"; del_forum($mycookie,$usercookie,$config,$forum); }
if ($func=="newforum")      {$vars="1"; new_forum($mycookie,$usercookie,$config); }
if ($func=="Forum erstellen"){$vars="1"; save_forum($mycookie,$usercookie,$config,$name,$description,$ename,$etext,$status); }

if ($func==$config[94])     {$vars="1"; login($time,$username,$password,$mycookie,$usercookie,$config); }
if ($func=="Registrieren")      {$vars="1"; signup($nickname,$email,$icq,$passworda,$passwordb,$mycookie,$usercookie,$config,$pic); }
if ($func==$config[66])     {$vars="1"; signupnow($nickname,$email,$icq,$passworda,$passwordb,$status,$mycookie,$config,$pic); }
if ($func=="back"|$func=="Abbrechen")    {$vars="1"; goback();}
if ($func=="Zur�ck" or $func=="back2")   {$vars="1";  if ($id) 	  { echo "<META http-equiv='Refresh' content='0; url=board.php?func=showpost&id=$id&status=$status&forum=$forum&theme=$theme'>"; die;}
                                                      if ($forum) { echo "<META http-equiv='Refresh' content='0; url=board.php?func=listthread&forum=$forum'>";} else { goback();}}
if ($func=="rules")         {$vars="1"; $noforum=true; rules($config,$mycookie,$usercookie,$noforum); }
if ($func=="configuration") {$vars="1"; configuration($mycookie,$usercookie,$config); }
if ($func==$config[84])     {$vars="1"; saveconfig($mycookie,$usercookie,$config,$c0,$c1,$c2,$c3,$c4,$c5,
$c6,$c7,$c8,$c9,$c10,$c11,$c12,$c13,$c14,$c15,$c16,$c17,$c18,$c19,$c20,$c21,$c22,$c23,$c24,$c25,$c26,$c27,
$c28,$c29,$c30,$c31,$c32,$c33,$c34,$c35,$c36,$c37,$c38,$c39,$c40,$c41,$c42,$c43,$c44,$c45,$c46,$c47,$c48,
$c49,$c50,$c51,$c52,$c53,$c54,$c55,$c56,$c57,$c58,$c59,$c60,$c61,$c62,$c63,$c64,$c65,$c66,$c67,$c68,$c69,
$c70,$c71,$c72,$c73,$c74,$c75,$c76,$c77,$c78,$c79,$c80,$c81,$c82,$c83,$c84,$c85,$c86,$c87,$c88,$c89,$c90,
$c91,$c92,$c93,$c94,$c95,$c96,$c97,$c98,$c99,$c100,$c101,$c102,$c103); }

if ($func=="newthread")     {$vars="1"; new_thread($time,$mycookie,$id,$usercookie,$config,$forum);}
if ($func=="Senden")        {$vars="1"; sended_thread($time,$mycookie,$usercookie,$thema,$text,$config,$forum); }
if ($func=="editthread")    {$vars="1"; edit_thread($time,$mycookie,$id,$usercookie,$config,$forum); }
if ($func=="�nderung speichern")   {$vars="1"; save_thread($time,$mycookie,$id,$usercookie,$idtimestamp,$theme,$config,$forum); }
if ($func=="delthread")     {$vars="1"; del_thread($time,$mycookie,$id,$usercookie,$config,$forum); }
if ($func=="prethread")     {$vars="1"; preview_thread($time,$mycookie,$id,$usercookie,$config);}
if ($func=="hndlthread")    {$vars="1"; handle_thread($time,$mycookie,$id,$usercookie,$config,$forum);}
if ($func=="listthread")    {$vars="1"; list_thread($mycookie,$usercookie,$config,$forum);}

if ($func=="newpost")       {$vars="1"; new_post($time,$mycookie,$usercookie,$id,$theme,$status,$config,$forum); }
if ($func=="Absenden")      {$vars="1"; sended_post($time,$mycookie,$usercookie,$id,$status,$theme,$text,$config,$forum);}
if ($func=="showpost")      {$vars="1"; show_post($time,$mycookie,$id,$theme,$usercookie,$status,$config,$forum);}
if ($func=="editpost")      {$vars="1"; edit_post($time,$mycookie,$id,$config,$theme,$usercookie,$forum); }
if ($func=="delpost")       {$vars="1"; del_post($time,$mycookie,$id,$secid,$config,$theme,$forum); }
if ($func=="prepost")       {$vars="1"; preview_post($time,$mycookie,$id,$config);}
if ($func=="Abspeichern")   {$vars="1"; writeedit($time,$mycookie,$usercookie,$id,$text,$config,$theme,$secid,$forum); }

if ($func=="forgotpw")  {$vars="1"; forgot_password($time,$mycookie,$id,$usercookie,$config);}
if ($func=="profile")   {$vars="1"; show_userprofil($time,$mycookie,$id,$usercookie,$config,$profile);}
if ($func=="statistic") {$vars="1"; show_statistic($time,$mycookie,$config,$usercookie,$config); }
if ($func=="delcookies"){$vars="1"; delete_cookies($mycookie,$usercookie,$config);}
if ($func=="goback")    {$vars="1"; goback($forum);}

if ($func=="Profil �ndern") {$vars="1"; edit_user($time,$mycookie,$usercookie,$id,$password,$firstaid,$name,$config); }
if ($func=="Speichern")     {$vars="1"; writepassed($time,$mycookie,$usercookie,$id,$nickname,$email,$icq,$password,$status,$posts,$lastpost,$active,$keyflip,$keyflip2,$md5key,$config,$pic); }
if ($func=="showusers") {$vars="1"; show_users($time,$mycookie,$usercookie,$config);}
if ($func=="unblockuser"){$vars="1"; unblock_user($time,$mycookie,$id,$usercookie,$config); }
if ($func=="blockuser") {$vars="1"; block_user($time,$mycookie,$id,$usercookie,$config); }
if ($func=="edituser")  {$vars="1"; edit_user($time,$mycookie,$usercookie,$id,$password,$firstaid,$name,$config); }
if ($func=="deluser")   {$vars="1"; del_user($time,$mycookie,$id,$usercookie,$config); }
if ($func=="Delete")    {$vars="1"; delusernow($id,$mycookie,$usercookie,$config); }
if ($func=="Cancel")    {$vars="1"; show_users($time,$mycookie,$usercookie,$config);}
if ($func=="mailit")    {$vars="1"; mailit($time,$mycookie,$usercookie,$id,$config);}
if ($func=="Send Message") {$vars="1"; sendthismail($mycookie,$usercookie,$id,$subject,$text,$config); }

if (empty($vars))       { if($config[75]=="0") { if($usercookie) {list_forum($mycookie,$usercookie,$config);} else
                                                                 {login_now($mycookie,$usercookie,$config); }
                                               } else            {list_forum($mycookie,$usercookie,$config); }
						}

//-------------------------------------------------------------------------------END

function login($time,$username,$password,$mycookie,$usercookie,$config)//--------LOGIN
{
 $proof = fopen($config[34],"r");
   while ($zeile = fgetcsv($proof, 1000, ";"))
   {
	 $spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	 {
     if ($username==$zeile[0]) { $md5pass = md5($password); if ($md5pass==$zeile[3]) { $status=$zeile[4]; $name=$zeile[0]; make_cookie($status,$name,$password); } else {

	 $schreiben = fopen($config[40],"a");
	 fwrite ($schreiben,$password.",");
	 fclose ($schreiben);
	  //Statistik
     $schreiben=fopen($config[36],"w");
     $holen=fopen($config[41],"r");
     while ($zeile = fgetcsv($holen, 1000, ";"))
     {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	 { $newvar = $zeile[2]+1;
	 fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$newvar.";".$zeile[3]."\n"); }}
	 fclose($holen); fclose ($schreiben); unlink($config[41]); rename ($config[36], $config[41]);
	 goback($forum); }}

	 }
   }
   goback($forum);
   fclose($proof);
}//------------------------------------------------------------------------------END

//-------------------------------------------------------------------------------SIGN UP
function signup($nickname,$email,$icq,$passworda,$passwordb,$mycookie,$usercookie,$config,$pic)
{
include ($config[42]);
if (empty($loggedip)) {
   echo "
         <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
         <td class=signup1><FONT class=one><FORM action='board.php' method='post' name='flowforever'>
         <b>$config[61]</td>
		 <td class=signup2><FONT class=two>";
		 if ($nickname==" ") { echo "&nbsp;<INPUT type=text size=50 class=normal name=nickname></td><tr>"; } else
		                       { echo "&nbsp;<INPUT type=text size=50 class=normal name=nickname value='$nickname'></td><tr>";}
   echo "<td class=signup1><FONT class=one>
         <b>$config[62]</td>
		 <td class=signup2><FONT class=two>";
		 if ($email==" ") { echo "&nbsp;<INPUT type=text size=50 class=normal name=email></td><tr>";} else
		                    { echo "&nbsp;<INPUT type=text size=50 class=normal name=email value='$email'></td><tr>"; } echo "
		 <td class=signup1><FONT class=one>
         <b>$config[63]</td>
         <td class=signup2><FONT class=two>";
		 if ($icq==" ") { echo "&nbsp;<INPUT type=text size=50 class=normal name=icq></td><tr>";} else
		                  { echo "&nbsp;<INPUT type=text size=50 class=normal name=icq value='$icq'></td><tr>"; } echo "
         <td class=signup1><FONT class=one>
         <b>$config[89]</td>
         <td class=signup2><FONT class=two>";
		 if ($pic) { echo "<IMG src='$pic' alt='User-Picture' width=50 height=40 border=0 align=right>";} else
		           { echo "<IMG src='$config[92]' alt='No User-Picture' width=50 height=40 border=0 align=right>";}
		 if ($pic==" ") { echo "&nbsp;<INPUT type=text size=50 class=normal name=pic></td><tr>";} else
		                  { echo "&nbsp;<INPUT type=text size=50 class=normal name=pic value='$pic'><br>
						          <FONT size=1>
						          &nbsp;$config[90]<br>
								  &nbsp;$config[91]</FONT></td><tr>"; }
if ($mycookie=="2") {
   echo "<td class=signup1><FONT class=one>
         <b>Status</td>
         <td class=signup2><FONT class=two>
		 &nbsp;<SELECT name=status class=normal>
		       <OPTION name=status value='1'>$config[96]</option>
			   <OPTION name=status value='2'>$config[95]</option>
			   <OPTION name=status value='3'>$config[97]</OPTION></SELECT></td><tr>"; } echo "
		 <td class=signup1><FONT class=one>
         <b>$config[64]</td>
         <td class=signup2><FONT class=two>";
		 if ($passworda==" " || $passworda=="") { echo "&nbsp;<INPUT type=password size=50 class=normal name=passworda></td><tr>"; } else
		                        { echo "&nbsp;<INPUT type=text size=50 class=normal name=passworda value='$passworda'></td><tr>"; } echo "
		 <td class=signup1><FONT class=one>
         <b>$config[65]</td>
         <td class=signup2><FONT class=two>";
		 if ($passwordb==" " || $passworda=="") { echo "&nbsp;<INPUT type=password size=50 class=normal name=passwordb></td><tr>"; } else
		                        { echo "&nbsp;<INPUT type=text size=50 class=normal name=passwordb value='$passwordb'></td><tr>";} echo "
		 <td class=signup1><FONT class=one></td>
         <td class=signup2><FONT class=two>
		 &nbsp;<INPUT type=submit name=func value='$config[66]' class=normal>&nbsp;&nbsp;
		       <INPUT class=normal type='reset' name=reset value='L�schen'>&nbsp;&nbsp;
		       <INPUT class=normal type='submit' name=func value='Zur�ck'></FORM></td></tr></table>";
		 }
include ($config[67]);
}//------------------------------------------------------------------------------END

//-------------------------------------------------------------------------------SIGN UP NOW
function signupnow($nickname,$email,$icq,$passworda,$passwordb,$status,$mycookie,$config,$pic)
{

$res = time();
$ret = gmdate("d M Y", $res);
$proof = fopen($config[34],"r");
  while ($zeile = fgetcsv($proof, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++){
	 if ($nickname==$zeile[0]) { $nickname = $config[43]; $error="1";}	 }}
 fclose($proof);
if (empty($pic))      { $pic = $config[92];}
if (empty($nickname)) { $nickname = $config[44]; $error="1";}
if (empty($email))    { $email = $config[45]; $error="1";}
if (empty($icq) or $icq=="0" or $icq=="" or $icq==" ") { $icq = "0"; }
if (empty($passworda)){ $passworda = $config[47]; $error="1";}
if (empty($passwordb)){ $passwordb = $config[48]; $error="1";}
if ($passworda<>$passwordb) { $passwordb = "`$passwordb` is different from `$passworda`"; $error="1"; }
if ($error=="1") { signup($nickname,$email,$icq,$passworda,$passwordb,$status,$mycookie,$config,$pic); }
if ($passworda==$passwordb) { $password = md5($passworda); }
if (empty($error)) {
$writeit = fopen($config[34],"a");
if ($mycookie=="2") { fwrite ($writeit,$nickname.";".$email.";".$icq.";".$password.";".$status.";0;0;".$ret.";".$res.";".$pic."\n"); } else {
fwrite ($writeit,$nickname.";".$email.";".$icq.";".$password.";1;0;0;".$ret.";".$res.";".$pic."\n"); }
fclose ($writeit);
echo "<META http-equiv='Refresh' content='0; url=board.php'>";
}
}//------------------------------------------------------------------------------END

function show_users($time,$mycookie,$usercookie,$config) //----------------------SHOW USERS
{
$noforum=true;
include ($config[42]);
echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
      <tr>
      <td bgcolor=$config[72] valign=top width=22%><FONT class=one><b>$config[61]</b></td>
	  <td bgcolor=$config[73] valign=top width=11%><FONT class=one><b>$config[62]</b></td>
 	  <td bgcolor=$config[73] valign=top width=14%><FONT class=one><b>$config[63]</b></td>
 	  <td bgcolor=$config[73] valign=top width=2%><FONT class=one><b>$config[27]</b></td>
  	  <td bgcolor=$config[73] valign=top width=2%><FONT class=one><b>$config[30]</b></td>
  	  <td bgcolor=$config[73] valign=top width=15%><FONT class=one><b>$config[26]</b></td>
 	  <td bgcolor=$config[73] valign=top width=14%><FONT class=one><b>$config[93]</b></td>
  	  <td bgcolor=$config[72] valign=top width=14%><FONT class=one><b>$config[89]</b></td>";
if ($mycookie=="2") { echo "
      <td bgcolor=$config[72] valign=top width=15% align=center><FONT class=one><b>$config[101]</b></td>"; }
$list = fopen($config[34],"r");
while ($zeile = fgetcsv($list, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++){

echo "<tr>
      <td bgcolor=$config[72] valign=center width=22%><FONT class=one>&nbsp;<A href='board.php?func=profile&id=$zeile[0]'>$zeile[0]</A></b></td>
	  <td bgcolor=$config[73] valign=center width=11%>&nbsp;<A href='board.php?func=mailit&id=$zeile[0]'><IMG src='$config[14]' border=0 align=middle></A>&nbsp;&nbsp;<A href='mailto:$zeile[1]'><IMG src='$config[15]' border=0 align=middle></A>&nbsp;</td>";
if ($zeile[2]<>"0") {	echo "
 	  <td bgcolor=$config[73] valign=center width=14%><FONT class=one>&nbsp;<A href='http://wwp.mirabilis.com/scripts/Search.dll?to=$zeile[2]'>$zeile[2]</A></b></td>";
	                } else
					{   echo "
 	  <td bgcolor=$config[73] valign=center width=14%><FONT class=one>&nbsp;$config[46]</b></td>";
	                }	echo "
 	  <td bgcolor=$config[73] valign=center width=2%><FONT class=one>&nbsp;";
if ($zeile[4]=="1") { echo "$config[96]"; } if ($zeile[4]=="2") { echo "$config[100]"; } if ($zeile[4]=="3") { echo "$config[97]"; }
echo "</b></td>
  	  <td bgcolor=$config[73] valign=center align=center width=2%><FONT class=one>$zeile[5]</b></td>";
if ($zeile[5]=="0") { echo "
  	  <td bgcolor=$config[73] valign=center width=14%><FONT class=one>&nbsp;kein Eintrag</b></td>"; } else { echo "
  	  <td bgcolor=$config[73] valign=center width=15%><FONT class=one>$zeile[6]</b></td>"; }
echo "<td bgcolor=$config[73] valign=center width=14%><FONT class=one>$zeile[7]</b></td>";

echo "</td><td bgcolor=$config[72] valign=center width=12% align=center>";
if (@fopen($zeile[9],"r")){ echo "<IMG src='$zeile[9]' width=50 height=40 alt='$config[96]-Picture' border=0 align=center>"; } else
              { echo "<IMG src='$config[92]' width=50 height=40 alt='$config[96]-Picture' border=0 align=center>"; }

if ($mycookie=="2") { echo "
      <td bgcolor=$config[72] valign=top width=15% align=left><FONT class=one>
	  <A class=imp href='board.php?func=edituser&id=$zeile[8]&name=$zeile[0]'>&nbsp;edit</A><br>
	  <A class=imp href='board.php?func=deluser&id=$zeile[0]'>&nbsp;del</A><br>";
if ($zeile[4]=="3") { echo "<A class=imp href='board.php?func=unblockuser&id=$zeile[0]'>&nbsp;unblock</A>"; }	else
	                { echo "<A class=imp href='board.php?func=blockuser&id=$zeile[0]'>&nbsp;block</A>"; }	}
} }
fclose($list);
echo "</td></tr></table>";
include ($config[67]);
} //-----------------------------------------------------------------------------END

//-------------------------------------------------------------------------------EDIT USER
function edit_user($time,$mycookie,$usercookie,$id,$password,$firstaid,$name,$config)
{
if ($mycookie=="2") {
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($id == $zeile[8]) { if ($name==$usercookie){$password = $firstaid;} else { $password = $zeile[3]; } ; passed($time,$mycookie,$usercookie,$id,$password,$config,$pic,$forum); }
    }
   }
fclose($holen); } else {

$md5pass = md5($password);
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($id == $zeile[8]) { if ($md5pass==$zeile[3]) { setcookie("keyflip2",$zeile[4]); passed($time,$mycookie,$usercookie,$id,$password,$config,$pic,$forum); } else { goback(); } }
    }
   }
fclose($holen);
}
} //-----------------------------------------------------------------------------END

function passed($time,$mycookie,$usercookie,$id,$password,$config,$pic,$forum) { //-----PASSED

$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($id == $zeile[8]) {
include ($config[42]);
   echo "<FORM action='board.php' method=post name=flowforever>
         <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
         <td bgcolor=$config[73] width=18% valign=center align=right><FONT class=one>
         <b>Nickname</td>
		 <td bgcolor=$config[72] width=83% valign=top><FONT class=two>
		 &nbsp;<INPUT type=text size=50 class=normal name=nickname value='$zeile[0]'></td><tr>
		 <td bgcolor=$config[73] width=18% valign=center align=right><FONT class=one>
         <b>eMail</td>
		 <td bgcolor=$config[72] width=83% valign=top><FONT class=two>
		 &nbsp;<INPUT type=text size=50 class=normal name=email value='$zeile[1]'></td><tr>
		 <td bgcolor=$config[73] width=18% valign=center align=right><FONT class=one>
         <b>ICQ</td>
         <td bgcolor=$config[72] width=83% valign=top><FONT class=two>
		 &nbsp;<INPUT type=text size=50 class=normal name=icq value='$zeile[2]'></td><tr>";

echo "   <td bgcolor=$config[73] width=18% valign=top align=right><FONT class=one>
         <b>$config[89]</td>
         <td bgcolor=$config[72] width=83% valign=top><FONT class=two>";
		 if (@fopen($zeile[9],"r")) { echo "<IMG src='$zeile[9]' alt='$config[96]-Picture' width=50 height=40 border=0 align=right>";} else
		                            { echo "<IMG src='$config[92]' alt='No $config[96]-Picture' width=50 height=40 border=0 align=right>";}
echo "&nbsp;<INPUT type=text size=50 class=normal name=pic value='$zeile[9]'><br>
						          <FONT size=1>
						          &nbsp;$config[90]<br>
								  &nbsp;$config[91]</FONT></td><tr>";
echo "  <td bgcolor=$config[73] width=18% valign=center align=right><FONT class=one>";
		 if ($mycookie=="2") {
         if ($zeile[0]<>$usercookie) {echo "<b>MD5-String</td><td bgcolor=$config[72] width=83% valign=top><FONT class=two>";} else {echo"<b>Password</td><td bgcolor=$config[72] width=83% valign=top><FONT class=two>";}
		                     } else {
   echo "<b>Password</td>
         <td bgcolor=$config[72] width=83% valign=top><FONT class=two>";
		                            }
         if ($mycookie=="2") {
         if ($zeile[0]<>$usercookie) {echo "&nbsp;<INPUT type=text size=50 class=normal name=password value='$zeile[3]'>


		 &nbsp;&nbsp;<INPUT type=text size=40 class=normal name=newpw value='Neues Password'>
		 </td><tr>"; $key="2";} else
		                             {echo "&nbsp;<INPUT type=text size=50 class=normal name=password value='$password'></td><tr>"; $key="1";}} else
									 {echo "&nbsp;<INPUT type=text size=50 class=normal name=password value='$password'></td><tr>"; $key="1";}
if ($mycookie=="2") {
   echo "<td bgcolor=$config[73] width=18% valign=center align=right><FONT class=one>
         <b>Status (!!!)</td>
         <td bgcolor=$config[72] width=83% valign=top><FONT class=two>
		 &nbsp;<SELECT name=status class=normal>
		       <OPTION name=status value='1'>$config[96]</option>
			   <OPTION name=status value='2'>$config[95]</option>
			   <OPTION name=status value='3'>$config[97]</OPTION></SELECT></td><tr>"; }
   echo "<td bgcolor=$config[73] width=18% valign=center align=right><FONT class=one></td>
         <td bgcolor=$config[72] width=83% valign=top><FONT size=1>&nbsp;</FONT>
		 <INPUT type=submit name=func value='Speichern' class=normal>
		 <INPUT type=hidden name=md5key value='$key'>
         <INPUT type=hidden name=posts value='$zeile[5]'>
		 <INPUT type=hidden name=lastpost value='$zeile[6]'>
		 <INPUT type=hidden name=active value='$zeile[7]'>
		 <INPUT type=hidden name=keyflip value='$zeile[8]'>
		 </td></tr></table></FORM>";
     }}
   }
fclose($holen);
include ($config[67]);
} //-----------------------------------------------------------------------------END

function writepassed($time,$mycookie,$usercookie,$id,$nickname,$email,$icq,$password,$status,$posts,$lastpost,$active,$keyflip,$keyflip2,$md5key,$config,$pic)
{
if(empty($status)) { $status=$keyflip2 ; }
$sichern = fopen($config[53]."temp.tmp","w");
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($keyflip<>$zeile[8]) {
	 fwrite ($sichern,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
	                           } } }
fclose($holen);
fclose($sichern);
unlink ($config[34]);

if ($md5key=="1") {$md5pass = md5($password);}
if ($md5key=="2") {$md5pass = $password; }

$writeit = fopen($config[34],"w");
fwrite ($writeit,$nickname.";".$email.";".$icq.";".$md5pass.";".$status.";".$posts.";".$lastpost.";".$active.";".$keyflip.";".$pic."\n");
fclose ($writeit);

$write = fopen($config[34],"a");
$holen = fopen($config[53]."temp.tmp","r");
while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	 {fwrite ($write,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
	 }
   }
fclose($holen);
fclose($write);
unlink($config[53]."temp.tmp");
  echo "<META http-equiv='Refresh' content='0; url=board.php?func=showusers'>";
}//------------------------------------------------------------------------------END

function make_cookie($status,$name,$password) //---------------------------------MAKE COOKIE
{
   setcookie("mycookie",$status);
   setcookie("usercookie",$name);
   setcookie("firstaid",$password);
   goback($forum);
}

function delete_cookies($mycookie,$usercookie,$config)//-------------------------DELETE COOKIES
{ setcookie ("mycookie");
  setcookie ("usercookie");
  goback($forum);
} //-----------------------------------------------------------------------------END


function list_forum($mycookie,$usercookie,$config) //---------------------------LIST FORUM
{
$noforum=true;
$noback=true;
include ($config[42]);

//Create Title.Bar
echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
	  <td width=55% bgcolor=$config[74] valign=top><FONT class=two><b>&nbsp;$config[12]</td>
	  <td width=15% bgcolor=$config[74] valign=center><FONT class=one><FONT size=1><b>$config[25]</b></FONT></td>
	  <td width=20% bgcolor=$config[74] align=left><FONT class=one><FONT size=1><b>$config[26]</b></FONT></td>
	  <td width=5%  bgcolor=$config[74] align=center><FONT class=one><FONT size=1><b>Threads</b></FONT></td>
	  <td width=5%  bgcolor=$config[74] align=center><FONT class=one><FONT size=1><b>Eintr�ge</b></FONT></td>
	  <td width=5%  bgcolor=$config[74] align=center><FONT class=one><FONT size=1><b>$config[27]</b></FONT></td>";
//Call Forenliste
$foren = fopen($config[51],"r");
while ($zeile = fgetcsv($foren, 1000, ";")){
$spalten = count($zeile);for ($i=3; $i<$spalten; $i++){
//L�sche Thread-Counter
$count=0;
$iptimer=0;

      //Call Thread
      $threads = @fopen($config[53].$zeile[0].".csv","r");
      while ($aa = @fgetcsv($threads, 1000, ";")){
      $rowa = count($aa);for ($ia=8; $ia<$rowa; $ia++){
      //Thread-Counter
      $count++;
      //Firsttimer zur�cksetzen

      //All-Post-Counter
      $allposts = $allposts+$aa[6];

        //Pr�fe auf File
	if (file_exists($config[53].$aa[0].".dat")) {

	//Call Posts
      	$posts = fopen($config[53].$aa[0].".dat","r");
      	while ($ab = fgetcsv($posts, 1000, ";")){
      	$rowb = count($ab);for ($ib=1; $ib<$rowb; $ib++){
	if ($iptimer==0) { $lastdate=$ab[0]; $lastname=$ab[1]; $iptimer=1;}
      	}}fclose($posts);                           }

      }}@fclose($threads);

//Create Bar
    echo "<tr><td width=55% bgcolor=$config[73] valign=center>
	  <table class=tb1 cellpadding=0 cellspacing=0 border=0><tr><td><FONT class=two>
	  <A href='board.php?func=listthread&forum=$zeile[0]'>";
	  $theme = stripslashes($zeile[2]); echo "<b>".$theme."</b><br>";

//Hole Forum-Thema aus Datei und schreibe...
  $holentext = fopen($config[53].$zeile[0].".nfo","r");
  while (!feof($holentext)){
  $text = fgets($holentext,1000);
  $newtext = stripslashes($text);
  echo "$newtext";
  }
  fclose ($holentext);

//sub.e
          echo "</A></FONT></td></tr></table></td>
	        <td width=15% bgcolor=$config[73] valign=center><FONT class=two><FONT size=1>".gmdate("<b>d M Y</b>",$zeile[0])."<br>".gmdate("h:m:s",$zeile[0])."</FONT></FONT></td>
		<td width=20% bgcolor=$config[73] valign=center><FONT class=two><FONT size=1>".gmdate("<b>d m y</b> - h:m:s",$lastdate)."<br> von $lastname</FONT></FONT></td>
      		<td width=5% bgcolor=$config[73] valign=center align=center><FONT class=two>$count</FONT></td>
                <td width=5% bgcolor=$config[73] valign=center align=center><FONT class=two>$allposts</FONT></td>";
if ($zeile[3]=="1")
     {echo "<td width=5% bgcolor=$config[73] valign=center align=center><IMG src='boarddata/gfx/badmin.jpg' border=0 alt='Nur $config[95] haben Zugriff!'></td>"; } else
	 {echo "<td width=5% bgcolor=$config[73] valign=center align=center><IMG src='boarddata/gfx/admin.jpg' border=0  alt='Alle Benutzer haben Zugriff!'></td>"; }

if ($mycookie=="2")
     {echo "<tr><td width=55% bgcolor=$config[72] valign=middle>";
	  echo "<A href='board.php?func=delforum&forum=$zeile[0]'><IMG src='$config[9]' border=0 alt='Delete Thread'></A>
	        <A href='board.php?func=editforum&forum=$zeile[0]'><IMG src='$config[6]' border=0 alt='Edit Thread'></A></td>
                <td width=15% bgcolor=$config[72]></td>
		<td width=20% bgcolor=$config[72]>&nbsp;</td>
		<td width=5% bgcolor=$config[72]>&nbsp;</td>
		<td width=5% bgcolor=$config[72]>&nbsp;</td>
    		<td width=5% bgcolor=$config[72] valign=middle align=center>";
if ($zeile[3]=="1")
            {echo "<A href='board.php?func=hndlforum&forum=$zeile[0]'><IMG src='boarddata/gfx/admin.jpg' border=0 valign=middle alt='Alle Benutzer haben Zugriff!'></A>";} else
      	    {echo "<A href='board.php?func=hndlforum&forum=$zeile[0]'><IMG src='boarddata/gfx/badmin.jpg' border=0 valign=middle alt='Nur Administratoren haben Zugriff!'></A>";}
	  echo "</td>"; }
   unset($allposts);
	 }
   }
   echo "</tr></table>";
  fclose ($foren);
  include ($config[67]);
}//-----------------------------------------------------------------------------END LIST FORUM

function list_thread($mycookie,$usercookie,$config,$forum) //-------------------LIST THREAD
{
include ($config[42]);


//Thementitel
 $tinfo = fopen($config[53]."actual.csv","r");
 while ($l = fgetcsv($tinfo, 1000, ";")){$row = count($l);

 for ($i=3; $i<$row; $i++){if ($l[0]==$forum){
echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[72] valign=middle width=18% align=center><FONT class=two><FONT size=3><b>$config[12]</b></FONT></FONT></td>
	  <td bgcolor=$config[72] valign=middle width=82%><FONT class=two><FONT size=3><b>&nbsp;$l[2]</td></tr></table><br>";
}}}fclose($tinfo);

//Zur�ck-Option oben
echo "<table width=$config[0] cellpadding=0 cellspacing=0 border=$config[4]><tr>
      <td valign=middle width=18% align=right><FONT class=two>";
if ($mycookie==1 or $mycookie==2) {echo "[ <A href='board.php?func=newthread&forum=$forum'>Neues Thema</A> ]&nbsp;&nbsp;&nbsp;";}
echo "[ <A href='board.php?func=back'>Zur�ck</A> ] &nbsp;</tr></table><br>";

// VERSUCH SECOND MENU END
//sub.e

echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
	  <td width=20% bgcolor=$config[74] valign=top><FONT class=two><b>&nbsp;$config[23]</td>
	  <td width=30% bgcolor=$config[74] valign=top><FONT class=two><b>&nbsp;$config[12]</td>
	  <td width=20% bgcolor=$config[74] valign=top><FONT class=one><b>$config[25]</td>
	  <td width=20% bgcolor=$config[74] align=top><FONT class=one><b>$config[26]</td>
	  <td width=5%  bgcolor=$config[74] align=center><FONT class=one><b>$config[30]</td>
	  <td width=5%  bgcolor=$config[74] align=center><FONT class=one><b>$config[86]</td>
	  <td width=5%  bgcolor=$config[74] align=center><FONT class=one><b>$config[27]</td>
	  ";
	  
//Access-Question
  $forums = fopen($config[51],"r");
  while ($zeile = fgetcsv($forums, 1000, ";")){$spalten = count($zeile);for ($i=3; $i<$spalten; $i++){
  if ($forum==$zeile[0]) { $status=$zeile[3];}}}fclose($forums);
  if ($mycookie<>2 && $status=="1") {echo "<META http-equiv='Refresh' content='0; url=$config[53]error.php?func=noaccess&forum=$forum'>"; die;}
  $threads = fopen($config[53].$forum.".csv","r");
  while ($zeile = fgetcsv($threads, 1000, ";"))
   {
	 $spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	 {
if (empty($zeile[2]))
     {echo "<tr><td bgcolor=$config[73] width=20% valign=center>&nbsp;<FONT class=two>$zeile[1]</FONT></td>";} else
     {echo "<tr><td bgcolor=$config[73] width=20% valign=center>&nbsp;<FONT class=two><A href='board.php?func=profile&id=$zeile[1]'>$zeile[1]</A></FONT></td>";}
      echo "<td width=30% bgcolor=$config[73] valign=center>
	        <table class=tb1 cellpadding=0 cellspacing=0 border=0><tr><td><FONT class=two>
	  <A href='board.php?func=showpost&id=$zeile[0]&theme=$zeile[2]&status=$zeile[4]&forum=$forum'>";
	  $theme = stripslashes($zeile[2]); echo $theme; echo "</A></FONT>
	        </td></tr></table>
	        </td>
	        <td width=20% bgcolor=$config[73] valign=center><FONT class=one>".gmdate("<b>d</b> M Y h:m:s",$zeile[0])."</td>";
if ($zeile[5]=="0") {echo "<td width=20% bgcolor=$config[73] valign=center><FONT class=one>$config[52]</td>"; } else {
	  echo "<td width=20% bgcolor=$config[73] valign=center><FONT class=one>".gmdate("<b>d</b> M Y h:m:s",$zeile[5])."</td>"; }
      echo "<td width=5% bgcolor=$config[73] valign=center align=center><FONT class=two>$zeile[6]</FONT></td>  
            <td width=5% bgcolor=$config[73] valign=center align=center><FONT class=two>$zeile[8]</FONT></td>"; //GELESEN
if ($zeile[4]=="1")
     {echo "<td width=5% bgcolor=$config[73] valign=center align=center><IMG src='$config[11]' border=0 valign=middle alt='closed thread'></td>"; } else
	 {echo "<td width=5% bgcolor=$config[73] valign=center align=center><IMG src='$config[10]' border=0 valign=middle alt='open thread'></td>"; }

if ($mycookie=="2")
     {echo "<tr><td width=20% bgcolor=$config[72] valign=middle>";
	  echo "<A href='board.php?func=delthread&id=$zeile[0]&forum=$forum'><IMG src='$config[9]' border=0 valign=middle alt='Delete Thread'></A></td>
			<td width=30% bgcolor=$config[72] valign=middle><A href='board.php?func=editthread&id=$zeile[0]&forum=$forum'><IMG src='$config[6]' border=0 valign=middle alt='Edit Thread'></A></td>
			<td width=20% bgcolor=$config[72]>&nbsp;</td>
			<td width=5% bgcolor=$config[72]>&nbsp;</td>
			<td width=5% bgcolor=$config[72]>&nbsp;</td>
			<td width=5% bgcolor=$config[72]>&nbsp;</td>
    		<td width=5% bgcolor=$config[72] valign=middle align=center>";
			if ($zeile[4]=="1")
            {echo "<A href='board.php?func=hndlthread&id=$zeile[0]&forum=$forum'><IMG src='$config[7]' border=0 valign=middle alt='Open Thread'></A>";} else
      	    {echo "<A href='board.php?func=hndlthread&id=$zeile[0]&forum=$forum'><IMG src='$config[8]' border=0 valign=middle alt='Close Thread'></A>";}
	  echo "</td>"; }
	 }
   }
   echo "</tr></table>";

//Zur�ck-Option unten
// VERSUCH SECOND MENU

echo "<br><table width=$config[0] cellpadding=0 cellspacing=0 border=$config[4]><tr>
      <td valign=middle width=18% align=right><FONT class=two>";
if ($mycookie==1 or $mycookie==2) {echo "[ <A href='board.php?func=newthread&forum=$forum'>Neues Thema</A> ]&nbsp;&nbsp;&nbsp;";}
echo "[ <A href='board.php?func=back'>Zur�ck</A> ] &nbsp;</tr></table>";

// VERSUCH SECOND MENU END
//sub.e
  fclose ($threads);
  include ($config[67]);
}//------------------------------------------------------------------------------END

function goback() { //-----------------------------------------------------------GO BACK
 echo "<META http-equiv='Refresh' content='0; url=board.php'>";
} //---------------------------------------------------------------------------END


//-------------------------------------------------------------------------------SHOW POSTs
function show_post($time,$mycookie,$id,$theme,$usercookie,$status,$config,$forum) {
 setcookie("secid",$id);
 if (file_exists($config[53].$id.".dat")) { } else {  echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=error404&forum=$forum'>"; }
$counter="0";

//-------------------------------------------------------------------------------LESE COUNTER <<
 $schreiben = fopen($config[36],"w"); 
 $schreiben2 = fopen($config[37],"w");
 $holen = fopen($config[53].$forum.".csv","r");
 while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	if ($id<$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($id>$zeile[0]) { fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($id==$zeile[0]){ $line0=$zeile[0]; $line1=$zeile[1]; $line2=$zeile[2]; $line3=$zeile[3]; $line4=$zeile[4]; $line5=$zeile[5]; $line6=$zeile[6]; $line7=$zeile[7]; $line8=$zeile[8]; }
    }
   } 
  fclose ($holen);
  fclose ($schreiben2);
  fclose ($schreiben);
  
  unlink ($config[53].$forum.".csv");
  $schreiben = fopen($config[53].$forum.".csv","w");
  $holen = fopen($config[36],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);

   $last = $line8 +1;
   
   $schreiben = fopen($config[53].$forum.".csv","a");
   fwrite ($schreiben,$line0.";".$line1.";".$line2.";".$line3.";".$line4.";".$line5.";".$line6.";".$line7.";".$last."\n");
   fclose ($schreiben);
   
  $schreiben = fopen($config[53].$forum.".csv","a");
  $holen = fopen($config[37],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   unlink($config[36]);
   unlink($config[37]);
//-------------------------------------------------------------------------------END <<

include ($config[42]);
echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[72] valign=middle width=18% align=center><FONT class=two><FONT size=3><b>$config[12]</b></FONT></FONT></td>
	  <td bgcolor=$config[72] valign=middle width=82%><FONT class=two><FONT size=3><b>&nbsp;$theme</td></tr></table><br>";

// TAB MENU
echo "<table width=$config[0] cellpadding=0 cellspacing=0 border=$config[4]><tr>
      <td valign=middle width=18% align=right><FONT class=two>";
if ($mycookie=="2" or $mycookie=="1") {
echo "[ <A href='board.php?func=newpost&id=$id&theme=$theme&status=$status&forum=$forum'>Neuer Beitrag</A> ]
&nbsp;&nbsp;[ <A href='board.php?func=newthread&id=$id&forum=$forum'>Neues Thema</A> ]&nbsp;&nbsp;&nbsp;"; }
echo "[ <A href='board.php?func=listthread&forum=$forum'>Zur�ck</A> ]</FONT></td></tr></table><FONT size=1><br></FONT>";
// TAB MENU END

$holen1 = fopen($config[53].$id.".dat","r");
while ($zeile = fgetcsv ($holen1, 1000, ";")) 
 { $spalten = count($zeile);
   for ($i=1; $i<$spalten; $i++) 	   
  { 
   $textid = $zeile[0];
   $author = $zeile[1];
 $counter++;
 $holen2 = fopen($config[34],"r");
 while ($zeile = fgetcsv ($holen2, 1000, ";")) 
 { $spalten = count($zeile);
   for ($i=$config[88]; $i<$spalten; $i++) 	   
  { 
  if ($author==$zeile[0]) { 
                            $email = $zeile[1]; 
                            $icq = $zeile[2];
							$status = $zeile[4];
							$posts = $zeile[5];
							$pic = $zeile[9];
						  }
  }
 }
 fclose($holen2);
  
  echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
        <tr><td bgcolor=$config[72] valign=top width=18%>
		<table width=105 border=0 valign=center align=center><tr><td valign=middle width=100%>
		
		<FONT class=two>";
   echo "<A href='board.php?func=profile&id=$author'><b>$author</b></A><br><br>"; 
  if(@fopen($pic,"r")) { echo "<IMG src='$pic' width=50 height=40 alt='$config[96]-Picture' border=0 align=center><br>";} else
                       { echo "<IMG src='$config[92]' width=50 height=40 alt='$config[96]-Picture' border=0 align=center><br>";}
  if ($status=="1"){ echo "<FONT size=1><br><b>$config[96]</b>"; } else 
                   { echo "<FONT size=1><br><b>$config[95]</b>";}
			   
                     echo "<br>Posts : <b>$posts</b>";
                     echo "<br>".gmdate("<b>d</b> M Y",$textid);
					 echo "<br>".gmdate("h:m:s",$textid)." Uhr";				 					 		     
  echo "</td></tr></table></td><td width=82% bgcolor=$config[73] valign=top><FONT class=two>";
  $holentext = fopen($config[53].$textid.".cmt","r");
  while (!feof($holentext)){
  $text = fgets($holentext,1000);
  $newtext = stripslashes($text);
  echo "$newtext<br>";
  }
  fclose ($holentext);
  echo "</td></tr>";
  

  if ($mycookie=="2") {
  
   if ($id<>$textid) {	echo "
        <td width=18% bgcolor=$config[72] valign=middle align=left>
		<A class=imp href='board.php?func=delpost&id=$textid&theme=$theme&forum=$forum'><IMG src='$config[9]' valign=middle border=0 align=middle alt='Delete Post'></A>
		</td>
		<td width=82% bgcolor=$config[72] valign=middle align=left> 
		<A class=imp href='board.php?func=editpost&id=$textid&theme=$theme&forum=$forum'><IMG src='$config[6]' valign=middle border=0 align=middle alt='Edit Post'></A>
		</td>";      } else
					 { echo "					 	
        <td width=18% bgcolor=$config[72] valign=middle align=left>
		&nbsp;&nbsp;
		</td>
		<td width=82% bgcolor=$config[72] valign=middle align=left> 
		<A class=imp href='board.php?func=editpost&id=$textid&theme=$theme&forum=$forum'><IMG src='$config[6]' valign=middle border=0 align=middle alt='Edit Post'></A>
		</td>";      }
		              }	

  echo "</tr></table><FONT size=1><br></FONT>";
  }
 }

 fclose($holen1);
$counter = $counter -1;
$holen2 = fopen($config[53].$forum.".csv","r");
 while ($zeile = fgetcsv ($holen2, 1000, ";"))
 { $spalten = count($zeile);
   for ($i=$config[87]; $i<$spalten; $i++) 	   
  { 
  if ($id==$zeile[0]) { $threadstatus = $zeile[4];}
  }
 }
fclose($holen2);

// TAB MENU
echo "<table width=$config[0] cellpadding=0 cellspacing=0 border=$config[4]><tr>
      <td valign=middle width=18% align=right><FONT class=two>";
if ($mycookie=="2" or $mycookie=="1") {
echo "[ <A href='board.php?func=newpost&id=$id&theme=$theme&status=$status&forum=$forum'>Neuer Beitrag</A> ]
&nbsp;&nbsp;[ <A href='board.php?func=newthread&id=$id&forum=$forum'>Neues Thema</A> ]&nbsp;&nbsp;&nbsp;"; }
echo "[ <A href='board.php?func=listthread&forum=$forum'>Zur�ck</A> ]</FONT></td></tr></table><FONT size=1><br></FONT>";
// TAB MENU END
                    

 echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
       <td bgcolor=$config[74] valign=top align=center width=25%>&nbsp;<FONT class=one>$config[30] : <b>$counter</b></td>
	   <td bgcolor=$config[74] valign=top align=center width=25%>&nbsp;<FONT class=one>$config[27] : ";
	   if ($threadstatus=="1") {echo "<b>closed</b></td>";} 
	   if ($threadstatus=="0") {echo "<b>open</b></td>";} 
 echo "<td bgcolor=$config[74] valign=top align=center width=50%>&nbsp;<FONT class=one>$config[32] <b>". gmdate("d M Y - h:m:s",$id)."</b></td></tr></table>";
include ($config[67]);	   
 }//-----------------------------------------------------------------------------END


function show_userprofil($time,$mycookie,$id,$usercookie,$config,$forum) { //-----------USER PROFILE
$noforum=true;
include ($config[42]);
 $proof = fopen($config[34],"r");
   while ($zeile = fgetcsv($proof, 1000, ";")) 
   {
	 $spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++) 	   
	 { 
	 if ($id==$zeile[0]) {
     echo "<FORM method=post action='board.php' name=flow>
	       <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
           <td bgcolor=$config[73] width=18% valign=top align=right><FONT class=two><b>$config[61]&nbsp;</td>
		   <td bgcolor=$config[72] width=83% valign=top><FONT class=two>&nbsp;$zeile[0]</td><tr>
           <td bgcolor=$config[73] width=18% valign=top align=right><FONT class=two><b>$config[62]&nbsp;</td>
		   <td bgcolor=$config[72] width=83% valign=top><FONT class=two>&nbsp;<A href='mailto:$zeile[1]'>$zeile[1]</A></td><tr>
		   <td bgcolor=$config[73] width=18% valign=top align=right><FONT class=two><b>$config[63]&nbsp;</td>
		   <td bgcolor=$config[72] width=83% valign=top><FONT class=two>";
if ($zeile[2]=="0") { echo "&nbsp;$config[46]</td><tr>"; } else { echo "&nbsp;<A href='$config[56]'>$zeile[2]</A></td><tr>"; }
     echo "<td bgcolor=$config[73] width=18% valign=top align=right><FONT class=two><b>$config[89]&nbsp;</td>
		   <td bgcolor=$config[72] width=83% valign=top><FONT class=two>";
if (@fopen($zeile[9],"r")) { echo "&nbsp;<IMG src='$zeile[9]' width=50 height=40 border=0 alt='$config[96]-Picture'></td><tr>"; } else 
                          { echo "&nbsp;<IMG src='$config[92]' width=50 height=40 border=0 alt='$config[96]-Picture'></td><tr>"; }
     echo "<td bgcolor=$config[73] width=18% valign=center align=right><FONT class=two><b>$config[27]&nbsp;</td>";
if ($zeile[4]=="1") {echo "<td bgcolor=$config[72] width=83% valign=top><FONT class=two>&nbsp;$config[96]</td><tr>"; }
if ($zeile[4]=="2") {echo "<td bgcolor=$config[72] width=83% valign=top><FONT class=two>&nbsp;$config[95]</td><tr>"; }	
if ($zeile[4]=="3") {echo "<td bgcolor=$config[72] width=83% valign=top><FONT class=two>&nbsp;$config[97]</td><tr>"; }		   		   
     echo "<td bgcolor=$config[73] width=18% valign=center align=right><FONT class=two>
		   <b>Anzahl Posts&nbsp;</td>
		   <td bgcolor=$config[72] width=83% valign=top><FONT class=two>
		   &nbsp;$zeile[5]</td><tr>
		   <td bgcolor=$config[73] width=18% valign=center align=right><FONT class=two>
		   <b>Letzter Post&nbsp;</td>
		   <td bgcolor=$config[72] width=83% valign=top><FONT class=two>";
if ($zeile[6]=="0") { echo "&nbsp;no available</td><tr>"; } else { echo "&nbsp;$zeile[6]</td><tr>";} echo "
		   <td bgcolor=$config[73] width=18% valign=center align=right><FONT class=two>
		   <b>Aktiv seit&nbsp;</td>
		   <td bgcolor=$config[72] width=83% valign=top><FONT class=two>
		   &nbsp;$zeile[7]</td><tr>
		   <td bgcolor=$config[73] width=18% valign=center align=right><FONT class=two><b>Actions&nbsp;</td>
		   <td bgcolor=$config[72] width=83% valign=center>&nbsp;<INPUT type=hidden name=name value='$zeile[0]'><INPUT type=hidden name=id value='$zeile[8]'><INPUT type=text name=password class=submit size=20 value='password'>&nbsp;<INPUT type=submit name=func class=normal value='Profil �ndern'>&nbsp;<INPUT type=submit name=func class=normal value='Zur�ck'></td></tr></table></FORM>";
	  }
     }
	}
 fclose($proof); 	
include ($config[67]);		
}//------------------------------------------------------------------------------END

function block_user($time,$mycookie,$id,$usercookie,$config)//-------------------BLOCK USER

{
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {



$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
if ($id==$zeile[0]) {	
	
if ($zeile[4]=="2") { echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=blockedadmin'>";	
	                  $key = "1"; } else { $key="0"; }
                    }									 
	}
   }
fclose($holen);
if ($key<>"1") {
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($id==$zeile[0]) 
	 {
	 $nickname = $zeile[0];
	 $email = $zeile[1];
	 $icq = $zeile[2];
	 $password = $zeile[3]; 
	 $status = "3";
	 $posts = $zeile[5];
	 $lastpost = $zeile[6];
	 $active = $zeile[7];
	 $keyflip = $zeile[8];
	 $pic = $zeile[9];
	 }
	} 
   }
fclose($holen);

$sichern = fopen($config[53]."temp.tmp","w");
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($id<>$zeile[0]) {
	 fwrite ($sichern,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
	                     } } }
fclose($holen);  
fclose($sichern);
unlink ($config[34]);

$writeit = fopen($config[34],"w");
fwrite ($writeit,$nickname.";".$email.";".$icq.";".$password.";".$status.";".$posts.";".$lastpost.";".$active.";".$keyflip.";".$pic."\n");
fclose ($writeit);

$write = fopen($config[34],"a");
$holen = fopen($config[53]."temp.tmp","r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	 {fwrite ($write,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
	 }
   }
fclose($holen);
fclose($write);
unlink($config[53]."temp.tmp");
show_users($time,$mycookie,$usercookie,$config);
}
}
}//------------------------------------------------------------------------------END

function unblock_user($time,$mycookie,$id,$usercookie,$config) //----------------UNBLOCK USER
{
//SICHER
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {

$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($id==$zeile[0]) 
	 {
	 $nickname = $zeile[0];
	 $email = $zeile[1];
	 $icq = $zeile[2];
	 $password = $zeile[3];
	 $status = "1";
	 $posts = $zeile[5];
	 $lastpost = $zeile[6];
	 $active = $zeile[7];
	 $keyflip = $zeile[8];
	 $pic = $zeile[9];
	 }
	} 
   }
fclose($holen);

$sichern = fopen($config[53]."temp.tmp","w");
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($id<>$zeile[0]) {
	 fwrite ($sichern,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
	                     } } }
fclose($holen);  
fclose($sichern);
unlink ($config[34]);

$writeit = fopen($config[34],"w");
fwrite ($writeit,$nickname.";".$email.";".$icq.";".$password.";".$status.";".$posts.";".$lastpost.";".$active.";".$keyflip.";".$pic."\n");
fclose ($writeit);

$write = fopen($config[34],"a");
$holen = fopen($config[53]."temp.tmp","r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	 {fwrite ($write,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
	 }
   }
fclose($holen);
fclose($write);
unlink($config[53]."temp.tmp");
show_users($time,$mycookie,$usercookie,$config);
}//SICHER
}//------------------------------------------------------------------------------END UNBLOCK USER

function del_user($time,$mycookie,$id,$usercookie,$config) { //------------------DELETE USER
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
if ($id==$zeile[0]) {	
	
if ($zeile[4]=="2") { echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=deladmin'>";	
	                  $key = "1"; } else { $key="0"; }
                    }									 
	} 
   }
fclose($holen);
if ($key=="0") { echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=delwarn&id=$id'>"; } 
}
}//------------------------------------------------------------------------------END

function delusernow($id,$mycookie,$usercookie,$config) { //----------------------DELETE USER NOW
if ($mycookie==0 or $mycookie>2) { echo "NO ACCESS ALLOWED"; } else {
$sichern = fopen($config[53]."temp.tmp","w");
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	 if ($id<>$zeile[0]) {
	 fwrite ($sichern,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
	 	                     } 
	 } 
    }
fclose($holen);  
fclose($sichern);
unlink ($config[34]);

$write = fopen($config[34],"w");
$holen = fopen($config[53]."temp.tmp","r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	 {fwrite ($write,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
	 }
   }
fclose($holen);
fclose($write);
unlink($config[53]."temp.tmp");

show_users($time,$mycookie,$usercookie,$config);
}
}//------------------------------------------------------------------------------END

function new_thread($time,$mycookie,$id,$usercookie,$config,$forum) //-----------NEW THEME
{
if ($mycookie==0 or $mycookie==3) { echo "NO ACCESS ALLOWED"; } else {
$noforum=true;
$noback=true;
$holen = fopen($config[34],"r");
  while ($zeile = fgetcsv ($holen, 1000, ";"))
  { $spalten = count ($zeile); for ($i=$config[88]; $i<$spalten; $i++) {
  if ($usercookie==$zeile[0]) { if ($zeile[4]=="3") {
   echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=blocked&id=$usercookie'>";
                                                    } else {
include($config[42]);
echo "<FORM action=board.php method=post name=XXXflow>
      <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=two><b>Thema</b>&nbsp;</FONT></td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<INPUT type=text class=normal size=88 name=thema></td><tr>
      <td bgcolor=$config[72] valign=top align=right width=20%><FONT class=two><b>Text</b>&nbsp;</FONT></td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<TEXTAREA cols=74 rows=14 class=normal name=text></TEXTAREA></td><tr>
      <td bgcolor=$config[72] valign=center width=20%>&nbsp;<INPUT type=hidden name=id value='$id'><INPUT type=hidden name=forum value='$forum'></td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<INPUT type=submit name=func value='Senden' class=normal>&nbsp;&nbsp;<INPUT type=submit name=func value='Zur�ck' class=normal></FORM></td></tr></table>
      ";
}}}}
fclose($holen);
include ($config[67]);
}
}//------------------------------------------------------------------------------END

function sended_thread($time,$mycookie,$usercookie,$thema,$text,$config,$forum)//-------SAVE THREAD
{
if ($mycookie<1 or $mycookie>3) { echo "NO ACCESS ALLOWED"; } else {
//Pr�ft auf Vollst�ndigkeit der Felder
if ($thema==false) {  echo "<META http-equiv='Refresh' content='0; url=board.php?func=listthread&forum=$forum'>"; die;}
if ($text==false)  {  echo "<META http-equiv='Refresh' content='0; url=board.php?func=listthread&forum=$forum'>"; die;}

//Pr�fung auf Semicolons und ggf. Austauschen gegen Doppelpunkte...
 $proof_thema = strstr($thema, ";"); IF ($proof_thema) { $thema=ereg_replace(";",":",$proof_thema);}

//Pr�fung des Textes auf Wordlist hin 
 $proof3 = fopen($config[35],"r");
 while ($zeile = fgetcsv ($proof3, 1000, ","))
 { $spalten = count ($zeile); for ($i=1; $i<$spalten; $i++)
  { $p1 = stristr($text,$zeile[0]); if ($p1) { $var="1"; }   } }
 fclose($proof3);
 if (empty($var))
 {

 //hole daten aus actual.csv (Hauptindex) und schreibe in Temp
  $schreiben = fopen($config[36],"w");
  $holen = fopen($config[53].$forum.".csv","r");
  while ($zeile = fgetcsv ($holen, 1000, ";"))
  { $spalten = count ($zeile); for ($i=$config[87]; $i<$spalten; $i++)
  { fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");  }}				  
 fclose($holen);
 fclose($schreiben);

 //schreiben der aktuellen daten in actual.csv (Hauptindex)
 $schreiben = fopen($config[53].$forum.".csv","w");
 fwrite ($schreiben,$time.";".$usercookie.";".$thema.";0;0;0;0;0;0\n");
 fclose ($schreiben);
 
 //anh�ngen der alten daten an den aktuellsten Datensatz in actual.csv (Hauptindex)
   $schreiben = fopen($config[53].$forum.".csv","a");
  $holen = fopen($config[36],"r");
  while ($zeile = fgetcsv ($holen, 1000, ";"))
  { $spalten = count ($zeile); for ($i=$config[87]; $i<$spalten; $i++)
  { fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");  }}				  
 fclose($holen);
 fclose($schreiben);
 unlink ($config[36]);
 
 //Hole das Datum des aktuellen Threads aus der actual.csv und erzeuge neuen Themenindex & Post
  $holen = fopen($config[53].$forum.".csv","r");
  while ($zeile = fgetcsv ($holen, 1000, ";"))
  { $spalten = count ($zeile); for ($i=$config[87]; $i<$spalten; $i++) {
  if ($thema==$zeile[2]) { $actdate=$zeile[0]; }
  }}				  
 fclose($holen);
 $schreiben = fopen($config[53].$actdate.".dat","w");
 fwrite ($schreiben,$actdate.";".$usercookie."\n");
 fclose($schreiben);
 $schreiben = fopen($config[53].$actdate.".cmt","w");
 fwrite ($schreiben,$text."\n");
 fclose($schreiben);
 
 //Statistik
    $schreiben=fopen($config[58],"w");  
   $holen=fopen($config[41],"r");
      while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	{$newvar=$zeile[0]+1;
	fwrite ($schreiben,$newvar.";".$zeil[1].";".$zeile[2].";".$zeile[3]."\n"); }} 
	fclose($holen); fclose ($schreiben); unlink($config[41]); rename ($config[58], $config[41]);

 echo "<META http-equiv='Refresh' content='0; url=board.php?func=listthread&forum=$forum'>";
 }

 //Blocken von Usern die gegen WL verstossen
 if ($var=="1") { $id = $usercookie;
 block_user($time,$mycookie,$id,$usercookie,$config);
 echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=blocked&id=$usercookie&forum=$forum'>";
}
}
}//------------------------------------------------------------------------------END

function new_post($time,$mycookie,$usercookie,$id,$theme,$status,$config,$forum) { //---NEW POST
if ($mycookie==0 or $mycookie>3) { echo "NO ACCESS ALLOWED"; } else {
$noforum=true;
$noback=true;
$holen = fopen($config[34],"r");
  while ($zeile = fgetcsv ($holen, 1000, ";"))
  { $spalten = count ($zeile); for ($i=$config[88]; $i<$spalten; $i++) {
  if ($usercookie==$zeile[0]) { if ($zeile[4]=="3") { 
   echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=blocked&id=$usercookie&forum=$forum'>";
                                                    } else {
include ($config[42]);
$proof = fopen($config[53].$forum.".csv","r");
  while ($zeile = fgetcsv ($proof, 1000, ";"))
  { $spalten = count ($zeile); 
    for ($i=$config[87]; $i<$spalten; $i++) 
	{
  if ($id==$zeile[0]) { if ($zeile[4]=="1") { 
  echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=closedthread&id=$id&theme=$theme&status=$status&forum=$forum'>"; } else
  {
  echo "
<FORM action=board.php method=post name=XXXflow>
<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
<td bgcolor=$config[72] valign=top align=right width=20%><FONT class=two><b>Text</b>&nbsp;</FONT></td>
<td bgcolor=$config[72] valign=center width=80%>&nbsp;<TEXTAREA cols=74 rows=14 class=normal name=text></TEXTAREA></td><tr>
<td bgcolor=$config[72] valign=center width=20%>&nbsp;<INPUT type=hidden name=id value='$id'>
                                                      <INPUT type=hidden name=status value='$status'>
						      <INPUT type=hidden name=theme value='$theme'>
						      <INPUT type=hidden name=forum value='$forum'></td>
<td bgcolor=$config[72] valign=center width=80%>&nbsp;<INPUT type=submit name=func value='Absenden' class=normal>&nbsp;&nbsp;
                                                      <INPUT type=submit name=func value='Zur�ck' class=normal>
                                             </FORM></td></tr></table>
";
include ($config[67]);
}}  }}
fclose($proof);
}}  }}
fclose($holen);
}
}//------------------------------------------------------------------------------END

function sended_post($time,$mycookie,$usercookie,$id,$status,$theme,$text,$config,$forum) //WRITE POST
{
if ($mycookie==0 or $mycookie>3) { echo "NO ACCESS ALLOWED"; } else {
//Pr�fung des Textes auf Wordlist hin 
 $proof3 = fopen($config[35],"r");
 while ($zeile = fgetcsv ($proof3, 1000, ","))
 { $spalten = count ($zeile); for ($i=1; $i<$spalten; $i++)
  { $p1 = stristr($text,$zeile[0]); if ($p1) { $var="1"; }   } } 					  
 fclose($proof3);
 if (empty($var)) 
 {

//Schreiben des Thread-Indexes
$schreiben = fopen($config[53].$id.".dat","a");
fwrite ($schreiben,$time.";".$usercookie."\n");
fclose($schreiben);
//Schreiben des Posts in die neue Postdatei
$schreiben = fopen($config[53].$time.".cmt","a");
fwrite ($schreiben,$text);
fclose ($schreiben);

//Trennen der User und aktualisierung der Postcounts/Last Post
$schreiben = fopen($config[36],"w"); //TEMP 1
$schreiben2 = fopen($config[37],"w"); //TEMP 2
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen,1000,";"))
{$spalten = count($zeile);
for ($i=$config[88]; $i<$spalten; $i++)
{ if ($usercookie<>$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");}
  if ($usercookie==$zeile[0]) { $actdate=gmdate("d M Y h:m:s",$time); 
								$actualposts=$zeile[5]+"1"; 
								fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$actualposts.";".$actdate.";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");}
}}
fclose($holen);
fclose($schreiben2);
fclose($schreiben);
unlink($config[34]);
rename ($config[37], $config[34]);
$schreiben = fopen($config[34],"a");
$holen = fopen($config[36],"r");
while ($zeile = fgetcsv($holen,1000,";"))
{$spalten = count($zeile);
for ($i=$config[88]; $i<$spalten; $i++)
{ fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8].";".$zeile[9]."\n");
}}
fclose($holen);
fclose($schreiben);
unlink($config[36]); 

//-------------------------------------------------------------------------------aktualisiere den Hauptindex...
 $schreiben = fopen($config[36],"w");
 $schreiben2 = fopen($config[37],"w");
 $holen = fopen($config[53].$forum.".csv","r");
 while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	if ($id<$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($id>$zeile[0]) { fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($id==$zeile[0]){ $newid=$zeile[0]; $newname=$zeile[1]; $newtheme=$zeile[2]; $newzero1=$zeile[3]; $newvar=$zeile[4]; $oldlp=$zeile[5]; $oldcp=$zeile[6]; $newzero3=$zeile[7]; $last=$zeile[8]; }
    }
   } 
  fclose ($holen);
  fclose ($schreiben2);
  fclose ($schreiben);
  
  unlink ($config[53].$forum.".csv");
  $schreiben = fopen($config[53].$forum.".csv","w");
  $holen = fopen($config[36],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   
   $newlp = $time;
   $newcp = $oldcp+"1";
   
   $schreiben = fopen($config[53].$forum.".csv","a");
   fwrite ($schreiben,$newid.";".$newname.";".$newtheme.";".$newzero1.";".$newvar.";".$newlp.";".$newcp.";".$newzero3.";".$last."\n");
   fclose ($schreiben);
   
  $schreiben = fopen($config[53].$forum.".csv","a");
  $holen = fopen($config[37],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   unlink($config[36]);
   unlink($config[37]);
   
   //Statistik
    $schreiben=fopen($config[58],"w");
    $holen=fopen($config[41],"r");
    while ($zeile = fgetcsv($holen, 1000, ";")) 
    {$spalten = count($zeile); for ($i=3; $i<$spalten; $i++) 
	 {$newvar=$zeile[1]+1; fwrite ($schreiben,$zeile[0].";".$newvar.";".$zeile[2].";".$zeile[3]."\n"); }} 
	 fclose($holen); fclose ($schreiben); unlink($config[41]); rename ($config[58], $config[41]);

          show_post($time,$mycookie,$id,$theme,$usercookie,$status,$config,$forum);
   }
    if ($var=="1") { 
	unset ($id);
	$id = $usercookie;
 block_user($time,$mycookie,$id,$usercookie,$config);
 echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=blocked&id=$usercookie&forum=$forum'>";
} 
}
}//------------------------------------------------------------------------------END

function mailit($time,$mycookie,$usercookie,$id,$config) { //--------------------WRITE MAIL
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$noforum=true;
include($config[42]);
  echo "
<FORM action=board.php method=post name=mailfunction>
<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
<td bgcolor=$config[72] valign=top align=right width=20%><FONT class=two><b>$config[70]</b>&nbsp;</FONT></td>
<td bgcolor=$config[72] valign=center width=80%>&nbsp;<INPUT type=text name=subject class=normal size=88></td><tr>
<td bgcolor=$config[72] valign=top align=right width=20%><FONT class=two><b>$config[71]</b>&nbsp;</FONT></td>
<td bgcolor=$config[72] valign=center width=80%>&nbsp;<TEXTAREA cols=74 rows=14 class=normal name=text></TEXTAREA></td><tr>
<td bgcolor=$config[72] valign=center width=20%>&nbsp;</td>
<td bgcolor=$config[72] valign=center width=80%>&nbsp;<INPUT type=hidden name=id value='$id'><INPUT type=submit name=func value='Send Message' class=normal></FORM></td></tr></table>
";
include ($config[67]);
}
} //-----------------------------------------------------------------------------END

function sendthismail($mycookie,$usercookie,$id,$subject,$text,$config) { //-----SEND MAIL
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen,1000,";"))
{$spalten = count($zeile);
for ($i=$config[88]; $i<$spalten; $i++)
{if ($usercookie==$zeile[0]) {
 $answer = $zeile[1];
 $icq = $zeile[2]; }}}
fclose($holen);

$second = fopen($config[34],"r");
while ($zeile = fgetcsv($second, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
	if ($id==$zeile[0]) 
	{ 	
	
	$to=$zeile[1];
	
	$message = "	
	\n
	The User $usercookie from board51 send you a Message :\n\n
	$text\n\n	
	Answer him over $answer, or ICQ #$icq \n\n"; 
	
    $res = mail ($to,$subject,$message);	
	
	if ($res=="0") {echo "<META http-equiv='Refresh' content='0; url=".$config[53]."error.php?func=mailfailure'>"; }
	
	//Statistik
    $schreiben=fopen($config[58],"w");  
    $holen=fopen($config[41],"r");
    while ($zeile = fgetcsv($holen, 1000, ";")) 
    {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++) 
	{$newvar=$zeile[3]+1;
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$newvar."\n"); }} 
	fclose($holen); fclose ($schreiben); unlink($config[41]); rename ($config[58], $config[41]);
	echo "<META http-equiv='Refresh' content='0; url=board.php?func=showusers'>";
    } else { echo "<META http-equiv='Refresh' content='0; url=board.php?func=showusers'>"; }
 }}
 fclose ($second);
 }
 }//-----------------------------------------------------------------------------END


function handle_thread($time,$mycookie,$id,$usercookie,$config,$forum) //--------HANDLE THREAD (CLOSE/OPEN)
{
if ($mycookie<2 or $mycookie>3) { echo "NO ACCESS ALLOWED"; } else {
 $schreiben = fopen($config[36],"w"); 
 $schreiben2 = fopen($config[37],"w");
 $holen = fopen($config[53].$forum.".csv","r");
 while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	if ($id<$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($id>$zeile[0]) { fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($id==$zeile[0]){ $newid=$zeile[0]; $newname=$zeile[1]; $newtheme=$zeile[2]; $newzero1=$zeile[3]; $oldvar=$zeile[4]; $newlp=$zeile[5]; $newcp=$zeile[6]; $newzero3=$zeile[7]; $last=$zeile[8]; }
    }
   } 
  fclose ($holen);
  fclose ($schreiben2);
  fclose ($schreiben);
  
  unlink ($config[53].$forum.".csv");
  $schreiben = fopen($config[53].$forum.".csv","w");
  $holen = fopen($config[36],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   
   if ($oldvar=="0") { $newvar="1"; } else { $newvar="0"; }
   
   $schreiben = fopen($config[53].$forum.".csv","a");
   fwrite ($schreiben,$newid.";".$newname.";".$newtheme.";".$newzero1.";".$newvar.";".$newlp.";".$newcp.";".$newzero3.";".$last."\n");
   fclose ($schreiben);
   
  $schreiben = fopen($config[53].$forum.".csv","a");
  $holen = fopen($config[37],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   echo "<META http-equiv='Refresh' content='0; url=board.php?func=listthread&forum=$forum'>";
   @unlink($config[36]);
   @unlink($config[37]);
   }
}//------------------------------------------------------------------------------END	

function edit_post($time,$mycookie,$id,$config,$theme,$usercookie,$forum) { //---EDIT POST
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$nopost=true;
$noforum=true;
$noback=true;

include ($config[42]);

echo "<FORM action=board.php name=xflow method=post>
      <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right>
	  <FONT class=two><b>Edit Text</b>&nbsp;</FONT></td>
	  <td bgcolor=$config[72] valign=top width=80%>
	  <TEXTAREA name=text cols=80 rows=18 class=normal>";
$holen = fopen($config[53].$id.".cmt","r");
  while (!feof($holen)){
  $text = fgets($holen,1000);
  $newtext = stripslashes($text);
  echo "$newtext";
  }
fclose ($holen);
echo "</TEXTAREA></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right>
      &nbsp;</td>
      <td bgcolor=$config[72] valign=top width=80%>
	  <INPUT type=hidden name=id value='$id'>
	  <INPUT type=hidden name=forum value='$forum'>
	  <INPUT type=hidden name=theme value='$theme'>
          <INPUT type=submit name=func value='Abspeichern' class=normal>&nbsp;&nbsp;
	  <INPUT type=submit name=func value='Zur�ck' class=normal></FORM>
	  </td></tr></table>";
	   include ($config[67]);
	  }

}//------------------------------------------------------------------------------END

//-------------------------------------------------------------------------------WRITE EDITED POST
function writeedit($time,$mycookie,$usercookie,$id,$text,$config,$theme,$secid,$forum)
{
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$schreiben = fopen($config[53].$id.".cmt","w");
fwrite ($schreiben,$text);
fclose ($schreiben);
$id = $secid;
show_post($time,$mycookie,$id,$theme,$usercookie,$status,$config,$forum);
}
}//------------------------------------------------------------------------------END

function del_post($time,$mycookie,$id,$secid,$config,$theme,$forum) { //---------DELETE POST

if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$schreiben = fopen($config[36],"w");
$holen = fopen($config[53]."$secid.dat","r");
 while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=1; $i<$spalten; $i++)
	 {
	 if ($id<>$zeile[0]) { fwrite ($schreiben,$zeile[0].";".$zeile[1]."\n"); }
	 }
   } 
   fclose($holen);
   fclose($schreiben);
 unlink ($config[53]."$secid.dat");
 rename ($config[36], $config[53]."$secid.dat");
 unlink ($config[53].$id.".cmt");
 
 
 //l�sche postcount -1 !!!
 //Trennen der Posts (sortieren nach alter)
 $schreiben = fopen($config[38],"w"); 
 $schreiben2 = fopen($config[58],"w");
 $holen = fopen($config[53].$forum.".csv","r");
 while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	if ($secid<$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($secid>$zeile[0]) { fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($secid==$zeile[0]){ $newid=$zeile[0]; $newname=$zeile[1]; $newtheme=$zeile[2]; $newzero1=$zeile[3]; $newvar=$zeile[4]; $newlp=$zeile[5]; $oldcp=$zeile[6]; $newzero3=$zeile[7]; $last=$zeile[8]; }
    }
   } 
  fclose ($holen);
  fclose ($schreiben2);
  fclose ($schreiben);
  
  //L�sche den alten Hauptindex 
  unlink ($config[53].$forum.".csv");

  //Schreibe aktuellste Daten zur�ck 
  $schreiben = fopen($config[53].$forum.".csv","w");
  $holen = fopen($config[38],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   
   //Behandel zu �ndernde Daten
  $newcp = $oldcp - 1;
   
   $schreiben = fopen($config[53].$forum.".csv","a");
   fwrite ($schreiben,$newid.";".$newname.";".$newtheme.";".$newzero1.";".$newvar.";".$newlp.";".$newcp.";".$newzero3.";".$last."\n");
   fclose ($schreiben);
   
  $schreiben = fopen($config[53].$forum.".csv","a");
  $holen = fopen($config[58],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[7]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);   	
   unlink($config[38]);
   unlink($config[58]);
    //Statistik
    $schreiben=fopen($config[58],"w");  
   $holen=fopen($config[41],"r");
      while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++) 
	{$newvar=$zeile[1]-1;
	fwrite ($schreiben,$zeile[0].";".$newvar.";".$zeile[2].";".$zeile[3]."\n"); }} 
	fclose($holen); fclose ($schreiben); unlink($config[41]); rename ($config[58], $config[41]);
	$id = $secid;
	show_post($time,$mycookie,$id,$theme,$usercookie,$status,$config,$forum);
	/*echo "<META http-equiv='Refresh' content='0; url=board.php?func=showpost&id=$secid&status=$status&forum=$forum&theme=$theme'>";*/
	 }
}//------------------------------------------------------------------------------END

function edit_thread($time,$mycookie,$id,$usercookie,$config,$forum) { //--------EDIT THREAD
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$holen = fopen($config[53].$forum.".csv","r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	if ($id==$zeile[0]) {$idtimestamp=$zeile[0]; $author=$zeile[1]; $theme=$zeile[2]; $zerozero=$zeile[3]; $status=$zeile[4]; $lptimestamp=$zeile[5]; $countedposts=$zeile[6]; $zeroone=$zeile[7]; $last=$zeile[8];}
    }
   }
fclose($holen);
$nopost=true;
$noback=true;
include($config[42]);
echo "<FORM name=xflow action=board.php method=post>
      <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>$config[77]&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>$idtimestamp</FONT></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>$config[78]&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>".gmdate("d M Y",$idtimestamp)."</FONT></td><tr>
	  <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>um :&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>".gmdate("h:m:s",$idtimestamp)." </FONT></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>$config[23]&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>$author</FONT></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>$config[12]&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><INPUT type=text name=theme value='$theme' class=normal size=90></td><tr>
	  <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>First Zero :&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>$zerozero</FONT></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>Status :&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%>";
if ($status=="1") { echo "<IMG src='$config[11]' border=0 valign=middle alt='closed thread'>"; } else
                  { echo "<IMG src='$config[10]' border=0 valign=middle alt='open thread'>";    } echo "</td><tr>";
echo "<td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>Last Post :&nbsp;</td>";
if ($lptimestamp=="0") { echo "<td bgcolor=$config[72] valign=top width=80%><FONT class=two>no re-posts</FONT></td><tr>"; } else
                       { echo "<td bgcolor=$config[72] valign=top width=80%><FONT class=two>".gmdate("d M Y h:m:s",$lptimestamp)."</FONT></td><tr>";}
echo "<td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>Posts :&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>$countedposts</FONT></td><tr>
  	  <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>Second Zero :&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>$zeroone</FONT></td><tr>
 	  <td bgcolor=$config[72] valign=top width=20% align=right>&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%>
	  <INPUT type=hidden name=idtimestamp value='$idtimestamp'>
	  <INPUT type=hidden name=forum value='$forum'>
	  <INPUT type=submit name=func value='�nderung speichern' class=normal>&nbsp;&nbsp;
	  <INPUT type=submit name=func value='Zur�ck' class=normal></FORM></td></tr></table>";
	  include($config[67]);
	  }

}//------------------------------------------------------------------------------END

//-------------------------------------------------------------------------------WRITE EDITED THREAD
function save_thread($time,$mycookie,$id,$usercookie,$idtimestamp,$theme,$config,$forum) {
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
//Pr�fung auf Semicolons und ggf. Austauschen gegen Doppelpunkte...
 $proof_theme = strstr($theme, ";"); IF ($proof_theme) { $theme=ereg_replace(";",":",$proof_theme);}
 //Trennen der Posts (sortieren nach alter)
 $schreiben = fopen($config[38],"w");
 $schreiben2 = fopen($config[58],"w");
 $holen = fopen($config[53].$forum.".csv","r");
 while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	if ($idtimestamp<$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($idtimestamp>$zeile[0]) { fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($idtimestamp==$zeile[0]){ $newid=$zeile[0]; $newname=$zeile[1]; $oldtheme=$zeile[2]; $newzero1=$zeile[3]; $newvar=$zeile[4]; $newlp=$zeile[5]; $newcp=$zeile[6]; $newzero3=$zeile[7]; $last=$zeile[8];}
    }
   }
  fclose ($holen);
  fclose ($schreiben2);
  fclose ($schreiben);

  //L�sche den alten Hauptindex
  unlink ($config[53].$forum.".csv");

  //Schreibe aktuellste Daten zur�ck 
  $schreiben = fopen($config[53].$forum.".csv","w");
  $holen = fopen($config[38],"r");
   while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   
   //Behandel zu �ndernde Daten
  $newtheme = $theme;

   $schreiben = fopen($config[53].$forum.".csv","a");
   fwrite ($schreiben,$newid.";".$newname.";".$newtheme.";".$newzero1.";".$newvar.";".$newlp.";".$newcp.";".$newzero3.";".$last."\n");
   fclose ($schreiben);

  $schreiben = fopen($config[53].$forum.".csv","a");
  $holen = fopen($config[58],"r");
   while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   unlink($config[38]);
   unlink($config[58]);
   echo "<META http-equiv='Refresh' content='0; url=board.php?func=listthread&forum=$forum'>";
   }
}//------------------------------------------------------------------------------END

function show_statistic($time,$mycookie,$config,$usercookie,$config) { //--------SHOW STATISTIC
if ($mycookie==0) { echo "NO ACCESS ALLOWED"; } else {

//Initalisierung
$noforum=true;
$postarray = array("0");
$userarray = array("none");
$blockeduser="0";
$admincount="0";
$usercount="0";

//Wieviele User ? Admins ? Blocked ?
$holen = fopen($config[34],"r");
   while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=$config[88]; $i<$spalten; $i++)
	{
    if ($zeile[4]=="3") { $blockeduser++;}
	if ($zeile[4]=="2") { $admincount++; }

	$usercount++;
	array_push($userarray,$zeile[0]);
	array_push($postarray,$zeile[5]);
	}
   }
fclose($holen);

//Wer hat die meisten Posts ?
$mostposts = max($postarray);

//Welcher User hat die meisten Posts ?
$holen = fopen($config[34],"r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
{$spalten = count($zeile); for ($i=$config[88]; $i<$spalten; $i++)
{if ($mostposts==$zeile[5]) { $mpuser = $zeile[0];}}}
fclose($holen);
 
//Z�hlung der Threads,Fehlgeschlagene Logins,Versendete Mails 
$holen=fopen($config[41],"r");
while ($zeile = fgetcsv($holen, 1000, ";")) 
{$spalten = count($zeile);
for ($i=3; $i<$spalten; $i++) 
{$allthreads = $zeile[0]; $allfalse = $zeile[2]; $allmails = $zeile[3]; }}
fclose($holen);   	

//Z�hlung der Posts   
$postcounter=fopen($config[53].$forum,"r");
while ($zeile = fgetcsv($postcounter, 1000, ";")){$spalten = count($zeile); for ($i=8; $i<$spalten; $i++) 
{$allposts = $allposts + $zeile[6]; }}	fclose($postcounter);
	
//HTML-Ausgabe f�r die Statistik 
include($config[42]);
echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[74] valign=top width=100%><FONT size=4 face=arial,verdana,tahoma color=000000><b>
	  &nbsp;Allgemeine Statistik</FONT></td></tr></table><br>
      <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
	  <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Start Statistik</td>
      <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$config[39]</td><tr>
      <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Benutzer</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$usercount</td><tr>
	  <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>$config[95]en</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$admincount</td><tr>
      <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Gesperrte Benutzer</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$blockeduser</td><tr>
      <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Beitrags-Maximum</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$mostposts </b>";
if ($mostposts=="0") { echo "Noch keine Beitr�ge vorhanden...</td><tr>";}	  
if ($mostposts=="1") { echo "Beitr�ge von <A href='board.php?func=profile&id=$mpuser'><b>$mpuser</b></A></td><tr>";}
if ($mostposts>"1")  { echo "Beitr�ge von <A href='board.php?func=profile&id=$mpuser'><b>$mpuser</b></A></td><tr>";}
echo "<td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Beitr�ge</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$allposts</b></td><tr>
	  <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Themen</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$allthreads</b></td>
	  </tr></table><br>";
	  
echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[74] valign=top width=100%><FONT size=4 face=arial,verdana,tahoma color=000000><b>
	  &nbsp;Erweiterte Statistik</FONT></td></tr></table><br>
      <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
	  <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Gesendete eMails</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$allmails</td><tr>
      <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Fehlgeschlagene Login's</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$allfalse</td>";
if ($mycookie=="2") { echo "<tr>  
	  <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Ung�ltige Passwort-Eingabe</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;";
	  $holentext = fopen($config[40],"r");
      while (!feof($holentext)){$text = fgets($holentext,1000); echo $text; }
      fclose ($holentext);
echo "</td>";       }

if ($mycookie=="2") {
   $holen=fopen($config[59],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
   for ($i=1; $i<$spalten; $i++) 
   {$downboard = $zeile[0]; $free = $zeile[1]; }}
   fclose($holen);
 echo "
	  <tr><td bgcolor=$config[72] valign=center align=right width=20%><FONT class=one>Downloaded board (board51.rar)</td>
	  <td bgcolor=$config[73] valign=center align=left width=80%><FONT class=one><b>&nbsp;$downboard</td></tr></table>";
                       }
					    else { echo "</tr></table>";}
 include($config[67]);
					    }
}//------------------------------------------------------------------------------END

function del_thread($time,$mycookie,$id,$usercookie,$config,$forum) { //---------DELETE THREAD
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
//Einlesen der Quellfiles aus der ID des jeweiligen Threads...
$holen= fopen($config[53].$id.".dat","r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
    for ($i=1; $i<$spalten; $i++)
	{
	 unlink($config[53].$zeile[0].".cmt");
	}
   }
   fclose($holen);
   unlink ($config[53].$id.".dat");
   
    //Trennen der Posts (sortieren nach alter)
 $schreiben = fopen($config[38],"w+");
 $schreiben2 = fopen($config[58],"w+");
 $holen = fopen($config[53].$forum.".csv","r");
 while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	if ($id<$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($id>$zeile[0]) { fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n"); }
	if ($id==$zeile[0]){ $newid=$zeile[0]; $newname=$zeile[1]; $newtheme=$zeile[2]; $newzero1=$zeile[3]; $newvar=$zeile[4]; $newlp=$zeile[5]; $newcp=$zeile[6]; $newzero3=$zeile[7]; $last=$zeile[8];}
    }
   } 
  fclose ($holen);
  fclose ($schreiben2);
  fclose ($schreiben);
  
  //L�sche den alten Hauptindex 
  unlink ($config[53].$forum.".csv");
  
  //Schreibe aktuellste Daten zur�ck
  $schreiben = fopen($config[53].$forum.".csv","w");
  $holen = fopen($config[38],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
  //Schreibe �ltere Daten zur�ck      
  $schreiben = fopen($config[53].$forum.".csv","a");
  $holen = fopen($config[58],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=$config[87]; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3].";".$zeile[4].";".$zeile[5].";".$zeile[6].";".$zeile[7].";".$zeile[8]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);   	
   unlink($config[38]);
   unlink($config[58]);
   
   //Statistik
   $schreiben=fopen($config[58],"w");  
   $holen=fopen($config[41],"r");
      while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++) 
	{$newvar=$zeile[0]-1;
	fwrite ($schreiben,$newvar.";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n"); }} 
	fclose($holen); fclose ($schreiben); unlink($config[41]); rename ($config[58], $config[41]);
	echo "<META http-equiv='Refresh' content='0; url=board.php?func=listthread&forum=$forum'>";
	}
}//------------------------------------------------------------------------------END


function login_now($mycookie,$usercookie,$config) { //---------------------------LOGIN NOW
     echo" 
	  <!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>
      <HTML><HEAD><TITLE>$config[69]</TITLE>
	  <link href='$config[49]' type='text/css' rel='stylesheet'>
	  </HEAD>
	  <BODY>
	  <center><br>
      <FORM action='board.php' method=post name=flowforever>
      <table width=$config[0] cellpadding=$config[50] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	  <tr><td width=600><IMG src='$config[5]' border=0></td></tr></table><br>
	  <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	  <tr><td width=100% bgcolor=$config[74] valign=middle align=right>
	  <INPUT type=text class=normal size=20 name=username value='Benutzername'>&nbsp;&nbsp;
	  <INPUT type=password class=normal size=20 name=password value=' password'>&nbsp;&nbsp;
	  <INPUT type=image src='$config[59]' align=center name=func value='$config[94]'>&nbsp;&nbsp;
	  <INPUT type=image src='$config[98]' align=center name=func value='register'>&nbsp;
	  </FORM></td></tr></table><br>
	  <table width=$config[0] cellpadding=4 cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	  <tr><td width=100% class=td22 align=center><br><br>
  	  <table width=500><tr><td>";
      include($config[85]);
echo "</td></tr></table><br><br><br>
	  </td></tr></table>";	
include($config[67]);	  
}//-----------------------------------------------------------------------------END

function rules($config,$mycookie,$usercookie,$noforum) { //----------------------RULES
$xul=true;
include($config[42]);
echo "<table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	  <tr>
	  <td bgcolor=$config[72]><FONT class=two>";
  $getrules = fopen($config[83],"r");
  while (!feof($getrules)){
  $text = fgets($getrules,1000);
  $newtext = stripslashes($text);
  echo "$newtext<br>";
  }
  fclose ($getrules);
echo "</td></tr></table>";
include($config[67]);
}//------------------------------------------------------------------------------END

function new_forum($mycookie,$usercookie,$config) { //----------------------------NEW FORUM
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$noforum=true;
include($config[42]);
echo "<FORM action=board.php method=post name=XXXflow>
      <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=two><b>Name</b>&nbsp;</FONT></td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<INPUT type=text class=normal size=89 name=name></td><tr>
      <td bgcolor=$config[72] valign=top align=right width=20%><FONT class=two><b>Beschreibung</b>&nbsp;</FONT></td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<TEXTAREA cols=74 rows=3 class=normal name=description></TEXTAREA></td><tr>
      <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=two><b>Thema</b>&nbsp;</FONT></td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<INPUT type=text class=normal size=89 name=ename></td><tr>
      <td bgcolor=$config[72] valign=top align=right width=20%><FONT class=two><b>Text</b>&nbsp;</FONT></td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<TEXTAREA cols=74 rows=15 class=normal name=etext></TEXTAREA></td><tr>
      <td bgcolor=$config[72] valign=center align=right width=20%><FONT class=two><b>Option</b>&nbsp;</FONT></td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<FONT class=two><INPUT type=checkbox class=normal name=status value='1'>&nbsp;&nbsp;Forum nur f�r Administratoren sichtbar?</FONT></td><tr>
      <td bgcolor=$config[72] valign=center width=20%>&nbsp;</td>
      <td bgcolor=$config[72] valign=center width=80%>&nbsp;<INPUT type=submit name=func value='Forum erstellen' class=normal>&nbsp;&nbsp;
      <INPUT type=reset name=reset value='Alles l�schen' class=normal>&nbsp;&nbsp; <INPUT type=submit name=func value='Abbrechen' class=normal></FORM></td></tr></table>";
      include($config[67]);
 }
} //-----------------------------------------------------------------------------NEW FORUM END

//-------------------------------------------------------------------------------SAVE NEW FORUM
function save_forum($mycookie,$usercookie,$config,$name,$description,$ename,$etext,$status) {
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
if(empty($status)) { $status="0";}
$time = time();
if ($status=="on") { $set="1"; } else { $set="0"; }

//Schreibe Forum-Info-Datei
$info=fopen($config[53].$time.".nfo","w+");
fwrite($info,$description);
fclose($info);

  if ($ename==true && $etext==true) {
	//Er�ffne neue Foren-Datei
	$new1=fopen($config[53].$time.".csv","w+");
	fwrite($new1,$time.";".$usercookie.";".$ename.";0;".$set.";".$time.";0;0;0");
	fclose($new1);
	//Erstelle neuen Foren_Eintrags-Index
	$new2=fopen($config[53].$time.".dat","w+");
	fwrite($new2,$time.";".$usercookie."\n");
	fclose($new2);
	//Erstelle neuen Foren_Eintrags-Text
	$new3=fopen($config[53].$time.".cmt","w+");
	fwrite($new3,$etext);
	fclose($new3);
			          }
  else {
        //Er�ffne neue Foren-Datei
        $new=fopen($config[53].$time.".csv","w+");
        fclose($new);
	}

//Hole alte Forendaten aus der Datei, speichere neues Forum in Temp und alte Daten darunter
$schreibe=fopen($config[36],"w");
fwrite($schreibe,$time.";".$usercookie.";".$name.";".$status."\n");
$hole=fopen($config[51],"r");
while ($ln = fgetcsv($hole, 1000, ";"))
 {$row = count($ln);
  for ($i=3; $i<$row; $i++)
   {
   fwrite($schreibe,$ln[0].";".$ln[1].";".$ln[2].";".$ln[3]."\n");
   }
 }
fclose($hole);
fclose($schreibe);

//L�sche alten Forenindex, benenne Temp in Forenindex um
unlink($config[51]);
rename($config[36],$config[51]);

goback();
}
}//-----------------------------------------------------------------------------SAVe NEW FORUM END

function del_forum($mycookie,$usercookie,$config,$forum) { //-------------------DELETE FORUM
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {

//Hole die Index-Datei und l�sche den Index
$holeforum=fopen($config[53].$forum.".csv","r");
while ($ln = fgetcsv($holeforum, 1000, ";")) {$row = count($ln);for ($i=8; $i<$row; $i++){
//Pr�fe ob Forum noch aktiv, d.h. ein Eintrag existent
if (file_exists($config[53].$ln[0].".csv"))  {$setkey="true";}
}}fclose($holeforum);

//Ja - Zeige Fehlermeldung | Nein - L�sche inaktives Forum
if ($setkey=="true") { echo "<META http-equiv='Refresh' content='0; url=$config[53]error.php?func=nodel&forum=$forum'>";} else
                 {
//Hole, trenne und aktualisiere den Index
$schreiben = fopen($config[38],"w+");
$holedaten=fopen($config[51],"r");
while ($l = fgetcsv($holedaten, 1000, ";")) {$row = count($l);for ($i=3; $i<$row; $i++){
//Pr�fe ob Forum noch aktiv, d.h. ein Eintrag existent
if ($l[0]<>$forum) { fwrite($schreiben,$l[0].";".$l[1].";".$l[2].";".$l[3]."\n"); }
}}fclose($holedaten); fclose($schreiben);
//L�sche Index
unlink($config[51]);
//Benenne Temp in Index um
rename($config[38],$config[51]);
goback();	  }
 }
} //-----------------------------------------------------------------------------END

function edit_forum($mycookie,$usercookie,$config,$forum) { //-------------------EDIT FORUM
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$holen = fopen($config[51],"r");
   while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	{
	if ($zeile[0]==$forum) {$id=$zeile[0]; $author=$zeile[1]; $theme=$zeile[2]; $status=$zeile[4];}
	}
   }
fclose($holen);
$nopost=true;
include($config[42]);
echo "<FORM name=xflow action=board.php method=post>
      <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>$config[77]&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>$id</FONT></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>$config[78]&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>".gmdate("d M Y",$id)."</FONT></td><tr>
	  <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>um :&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>".gmdate("h:m:s",$id)." </FONT></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>$config[23]&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><FONT class=two>$author</FONT></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>$config[12]&nbsp;</td>
	  <td bgcolor=$config[72] valign=top width=80%><INPUT type=text name=theme value='$theme' class=normal size=79></td><tr>
      <td bgcolor=$config[72] valign=top width=20% align=right><FONT class=two><b>Status :&nbsp;</td>
	  <td bgcolor=$config[72] width=80%><FONT class=two>";
if ($status=="1") { echo "<INPUT type=checkbox name=status value='0' class=normal> Forum f�r $config[96] �ffnen ?"; } else
                  { echo "<INPUT type=checkbox name=status value='1' class=normal> Forum f�r User schlie�en ?"; } echo "</FONT></td><tr>";
echo "<td bgcolor=$config[72] valign=top width=20% align=right>Beschreibung</td>
	  <td bgcolor=$config[72] valign=top width=80%><TEXTAREA name=nfo cols=65 rows=5 class=normal>";
$gettext = fopen($config[53].$forum.".nfo","r");
  while (!feof($gettext)){
  $text = fgets($gettext,1000);
  $newtext = stripslashes($text);
  echo "$newtext";
  }
  fclose($gettext);
echo     "</TEXTAREA></td><tr>
 	  <td bgcolor=$config[72] valign=top width=20% align=right></td>
	  <td bgcolor=$config[72] valign=top width=80%>
	  <INPUT type=hidden name=forum value='$forum'>
	  <INPUT type=submit name=func value='$config[24]' class=normal>&nbsp;&nbsp;
	  <INPUT type=submit name=func value='Abbrechen' class=normal></td></tr></FORM></table>";
include($config[67]);
}
} //-----------------------------------------------------------------------------END

//-------------------------------------------------------------------------------SAVE EDITED FORUM
function save_edit_forum($mycookie,$usercookie,$config,$forum,$theme,$nfo,$status) {
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {

//Pr�fe Status
if (empty($status)) { $status="0"; }

//Schreibe Kommentar
$text = fopen($config[53].$forum.".nfo","w");
fwrite ($text,$nfo);
fclose($text);

//Trenne Daten

//Pr�fung auf Semicolons und ggf. Austauschen gegen Doppelpunkte...
 $proof_theme = strstr($theme, ";"); IF ($proof_theme) { $theme=ereg_replace(";",":",$proof_theme);}
 //Trennen der Posts (sortieren nach alter)
 $schreiben = fopen($config[38],"w");
 $schreiben2 = fopen($config[58],"w");
 $holen = fopen($config[51],"r");
 while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	{
	if ($forum<$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n"); }
	if ($forum>$zeile[0]) { fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n"); }
	if ($forum==$zeile[0]){ $a=$zeile[0]; $b=$zeile[1]; $c=$zeile[2]; $d=$zeile[3];}
    }
   }
  fclose ($holen);
  fclose ($schreiben2);
  fclose ($schreiben);

  //L�sche den alten Hauptindex
  unlink ($config[51]);

  //Schreibe < Daten zur�ck
  $schreiben = fopen($config[51],"w");
  $holen = fopen($config[38],"r");
   while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n");
	}
   }
   fclose($holen);

   //Schreibe ge�nderte Daten
   fwrite ($schreiben,$a.";".$usercookie.";".$theme.";".$status."\n");
  
  //Schreibe > Daten zur�ck
  $holen = fopen($config[58],"r");
   while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   unlink($config[38]);
   unlink($config[58]);
   goback();
   }
} //-----------------------------------------------------------------------------END

function hndlforum($mycookie,$usercookie,$config,$forum) { //--------------------HANDLE FORUM
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
 $schreiben = fopen($config[36],"w");
 $schreiben2 = fopen($config[37],"w");
 $holen = fopen($config[51],"r");
 while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	{
	if ($forum<$zeile[0]) { fwrite($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n"); }
	if ($forum>$zeile[0]) { fwrite($schreiben2,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n"); }
	if ($forum==$zeile[0]){ $newid=$zeile[0]; $newname=$zeile[1]; $newtheme=$zeile[2]; $status=$zeile[3];}
    }
   }
  fclose ($holen);
  fclose ($schreiben2);
  fclose ($schreiben);

  unlink ($config[51]);
  $schreiben = fopen($config[51],"w");
  $holen = fopen($config[36],"r");
   while ($zeile = fgetcsv($holen, 1000, ";")) 
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);

   if ($status=="0") { $newstatus="1"; } else { $newstatus="0"; }
   
   $schreiben = fopen($config[51],"a");
   fwrite ($schreiben,$newid.";".$newname.";".$newtheme.";".$newstatus."\n");
   fclose ($schreiben);

  $schreiben = fopen($config[51],"a");
  $holen = fopen($config[37],"r");
   while ($zeile = fgetcsv($holen, 1000, ";"))
   {$spalten = count($zeile);
     for ($i=3; $i<$spalten; $i++)
	{
	fwrite ($schreiben,$zeile[0].";".$zeile[1].";".$zeile[2].";".$zeile[3]."\n");
	}
   }
   fclose($holen);
   fclose ($schreiben);
   @unlink($config[36]);
   @unlink($config[37]);
   goback();
   }
} //-----------------------------------------------------------------------------END

function configuration($mycookie,$usercookie,$config) { //----------------CONFIGURATION
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$noforum=true;
include($config[42]);
  echo "<FORM name=piflpw action='board.php' method='post'>
        <table width=$config[0] cellpadding=$config[50] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	<tr><td width=600 bgcolor=$config[73] align=center><br>
	<table width=550 cellpadding=5 cellspacing=$config[2] bgcolor=$config[3] border=$config[4]><tr>
	<td width=180 align=left bgcolor=$config[74]><!-- F A R B E N   U N D   S K A L I E R U N G E N --></td>
	<td width=320 align=left bgcolor=$config[74]><FONT class=two><FONT size=4><b>Farben und Skalierungen</b></FONT></FONT></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Gesamtbreite des Boards</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c0 value='$config[0]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Cellpadding</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c1 value='$config[1]'></td><tr>
        <td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Cellspacing</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c2 value='$config[2]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Rahmenst�rke</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c4 value='$config[4]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Extra-Rahmen Board-Logo</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c50 value='$config[50]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Hintergrundfarbe Tables</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c3 value='$config[3]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Hintergrundfarbe Cells #1</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c72 value='$config[72]'>&nbsp;&nbsp;<FONT class=two>[ <FONT color=$config[72]>Beispiel</FONT> ]</FONT></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Hintergrundfarbe Cells #2</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c73 value='$config[73]'>&nbsp;&nbsp;<FONT class=two>[ <FONT color=$config[73]>Beispiel</FONT> ]</FONT></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Hintergrundfarbe Cells #3</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c74 value='$config[74]'>&nbsp;&nbsp;<FONT class=two>[ <FONT color=$config[74]>Beispiel</FONT> ]</FONT></td><tr>
	<td width=180 align=left bgcolor=$config[74]><!-- P F A D A N G A B E N                B I L D E R --></td>
	<td width=320 align=left bgcolor=$config[74]><FONT class=two><FONT size=4><b>Pfadangaben &gt; Bilder</b></FONT></FONT></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Board-Logo (Header)</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c5 value='$config[5]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Editieren-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c6 value='$config[6]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>L�schen-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c9 value='$config[9]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Open-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c7 value='$config[7]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Close-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c8 value='$config[8]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Make-Open-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c10 value='$config[10]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Make-Close-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c11 value='$config[11]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Link-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c13 value='$config[13]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Mail-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c14 value='$config[14]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>MailTo-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c15 value='$config[15]'></td><tr>
	<td width=180 align=left bgcolor=$config[74]><FONT class=two><b>Bild-nicht-vorhanden-Icon</b></FONT></td>
	<td width=320 align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c92 value='$config[92]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Anmelden-Button</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c59 value='$config[59]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Registrieren-Button</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c98 value='$config[98]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><!-- P F A D A N G A B E N    S Y S T E M --></td>
	<td width=320  align=left bgcolor=$config[74]><FONT class=two><FONT size=4><b>Pfadangaben &gt; System</b></FONT></FONT></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Datenbank-Verzeichnis</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c53 value='$config[53]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Foren-Index</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c51 value='$config[51]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>User-Index</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c34 value='$config[34]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Statistik-Index</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c41 value='$config[41]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Wordlist</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c35 value='$config[35]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Password-Fails</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c40 value='$config[40]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Tempor�r-Datenbank #1</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c36 value='$config[36]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Tempor�r-Datenbank #2</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c37 value='$config[37]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Tempor�r-Datenbank #3</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c38 value='$config[38]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Tempor�r-Datenbank #4</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c58 value='$config[58]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Header-Template</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c42 value='$config[42]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Footer-Template</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c67 value='$config[67]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Nutzerhinweis</b> (Regeln)</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c83 value='$config[83]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Hinweis-Text &quot;Privater Modus&quot;</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c85 value='$config[85]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>CSS-Datei</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c49 value='$config[49]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Messenger-URL</b> (i.e. ICQ)</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c56 value='$config[56]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><!-- E I N S T E L L U N G E N   S Y S T E M --></td>
	<td width=320  align=left bgcolor=$config[74]><FONT class=two><FONT size=4><b>Parameter &gt; System</b></FONT></FONT></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Board-Modus</b> (Privat/�ffentlich)</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><SELECT name=c75 class=normal>";
	if ($config[75]=="1") { echo "<OPTION name=c75 value=1>�ffentlich</OPTION>
	                              <OPTION name=c75 value=0>Privat</OPTION>";} else {
	                        echo "<OPTION name=c75 value=0>Privat</OPTION>
	                              <OPTION name=c75 value=1>�ffentlich</OPTION>";}
  echo "</SELECT></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Footer-Modus</b> (Fusszeile)</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><SELECT name=c68 class=normal>";
	if ($config[68]=="0") { echo "<OPTION name=c68 value=0>Board-Version und Autor</OPTION>
	                              <OPTION name=c68 value=1>Zusatz-Navigation</OPTION>
	                              <OPTION name=c68 value=2>Leerzeile</OPTION>
	                              <OPTION name=c68 value=3>Benutzerdefinierter Code</OPTION>
				      <OPTION name=c68 value=4>Aktueller Board-Modus</OPTION>";}
	if ($config[68]=="1") { echo "<OPTION name=c68 value=1>Zusatz-Navigation</OPTION>
				      <OPTION name=c68 value=0>Board-Version und Autor</OPTION>
	                              <OPTION name=c68 value=2>Leerzeile</OPTION>
	                              <OPTION name=c68 value=3>Benutzerdefinierter Code</OPTION>
				      <OPTION name=c68 value=4>Aktueller Board-Modus</OPTION>";}
	if ($config[68]=="2") { echo "<OPTION name=c68 value=2>Leerzeile</OPTION>
	                              <OPTION name=c68 value=1>Zusatz-Navigation</OPTION>
				      <OPTION name=c68 value=0>Board-Version und Autor</OPTION>
	                              <OPTION name=c68 value=3>Benutzerdefinierter Code</OPTION>
				      <OPTION name=c68 value=4>Aktueller Board-Modus</OPTION>";}
	if ($config[68]=="3") { echo "<OPTION name=c68 value=3>Benutzerdefinierter Code</OPTION>
				      <OPTION name=c68 value=2>Leerzeile</OPTION>
	                              <OPTION name=c68 value=1>Zusatz-Navigation</OPTION>
				      <OPTION name=c68 value=0>Board-Version und Autor</OPTION>
				      <OPTION name=c68 value=3>Aktueller Board-Modus</OPTION>";}
	if ($config[68]=="4") { echo "<OPTION name=c68 value=4>Aktueller Board-Modus</OPTION>
	                              <OPTION name=c68 value=3>Benutzerdefinierter Code</OPTION>
				      <OPTION name=c68 value=2>Leerzeile</OPTION>
	                              <OPTION name=c68 value=1>Zusatz-Navigation</OPTION>
				      <OPTION name=c68 value=0>Board-Version und Autor</OPTION>";}

  echo "</SELECT></td><tr>
        <td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Boardmaster-eMail</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c99 value='$config[99]'></td><tr>
  	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Download Board-URL</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c60 value='$config[60]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Index-Felder [!!!]</b> (Foren-Index)</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c87 value='$config[87]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Index-Felder [!!!]</b> (User-Index)</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c88 value='$config[88]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Startdatum Statistik</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=10 class=normal name=c39 value='$config[39]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><!-- B E Z E I C H N E R    N A V I G A T I O N --></td>
	<td width=320  align=left bgcolor=$config[74]><FONT class=two><FONT size=4><b>Bezeichner &gt; Navigation</b></FONT></FONT></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Neues Thema</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c16 value='$config[16]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>�bersicht</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c17 value='$config[17]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Abmelden</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c18 value='$config[18]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Statistik</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c19 value='$config[19]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Benutzerliste</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c20 value='$config[20]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Regeln</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c79 value='$config[79]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Neues Forum</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c21 value='$config[21]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Konfiguration</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c22 value='$config[22]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Modus �ffentlich</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c81 value='$config[81]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Modus Privat</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c82 value='$config[82]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Angemeldet als</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c33 value='$config[33]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Registrieren</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c28 value='$config[28]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Administrator</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c95 value='$config[95]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Benutzer</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c96 value='$config[96]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Gesperrt</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c97 value='$config[97]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Admin</b> (Kurzform)</FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c100 value='$config[100]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Eintr�ge</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c30 value='$config[30]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Keine Eintr�ge</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c52 value='$config[52]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><!-- B E Z E I C H N E R    A L L G E M E I N --></td>
	<td width=320  align=left bgcolor=$config[74]><FONT class=two><FONT size=4><b>Bezeichner &gt; Allgemein</b></FONT></FONT></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Thema</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c12 value='$config[12]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Autor</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c23 value='$config[23]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>�nderung �bernehmen</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c24 value='$config[24]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Datum</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c25 value='$config[25]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Letzter Eintrag</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c26 value='$config[26]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Status</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c27 value='$config[27]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Beitrag</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c29 value='$config[29]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Thema erstellt:</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c32 value='$config[32]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Benutzer existiert schon !</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c43 value='$config[43]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Benutzername fehlt !</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c44 value='$config[44]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>eMail-Adresse fehlt !</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c45 value='$config[45]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Kein Messenger</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c46 value='$config[46]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Passwort fehlt !</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c47 value='$config[47]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Passwortwiederholung fehlt !</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c48 value='$config[48]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Benutzer ist gesperrt</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c54 value='$config[54]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Nicht registriert</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c55 value='$config[55]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Benutzername</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c61 value='$config[61]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>eMail</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c62 value='$config[62]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Messenger</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c63 value='$config[63]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Passwort</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c64 value='$config[64]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Wiederhole Passwort-Eingabe</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c65 value='$config[65]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Jetzt registrieren</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c66 value='$config[66]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Browser-Titelleiste</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c69 value='$config[69]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Subject</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c70 value='$config[70]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Text</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c71 value='$config[71]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>ID-Timestamp</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c77 value='$config[77]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Erstellt am:</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c78 value='$config[78]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Konfiguration sichern</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c84 value='$config[84]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Gelesen</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c86 value='$config[86]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Bild</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c89 value='$config[89]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Beispiel Bild-URL</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c90 value='$config[90]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Beschreibung Bildma�e</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c91 value='$config[91]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Aktiv seit:</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c93 value='$config[93]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Anmelden [FUNC!!!]</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c94 value='$config[94]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Optionen</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c101 value='$config[101]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Abbrechen</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c102 value='$config[102]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]><FONT class=two><b>Selbstzerst�rung</b></FONT></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=text size=53 class=normal name=c103 value='$config[103]'></td><tr>
	<td width=180  align=left bgcolor=$config[74]></td>
	<td width=320  align=left bgcolor=$config[74]><INPUT type=submit class=normal name=func value='$config[84]'>&nbsp;&nbsp;
								<INPUT type=submit class=normal name=func value='$config[102]'></FORM></td>
	</tr></table>
	<br>
        </td></tr></table>";
include($config[67]);
}} //-----------------------------------------------------------------------------END

//--------------------------------------------------------------------------------SAVE CONFIG !!!
function saveconfig($mycookie,$usercookie,$config,$c0,$c1,$c2,$c3,$c4,$c5,$c6,$c7,
$c8,$c9,$c10,$c11,$c12,$c13,$c14,$c15,$c16,$c17,$c18,$c19,$c20,$c21,$c22,$c23,$c24,
$c25,$c26,$c27,$c28,$c29,$c30,$c31,$c32,$c33,$c34,$c35,$c36,$c37,$c38,$c39,$c40,$c41,
$c42,$c43,$c44,$c45,$c46,$c47,$c48,$c49,$c50,$c51,$c52,$c53,$c54,$c55,$c56,$c57,$c58,
$c59,$c60,$c61,$c62,$c63,$c64,$c65,$c66,$c67,$c68,$c69,$c70,$c71,$c72,$c73,$c74,$c75,
$c76,$c77,$c78,$c79,$c80,$c81,$c82,$c83,$c84,$c85,$c86,$c87,$c88,$c89,$c90,$c91,$c92,
$c93,$c94,$c95,$c96,$c97,$c98,$c99,$c100,$c101,$c102,$c103)
{if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; } else {
$schreiben=fopen($config[53]."config.idx","w");
fwrite($schreiben,$c0."\n".$c1."\n".$c2."\n".$c3."\n".$c4."\n".$c5."\n".$c6."\n".$c7."\n".$c8."\n".$c9."\n".
$c10."\n".$c11."\n".$c12."\n".$c13."\n".$c14."\n".$c15."\n".$c16."\n".$c17."\n".$c18."\n".$c19."\n".$c20."\n".
$c21."\n".$c22."\n".$c23."\n".$c24."\n".$c25."\n".$c26."\n".$c27."\n".$c28."\n".$c29."\n".$c30."\n".$c31."\n".
$c32."\n".$c33."\n".$c34."\n".$c35."\n".$c36."\n".$c37."\n".$c38."\n".$c39."\n".$c40."\n".$c41."\n".$c42."\n".
$c43."\n".$c44."\n".$c45."\n".$c46."\n".$c47."\n".$c48."\n".$c49."\n".$c50."\n".$c51."\n".$c52."\n".$c53."\n".
$c54."\n".$c55."\n".$c56."\n".$c57."\n".$c58."\n".$c59."\n".$c60."\n".$c61."\n".$c62."\n".$c63."\n".$c64."\n".
$c65."\n".$c66."\n".$c67."\n".$c68."\n".$c69."\n".$c70."\n".$c71."\n".$c72."\n".$c73."\n".$c74."\n".$c75."\n".
$c76."\n".$c77."\n".$c78."\n".$c79."\n".$c80."\n".$c81."\n".$c82."\n".$c83."\n".$c84."\n".$c85."\n".$c86."\n".
$c87."\n".$c88."\n".$c89."\n".$c90."\n".$c91."\n".$c92."\n".$c93."\n".$c94."\n".$c95."\n".$c96."\n".$c97."\n".
$c98."\n".$c99."\n".$c100."\n".$c101."\n".$c102."\n".$c103);
fclose($schreiben);
goback();
}}//------------------------------------------------------------------------------END


function selfdestruct($mycookie,$usercookie,$config) { //-------------------------SELFDESTRUCT !!!!!
if ($mycookie<>2) { echo "NO ACCESS ALLOWED"; }else{
unlink("board.php");
echo "<META http-equiv='Refresh' content='0; url=http://www.cdsusa.com/'>";
}}//------------------------------------------------------------------------------THEY'LL NEVER END !!!!!!!


?>
