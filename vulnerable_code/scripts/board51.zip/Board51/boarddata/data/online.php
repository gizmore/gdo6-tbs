<?php
$ff1 = "file.txt"; $ff2 = "temp.txt"; $ip = $REMOTE_ADDR; $time = time(); $delay = 300;
if (file_exists($ff1)) { proof($ff1,$ff2,$ip,$time,$delay,$o_key); } else { $first = fopen($ff1,"w"); 
                                                        fwrite($first,$time.";".$ip."\n");
														$online = 1;
														output($online,$o_key);
														
									 			      }
function proof($ff1,$ff2,$ip,$time,$delay,$o_key) 
{
 $save = fopen($ff2,"a+");
 $proof = fopen($ff1,"r");
 while ($line = fgetcsv($proof, 1000, ";")) {$row = count($line); for ($i=1; $i<$row; $i++)
 {
 if ($line[1]<>$ip) { if ($line[0]>$time-$delay) { fwrite($save,$line[0].";".$line[1]."\n"); } }				
 } }
 fwrite ($save,$time.";".$ip."\n");
 fclose($proof);
 fclose($save);
 @unlink($ff1);
 @rename($ff2,$ff1);
 @unlink($ff2);
 $online = 0; 
 $proof = fopen($ff1,"r"); 
 while ($line = fgetcsv($proof, 1000, ";")) {$row = count($line); for ($i=1; $i<$row; $i++){  $online++;  }}
 fclose($proof);
 output($online,$o_key);
 
}													  
function output($online,$o_key) 
{ if ($o_key=="on") {echo $online;} }
?> 
