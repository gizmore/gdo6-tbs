<?php
  /*FOOTER - FILE
    created 01.10.02
    by laforge */

if ($config[68]=="0") { onlyautor($config);}
if ($config[68]=="1") { tools($config);    }
if ($config[68]=="2") { emtpy($config);    }
if ($config[68]=="3") { custom($config);   }
if ($config[68]=="4") { modus($config);    }


function onlyautor($config) { //----------------------------------------ONLY AUTOR
echo "<br><table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
      <tr><td width=100% bgcolor=$config[74] valign=middle align=center><FONT class=one><FONT color=#636468>
      board51 v1.0 - written by laforge</FONT></FONT></td></tr></table>";
} //--------------------------------------------------------------------END

function tools($config) { //--------------------------------------------TOOLS
echo "<br><table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
      <tr><td width=100% bgcolor=$config[74] valign=middle align=center><FONT class=one><FONT color=#636468>
      <A href='mailto:$config[99]'>Boardmaster</A> | <A href='board.php?func=rules'>Nutzungshinweis</A> | <A target='new' href='$config[60]'>Download Board51</A></FONT></FONT></td></tr></table>";
} //--------------------------------------------------------------------END

function emtpy($config) { //--------------------------------------------EMPTY COLUMN
echo "<br><table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
      <tr><td width=100% bgcolor=$config[74] valign=middle align=center> </td></tr></table>";
} //--------------------------------------------------------------------END

function modus($config) { //--------------------------------------------EMPTY COLUMN
echo "<br><table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
      <tr><td width=100% bgcolor=$config[74] valign=middle align=center><FONT class=one><FONT color=#636468>";
if ($config[75]=="1") { echo $config[81]; } else { echo $config[82]; }
echo "</FONT></FONT></td></tr></table>";
} //--------------------------------------------------------------------END


function custom($config) { //-------------------------------------------CUSTOM

// ENTER YOUR CODE HERE !

} //--------------------------------------------------------------------END
?>
