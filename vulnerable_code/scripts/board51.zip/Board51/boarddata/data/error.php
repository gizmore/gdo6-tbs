<?php

/*   ERROR-TEMPLATE
     BOARD/FORUM51
     by laforge Y2002
*/
if ($func=="selfdestruct")     { selfdestruct();}
if ($func=="blockedadmin")     { blockedadmin($forum); }
if ($func=="deladmin")         { deladmin($forum); }
if ($func=="delwarn")          { delwarn($id,$forum); }
if ($func=="closedthread")     { closedthread($id,$theme,$status,$forum); }
if ($func=="error404")         { error404($forum); }
if ($func=="blocked")          { blocked($id,$forum); }
if ($func=="mailfailure")      { mailfailure($forum); }
if ($func=="nodel")            { nodel($forum); }
if ($func=="noaccess")         { noaccess($forum);}

function blockedadmin($forum) { //--------------------------------------------------------BLOCKED ADMIN

echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/error.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two> Du versuchst gerade einen Administrator zu blockieren.<br>
	                   Das ist nicht m�glich. Sollte dein Anliegen, diesen Administrator<br>
					   zu blockieren, berechtigt sein, so setze dich mit ihm pers�nlich<br>
					   in Verbindung.<br><br>
					   Benutze den &quot;Zur�ck&quot;-Button deines Browsers oder warte<br>
					   15 Sekunden, um zur Benutzerliste zur�ck zu gelangen...<br> 
					   <br></b></FONT></td></tr></table>";
echo "<META http-equiv='Refresh' content='15; url=../../board.php?func=showusers'>";			
}//---------------------------------------------------------------------------------END		

function deladmin($forum) { //------------------------------------------------------------DELETE ADMIN

echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/error.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two> Du versuchst gerade einen Administrator zu l�schen.<br>
	                   Das ist nicht m�glich. Nur durch manuelle Ver�nderung<br>
					   der Userliste kann ein Administrator vollst�ndig gel�scht<br>
					   werden. <br><bR>
					   Benutze den &quot;Zur�ck&quot;-Button deines Browsers oder warte<br>
					   15 Sekunden, um zur Benutzerliste zur�ck zu gelangen...<br> 					   
					    <br></b></FONT></td></tr></table>";
echo "<META http-equiv='Refresh' content='15; url=../../board.php?func=showusers'>";
}//---------------------------------------------------------------------------------END

function delwarn($id,$forum) { //----------------------------------------------------------DELETE WARNING
echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <FORM name=flow method=post action='../../board.php'>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/warning.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two> Soll der Benutzer wirklich gel�scht werden ?<br>
					   Gel�schte Benutzer k�nnen nicht wiederhergestellt<br>
					   werden !<br><br>
					      <INPUT type=hidden name=id value='$id'>
						  <INPUT type=submit name=func value='Delete' class=normal>&nbsp;&nbsp;
						  <INPUT type=submit name=func value='Cancel' class=normal></FORM>
					    <br></b></FONT></td></tr></table>";
}//---------------------------------------------------------------------------------END

function closedthread($id,$theme,$status,$forum) { //--------------------------------------------------------CLOSED THREAD
echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/error.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two> Du versuchst gerade einen Beitrag zu einem bereits geschlossenen<br>
	                   Thema zu schreiben. Das ist nicht m�glich.<br>
					   Bitte setze dich mit dem Ersteller des Themas, oder mit dem Administrator<br>
					   in Verbindung, wenn dir dein Beitrag notwendig erscheint.<br><br>
					   Klicke <A href='../../board.php?func=showpost&id=$id&theme=$theme&status=$status&forum=$forum'>hier</A> oder warte<br>
					   15 Sekunden, um zur Benutzerliste zur�ck zu gelangen...<br> 					   
					    <br></b></FONT></td></tr></table>";
echo "<META http-equiv='Refresh' content='15; url=../../board.php?func=showpost&id=$id&theme=$theme&status=$status&forum=$forum'>";
}//---------------------------------------------------------------------------------END
	
function error404($forum) { //-----------------------------------------------------------------NOT FOUND
echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/error.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two> Das gew�nschte Thema existiert nicht mehr. 
	                                   Es ist entweder vom Administrator gel�scht worden, oder<br>
					   konnte aufgrund eines Serverfehlers nicht geladen werden.<br><br>
					   Setze dich bitte mit dem Administrator des boards in Verbindung.<br><br>					  
					   Benutze den &quot;Zur�ck&quot;-Button deines Browsers oder warte<br>
					   15 Sekunden, um zur Benutzerliste zur�ck zu gelangen...<br> 					    					   
					    <br></b></FONT></td></tr></table>";
echo "<META http-equiv='Refresh' content='15; url=../../board.php?func=listthread&forum=$forum'>";
}//---------------------------------------------------------------------------------END				

function blocked($id,$forum) { //-----------------------------------------------------------------BLOCKED
echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/error.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two> Du bist nicht berechtigt in diesem Board Beitr�ge zu schreiben.<br><br>
                       Der Grund daf�r ist entweder die manuelle Sperrung durch den Administrator<br>
					   oder die automatische Sperrung, verursacht durch einen Versto� deinerseits<br>
					   gegen die Regeln dieses boards...<br><br>
                       G�ste, die sich mit dem Benutzernamen &quot;Guest&quot; eingeloggt haben,<br>
					   k�nnen ebenfalls keine Eintr�ge vornehmen.<br><bR>					   
					   Benutze den &quot;Zur�ck&quot;-Button deines Browsers oder warte<br>
					   15 Sekunden, um zur Benutzerliste zur�ck zu gelangen...<br> 					    					   
					    <br></b></FONT></td></tr></table>";
echo "<META http-equiv='Refresh' content='15; url=../../board.php?func=listthread&forum=$forum'>";
}//---------------------------------------------------------------------------------END		

function mailfailure($forum) { //-----------------------------------------------------MAIL FAILURE
echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/error.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two> Leider ist bei dem Versuch, deine Mail zu versenden, ein Fehler aufgetreten<br>
                       Schuld daran kann entweder eine falsch eingegebene eMail-Adresse,<br>
					   ein Serverfehler oder Wartungsarbeiten sein.<br>
					   Probiere es bitte etwas sp�ter noch einmal. Sollte sich dieser Fehler<br>
					   widerholen, so informiere bitte den Administrator...<br><br>
					   Benutze den &quot;Zur�ck&quot;-Button deines Browsers oder warte<br>
					   15 Sekunden, um zur Benutzerliste zur�ck zu gelangen...<br>
					    <br></b></FONT></td></tr></table>";
echo "<META http-equiv='Refresh' content='0; url=../../board.php?func=showusers'>";

}//-----------------------------------------------------------------------------END

function nodel($forum) { //-----------------------------------------------------Cannot delete Forum
echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/error.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two>Das zu l�schende Forum ist nicht leer !<br>
					   Bitte zuerst alle Threads im jeweiligen Forum l�schen.<br><br>
					   Benutze den &quot;Zur�ck&quot;-Button deines Browsers oder warte<br>
					   15 Sekunden, um zur Board�bersicht zur�ck zu gelangen...<br>
					    <br></b></FONT></td></tr></table>";
echo "<META http-equiv='Refresh' content='15; url=../../board.php'>";

}//-----------------------------------------------------------------------------END

function noaccess($forum) { //--------------------------------------------------NO ACCESS
echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/error.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two>Kein Zugriff auf dieses Forum !<br>
					   Dieses Forum zur Zeit nur den Administratoren zug�nglich.<br>
			                   Benutze den &quot;Zur�ck&quot;-Button deines Browsers oder warte<br>
					   15 Sekunden, um zur Board�bersicht zur�ck zu gelangen...<br>
					    <br></b></FONT></td></tr></table>";
echo "<META http-equiv='Refresh' content='15; url=../../board.php'>";

}//-----------------------------------------------------------------------------END

function selfdestruct() { //----------------------------------------------------------DELETE WARNING
echo "<HTML><HEAD><LINK href='../styles/standard.css' type=text/css rel=stylesheet></HEAD><BODY><center><br>
      <FORM name=flow method=post action='../../board.php'>
      <table width=600 bgcolor=000000 cellpadding=5 cellspacing=1 border=0 height=250><tr>
      <td bgcolor=FFFFFF width=10% valign=top align=center><br>
	  <FONT class=four><b><IMG src='../gfx/warning.gif' border=0 alt='Error'></b> </FONT></td>
	  <td bgcolor=EFEFEF width=90% valign=top><br>
	  <FONT class=two> Willst du das Board zerst�ren, so best�tige<br>
			   mit &quot;YES&quot;, anderenfalls kehre mit &quot;NO&quot;<br>
			   zum Board zur�ck. <br><br>			   			  
						  <INPUT type=submit name=selfdestruct value='YES' class=normal>&nbsp;&nbsp;
						  <INPUT type=submit name=selfdestruct value='NO' class=normal></FORM>
					    <br></b></FONT></td></tr></table>";
}//---------------------------------------------------------------------------------END

?>
