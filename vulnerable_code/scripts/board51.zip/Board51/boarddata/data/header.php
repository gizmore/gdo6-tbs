<?php
 /* NAVIGATION - FILE 
    created 01.10.02
    by laforge */

if (empty($mycookie)) {
     echo"
	  <!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>
      <HTML><HEAD><TITLE>$config[69]</TITLE>
	  <link href='$config[49]' type='text/css' rel='stylesheet'>
	  </HEAD>
	  <BODY>
	  <center><br>
<FORM action='board.php' method='post'>
      <table width=$config[0] cellpadding=$config[50] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	  <tr><td width=600><IMG src='$config[5]' border=0></td></tr></table><br>
	  <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	  <tr><td width=100% bgcolor=$config[74] valign=middle align=right>

	  <INPUT type=text class=normal size=20 name=username value='Benutzername'>&nbsp;&nbsp;
	  <INPUT type=password class=normal size=20 name=password value=' password'>&nbsp;&nbsp;
	  <INPUT type=submit align=center name=func value='$config[94]' class=normal>&nbsp;&nbsp;
	  <INPUT type=submit align=center name=func value='$config[28]' class=normal>&nbsp;
	  </td></tr></table></FORM>";
	  } else {

if ($mycookie>"0") {
echo "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>
      <HTML><HEAD><TITLE>$config[69]</TITLE>
	  <link href='$config[49]' type='text/css' rel='stylesheet'>
	  </HEAD>
	  <BODY><center><br>
      <FORM action='board.php' method=post name=flowforever>
      <table width=$config[0] cellpadding=$config[50] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	  <tr><td width=600><IMG src='$config[5]' border=0></td></tr></table><br>
	  <table width=$config[0] cellpadding=$config[1] cellspacing=$config[2] bgcolor=$config[3] border=$config[4]>
	  <tr><td width=18% bgcolor=$config[74] valign=top valign=middle>";
if ($theme) { 
if ($nopost==true) {
echo "<FONT class=two><IMG src='$config[13]' valign=middle><FONT color=#636468>&nbsp;&nbsp;<b>$config[29]</b></FONT><br>";} else {
echo "<FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=newpost&id=$id&theme=$theme&status=$status&forum=$forum'><b>$config[29]</b></A><br>";
                       }} else {
if ($noforum==true) {
echo "<FONT class=two><IMG src='$config[13]' valign=middle><FONT color='#636468'>&nbsp;&nbsp;<b>$config[16]</b></FONT><br>";
					} else {
echo "<FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=newthread&forum=$forum'><b>$config[16]</b></A><br>"; }}
if ($noback==true) {
echo "<FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<FONT color=#636468>$config[17]</FONT><br>";} else {
echo "<FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=back2'>$config[17]</A><br>";}
echo "<FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=delcookies'>$config[18]</A>
      </td><td width=22% bgcolor=$config[74] valign=top>
      <FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=statistic'>$config[19]</A><br>
      <FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=showusers'>$config[20]</A><br>
	  <FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=rules'>$config[79]</A><br></td>";
if ($mycookie=="2") {
echo "<td width=22% bgcolor=$config[74] valign=top>
	  <FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=newforum'>$config[21]</A><br>
	  <FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A href='board.php?func=configuration'>$config[22]</A><br>
	  <FONT class=two><IMG src='$config[13]' valign=middle>&nbsp;&nbsp;<A class=imp href='board.php?func=selfdestruct'>$config[103]</A><br>";}
echo "</td><td width=34% bgcolor=$config[74] valign=center align=left>";
if ($mycookie=="1") { echo "<FONT class=one>&nbsp;&nbsp;$config[33] $config[96]
      <A href='board.php?func=profile&id=$usercookie'><FONT color=#092473><b><u>$usercookie</b></u></FONT></A>"; }
if ($mycookie=="2") { echo "</b><FONT class=one>&nbsp;&nbsp;$config[33] $config[100]
      <A href='board.php?func=profile&id=$usercookie'><FONT color=#092473><b><u>$usercookie</b></u></FONT></A>"; }
if ($mycookie=="3") { echo "</b><FONT class=one>&nbsp;&nbsp;$config[33] $config[96]
      <A href='board.php?func=profile&id=$usercookie'><FONT color=#092473><b><u>$usercookie</b></u></FONT></A> &nbsp;<b>[$config[97]]</b>"; }
echo "<br>&nbsp;&nbsp;Besucher online : <b>";

 $online = 0;
 $proof = fopen("boarddata/data/file.txt","r"); 
 while ($line = fgetcsv($proof, 1000, ";")) {$row = count($line); for ($a=1; $a<$row; $a++){  $online++;  }}
 fclose($proof);
 echo $online;
echo "</b></FONT> </td></tr></table></FORM>";	 

}}

?>
