Instructions:

- Study the given printf_vuln
- The provided binary is located at /home/levels/printf_vuln
- This program has the rights to read /home/levels/printf_sol.txt
- Make your exploit print the contents of /home/levels/printf_sol.txt to the screen

There is one little problem:
You have no write access to the directory the exploit will be run in, so you cannot create any files in there. 

Just send your perl script, c source (!) & compiling options (if you want any special) or any other script that runs on linux to my email matrix_man@gmx.net with subject challenge name and your tbs username. 
And please be patient, i cannot always check your solution within one day, so just wait, i'll reply to every submission as soon as i can.

matrixman