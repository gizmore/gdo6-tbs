

Welcome to your worst nightmare ...


=====================================================================================
*                                                                                   *
*   Your boss has just discovered that you have been h4ck1ng and r3v3rs1ng on       *
*                                                                                   *
*   TheBlacksheep (http://www.bright-shadows.net/) during work hours.               *
*                                                                                   *
=====================================================================================


Your first thought, "I should delete the stuff from my PC", destroy the evidence.

As you attempt to logon, your PC automatically locks and a "Sentinel" dialog appears
asking for a password.

The boss has devised an evil little challenge of his own to test your skills. You have
til the end of the day to get the password or else you're fired.


In case you don't know what to do you can start with these tools :-

Reflector		-->	http://www.aisto.com/roeder/dotnet/

Salamander		-->	http://www.remotesoft.com/salamander/



P.S. When you find the password for the "Sentinel" you will get the password for the
     challenge. This can be done in less than 5 mins with the right tools.
     Good luck ...