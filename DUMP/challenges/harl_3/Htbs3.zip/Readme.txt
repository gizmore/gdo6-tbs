Hi, I really need your help!
I have lost my password to tbs, however I know I used the same password to encrypt the following text: 
"Harley's crackmes make my head hurt"
using a simple encryption program I was trying out. 
The output file was as follows:

35 7B EB 99 EA B8 38 47 53 51 66 1A 9E DC AD 52  5{��8GSQf�ܭR
3E C8 9B 2C 3E 18 FC 4A 35 DF BF CE 59 F2 12 39  >ț,>�J5߿�Y�9
38 31 0B 00 00 00 00 00 00 00 00 00 00 00 00 00  81.............

Unfortunatly I removed the program from my system and I cannot remember its name. Like all good installers though it didn't clean up all its mess and I found the attached dll in my system folder.
Can you recover my lost password for me?
A few things I do remember which might help you on your way:
When I installed the program it asked me for an unlock code, and I noticed it created a file unlock.dat. I also remember while cracking the original program, all the dll functions began with the same instructions.
The first time I ran it it asked me to register otherwise it would not proceed.
I managed to crack it for my username and had the program working fully.
It would encrypt text using an entered password, pretty basic stuff really, I am sure you wont have much difficulty with it.
Oh yeah, dont know if it helps but my password was all lower case.

Thanks in advance

Harlequin

PS: To the merry moaners. I wrote, checked and cracked this all on a 400mhz 2g HD 64mb-ram, using OllyDbg alone, while online running irc/icq etc. So if you cant do it with your 200ghz 3000mb-ram machine then dont look to me to blame.