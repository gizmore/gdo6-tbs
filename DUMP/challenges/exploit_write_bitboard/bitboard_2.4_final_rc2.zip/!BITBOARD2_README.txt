**********************************************************
** "BiTSHiFTERS BiTBOARD" Bulletin Software		**
**							**
** written 2003 by Spy98				**
** (C)opyright 2000 - 2003 by the BiTSHiFTERS SDC	**
** All Rights Reserved					**
**********************************************************

Thank you for downloading and trying BiTSHiFTERS BiTBOARD.

==========================================================

1) Introduction
2) End User License Agreement
3) If you're upgrading from v1.0
4) Installation
5) Release Notes
6) Contact
7) Thanks

==========================================================

1) Introduction

The BiTBOARD is a Internet Bulletin Board software based
on the Scripting Language PHP.
It is a small, clean and fast forum for home or personal
use. Its usage of flatfile databases makes it the perfect
choice for webdesigners / administrators without MySQL-
support on their websites.

BiTBOARD is easy to install and configure. 
By using CSS stylesheets BiTBOARD enables users to change 
the colors to fit their website.
And best of all, BiTBOARD is free of charge and ads.

=========================================================

2) End User License Agreement

Please refer to "Bitshifters_EULA.txt" file,
installed with this package.

==========================================================

3) If you're upgrading from v1.0

Thanks for using version 1.0. We hope you were 
satisfied enough to give the latest release a try.
We hope you won't be dissatisfied.

There are a few points to remember when upgrading.
You can delete the contents database file
(data_contents.txt) because its of no use anymore.
You can keep the contentsfolder of your previous 
installation but have to rename it to "contents".

Timestamp functions for "started by" won't work
in old posts. Only freshly posted posts will use 
this feature.

If you can afford to loose current posts, delete your
whole folder and upload the included folder-structure
to begin with a fresh installation.

The Admin Place is new. You can reach it by 
http://yourhost.com/bitboard/admin/index.php

==========================================================

4) Installation

Follow the following quick steps to install
your BiTBOARD community forum...

-> Unpack all the files to a destination of your choice.

-> Open up "bitboard_configuration.php", located in the
   includes folder and set the configuration-variables 
   (in the *configs* section) to your fit.

-> Upload all the folders content (including subfolders)
   to your webserver.

-> Create a link to the document "bitboard_forum.php" on
   your website, to let users access it.

-> In your webbrowser launch the admin interface.
   Example: 
	www.mywebspace.com/bitboard/admin/index.php

-> LogIn with the default password "install".
   In the menu, selecht "change password" and change it.	

If further assistance is needed, please do not hesitate
to contact us using the options stated below...

==========================================================

5) Release Notes

BiTBOARD is a basic forum for your personal use.
It was programmed on an Apache 1.3.23 WindowsXP
Platform with PHP 4.3.0. It has been tested 
to work with PHP version 4.1.1 on a 
Linux Apache Platform.

The Forums Software is not built to be 
"something special". It is built to score in speed,
compatabillity (not everyone owns a mySQL) and 
communication - thats what forums should be about.

To improve security, you should, if possible,
run the forum in a frame or inline-frame.

==========================================================

6) Contact

For support questions, further assistance or 
general questions and comments, 
don't hesitate to visit our website at:

	* http://www.bitshifters.bl.am

we have bitboard installed as forum, and like
to get in touch with, and help out with any
problems that might come up.

or email the author directly:

	* Email : Spy98@gmx.net * ICQ : 92069265

==========================================================

7) Thanks

The BiTSHiFTERS SDC would like to thank following testers
of the CE-BF Community (www.cebf.ws) for their much 
appreciated support (in no particular order)...

	- fedaykin
	- legheliel
	- mickle
	- khl86
	- sitnika.co
	- manowar
	- guido
	- thanatos
	- cyma
	- zzice
	- chipper
	- cliff
	- TheGrey

==========================================================
----------------------------------------------------------
(C)oypright 2002 by The BiTSHiFTERS SDC.
All Rights Reserved.
----------------------------------------------------------
