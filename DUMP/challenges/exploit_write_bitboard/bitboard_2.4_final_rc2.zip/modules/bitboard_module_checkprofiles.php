<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////

if (isset($HTTP_POST_VARS['txtUserName'])) {

    // User probably not logged in, we get the username from form.
    $pwdFile = strtolower(trim($HTTP_POST_VARS['txtUserName'])).".inf";
    
}else{

    // User logged in, get username from cookie.
    $cookie_username = $HTTP_COOKIE_VARS['usr'];
    $cookie_username = $cookie_username['name'];
    
    $pwdFile = strtolower(trim($cookie_username)).".inf";
    
}

if (file_exists("./profiles/pwd_".$pwdFile)) {

    // Profile exists... check if the user logged in:
    if (!isset($HTTP_COOKIE_VARS['usr'])) {

        // FAIL: User did not log in...
        $ERRORFLAG = " *NOPASS";
        
    }else{

        // OKAY: User logged in.
        // Check for password again (hey you never know! ;))
        $cookie_password = $HTTP_COOKIE_VARS['usr'];
        $cookie_password = trim($cookie_password['pass']);

        $stored_password = file("./profiles/pwd_".$pwdFile);
        $stored_password = trim($stored_password[0]);

        if ($cookie_password != $stored_password) {

            // FAIL: Strangely enough the password is all wrong...
            $ERRORFLAG = " *NOPASS";

        }
        
    }
    
}

// NO PROFILE EXISTS:.. Dont care ;)

?>

