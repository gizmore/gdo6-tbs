<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


// Lets Log...
$lgf = fopen($BITBOARD_LOGFILE,'a');
if(!$lgf){
    echo $BITBOARD_ERRCONTENTFILE;
    exit;
}

if(isset($REPLYTO))
{

    // IS a reply.
    $USEDTOPICID = $REPLYTO;

}else{

    // IS new topic.
    $USEDTOPICID = $tmpTopicID;

}
    
$LOGDATE=date("j.n.Y H:i:s",time());

// If $REMOTE_ADDR is not globaly accessible try catch it from ENV VARS...

if (empty($REMOTE_ADDR) || !isset($REMOTE_ADDR)) {

    // If also ENV VARS wont be working try last thing - getenv...

    if (empty($HTTP_ENV_VARS['REMOTE_ADDR']) || !isset($HTTP_ENV_VARS['REMOTE_ADDR'])) {

        // Env Vars is not accessible, use getenv.
        $LOGIP = getenv('REMOTE_ADDR');
        
    }else{

        // Env vars okay, use this one.
        $LOGIP = $HTTP_ENV_VARS['REMOTE_ADDR'];

    }

}else{

    // $REMOTE ADDR is accessible, lets use this one.
    $LOGIP = $REMOTE_ADDR;
}

if (!empty($LOGIP)) {
    $LOGADR = gethostbyaddr($LOGIP);
}else{
    $LOGIP = "0.0.0.0";$LOGADR = "0.0.0.0";
}

$LOGLINE = $LOGDATE."#".$txtUserName."#".$txtSubject."#".$USEDTOPICID."#";
$LOGLINE .= $LOGIP."#".$LOGADR."\r\n";

fwrite($lgf,$LOGLINE);
fclose($lgf);

?>

