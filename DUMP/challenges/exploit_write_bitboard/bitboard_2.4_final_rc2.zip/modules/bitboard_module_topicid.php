<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


function CREATETOPICID()
{
    do {
        srand(time());
        $tmpString = "";
        for ($i=1; $i<10; $i++)
        {
            $tmpString .= chr(rand(0,25) + ord("a"));
        }

        $tmpFName = "tpc_".$tmpString."_".time();
        $tmpFName = stripslashes($tmpFName);

        if (file_exists($tmpFName.".txt")) {
            $AVAIL=0;
        }else{
            $AVAIL=1;
        }

    } while ($AVAIL==0);

    return $tmpFName;
}

?>

