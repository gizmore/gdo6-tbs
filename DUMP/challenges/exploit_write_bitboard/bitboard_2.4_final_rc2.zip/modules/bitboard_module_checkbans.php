<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


////////////Filterfiles
if (filesize($BITBOARD_BANNEDUSERSFILE) > 0) {

    ////////////Filter function --BANNED USERS--...
    $BANNED_USERS = @file($BITBOARD_BANNEDUSERSFILE) or Die($BITBOARD_ERRBANNEDUSERSFILE);

    for ($X=0; $X<=sizeof($BANNED_USERS); $X++){
        if (strtolower(trim($BANNED_USERS[$X])) == strtolower(trim($HTTP_POST_VARS['txtUserName'])))
        {
            $ERRORFLAG = " *BANNED";
        }
    }

}

if (filesize($BITBOARD_BANNEDIPSFILE) > 0) {

    ////////////Filter function --BANNED IPS--...
    $BANNED_IPS = @file($BITBOARD_BANNEDIPSFILE) or Die($BITBOARD_ERRBANNEDIPSFILE);

    for ($X=0; $X<=sizeof($BANNED_IPS); $X++){

        if (strtolower(trim($BANNED_IPS[$X])) == $REMOTE_ADDR)
        {
            $ERRORFLAG = " *BANNED";
        }
        if (strtolower(trim($BANNED_IPS[$X])) == $HTTP_ENV_VARS['REMOTE_ADDR'])
        {
            $ERRORFLAG = " *BANNED";
        }

    }

}
?>

