<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////

/*

    REVISION 2
    
    Programmed by Michael Opacic
    www.sandsoft.co.uk
    
    Mike@sandsoft.co.uk
    
*/



function FilterBadmouth($stringneedle)
{
   global $BITBOARD_BADMOUTHFILE;
   $asterisks = "********************";

   ////////////Badmouthing words...
   $BADMOUTH = @file($BITBOARD_BADMOUTHFILE) or Die($BITBOARD_ERRBADMOUTHFILE);

   ////////////Filter function...
   $needleCopy = " ".strtoupper($stringneedle)." ";
   $needleCopy = strtr($needleCopy,",.;()[]{}-_+*�$!=:@~/|&^><#", "                           ");
   for ($X=0; $X<=sizeof($BADMOUTH); $X++){
      $bWord = Trim(strtoupper($BADMOUTH[$X]));
      if ($bWord != "") {
         $bWord = " ".$bWord." ";
         $needleCopy = str_replace($bWord," ".substr($asterisks,0,(strlen($bWord)-2))." ",$needleCopy);
      }
   }

   $needleCopy = substr($needleCopy,1,strlen($needleCopy)-2);

   for ($x=0; $x<strlen($needleCopy);$x++) {
      if (substr($needleCopy,$x,1)=="*") {
         $stringneedle = substr_replace($stringneedle,"*",$x,1);
      }
   }

   return $stringneedle;
}

?>

