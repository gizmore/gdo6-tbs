Free Images by Forum Images.com

ABOUT
As we firmly believe in the free software philosophy, in this archive you will find a set of free images that were primarily designed for use with the phpBB version 2.x forum software that is available from http://www.phpbb.com/.

----------

USAGE
You may use these images free of charge, but we do ask that you place a link somewhere on your site/forum linking back to our main site at http://www.forumimages.com/. Another request we have is that the Forum Images web site and our efforts are supported by our web host, Efficient Hosting, who provide UK based hosting with both excellent features and support. Please feel free to visit the Efficient Hosting web site if you need quality hosting for your site;

http://www.efficienthosting.co.uk/index.cgi?eh=1078

----------
CONTENTS OF THIS ARCHIVE
Emoticons (smilies) for dark backgrounds
----------
HELP
Please do not ask for help with adding these images to your forum and/or web site - Read the documentation that came with the software as well as checking the Forum Images web site.
----------

DISTRIBUTION
This file should accompany the images if you are re-distributing this archive. No charge is to be made for the supply of these images without prior permission of Darren Burnhill.

----------

CONTACTING US
The most reliable way in which to contact us is via the phpBB Community forum;
Member Name: Daz
Profile: http://www.phpbb.com/phpBB/profile.php?mode=viewprofile&u=2135

Email contact is available at the Forum Images web site for those that need to, although we do not accept requests through the web site.

----------

LEGAL INFORMATION
Unless stated otherwise, all images are copyright (c) Darren Burnhill 2002 - please do not sell these graphics without prior permission.

We create all the images ourselves, but if you feel we have in any way infringed on your rights as a company or individual, please contact us via the Forum Images web site.

----------

- Daz -