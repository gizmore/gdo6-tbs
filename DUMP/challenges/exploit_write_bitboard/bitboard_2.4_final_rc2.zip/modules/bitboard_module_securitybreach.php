<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////

include "../include/bitboard_configuration.php";

$LOGDATE=date("j.n.Y H:i:s",time());

$WHOIS_RIPE = "http://www.ripe.net/db/whois/whois.html";
$WHOIS_ARIN = "http://www.arin.net/";
$WHOIS_ABUSE = "http://www.ripe.net/ripencc/faq/hackin.html";

if (empty($REMOTE_ADDR) || !isset($REMOTE_ADDR)) {
    if (empty($HTTP_ENV_VARS['REMOTE_ADDR']) || !isset($HTTP_ENV_VARS['REMOTE_ADDR'])) {
        $LOGIP = getenv('REMOTE_ADDR');
    }else{
        $LOGIP = $HTTP_ENV_VARS['REMOTE_ADDR'];
    }
}else{
    $LOGIP = $REMOTE_ADDR;
}

if (!empty($LOGIP)) {
    $LOGADR = gethostbyaddr($LOGIP);
}else{
    $LOGIP = "0.0.0.0";$LOGADR = "0.0.0.0";
}

echo $LOGDATE."<br><br>";
echo "You have tried accessing a secured file.<br>";
echo "Your IP ($LOGIP) and DNS ($LOGADR)<br>";
echo "have been stored.";
echo "The administrator has been alerted by email.<br><br>";
echo "<a href=\"mailto:$BITBOARD_ADMINCONTACT\">$BITBOARD_ADMINCONTACT</a>";

$MAILTO = $BITBOARD_ADMINCONTACT;

$mailFrom = "From: BiTBOARD-MAILER";
$mailSubject = "(".date("j.n.Y",Time()).") BiTSHiFTERS Security Warning";
$mailMessage = "

    Hello,

    You received this message because your eMail notification is
    enabled on your BiTBOARD and your eMail adress is stated there.

    =======================================================================

    ".$LOGDATE."

    Someone has tried accessing a password hash file on your forum.
    The IP and DNS are: ".$LOGIP."; ".$LOGADR.".
    
    If you wish, you can inform the abuse department of the Users ISP.
    To trace the attack back, you may query a whois database like
    RIPE or ARIN.

    RIPE
    ".$WHOIS_RIPE."
    
    ARIN
    ".$WHOIS_ARIN."
    
    To find information on where to report abusive behaviour you might
    want to take a look at http://www.ripe.net/ripencc/faq/hackin.html

";
    
@mail ($MAILTO,$mailSubject,$mailMessage,$mailFrom);

?>

