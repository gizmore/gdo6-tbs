// JAVA SCRIPT "NewWindow"
// (C)OPYRIGHT 2002 by Spy98 for The BiTSHiFTERS SDC
// All Rights Reserved.
//
// No Public use with out expressly written permission of Spy98@gmx.net
//
// Einbinden mit <SCRIPT src="fnc_newwindow.js" type="text/javascript"></SCRIPT>
// Execute mit 
// onclick="NewWindow(FensterReferenz,'Klassenname','breite','h�he','scrollbars[yes|no]');return false">
// 
// Beispiel
// <a href="page" 
//	onclick="NewWindow(this.href,'iexp','800','600','yes');return false">
// Enter</a>
//

var win= null;

// Function 
// NewWindow   (PageReference as string,
//				PageName as string ,
//				Width as integer ,
//				Height as integer,
//				Scrollbars as boolean)

function NewWindow(mypage,myname,w,h,scroll)
{
// declare variables.

// define focus variables.
	var winl = (screen.width-w)/2;
	var wint = (screen.height-h)/2;

// should be resizable?

	var resize='no';

// define popup window elements.
	var settings  ='height='+h+',';
    	settings +='width='+w+',';
     	settings +='top='+wint+',';
      	settings +='left='+winl+',';
      	settings +='scrollbars='+scroll+',';
      	settings +='resizable='+resize;

// execute window popup.  	
	win=window.open(mypage,myname,settings);

// if Netscape browser, bring window to top.  	
	if(parseInt(navigator.appVersion) >= 4){win.window.focus();}

}
