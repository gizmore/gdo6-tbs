<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


/*  Image bitcode

    Usage : [img]http://www.myhost.com/linktomy/image.jpg[/img]
*/
$txtMessage = str_replace("[img]","<img src='", $txtMessage);
$txtMessage = str_replace("[/img]","'>", $txtMessage);

/*  Hyperlink bitcode

    Usage : [url]http://www.fakesite.com[linkas]check this out[/url]
*/
$txtMessage = str_replace("[url]","<a href='", $txtMessage);
$txtMessage = str_replace("[linkas]","' target='_blank'>", $txtMessage);
$txtMessage = str_replace("[/url]","</a>", $txtMessage);

/*  EMail bitcode

    Usage : [mail]mymail@myserver.com[/mail]
*/
$txtMessage = str_replace("[mail]","<a href='mailto:", $txtMessage);
$txtMessage = str_replace("[/mail]","'>Email</a>", $txtMessage);

/*  Font Formatting Bitcodes

    Usage : [b] [/b] [i] [/i] [u] [/u]
*/
$txtMessage = str_replace("[b]","<strong>", $txtMessage);
$txtMessage = str_replace("[B]","<strong>", $txtMessage);
$txtMessage = str_replace("[/b]","</strong>", $txtMessage);
$txtMessage = str_replace("[/B]","</strong>", $txtMessage);

$txtMessage = str_replace("[i]","<em>", $txtMessage);
$txtMessage = str_replace("[I]","<em>", $txtMessage);
$txtMessage = str_replace("[/i]","</em>", $txtMessage);
$txtMessage = str_replace("[/I]","</em>", $txtMessage);

$txtMessage = str_replace("[u]","<u>", $txtMessage);
$txtMessage = str_replace("[U]","<u>", $txtMessage);

$txtMessage = str_replace("[/u]","</u>", $txtMessage);
$txtMessage = str_replace("[/U]","</u>", $txtMessage);
?>

