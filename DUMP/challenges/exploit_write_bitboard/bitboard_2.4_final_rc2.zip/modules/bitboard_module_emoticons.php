<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


/*
    Remark of Copyright.
    
    The Emoticon Images are taken from http://www.forumimages.com
    They are copyright � Darren Burnhill 2002

    Please read the included

*/
$txtMessage = str_replace(":[","<img src='modules/emoticons/icon_evil.gif'>", $txtMessage);
$txtMessage = str_replace(":D","<img src='modules/emoticons/icon_biggrin.gif'>", $txtMessage);
$txtMessage = str_replace("8)","<img src='modules/emoticons/icon_cool.gif'>", $txtMessage);
$txtMessage = str_replace("^_^","<img src='modules/emoticons/icon_cheesygrin.gif'>", $txtMessage);
$txtMessage = str_replace(":?","<img src='modules/emoticons/icon_question.gif'>", $txtMessage); 		
$txtMessage = str_replace(":lol:","<img src='modules/emoticons/icon_lol.gif'>", $txtMessage);
$txtMessage = str_replace(":(", "<img src='modules/emoticons/icon_sad.gif'>", $txtMessage);
$txtMessage = str_replace(":)","<img src='modules/emoticons/icon_smile.gif'>", $txtMessage);
$txtMessage = str_replace(":P","<img src='modules/emoticons/icon_razz.gif'>", $txtMessage);
$txtMessage = str_replace(";)","<img src='modules/emoticons/icon_wink.gif'>", $txtMessage);
?>
