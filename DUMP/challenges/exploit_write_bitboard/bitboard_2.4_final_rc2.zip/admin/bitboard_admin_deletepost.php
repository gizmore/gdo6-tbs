<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

if (!isset($HTTP_GET_VARS['USETOPIC'])) {

    echo"
    <table width='100%' border='1' cellpadding='0'>
    <tr bgcolor='#999999'>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Browse Topic</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Author</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Topic
    Subject</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Topic
    ID</font></strong></td>
    </tr>
    ";

    if (0 != 0) {

        // ^^^
        // Former password lookup. Left for compatabillity purposes.
        // Password check now done in bitboard_admin_head.php.

    }else{

        // Open the directory, get handle and push topic files to array
        $ContentsDirectory = array();
        
        $directory = "../contents/";
        $dir_handle = opendir($directory);

        while ($file = readdir($dir_handle)) {

            if (is_file($directory.$file)){
                // FILE FOUND!

                clearstatcache();
                $ftype = strtolower(substr($file,strlen($file)-3));

                if ($ftype == "txt") {
                    // IS TOPIC FILE, ADD TO ARRAY

                    $creationdate = filemtime(trim($directory.$file));
                    array_push($ContentsDirectory,$creationdate."#".$directory.$file);
                }

            }

        }

        // Sort Array by Filemodification time stored in cell [1]
        $ContentsDirectory = SORTPOSTS($ContentsDirectory);

        // If There are no files in the directory, quit here.
        if (strlen($ContentsDirectory[0]) < 2) {
            exit;
        }

        foreach($ContentsDirectory as $Topic){

            $ITEMS++;
            $Topic = explode("#",$Topic);
            $TopicFile = trim($Topic[1]);
            
            // LIST ALL
            echo"<tr bgcolor=\"#CCCCCC\">\r\n";

            // ITEM
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">(<a href=\"".$PHP_SELF."?USETOPIC=".$Topic[1]."\">SHOW TOPIC</a>)";

            // AUTHOR
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".str_replace("<br>"," (",GETAUTHOR($TopicFile)).")</font></td>\r\n";

            // TOPIC SUBJECT
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".GETSUBJECT($TopicFile)."</font></td>\r\n";

            // TOPIC ID
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><a href=\"../$BITBOARD_MAIN?DATEIN=".GETTOPICID($TopicFile)."\" target=\"_blank\">".GETTOPICID($TopicFile)."</a></font></td>\r\n";

            echo "</tr>";

        }
        
    }

}else{

    if (!isset($HTTP_GET_VARS['DELPOST'])){

        // SHOW POSTS
        $TopicFile = $HTTP_GET_VARS['USETOPIC'];
        
        echo"
        <table width='100%' border='1' cellpadding='0'>
        <tr bgcolor='#999999'>
        <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Delete</font></strong></td>
        <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Author</font></strong></td>
        <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Subject</font></strong></td>
        <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Content</font></strong></td>
        </tr>
        ";

        
        $Posts = file($TopicFile);
        
        foreach ($Posts as $Post) {

            $Entry = explode ("#",$Post);
            
            $Items++;
            
            // LIST ALL
            echo"<tr bgcolor=\"#CCCCCC\">\r\n";

            // DELETE
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">(<a href=\"".$PHP_SELF."?USETOPIC=$TopicFile&DELPOST=$Items\">DELETE</a>)";

            // AUTHOR
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">$Entry[0]</font></td>\r\n";

            // SUBJECT
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">$Entry[1]</font></td>\r\n";

            // Content.
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".substr($Entry[2],0,50)."...</font></td>\r\n";

            echo "</tr>";

        }
        
    }else{

        $TopicFile = $HTTP_GET_VARS['USETOPIC'];
        $PostNumber = $HTTP_GET_VARS['DELPOST'];

        if (!isset($HTTP_GET_VARS['DOIT'])){

            // ASK BEFORE REMOVING THE POST!
            
            echo "<br><br><table border='1' align='center' cellpadding='10' cellspacing='1' bordercolor='#000000'>";
            echo "<tr bordercolor='#0000FF'><td colspan='2' bgcolor='#999999'><p align='left'>";
            echo "<font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Do you really want to delete Post Number $PostNumber of Topic \"".GETSUBJECT($TopicFile)."\".<br>";
            echo "(TopicID:".GETTOPICID($TopicFile).")<br><br>";
            echo "<br><p align='right'>[ <a href='$PHP_SELF?USETOPIC=$TopicFile&DELPOST=$PostNumber&DOIT=TRUE'>YES</a> ] [ <a href='admin_admin_welcome.php'>NO</a> ]";
            echo "</p></font></p></td></tr></table>";
            Die;

        }else{

            // USER IS SURE TO REMOVE THE POST...

            // Read Post to array...
            $OldTopic = @file($TopicFile);
            $NewTopic = array();
            
            foreach ($OldTopic as $Entry){
                $Item++;
                
                if ($Item != $PostNumber) {
                    array_push($NewTopic,$Entry);
                }
            }

            $fp = fopen($TopicFile,"w");
            foreach ($NewTopic as $Entry) {
                fwrite($fp,$Entry);
            }
            fclose ($fp);

            echo "<br><br><table border='1' align='center' cellpadding='10' cellspacing='1' bordercolor='#000000'>";
            echo "<tr bordercolor='#0000FF'><td colspan='2' bgcolor='#999999'><p align='left'>";
            echo "<font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Post Number $PostNumber has been removed from \"".GETSUBJECT($TopicFile)."\".<br>";
            echo "The File with the Topic ID ".GETTOPICID($TopicFile).", has been modified.<br><br>";
            echo "<br>Click <a href='bitboard_admin_deletepost.php'>here</a> to return to the TopicBrowser.";
            echo "</p></font></p></td></tr></table>";
            Die;
            
        }

    }

}
?>

</table>
</body>
</html>
