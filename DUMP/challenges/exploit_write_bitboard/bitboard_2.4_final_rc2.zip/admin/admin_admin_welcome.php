<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "bitboard_admin_head.php";
?>
<p><font size="2" face="Tahoma"><strong>Welcome to the BiTSHiFTERS BiTBOARD Administation 
  Panel.</strong><br>
  </font></p>
<table width="452" border="0" align="left" cellspacing="0">
  <tr> 
    <td width="450" valign="top"><font size="2" face="Tahoma"><br>
      On the left you can see tasks you can perform in order to change specific 
      <br>
      options and manage the forum.<br>
      <br>
      If this is your first time starting this panel, please take the time and 
      change your password. Notice, that the default password every Installation 
      uses, is &quot;install&quot;.</font><br> </td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><br>
</p>
<table width="452" border="0" align="left" cellspacing="0">
  <tr> 
    <td width="101" valign="top"><a href="http://www.forumimages.com" target="_blank"><img src="../modules/emoticons/forum_images_banner_88x31.gif" width="88" height="31" border="0"></a></td>
    <td width="347" valign="top"><font size="2" face="Tahoma">The emoticon graphics 
      used by BiTBOARD are taken <br>
      from forumimages.com. &copy; Darren Burnhill 2002</font><br></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp; </p>
<table width="452" border="0" align="left" cellspacing="0">
  <tr> 
    <td width="101" valign="top"><a href="http://www.bitshifters.bl.am" target="_blank"><img src="../modules/emoticons/bitshifters_software_banner_88x31.jpg" width="88" height="31" border="0"></a></td>
    <td width="347" valign="top"><font size="2" face="Tahoma">The software you 
      are using was developed by<br>
      The BiTSHiFTERS Software Development Crew.<br>
      Please see the EULA or our website for licensing and copyright information.<br>
      </font></td>
  </tr>
</table>
<p>&nbsp;</p>
<p><br>
  <br>
</p>
<table width="452" border="0" align="left" cellspacing="0">
  <tr> 
    <td width="101" valign="top">&nbsp;</td>
    <td width="347" valign="top"><p> <font size="2" face="Tahoma">The Revision2 
        Badmouthfilter module was kindly written by Michael Opacic of www.sandsoft.co.uk.<br>
        </font> <br>
      </p></td>
  </tr>
</table>
<p>&nbsp;</p>
<p></p>
<p>&nbsp; </p>
</body>
</html>
