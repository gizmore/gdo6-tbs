<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

$SELECTEDPROFILE = $HTTP_POST_VARS['select'];

echo "<br><br>";

if (!$HTTP_POST_VARS['SUBMIT']) {

?>

<form name="form1" method="post" action="">
  <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;:: 
        Edit Profile.</strong></font></td>
    </tr>
    <tr>
      <td><table width="403" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
          <tr bgcolor="#999999"> 
            <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
              Select a profile and click &quot;delete&quot; to <b>confirm</b> your request.</strong></font><br>
              <font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="darkred"><br>
              Warning: This procedure is irreversible. It deletes all selected profile data completely from the servers harddisk.</font><hr size="1"></td>
          </tr>
          <tr bgcolor="#999999">
            <td width="47%" height="30"><font size="2" face="Tahoma">Available 
              Profiles:</font></td>
            <td width="53%" height="30"> 
              <div align="right"><font size="2" face="Tahoma"> 
                <select name="select">

                <?php

                // PROFILE FINDER!

                // Open the directory, get handle and output themes

                $directory = "../profiles/";
                $dir_handle = opendir($directory);

                while ($file = readdir($dir_handle)) {

                    if (is_file($directory.$file))
                    {
                        // FILE FOUND!
                        $i++;
                        $ftype = strtolower(substr($file,0,3));
                        $prfname = strtolower(substr($file,4,strlen($file)-8));

                        if ($ftype == "prf") {

                            if ($i==1) {
                                echo "<option value=\"$prfname\" selected>$prfname</option>";
                            }else{
                                echo "<option value=\"$prfname\">$prfname</option>";

                            }
                        }
                    }

                }

                ?>
                </select>
                </font></div></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td height="35" colspan="2"> <div align="right">
                <input name="SUBMIT" type="submit" id="SUBMIT" value="Select">
                <input name="CANCEL" type="submit" id="CANCEL" value="Cancel" onClick="history.back()">
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>

<?php
}else{
?>

  <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;::
        Edit Profile.</strong></font></td>
    </tr>
    <tr>
      <td><table width="403" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
          <tr bgcolor="#999999">
            <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
              Please select what file you wish to edit for "<?= $SELECTEDPROFILE ?>"...</strong></font><br><hr size="1"></td>
          </tr>
          <tr bgcolor="#999999">
            <td width="47%" height="30"><font size="2" face="Tahoma">Available
              files:</font></td>
            <td width="53%" height="30">
              <div align="right"><font size="2" face="Tahoma">
              <a href="bitboard_admin_hardedit_editor.php?EditFile=<?= "../profiles/prf_".trim($SELECTEDPROFILE).".php"?>" onclick="NewWindow(this.href,'iexp','740','520','yes');return false">Profile</a></font></div></td>
          </tr>
          <tr bgcolor="#999999">
            <td width="47%" height="30"></td>
            <td width="53%" height="30">
              <div align="right"><font size="2" face="Tahoma">
              <a href="bitboard_admin_hardedit_editor.php?EditFile=<?= "../profiles/sig_".trim($SELECTEDPROFILE).".php"?>" onclick="NewWindow(this.href,'iexp','740','520','yes');return false">Signature</a></font></div></td>
          </tr>
          <tr bgcolor="#999999">
            <td width="47%" height="30"></td>
            <td width="53%" height="30">
              <div align="right"><font size="2" face="Tahoma">
              <a href="bitboard_admin_editprofile_password.php?UserName=<?=$SELECTEDPROFILE?>">Password</a></font></div></td>
          </tr>

<?php


}
?>



