<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

if (!isset($HTTP_GET_VARS['MODIFYITEM'])) {

    echo"
    <table width='100%' border='1' cellpadding='0'>
    <tr bgcolor='#999999'>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Modify</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Author</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Topic Subject</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Sticky</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Closed</font></strong></td>
    </tr>
    ";

    // Open the directory, get handle and push topic files to array
    $ContentsDirectory = array();
        
    $directory = "../contents/";
    $dir_handle = opendir($directory);

    while ($file = readdir($dir_handle)) {

        if (is_file($directory.$file)){
            // FILE FOUND!

            clearstatcache();
            $ftype = strtolower(substr($file,strlen($file)-3));

            if ($ftype == "txt") {
                // IS TOPIC FILE, ADD TO ARRAY

                $creationdate = filemtime(trim($directory.$file));
                array_push($ContentsDirectory,$creationdate."#".$directory.$file);
            }

        }

    }

    // Sort Array by Filemodification time stored in cell [1]
    $ContentsDirectory = SORTPOSTS($ContentsDirectory);

    // If There are no files in the directory, quit here.
    if (strlen($ContentsDirectory[0]) < 2) {
        exit;
    }

    foreach($ContentsDirectory as $Topic){

        $ITEMS++;
        $Topic = explode("#",$Topic);
        $TopicFile = trim($Topic[1]);
            
        if (IS_STICKY($TopicFile) || IS_CLOSED($TopicFile)) {

                    // Some flag is true...
                    echo"<tr bgcolor=\"#DDDDDD\">\r\n";
                    
        }else{

                    // Both flags false...
                    echo"<tr bgcolor=\"#CCCCCC\">\r\n";

        }

        // ITEM
        echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">(<a href=\"".$PHP_SELF."?MODIFYITEM=".$Topic[1]."&pfTOPICNAME=".GETSUBJECT($TopicFile)."\">MODIFY</a>)";

        // AUTHOR
        echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".str_replace("<br>"," (",GETAUTHOR($TopicFile)).")</font></td>\r\n";

        // TOPIC SUBJECT
        echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".GETSUBJECT($TopicFile)."</font></td>\r\n";

        // STICKY FLAG
        if (IS_STICKY($TopicFile)) {
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><strong>true</strong></font></td>\r\n";
        }else{
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">false</font></td>\r\n";
        }
        
        // CLOSED FLAG
        if (IS_CLOSED($TopicFile)) {
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><strong>true</strong></font></td>\r\n";
        }else{
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">false</font></td>\r\n";
        }

        echo "</tr>";

    }
        
}else{

    if (!$HTTP_POST_VARS['cmdChange']) {

        /*
            User has selected a topic to modify...

            - Set necessary values
            - Show ChangePostflags Template.
            
        */

        echo "<br><br>";
        $TopicName = $HTTP_GET_VARS['pfTOPICNAME'];
        $valSticky = convBOOL_TO_CHECKBOX(IS_STICKY($HTTP_GET_VARS['MODIFYITEM']));
        $valClosed = convBOOL_TO_CHECKBOX(IS_CLOSED($HTTP_GET_VARS['MODIFYITEM']));
        include "bitboard_admin_postflagmodify_template.php";

    }else{

        /*
        
            Apply changes to selected file...
            
        */

        $Topic = file($HTTP_GET_VARS['MODIFYITEM']);

        // See if we should sticky / unstick the topic...
        if (convCHECKBOX_TO_BOOL($HTTP_POST_VARS['chkSticky']) == "true") {
            $valSticky = "IsSticky";
            $natSticky = "sticked";
        }else{
            $valSticky = "NotSticky";
            $natSticky = "unsticked";
        }
        
        // See if we should close / reopen the topic...
        if (convCHECKBOX_TO_BOOL($HTTP_POST_VARS['chkClosed']) == "true") {
            $valClosed = "IsClosed";
            $natClosed = "closed";
        }else{
            $valClosed = "NotClosed";
            $natClosed = "opened";
        }
        
        $oldHeaderLine = explode("#",$Topic[0]);

        
        // Apply necessary changes to topics headerline...
        
        foreach ($oldHeaderLine as $entry) {
            if ($i != 4 && $i != 5) {
                $newHeaderLine .= $entry;
            }else{
                if ($i == 4) {
                    $newHeaderLine .= $valSticky;
                }else{
                    $newHeaderLine .= $valClosed;
                }
            }
            $newHeaderLine .= "#";
            $i++;
        }
        
        $Topic[0] = substr($newHeaderLine,0,strlen($newHeaderLine)-1)."\r\n";
        
        $fp = fopen($HTTP_GET_VARS['MODIFYITEM'],"w");
        foreach ($Topic as $NewLine) {
            fwrite($fp,trim($NewLine)."\r\n");
        }
        fclose ($fp);

        ?>
          <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
            <tr>
              <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;::
                Edit Postflag.</strong></font></td>
            </tr>
            <tr>
              <td><table width="403" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
                  <tr bgcolor="#999999">
                    <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
                     The selected topic has been <?= $natSticky." and ".$natClosed ?>.<br>
                      </strong></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="darkred"><br>
                      <br>

        <?php

    }

}

?>

</table>
</body>
</html>
