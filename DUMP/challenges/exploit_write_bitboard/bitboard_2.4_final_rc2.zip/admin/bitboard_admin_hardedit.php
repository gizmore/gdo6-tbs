<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////

/*

    HARDEDIT SPECIAL NOTICE:
    
    This piece of code has been written entirely by the bitshifters
    for use within bitboard. However a retail version of script is
    soon to be done. free download of course!
    
*/

include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";
?>
<link href="lib_dir_styles.css" rel="stylesheet" type="text/css"><body>
<table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" bgcolor="#999999">
  <tr>
    <td><blockquote>
        <p><br><strong><font color="#000000" size="3" face="Verdana, Arial, Helvetica, sans-serif">
          BiTBOARD HardEdit ["<?=$BITBOARD_FORUMNAME?>"]</font></p>
      </blockquote></td>
  </tr>
</table>

<pre>

<?php
// get last path from HTTP. if not existend, use relative path
if (!isset($HTTP_GET_VARS['directory'])) {
    $path = "..";
    $oneup = "..";
} else {
    $path = $HTTP_GET_VARS['directory'];
    $oneup = substr($path,0,strrpos($path,"/"));
}

// constants declaration
$ENABLEDIRECTORIES='true';
$GOBACKROOT="<a href=$PHP_SELF? target=_self>GO TO YOUR ROOT</a>";
$GOONEUP="<a href=$PHP_SELF?directory=".$oneup." target=_self>MOVE ONE FOLDER UP</a>";
$ICONFILE="<img src=lib_dir_icn_files.gif>";
$ICONFOLDER="<img src=lib_dir_icn_folder.gif>";

function FileSizes($file,$space,$path){
// Check if path is root or not.
if ($path == ".") {

    $tsize=(filesize($file)/1024);
    $tdate=date("d.M Y H:i:s", filemtime($file));
} else {

    $tsize=(filesize($path."/".$file)/1024);
    $tdate=date("d.M Y H:i:s", filemtime($path."/".$file));

}
$tsize=sprintf("%01.2f",$tsize)."kb ";
echo substr($space,0,10-strlen($tsize)) . $tsize;
echo $tdate.substr($space,0,20-strlen($file));
echo "\n";
}

echo "Listing Contents of Directory: \"$path\"...\n";
if ($path != "..") {
    echo "| $GOBACKROOT | $GOONEUP |\n\n";
} else {
    echo "| You are in your root. |\n\n";
}


// Open the directory and give handle...
$dir_handle = @opendir($path) or exit("Unable to open path $path $GOBACKROOT \n\n");

// 70 Spaces.
$space=" ";

// As Long as there are folders and files...
while ($file = readdir($dir_handle)) {

    // filename - output left-justified.
    // files are executed within a new window.
    if ($file == ".." || $file == ".") {

        // . and .. folders are disabled.
        $t="$ICONFOLDER <b>$file</b>";
        echo $t."\n";//.substr($space,0,40-strlen($file))."\n";

    } elseif (is_dir($path."/".$file)) {

        // lets print those...
        $t="$ICONFOLDER <b><a href=$PHP_SELF?directory=$path/$file target=_self>$file</a></b>";
        echo $t.substr($space,0,40-strlen($file));
        FileSizes($file,$space,$path);

    } else {

        // files...
        $t="$ICONFILE <a href=bitboard_admin_hardedit_editor.php?EditFile=$path/$file onclick=\"NewWindow(this.href,'iexp','740','520','yes');return false\">$file</a>";
        echo $t.substr($space,0,40-strlen($file));
        FileSizes($file,$space,$path);

    }

}
// closing the directory with the handle.
closedir($dir_handle);
echo ("</PRE><p></body></html>");

?>
