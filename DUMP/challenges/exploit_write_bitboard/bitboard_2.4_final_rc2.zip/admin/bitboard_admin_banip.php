<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

echo "<br><br>";

if (!$HTTP_POST_VARS['SUBMIT'] && empty($HTTP_POST_VARS['txtIP'])) {

?>

<form name="form1" method="post" action="">
  <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;:: 
        Ban IP.</strong></font></td>
    </tr>
    <tr>
      <td><table width="403" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
          <tr bgcolor="#999999"> 
            <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
              Please enter the IP to ban.<br>Then Click &quot;Ban&quot; to add the IP to the banlist.
              </strong></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="darkred"><br>
              <br>
              </font> <hr size="1"></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="47%" height="30"><font size="2" face="Tahoma">Enter IP (x.x.x.x):
              </font></td>
            <td width="53%" height="30"> <div align="right"><font size="2" face="Tahoma"> 
                <input name="txtIP" type="text" size="30">
                </font></div></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td height="35" colspan="2"> <div align="right"> 
                <input name="SUBMIT" type="submit" id="SUBMIT" value="Ban">
                <input name="CANCEL" type="submit" id="CANCEL" value="Cancel" onClick="history.back()">
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>

<?php
}else{

if (!empty($HTTP_POST_VARS['txtIP'])) {
    $fp = fopen ("../".$BITBOARD_BANNEDIPSFILE,"a");
    fwrite ($fp,trim($HTTP_POST_VARS['txtIP'])."\r\n");
    fclose($fp);
}

?>

  <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;::
        Ban IP.</strong></font></td>
    </tr>
    <tr>
      <td><table width="403" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
          <tr bgcolor="#999999">
            <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
        The IP has been added to the banlist.<br>
              </strong></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="darkred"><br>
              <br>
              
<?php
}
?>



