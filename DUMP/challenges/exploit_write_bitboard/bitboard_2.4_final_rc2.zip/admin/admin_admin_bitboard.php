<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>BiTSHiFTERS BiTBOARD - Administration Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<frameset rows="*" cols="170,*" framespacing="0" frameborder="NO" border="0">
	<frame src="admin_admin_menu.php" name="leftFrame" scrolling="AUTO" noresize>
	
		<frameset rows="74,*" cols="*" frameborder="NO" border="0" framespacing="0">
  			<frame src="admin_admin_header.php" name="topFrame" scrolling="NO" noresize>
    	    <frame src="admin_admin_welcome.php" name="mainFrame">
        </frameset>
</frameset>

<noframes><body>

</body></noframes>
</html>
