<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

if (!isset($HTTP_GET_VARS['RECYCLEITEM'])) {

    echo"
    <table width='100%' border='1' cellpadding='0'>
    <tr bgcolor='#999999'>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Move</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Author</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Topic
    Subject</font></strong></td>
    <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Topic
    ID</font></strong></td>
    </tr>
    ";

    if (0 != 0) {

        // ^^^
        // Former password lookup. Left for compatabillity purposes.
        // Password check now done in bitboard_admin_head.php.

    }else{

        // Open the directory, get handle and push topic files to array
        $ContentsDirectory = array();
        
        $directory = "../contents/trashcan/";
        $dir_handle = opendir($directory);

        while ($file = readdir($dir_handle)) {

            if (is_file($directory.$file)){
                // FILE FOUND!

                clearstatcache();
                $ftype = strtolower(substr($file,strlen($file)-3));

                if ($ftype == "txt") {
                    // IS TOPIC FILE, ADD TO ARRAY

                    $creationdate = filemtime(trim($directory.$file));
                    array_push($ContentsDirectory,$creationdate."#".$directory.$file);
                }

            }

        }

        // Sort Array by Filemodification time stored in cell [1]
        $ContentsDirectory = SORTPOSTS($ContentsDirectory);

        // If There are no files in the directory, quit here.
        if (strlen($ContentsDirectory[0]) < 2) {
            exit;
        }

        foreach($ContentsDirectory as $Topic){

            $ITEMS++;
            $Topic = explode("#",$Topic);
            $TopicFile = trim($Topic[1]);
            
            // LIST ALL
            echo"<tr bgcolor=\"#CCCCCC\">\r\n";

            // ITEM
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">(<a href=\"".$PHP_SELF."?RECYCLEITEM=".$Topic[1]."\">TO FORUM</a>)";

            // AUTHOR
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".str_replace("<br>"," (",GETAUTHOR($TopicFile)).")</font></td>\r\n";

            // TOPIC SUBJECT
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".GETSUBJECT($TopicFile)."</font></td>\r\n";

            // TOPIC ID
            echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><a href=\"../$BITBOARD_MAIN?DATEIN=".GETTOPICID($TopicFile)."\" target=\"_blank\">".GETTOPICID($TopicFile)."</a></font></td>\r\n";

            echo "</tr>";

        }
        
    }

}else{

    if (!isset($HTTP_GET_VARS['DOIT'])){

        // ASK BEFORE MOVING...
        $TopicFile = $HTTP_GET_VARS['RECYCLEITEM'];
        
        echo "<br><br><table border='1' align='center' cellpadding='10' cellspacing='1' bordercolor='#000000'>";
        echo "<tr bordercolor='#0000FF'><td colspan='2' bgcolor='#999999'><p align='left'>";
        echo "<font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Do you really want to move the Topic \"".GETSUBJECT($TopicFile)."\" back to the forum?<br>";
        echo "(TopicID:".GETTOPICID($TopicFile).")<br><br>";
        echo "<br><p align='right'>[ <a href='$PHP_SELF?RECYCLEITEM=$TopicFile&DOIT=TRUE'>YES</a> ] [ <a href='admin_admin_welcome.php'>NO</a> ]";
        echo "</p></font></p></td></tr></table>";
        Die;

    }else{

        // USER IS SURE TO DELETE...
        $TopicFile = $HTTP_GET_VARS['RECYCLEITEM'];
        
        // Kill Topic File through its ID.
        if (copy("../contents/trashcan/".GETTOPICID($TopicFile).".txt","../contents/".GETTOPICID($TopicFile).".txt")) {
            unlink ($TopicFile);
        }else {
            echo "Couldnt Copy & Unlink $TopicFile!!!";
        }
        
        echo "<br><br><table border='1' align='center' cellpadding='10' cellspacing='1' bordercolor='#000000'>";
        echo "<tr bordercolor='#0000FF'><td colspan='2' bgcolor='#999999'><p align='left'>";
        echo "<font size='2' face='Verdana, Arial, Helvetica, sans-serif'>The selected topic has been moved back to the forum.<br>";
        echo "The File with the Topic ID ".GETTOPICID($TopicFile).", has been moved,<br> and is now accessbile via the forum index.<br><br>";
        echo "<br>Click <a href='bitboard_admin_trashcan_movefromtrash.php'>here</a> to return to the TopicBrowser.";
        echo "</p></font></p></td></tr></table>";
        Die;

    }


}
?>

</table>
</body>
</html>
