<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>bitboard_header</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#EFEFEF">
<table width="100%">
  <tr> 
    <td><u><b><font color="#003366" size="4" face="Tahoma"><strong>BiTSHiFTERS
      BiTBOARD CONTROL PANEL</strong></font></b></u></td>
    <td><div align="right"><font size="2" face="Tahoma"> [ <a href="../index.php" target="_blank">Forum
        Index</a> ] [ <a href="admin_admin_welcome.php" target="mainFrame">Welcome 
        Page</a> ] [ <a href="index.php?uncookie=true" target="_parent">Log out
        </a> ]</font></div></td>
  </tr>
</table>

