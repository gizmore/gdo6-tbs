<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

$CURRENTLANGUAGE = @file("../$BITBOARD_LANGFILE");
$CURRENTLANGUAGE = trim($CURRENTLANGUAGE[0]);
$SELECTEDLANGUAGE = $HTTP_POST_VARS['select'];

echo "<br><br>";

if (!$HTTP_POST_VARS['SUBMIT']) {

?>

<form name="form1" method="post" action="">
  <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;:: 
        Change Language.</strong></font></td>
    </tr>
    <tr>
      <td><table width="403" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
          <tr bgcolor="#999999"> 
            <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
              You can switch to a specific language, by selecting it in the dropdown-box
              and clicking &quot;Switch&quot;</strong></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="darkred"><br>
              <br>
              </font> <hr size="1"></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td height="30"><font size="2" face="Tahoma">Currently selected Language:</font></td>
            <td height="30">
          <div align="right"><font size="2" face="Tahoma"><?php echo $CURRENTLANGUAGE; ?></font></div></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="47%" height="30"><font size="2" face="Tahoma">Available 
              Languages:</font></td>
            <td width="53%" height="30"> 
              <div align="right"><font size="2" face="Tahoma"> 
                <select name="select">

                <?php

                // THEME FINDER!

                // Open the directory, get handle and output themes

                $directory = "../languages/";
                $dir_handle = opendir($directory);

                while ($file = readdir($dir_handle)) {

                    if (is_file($directory.$file))
                    {
                        // FILE FOUND!
                        $i++;
                        $ftype = strtolower(substr($file,strlen($file)-3));

                        if ($ftype == "inc") {

                            if ($i==1) {
                                echo "<option value=\"$file\" selected>$file</option>";
                            }else{
                                echo "<option value=\"$file\">$file</option>";

                            }
                        }
                    }

                }

                ?>
                </select>
                </font></div></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td height="35" colspan="2"> <div align="right">
                <input name="SUBMIT" type="submit" id="SUBMIT" value="Switch">
                <input name="CANCEL" type="submit" id="CANCEL" value="Cancel" onClick="history.back()">
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>

<?php
}else{
?>

  <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;::
        Change Language.</strong></font></td>
    </tr>
    <tr>
      <td><table width="403" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
          <tr bgcolor="#999999">
            <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
              You have successfully switched to the language file <br>"<?= $SELECTEDLANGUAGE ?>".
              </strong></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="darkred"><br>
              <br>
              
<?php

$fp = fopen("../$BITBOARD_LANGFILE","w");
fwrite($fp,$SELECTEDLANGUAGE);
fclose($fp);

}
?>



