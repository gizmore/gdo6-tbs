<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";
echo "<br><br>";

if (0 != 0) {

    // ^^^
    // Former password lookup. Left for compatabillity purposes.
    // Password check now done in bitboard_admin_head.php.

}else{

    if (!isset($HTTP_GET_VARS['ISSURE'])){
        // ASK BEFORE DELETITION...
        echo "
        <table width='490' border='1' align='center' cellpadding='10' cellspacing='1' bordercolor='#000000'>
        <tr bordercolor='#0000FF'><td width='748' colspan='2' bgcolor='#999999'><p align='left'>
        <font size='2' face='Verdana, Arial, Helvetica, sans-serif'><strong>WARNING!</strong><br>
        Resetting your forum, deletes all topic-files,their included replies and your logfile.
        It does not reset any changes possible with the admin-panel (stylesheet, password, bans).<br>
        <br>
        Do you really want to reset your forum?<br>
        <br>
        <p align='right'>[ <a href='$PHP_SELF?ISSURE=TRUE'>YES</a> ] [ <a href='#' onClick='history.back()'>NO</a>
        ]</p>
        </font></td>
        </tr></table>
        ";
        Die;

    }else{

        if ($HTTP_GET_VARS['ISSURE'] == "TRUE") {

            // CONFIRMATIONS IS OKAY!

            $fp = fopen("../".$BITBOARD_LOGFILE,"w");     // Clean Logfile
            fclose ($fp);

            // Open the directory and give handle...
            $dir_handle = opendir("../contents/");

            while ($file = readdir($dir_handle)) {

                if (is_file("../contents/$file")){
                    @unlink ("../contents/$file");
                }

            }

            // closing the directory with the handle.
            closedir($dir_handle);

            echo "
            <table width='490' border='1' align='center' cellpadding='10' cellspacing='1' bordercolor='#000000'>
            <tr bordercolor='#0000FF'><td width='748' colspan='2' bgcolor='#999999'><p align='left'>
            <font size='2' face='Verdana, Arial, Helvetica, sans-serif'><strong>The
            reset has been finished.</strong><br>
            <br></td></tr></table>";
            Die;

        }

    }

}
?>

</table>
</body>
</html>
