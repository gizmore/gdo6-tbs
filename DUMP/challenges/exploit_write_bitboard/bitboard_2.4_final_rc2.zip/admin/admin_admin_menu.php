<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>bitboard_menu</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.tableseparator {
	border-top-width: 0px;
	border-right-width: 1px;
	border-bottom-width: 0px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: none;
	border-bottom-style: solid;
	border-left-style: none;
	border-top-color: #999999;
	border-right-color: #999999;
	border-bottom-color: #999999;
	border-left-color: #999999;
}
.tablemenu {
	border: 1px solid #999999;
}
-->
</style>
</head>

<body bgcolor="#EFEFEF" text="#000000" link="#0000CC" vlink="#0000CC" alink="#0000CC" leftmargin="5" topmargin="10" marginwidth="5" marginheight="5">
<div align="center"> 
  <table width="141" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000" class="tablemenu">
    <tr bgcolor="#999999">
      <td height="30" bgcolor="#EEEEEE" class="tableseparator"><font size="2" face="Tahoma"><strong>Installation 
        Options</strong></font></td>
    </tr>
    <!-- CHANGE PASSWORD -->
    <tr bgcolor="#999999"> 
      <td width="62%" height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_install.php" target="mainFrame">
        Change Password</a></font></td>
    </tr>
    <!-- CHANGE THEME -->
    <tr bgcolor="#CCCCCC"> 
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_themeselect.php" target="mainFrame">Change
        Theme</a></font></td>
    </tr>
    <!-- CHANGE LANGUAGE -->
    <tr bgcolor="#CCCCCC">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_languageselect.php" target="mainFrame">Change
        Language</a></font></td>
    </tr>
    <!-- RESET FORUM -->
    <tr bgcolor="#999999"> 
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_forumreset.php" target="mainFrame">Reset
        Forum</a></font></td>
    </tr>
    <tr bgcolor="#999999"> 
      <td height="30" bgcolor="#EEEEEE" class="tableseparator"><font size="2" face="Tahoma"><strong>Statistics</strong></font></td>
    </tr>
    <!-- SHOW STATISTICS -->
    <tr bgcolor="#999999"> 
      <td width="62%" height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"> <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_showstatistics.php" target="mainFrame">Show
          Statistics</a></font></p></td>
    </tr>
    <!-- SHOW LOGFILE -->
    <tr bgcolor="#CCCCCC"> 
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_showlogs.php" target="mainFrame">Show
        Logs</a></font></td>
    </tr>


    <tr bgcolor="#999999">
      <td height="30" bgcolor="#EEEEEE" class="tableseparator"><font size="2" face="Tahoma"><strong>Post
        Management</strong></font></td>
    </tr>
    <!-- EDIT POSTFLAGS -->
    <tr bgcolor="#999999">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_postflagmodify.php" target="mainFrame">Edit Postflags</a></font></td>
    </tr>
    <!-- DELETE TOPIC -->
    <tr bgcolor="#999999"> 
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_deletetopic.php" target="mainFrame">Delete
        Topic</a></font></td>
    </tr>
    <!-- DELETE POST -->
    <tr bgcolor="#CCCCCC"> 
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_deletepost.php" target="mainFrame">Delete
        Post</a></font></td>
    </tr>

    <tr bgcolor="#999999">
      <td height="30" bgcolor="#EEEEEE" class="tableseparator"><font size="2" face="Tahoma"><strong>Trashcan</strong></font></td>
    </tr>
    <!-- MOVE TO -->
    <tr bgcolor="#999999">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_trashcan_movetotrash.php" target="mainFrame">To Trash</a></font></td>
    </tr>
    <!-- REMOVE FROM -->
    <tr bgcolor="#999999">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_trashcan_movefromtrash.php" target="mainFrame">From Trash</a></font></td>
    </tr>
    <!-- EMPTY TRASH -->
    <tr bgcolor="#CCCCCC">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_trashcan_emptytrashcan.php" target="mainFrame">Empty Trashcan</a></font></td>
    </tr>

    <tr bgcolor="#999999">
      <td height="30" bgcolor="#EEEEEE" class="tableseparator"><font size="2" face="Tahoma"><strong>Profiles
    </strong></font></td>
    </tr>
    <!-- CREATE PROFILE -->
    <tr bgcolor="#999999">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_createprofile.php" target="mainFrame">Create
        Profile</a></font></td>
    </tr>
    <!-- EDIT PROFILE -->
    <tr bgcolor="#CCCCCC">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_editprofile.php" target="mainFrame">Edit
        Profile</a></font></td>
    </tr>
    <!-- DELETE PROFILE -->
    <tr bgcolor="#CCCCCC">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_deleteprofile.php" target="mainFrame">Delete
        Profile</a></font></td>
    </tr>

    <tr bgcolor="#999999"> 
      <td height="30" bgcolor="#EEEEEE" class="tableseparator"><font size="2" face="Tahoma"><strong>Banning</strong></font></td>
    </tr>
    <!-- BAN USERNAME -->
    <tr bgcolor="#999999"> 
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_banusername.php" target="mainFrame">Ban
        Username</a></font></td>
    </tr>
    <!-- BAN IP -->
    <tr bgcolor="#CCCCCC"> 
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_banip.php" target="mainFrame">Ban
        IP</a></font></td>
    </tr>
    <!-- BANNED LIST -->
    <tr bgcolor="#999999"> 
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_showbanlist.php" target="mainFrame">Show
        Ban List</a></font></td>
    </tr>

    <tr bgcolor="#999999">
      <td height="30" bgcolor="#EEEEEE" class="tableseparator"><font size="2" face="Tahoma"><strong>HardEdit</strong></font></td>
    </tr>
    <!-- BAN USERNAME -->
    <tr bgcolor="#999999">
      <td height="20" bgcolor="#EEEEEE" onmouseover="this.bgColor='#CCCCCC'" onmouseout="this.bgColor='#EEEEEE'"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="bitboard_admin_hardedit.php" target="mainFrame">HardEdit
      </a></font></td>
    </tr>

    <!-- END MENU -->
  </table>
<p><font size="2" color="#FFFFFF">* BiTBOARD CP *</font></p></div>
</body>
</html>
