<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>BiTBOARD administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<SCRIPT src="../modules/fnc_newwindow.js" type="text/javascript"></SCRIPT>
<body bgcolor="#EFEFEF" leftmargin="10" topmargin="0" marginwidth="10" marginheight="10">
<?

/// CHECK FOR CORRECT ADMIN RIGHTS BEFORE PRINTING EACH ADMIN-PAGE ::
// ->> print_r($HTTP_COOKIE_VARS); // DEBUG

include "../include/bitboard_functionslibrary.php";

if (!isset($HTTP_COOKIE_VARS['BITMIN'])){

    echo "<table width=\"452\" border=\"1\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\" bordercolor=\"#000000\">";
    echo "<tr bordercolor=\"#0000FF\"><td colspan=\"2\" bgcolor=\"#999999\"><p align=\"center\">";
    echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">You did not yet Log In.<br>";
    echo " Please Log In at your Admin Control Center by going <a href=\"index.php\" target=\"_parent\">here</a>.</font></p></td></tr></table>";
    Die;
}

$OLDPASS = PASSWORD_GET("data_passwd.php");

if (crypt($HTTP_COOKIE_VARS['BITMIN'],"BS") != trim($OLDPASS)) {

    echo "<br><table width=\"452\" border=\"1\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\" bordercolor=\"#000000\">";
    echo "<tr bordercolor=\"#0000FF\"><td colspan=\"2\" bgcolor=\"#999999\"><p align=\"center\">";
    echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">The password you";
    echo " typed is incorrect.<br>Please try again. Click <a href=\"#\" onClick=\"history.back()\">here</a>.</font></p></td></tr></table>";
    Die;
}

?>
