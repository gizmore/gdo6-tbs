<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

if (empty($HTTP_GET_VARS['select']) || !isset($HTTP_GET_VARS['select'])) {

?>
<br><br>
<form name="form1" method="post" action="">
  <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;:: 
        Show Banlist.</strong></font></td>
    </tr>
    <tr>
      <td><table width="403" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
          <tr bgcolor="#999999"> 
            <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
              Please select what banlist you wish to view. <br>Simply click the appropriate link below.
              </strong></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="darkred"><br>
              <br>
              </font> <hr size="1"></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td height="25" align="center"><font size="2" face="Tahoma"><a href="<?= $PHP_SELF."?select=BannedUsers"?>">Show banned Users</a></font></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td height="25" align="center"><font size="2" face="Tahoma"><a href="<?= $PHP_SELF."?select=BannedIPs"?>">Show banned IPs</a>
            </font></td>
            </tr>
          <tr bgcolor="#999999"> 
            <td height="35" colspan="2"> <div align="right">
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>

<?php

}else{

    switch ($HTTP_GET_VARS['select']) {

        case "BannedUsers":
            //////////////////////////////////////// SHOW / REMOVE USER BANS.
            
            // Check if we should remove a ban before showing the list.
            if (isset($HTTP_GET_VARS['BanID'])) {

                $OldBans = @file("../".$BITBOARD_BANNEDUSERSFILE);
                $NewBans = array();

                foreach ($OldBans as $Entry){
                    $BanItem++;

                    if ($BanItem != $HTTP_GET_VARS['BanID']) {
                        array_push($NewBans,$Entry);
                    }
                }

                $fp = fopen("../".$BITBOARD_BANNEDUSERSFILE,"w");
                foreach ($NewBans as $Entry) {
                    fwrite($fp,$Entry);
                }
                fclose ($fp);

            }

            // Show Banned Users!
            echo"
            <table width='100%' border='1' cellpadding='0'>
            <tr bgcolor='#999999'>
            <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Remove Ban</font></strong></td>
            <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Username</font></strong></td>
            <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>ID</font></strong></td>
            </tr>
            ";
            
            // Load Banning File
            if (filesize("../".$BITBOARD_BANNEDUSERSFILE) >0 ){

                $Bans = @file("../".$BITBOARD_BANNEDUSERSFILE) or Die($BITBOARD_ERRBANNEDUSERSFILE);

                foreach ($Bans as $Ban) {

                    $ITEMS++;

                    // LIST ALL
                    echo"<tr bgcolor=\"#CCCCCC\">\r\n";

                    // Remove Ban
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">(<a href=\"".$PHP_SELF."?select=BannedUsers&BanID=".$ITEMS."\">REMOVE BAN</a>)";

                    // Username
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".trim($Ban)."</font></td>\r\n";

                    // ID
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">$ITEMS</font></td>\r\n";

                    echo "</tr>";
                    
                }

            }else{

                echo "<tr><td><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>There are no bans in this list</td></tr>";
            }

            break;

        case "BannedIPs":
        
            //////////////////////////////////////// SHOW / REMOVE IP BANS.

            // Check if we should remove a ban before showing the list.
            if (isset($HTTP_GET_VARS['BanID'])) {

                $OldBans = @file("../".$BITBOARD_BANNEDIPSFILE);
                $NewBans = array();

                foreach ($OldBans as $Entry){
                    $BanItem++;

                    if ($BanItem != $HTTP_GET_VARS['BanID']) {
                        array_push($NewBans,$Entry);
                    }
                }

                $fp = fopen("../".$BITBOARD_BANNEDIPSFILE,"w");
                foreach ($NewBans as $Entry) {
                    fwrite($fp,$Entry);
                }
                fclose ($fp);

            }

            // Show Banned IPs!
            echo"
            <table width='100%' border='1' cellpadding='0'>
            <tr bgcolor='#999999'>
            <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>Remove Ban</font></strong></td>
            <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>IP</font></strong></td>
            <td><strong><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>ID</font></strong></td>
            </tr>
            ";

            // Load Banning File
            if (filesize("../".$BITBOARD_BANNEDIPSFILE) >0 ){

                $Bans = @file("../".$BITBOARD_BANNEDIPSFILE) or Die($BITBOARD_ERRBANNEDIPSFILE);

                foreach ($Bans as $Ban) {

                    $ITEMS++;

                    // LIST ALL
                    echo"<tr bgcolor=\"#CCCCCC\">\r\n";

                    // Remove Ban
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">(<a href=\"".$PHP_SELF."?select=BannedIPs&BanID=".$ITEMS."\">REMOVE BAN</a>)";

                    // Username
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">".trim($Ban)."</font></td>\r\n";

                    // ID
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">$ITEMS</font></td>\r\n";

                    echo "</tr>";

                }

            }else{

                echo "<tr><td><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>There are no bans in this list</td></tr>";

            }

            break;

    }


}
?>


