<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

?>
<table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000" bgcolor="#999999">
  <tr>
    <td><blockquote>
        <p><br><strong><font color="#000000" size="3" face="Verdana, Arial, Helvetica, sans-serif">
          BiTBOARD Statistics for Forum "<?=$BITBOARD_FORUMNAME?>"</font></p>
      </blockquote></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="100%" cellspacing="0" cellpadding="0" border="1">
  <tr>
    <td colspan="3" bgcolor="#999999"><strong><font color="#000000" size="3" face="Verdana, Arial, Helvetica, sans-serif">General</font></strong></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Your Forum's
      Name</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?=$BITBOARD_FORUMNAME?></font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Your Forum's
      Description</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?=$BITBOARD_FORUMDESC?></font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">First Post</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
    <?php

        $file = GETFIRSTPOST();
        echo "<a href=\"../$BITBOARD_MAIN?DATEIN=".GETTOPICID($file)."\" target=\"_blank\">".GETSUBJECT($file)."</a>";

    ?>
        </font>
    </td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td colspan="3" bgcolor="#999999"><strong><font color="#000000" size="3" face="Verdana, Arial, Helvetica, sans-serif">Bitboard</font></strong></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Used Version</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?=$BITBOARD_VERSION?></font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">(<a href="http://www.bitshifters.bl.am" target="_blank">check for
      new version</a>)</font></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Used Index
      File </font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?=$BITBOARD_MAIN?></font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td colspan="3" bgcolor="#999999"><strong><font color="#000000" size="3" face="Verdana, Arial, Helvetica, sans-serif">Database</font></strong></td>
  </tr>
  <tr>
    <td width="33%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Amount
      of Topics</font></td>
    <td width="32%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?= GETPOSTSAMOUNT()?></font></td>
    <td width="35%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Size of Topics</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?= ceil(GETPOSTSTOTALSIZE()/1024) ?> KB</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Largest Topic</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
        <?php
        $info = GETLARGESTTOPIC();
        $info = explode("#",$info);

        echo ceil($info[0]/1024)." KB</font></td>";
        echo "<td><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">";
        echo "(Subject: <a href=\"../$BITBOARD_MAIN?DATEIN=t".GETTOPICID($info[1])."\" target=\"_blank\">".GETSUBJECT("../contents/$info[1]")."</a>)";
        ?>
  </tr>
  <tr>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
    <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
