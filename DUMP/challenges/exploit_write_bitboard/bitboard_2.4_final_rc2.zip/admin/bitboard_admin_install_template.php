<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


?>
<form name="form1" method="post" action="">
  <table width="30%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td height="26" bgcolor="#0000CC"><font color="#FFFFFF" face="Tahoma"><strong>&nbsp;:: 
        Change Aministration Password.</strong></font></td>
    </tr>
    <tr>
      <td><table width="452" border="0" align="center" cellpadding="3" cellspacing="0" bordercolor="#000000">
          <tr bgcolor="#999999"> 
            <td height="43" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><br>
              Install your script by changing your password.<br>
              By doing so, you accept the supplied license for this script.</strong></font> 
              <br>
              <font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="darkred"><br>
              Please read the included readme file, to see the default password.<br>
              For security reasons you will have to retype the old password,<br>
              even if you allready logged in at the admin center.<br><br>
              Notice, you might need to close down this browser to be able to<br>
              proceed with other functions of the admin center.<br>
              </font> 
              <hr size="1"></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="40%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Old 
              Password :</font></td>
            <td width="60%"> <div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                <input name="txtPwOLD" type="password" id="txtPwOLD" size="40" maxlength="60">
                </font></div></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">New 
              Password :</font></td>
            <td> <div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                <input name="txtPwNEW1" type="password" id="txtPwNEW1" size="40" maxlength="60">
                </font></div></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Retype 
              New Password :</font></td>
            <td> <div align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                <input name="txtPwNEW2" type="password" id="txtPwNEW2" size="40" maxlength="60">
                </font></div></td>
          </tr>
          <tr bgcolor="#999999"> 
            <td colspan="2"> <div align="right"> 
                <input name="SUBMIT" type="submit" id="SUBMIT" value="Okay">
                &nbsp; 
                <input type="reset" name="Submit" value="Cancel">
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
  <div align="center"></div>
</form>
