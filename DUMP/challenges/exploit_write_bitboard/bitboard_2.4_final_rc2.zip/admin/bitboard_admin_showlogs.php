<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";
?>
<form action="<?php echo $PHP_SELF ?>" method="post" enctype="application/x-www-form-urlencoded" name="form1" target="_self">
    <table width="100%" border="1" cellspacing="0" bordercolor="#000000" bgcolor="#999999">
    <tr>
    <td width="28%" rowspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
    <input name="optionsList" type="radio" value="0" checked>
    List All<br>
    <input name="optionsList" type="radio" value="1">
    Seek by Username<br>
    <input type="radio" name="optionsList" value="2">
    Seek by TopicID <br>
    <input type="radio" name="optionsList" value="3">
    Seek by IP </font></td>
    <td width="72%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Please
    insert a valid search string and click &quot;Search Log&quot;
    to list all entries matching your criteria.</font></td>
    </tr>
    <tr>
      <td valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Search
        for: 
        <input name="txtSEARCHCRITERIA" type="text" id="txtSEARCHCRITERIA" size="40" maxlength="60">
              <input name="cmdLIST" type="submit" id="cmdLIST" value="Search Log">
        </font></td>
    </tr>
  </table>
</form>  
<br>
<table width="100%" border="1" cellpadding="0">
  <tr bgcolor="#999999"> 
    <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Date</font></strong></td>
    <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Username</font></strong></td>
    <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Topic 
      Subject</font></strong></td>
    <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Topic 
      ID</font></strong></td>
    <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">User's 
      IP</font></strong></td>
    <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Users 
      DNS</font></strong></td>
  </tr>

<?php

// If there are no logs..
if (filesize("../datafiles/data_logs.log") < 1) {
    echo "<tr><td><font size='2' face='Verdana, Arial, Helvetica, sans-serif'>There are no logs stored</td></tr>";
    exit;
}

$LOGS = @file("../datafiles/data_logs.log") or Die("Couldn't open the LogFile. Is it created?");
$LOGS = array_reverse($LOGS);

foreach($LOGS as $LOG){

    $LOGITEM = explode("#",$LOG);

    $optionsList = $HTTP_POST_VARS['optionsList'];
    $txtSEARCHCRITERIA = $HTTP_POST_VARS['txtSEARCHCRITERIA'];

    // LIST ALL
    if ( (!isset($optionsList)) || ($optionsList == 0) )
    {
        echo"<tr bgcolor=\"#CCCCCC\">\r\n";
        for ($X=0;$X <= (sizeof($LOGITEM)-1);$X++){
            if ($X != 3){
                echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">$LOGITEM[$X]</font></td>\r\n";
            }else{
                echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><a href=\"../forum.php?DATEIN=$LOGITEM[$X]\" target=\"_blank\">$LOGITEM[$X]</a></font></td>\r\n";
            }
        }
    }

    // LIST BY USERNAME
    if ( $optionsList == 1 )
    {
        if (strtolower($LOGITEM[1]) == strtolower($txtSEARCHCRITERIA))
        {
            echo"<tr bgcolor=\"#CCCCCC\">\r\n";
            for ($X=0;$X <= (sizeof($LOGITEM)-1);$X++){
                if ($X != 3){
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">$LOGITEM[$X]</font></td>\r\n";
                }else{
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><a href=\"../forum.php?DATEIN=$LOGITEM[$X]\" target=\"_blank\">$LOGITEM[$X]</a></font></td>\r\n";
                }
            }
        }
    }

    // LIST BY TOPICID
    if ( $optionsList == 2 )
    {
        if (strtolower($LOGITEM[3]) == strtolower($txtSEARCHCRITERIA))
        {
            echo"<tr bgcolor=\"#CCCCCC\">\r\n";
            for ($X=0;$X <= (sizeof($LOGITEM)-1);$X++){
                if ($X != 3){
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">$LOGITEM[$X]</font></td>\r\n";
                }else{
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><a href=\"../forum.php?DATEIN=$LOGITEM[$X]\" target=\"_blank\">$LOGITEM[$X]</a></font></td>\r\n";
                }
            }
        }
    }

    // LIST BY IP
    if ( $optionsList == 3 )
    {
        if (strtolower($LOGITEM[4]) == strtolower($txtSEARCHCRITERIA))
        {
            echo"<tr bgcolor=\"#CCCCCC\">\r\n";
            for ($X=0;$X <= (sizeof($LOGITEM)-1);$X++){
                if ($X != 3){
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\">$LOGITEM[$X]</font></td>\r\n";
                }else{
                    echo"\t<td><font color=\"#990000\" size=\"2\" face=\"Arial, Helvetica, sans-serif\"><a href=\"../forum.php?DATEIN=$LOGITEM[$X]\" target=\"_blank\">$LOGITEM[$X]</a></font></td>\r\n";
                }
            }
        }
    }

    echo "</tr>";
}

?>

</table>
</body>
</html>
