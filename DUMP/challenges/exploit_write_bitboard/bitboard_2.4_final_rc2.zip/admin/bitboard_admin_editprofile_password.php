<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

echo "<br><br>";

if(!$HTTP_POST_VARS['SUBMIT']){

    include 'bitboard_admin_editprofile_password_template.php';

}else{

    $txtPHPinits = "<?php\r\n?>";
    $txtProfileUserName = $HTTP_GET_VARS['UserName'];
    $txtPwOLD = $HTTP_POST_VARS['txtPwOLD'];
    $txtPwNEW1 = $HTTP_POST_VARS['txtPwNEW1'];
    $txtPwNEW2 = $HTTP_POST_VARS['txtPwNEW2'];

    $oldPW = PASSWORD_GET("../profiles/pwd_".trim($txtProfileUserName).".php");

    if (crypt($txtPwOLD,"BS") != $oldPW){

        echo "<br><table width=\"452\" border=\"1\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\" bordercolor=\"#000000\">";
        echo "<tr bordercolor=\"#0000FF\"><td colspan=\"2\" bgcolor=\"#999999\"><p align=\"center\">";
        echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">The old password differs from the one stored on the server.";
        echo "<br>Please try again. Click <a href=\"bitboard_admin_editprofile_password.php\">here</a>.</font></p></td></tr></table>";
        Die;
    }

    if (crypt($txtPwNEW1,"BS") != crypt($txtPwNEW2,"BS")){

        echo "<br><table width=\"452\" border=\"1\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\" bordercolor=\"#000000\">";
        echo "<tr bordercolor=\"#0000FF\"><td colspan=\"2\" bgcolor=\"#999999\"><p align=\"center\">";
        echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">The new password differs from the retyped one.";
        echo "<br>Please try again. Click <a href=\"bitboard_admin_editprofile_password.php\">here</a>.</font></p></td></tr></table>";
        Die;
    }
    
    if (empty($txtPwNEW1) || empty($txtPwNEW2)){

        echo "<br><table width=\"452\" border=\"1\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\" bordercolor=\"#000000\">";
        echo "<tr bordercolor=\"#0000FF\"><td colspan=\"2\" bgcolor=\"#999999\"><p align=\"center\">";
        echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">Your new password is lenght 0. This won't work.";
        echo "<br>Please try again. Click <a href=\"bitboard_admin_editprofile_password.php\">here</a>.</font></p></td></tr></table>";
        Die;
    }

    if (crypt($txtPwNEW1,"BS") == crypt($txtPwNEW2,"BS")){

        // Password
        PASSWORD_WRITE("../profiles/pwd_".$txtProfileUserName.".php",crypt($txtPwNEW2,"BS"));

        echo "<br><table width=\"452\" border=\"1\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\" bordercolor=\"#000000\">";
        echo "<tr bordercolor=\"#0000FF\"><td colspan=\"2\" bgcolor=\"#999999\"><p align=\"center\">";
        echo "<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">Your password has been written.";
        echo "<br>Click <a href='admin_admin_welcome.php'>here</a> to proceed to the Administration Center.</font></p></td></tr></table>";
        Die;
    }
}
    
?>
</body>
</html>
