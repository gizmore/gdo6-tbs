<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////

/*

    HARDEDIT SPECIAL NOTICE:
    
    This piece of code has been written entirely by the bitshifters
    for use within bitboard. However a retail version of script is
    soon to be done. free download of course!
    
*/

include "../include/bitboard_configuration.php";
include "bitboard_admin_head.php";

if (!$HTTP_POST_VARS['cmdSubmit']) {

?>

<form name="form1" method="post" action="">
  <table width="63" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr>
      <td colspan="2"><font face="Tahoma" size="3"><strong>HardEdit Editpad</strong></font></td>
    </tr>
    <tr>
      <td colspan="2" align="left" valign="middle">
        <textarea name="txtEditText" cols="80" rows="20" wrap="OFF" id="txtEditText"><?php
            $fp = fopen($HTTP_GET_VARS['EditFile'],"r");
            fpassthru($fp);
        ?></textarea></td>
    </tr>
    <tr>
      <td colspan="2"><font face="Verdana" size="2"><strong>Warning:</strong> Edited, existing files are overwritten without
        prior notice when you click &quot;save as&quot;.<br>You can also save the
        edited file with a different name.</font></td>
    </tr>
    <tr>
      <td width="82%" align="left" valign="middle">
        <input name="txtFileName" type="text" id="txtFileName" value="<?php echo $HTTP_GET_VARS['EditFile'] ?>" size="80"></td>
      <td width="18%" align="right" valign="middle">
        <input type="submit" name="cmdSubmit" value="Save As">
      </td>
    </tr>
  </table>
</form>
<p>&nbsp;</p></body>
</html>
<?php

}else{

  $sText = stripslashes($HTTP_POST_VARS['txtEditText']);
  $fp = fopen($HTTP_POST_VARS['txtFileName'],"w");
  fwrite($fp,$sText);
  fclose($fp);

?>
  <table width="90%" border="0" align="center" cellpadding="5" cellspacing="2">
    <tr>
      <td colspan="2"><font face="Tahoma" size="3"><strong>HardEdit Editpad</strong></font></td>
    </tr>
    <tr>
      <td colspan="2"><font face="Tahoma" size="2">The file has been written to <?= $HTTP_POST_VARS['txtFileName'] ?><br>
      You may close this window now.</td>
    </tr>
  </table>

<?php

}


?>
