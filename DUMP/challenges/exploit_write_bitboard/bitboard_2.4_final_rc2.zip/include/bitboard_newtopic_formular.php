<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


?><form name="form1" method="post" action="">
  <table width="63%" border="0" align="center" cellpadding="1" cellspacing="1">
    <tr>
      <td align="left" valign="top" class="boardtablerow1"><?= $BITBOARD_USERNAME ?>:</td>
      <td class="boardtablerow1">
        <div align="center">
          <p align="left">
            <?php
                if (isset($HTTP_COOKIE_VARS['usr'])) {

                    // User is a registered, logged in user...
                    $usr = $HTTP_COOKIE_VARS['usr'];
                    echo $usr['name'];
                    
                }else{

                    // User is not logged in.

                    echo "<input name=\"txtUserName\" type=\"text\" id=\"txtUserName\" value=\"".$HTTP_COOKIE_VARS['BITBOARDUSER']."\" size=\"70\" maxlength=\"50\">";
                    
                }
            ?>
          </p>
        </div></td>
    </tr>
    <tr>
      <td align="left" valign="top" class="boardtablerow1"><?= $BITBOARD_SUBJECT ?>:</td>
      <td class="boardtablerow1">
        <div align="center">
        <p align="left">
          <input name="txtSubject" type="text" id="txtSubject" value="<?php echo $RESUBJECT ?>" size="70" maxlength="60">
        </p>
        </div></td>
    </tr>
    <tr>
      <td colspan="2" align="center" valign="middle" class="boardtablerow2">
        <div align="center"><br>
          <textarea name="txtMessage" cols="70" rows="15" id="txtMessage"></textarea>
        </div><br></td>
    </tr>
    <tr>
      <td colspan="2" align="left" valign="top" class="boardtablerow2">
        <div align="right"><br>
          <input name="cmdSubmit" type="submit" id="cmdSubmit" value="Post Topic">
          <br>
          <br>
        </div></td>
    </tr>
  </table>
</form>
 <table width="63%" border="0" align="center" cellpadding="1" cellspacing="1">
       <?php
       if($BITBOARD_ENABLEHTML){
           $ADMMSG= $BITBOARD_OPT_HTML." ".$BITBOARD_OPT_ENABLED." ";
       }else{
           $ADMMSG= $BITBOARD_OPT_HTML." ".$BITBOARD_OPT_DISABLED." ";
       }
       if($BITBOARD_FILTERBADMOUTHING){
           $ADMMSG .= $BITBOARD_OPT_BADMOUTH." ".$BITBOARD_OPT_ENABLED." ";
       }else{
           $ADMMSG .= $BITBOARD_OPT_BADMOUTH." ".$BITBOARD_OPT_DISABLED." ";
       }
       if($BITBOARD_ENABLELOGS){
           $ADMMSG .= $BITBOARD_OPT_LOGGING1;
       }else{
           $ADMMSG .= $BITBOARD_OPT_LOGGING2;
       }
       echo "<td align=\"center\" class=\"boardpostingoptions\">$ADMMSG</td>";
	   ?>
    </tr>
</table>
