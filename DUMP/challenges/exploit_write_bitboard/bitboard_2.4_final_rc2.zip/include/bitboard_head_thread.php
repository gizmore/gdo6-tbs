<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2003 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


echo "
<html>
<head>
<title>'$BITBOARD_FORUMNAME' - powered by BiTBOARD</title>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>
<link href='".GETSTYLESHEET()."' rel='stylesheet' type='text/css'>
</head>
<body class='boardsite'>
<p align='center' class='boardheadline'>&quot;$BITBOARD_FORUMNAME&quot;</p>
<p align='center' class='boardsite'>$BITBOARD_FORUMDESC</p>
<p align='center' class='boardsite'>&nbsp;</p>
<table width='90%' height='5' border='0' align='center' cellpadding='0' cellspacing='1'>
  <tr class='boardtableheader'>
   <td><a href='reply.php?REPLYTO=".$HTTP_GET_VARS['DATEIN']."' target='_self'>$BITBOARD_REPLY</a> &nbsp;&nbsp; <a href='$BITBOARD_MAIN'>$BITBOARD_MAINPAGE</a></td>
   </tr>
  <tr class='boardtableheader'>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

";
?>
