<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


$ContentsDirectory = array();
$StickyTopics = array();

// Open the directory, get handle and push topic files to array

$directory = "./contents/";
$dir_handle = opendir($directory);

while ($file = readdir($dir_handle)) {

    if (is_file($directory.$file)){
        // FILE FOUND!

        clearstatcache();
        $ftype = strtolower(substr($file,strlen($file)-3));

        if ($ftype == "txt") {
        // IS TOPIC FILE, ADD TO ARRAY
        
            $creationdate = filemtime(trim($directory.$file));

            // IF TOPIC IS DETONTED STICKY, ADD TO STICKY ARRAY...
            if (IS_STICKY($directory.$file)) {
                // Sticky Array
                array_push($StickyTopics,$creationdate."#".$directory.$file);
            }else{
                // Normal Array
                array_push($ContentsDirectory,$creationdate."#".$directory.$file);
            }
            
        }

    }

}

// Sort Array by Filemodification time stored in cell [1]
// PHP's own SortRoutines did not entirely do the job,
// So I used my own reversing function...
$ContentsDirectory = SORTPOSTS($ContentsDirectory);
$StickyTopics = SORTPOSTS($StickyTopics);

// If There are no files in the directory, quit here.
if (strlen($ContentsDirectory[0]) < 2 && strlen($StickyTopics[0]) < 2) {
    $ContentsDirectory = array();
    $StickyTopics = array();
}

// Join both arrays... (if theres actually a sticky post)
if (!empty($StickyTopics[0])) {
    $ContentsDirectory = array_merge($StickyTopics, $ContentsDirectory);
}

// ArrayStatistics

$StoredTopics = sizeof($ContentsDirectory);

// Available Amount of Visible Pages with current settings.
$AvailPages = ceil($StoredTopics / $BITBOARD_MAXTOPICS);
if ($AvailPages == 0) {
    $AvailPages = 1;
}

// Slice Array
if (isset($HTTP_GET_VARS['showpage']) && !empty($HTTP_GET_VARS['showpage'])) {
    $seite = $HTTP_GET_VARS['showpage'];
}else{
    $seite = 1;
}

$START = ($seite * $BITBOARD_MAXTOPICS) - $BITBOARD_MAXTOPICS;

$ContentsDirectory = array_slice($ContentsDirectory,$START,$BITBOARD_MAXTOPICS);

// Define PrevPage NextPage

$ENDE=$BITBOARD_MAXTOPICS*$seite;

if ($START != '0') {
    $NEUE_SEITE=$seite-1;
    $SEITEVOR="<a href='$PHP_SELF?showpage=$NEUE_SEITE'>$BITBOARD_PREVPAGE</a>";
}
else {
    $SEITEVOR="";
}
if ($ENDE < $StoredTopics) {
    $NEUE_SEITE1=$seite+1;
    $SEITENEXT="<a href='$PHP_SELF?showpage=$NEUE_SEITE1'>$BITBOARD_NEXTPAGE</a>";
}
    else {
$SEITENEXT="";
}


// START CONTENTS TABLE

echo $BITBOARD_TABLESTART;

foreach ($ContentsDirectory as $TopicFiles) {

    $i++;
    $TopicFiles = explode("#",$TopicFiles);

    if ($i <= $BITBOARD_MAXTOPICS) {

    $ROWCOUNT++;
    $TOPICID = substr($TopicFiles[1],0,strlen($TopicFiles[1])-4);
    $TOPICID = substr($TOPICID,strrpos($TOPICID,"/")+1);
    
    // Define which row to use.
    if ((round($ROWCOUNT / 2)) != ($ROWCOUNT/2))
    {
        $useClass = $BITBOARD_TABLEROW1;
    }else{
        $useClass = $BITBOARD_TABLEROW2;
    }
    echo "<tr>";

    if (IS_STICKY($TopicFiles[1])) {
        echo "<td $useClass width=\"*\">&nbsp;<a href=\"$BITBOARD_MAIN?DATEIN=$TOPICID\" target=\"_self\" class=\"TopicLink\"><strong>$BITBOARD_STICKY:</strong> ".GETSUBJECT($TopicFiles[1])."</a></td>";
    }else{
        echo "<td $useClass width=\"*\">&nbsp;<a href=\"$BITBOARD_MAIN?DATEIN=$TOPICID\" target=\"_self\" class=\"TopicLink\">".GETSUBJECT($TopicFiles[1])."</a></td>";
    }
    echo "<td $useClass width=\"130\"><div align=\"center\">".GETAUTHOR($TopicFiles[1])."</div></td>";
    echo "<td $useClass width=\"130\"><div align=\"center\">".GETLASTREPLY($TopicFiles[1])."</div></td>";
    echo "<td $useClass width=\"70\"><div align=\"center\">".GETREPLIES($TopicFiles[1])."</div></td>";
    echo "</tr>";
    
    }

}

echo "</tr></table><br>";
echo "<table align=\"center\" width=\"90%\"><tr class=\"boardtableheader\">";
echo "<td align=\"left\">$BITBOARD_CURRENTPAGE $seite/$AvailPages</td>";
echo "<td align=\"right\">$SEITEVOR $SEITENEXT</td></tr></table>";

// closing the directory with the handle.
closedir($dir_handle);
?>

