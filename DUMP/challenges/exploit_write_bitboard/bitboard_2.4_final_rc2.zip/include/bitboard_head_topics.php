<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


echo "
<html>
<head>
<title>'$BITBOARD_FORUMNAME' - powered by BiTBOARD</title>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>
<link href='".GETSTYLESHEET()."' rel='stylesheet' type='text/css'>
</head>
<body class='boardsite'>
<p align='center' class='boardheadline'>&quot;$BITBOARD_FORUMNAME&quot;</p>
<p align='center' class='boardsite'>$BITBOARD_FORUMDESC</p>
<p align='center' class='boardsite'>&nbsp;</p>
<table width='90%' height='5' border='0' align='center' cellpadding='5' cellspacing='2'>
  <tr class='boardheadermenu'>
    <td><a href='newtopic.php' target='_self'>$BITBOARD_NEWTOPIC</a> &nbsp;&nbsp; <a href='$BITBOARD_MAIN'>$BITBOARD_RELOAD</a> &nbsp;&nbsp; ";

    if (!isset($HTTP_COOKIE_VARS['usr'])) {
        echo "<a href='login.php' target='_self'>$BITBOARD_LOGIN</a>";
    }else{
        $usr = $HTTP_COOKIE_VARS['usr'];
        echo "<a href='logoff.php' target='_self'>$BITBOARD_LOGOFF, ".$usr['name']."</a>";
    }
    
    if (!empty($BITBOARD_WEBSITE)){
        $WEBURL = parse_url($BITBOARD_WEBSITE);
        echo "  &nbsp;&nbsp; <a href='$BITBOARD_WEBSITE'>$WEBURL[host]</a>";
    }

echo "
    </td>
  </tr>
  <tr class='boardtableheader'>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr class='boardtableheader'>
    <td width='*'>$BITBOARD_SUBJECT</td>
    <td width='130'><div align='center'>$BITBOARD_STARTEDBY</div></td>
    <td width='130'><div align='center'>$BITBOARD_LASTREPLY</div></td>
    <td width='70'><div align='center'>$BITBOARD_REPLIES</div></td>
  </tr>
</table>

";

?>
