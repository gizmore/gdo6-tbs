<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


/************************************************** CONFIGS **************/
/* here are are the configs you might change.others you should leave the */
/* way they are. they are hard-coded and the board might failure if      */
/* the variables are changed...                                          */
/*************************************************************************/

/*
        GENERAL
*/

// Your Forums name: (i.e. "The MultiGaming Community")
$BITBOARD_FORUMNAME = "BiTSHiFTERS BiTBOARD";

// Your Forums Description (i.e. "Successful Gaming Since 1920")
$BITBOARD_FORUMDESC = "Creating Code Since 1992";

// Your Website: (i.e. "http://www.gamingcommunity.com/news/today.htm")
// ...leave blank if unused.
$BITBOARD_WEBSITE = "";

// Administrator Email. (Used for Security warnings or Users Contact)
$BITBOARD_ADMINCONTACT = "example@host.com";

/*
        OPTIONS
*/

// Lets users post HTML code. This can be exploited.
// So, if it is going to be a public board - set it to FALSE.
$BITBOARD_ENABLEHTML = FALSE;

// if on logs Username, IP, DNS and topicID to the Logfile.
$BITBOARD_ENABLELOGS = TRUE;

// filter badmouthing in userposts.
$BITBOARD_FILTERBADMOUTHING = TRUE;

// convert ASCII emoticons to graphics...
$BITBOARD_USEEMOTICONS = FALSE;

// mail admins on new posts...
$BITBOARD_MAILADMINS = TRUE;

// emails of admins. Seperate with Spaces... (i.e. Me@here.com You@now.net)
$BITBOARD_ADMINS = "";

// use new profile friendly thread-alignment
// (if you plan on using profiles it is recommended to set that to true.
// if you are going to use a freedom-of-speech kind of board you can set
// it to false too. try for your self.)
$BITBOARD_USENEWTHREADWALK = TRUE;

/*
        TIME & DATE
*/

// how to express the date. php syntax.
$BITBOARD_DATEFORMAT = "y-m-d H:i:s";

// Add this amount of hours to the servers time.
// Only Integervalues. Negative works too. (i.e. +2 or -12)
// If your server is on GMT, but you're living in GMT+1,
// You can add +1 hour to make the server fit your time.
$BITBOARD_TIMEZONE = +0;

/*
        PAGE VIEW
*/

// maximum number of topics to show on one page
$BITBOARD_MAXTOPICS = 20;   // Topics
$BITBOARD_MAXTHREADS = 10;   // Threads

/*
 *
 *
 ************************************************** INTERNAL *************/
global $DATEIN;

$BITBOARD_MAIN = "index.php";
$BITBOARD_LOGFILE = "./datafiles/data_logs.log";
$BITBOARD_BADMOUTHFILE = "./datafiles/data_badmouthwords.txt";
$BITBOARD_BANNEDIPSFILE = "./datafiles/data_bannedips.dat";
$BITBOARD_BANNEDUSERSFILE = "./datafiles/data_bannedusers.dat";
$BITBOARD_STYLEFILE = "./datafiles/data_stylesheet.dat";
$BITBOARD_LANGFILE = "./datafiles/data_language.dat";
$BITBOARD_VERSION = "2.4 RC2";

/************************************************** ERRORMSGS ************/
$BITBOARD_ERRTOPICFILE = "<br>ERROR: Could not open the post with TopicID #$DATEIN. Script aborted!";
$BITBOARD_ERRMISSINGFIELD = "ERROR: Post failed. One or more fields were missing.";
$BITBOARD_ERRCREATETOPIC = "<br>ERROR: Could not create topic.";
$BITBOARD_ERRNOREPLY = "<br>ERROR: No TopicID for reply transmitted. Aborting Script.";
$BITBOARD_ERRLOGGING = "<br>ERROR: Could not open/close logging file";
$BITBOARD_ERRBADMOUTHFILE = "<br>ERROR: Could not open the badmouthfilter datafile. Badmouthing disabled!";
$BITBOARD_ERRBANNEDUSERSFILE = "<br>ERROR: Could not open the banned users datafile.";
$BITBOARD_ERRBANNEDIPSFILE = "<br>ERROR: Could not open the banned ips datafile.";

/************************************************** TABLECFGS ************/
$BITBOARD_TABLESTART = "<table width='90%' height='5' border='0' align='center' cellpadding='5' cellspacing='2'>";
$BITBOARD_TABLEROW1 = "class='boardtablerow1'";
$BITBOARD_TABLEROW2 = "class='boardtablerow2'";

/************************************************** COOKIE USAGE ********/

if (!empty($HTTP_POST_VARS['txtUserName'])){
    /// Cookie setzen
    setcookie("BITBOARDUSER",$HTTP_POST_VARS['txtUserName'],time()+31536000);
}

/************************************************** LANGUAGE FILES ******/

// Language files::
if (file_exists($BITBOARD_LANGFILE)) {
    $USELANGUAGE = file($BITBOARD_LANGFILE);
    $USELANGPATH = "./languages/";
}else{
    $USELANGUAGE = file("../".$BITBOARD_LANGFILE);
    $USELANGPATH = "../languages/";
}
include $USELANGPATH.trim($USELANGUAGE[0]);

?>
