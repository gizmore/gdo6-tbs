<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////

// disable html
if(!$BITBOARD_ENABLEHTML){
    $txtSubject = str_replace("<","&lt;",$txtSubject);$txtSubject = str_replace(">","&gt;",$txtSubject);
    $txtMessage = str_replace("<","&lt;",$txtMessage);$txtMessage = str_replace(">","&gt;",$txtMessage);
    $txtUserName = str_replace("<","&lt;",$txtUserName);$txtUserName = str_replace(">","&gt;",$txtUserName);
}

// insert emoticons...
if ($BITBOARD_USEEMOTICONS) {
    include "./modules/bitboard_module_emoticons.php";
}

// convert bitcodes...
include "./modules/bitboard_module_bitcodes.php";

// remove Database Seperator "#" from Line...
$txtSubject = str_replace("#","",$txtSubject);
$txtUserName = str_replace("#","",$txtUserName);
$txtMessage = str_replace("#","",$txtMessage);

// Define content for new Topic...
$line = ucfirst($txtSubject);
$line .= "#".$txtUserName;
$line .= "#".$txtMessage."<BR>#".time()."#NotSticky#NotClosed";

// filter badmouthing
if($BITBOARD_FILTERBADMOUTHING){
    $line = FilterBadmouth($line);
}

// Change \r\n'S to html <br>eak.
$line = str_replace("\r\n","<BR>",$line);
// remove all other \
$line = stripcslashes($line);
// add carriage return to datafile...
$line .= "\r\n";

?>

