<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


// Open selected file stored in $DATEIN and gather all available data.
$DATEIN = $HTTP_GET_VARS['DATEIN'];
$DATEIIST = "./contents/".$DATEIN.".txt";
$CONTENTARRAY = @file($DATEIIST) or Die($BITBOARD_ERRTOPICFILE);

// Remove empty lines that might occure after hardedit.
$CONTENTARRAY = REMOVEEMPTYLINES($CONTENTARRAY);

// ArrayStatistics
$StoredThreads = sizeof($CONTENTARRAY);

// Available Amount of Visible Pages with current settings.
$AvailPages = ceil($StoredThreads / $BITBOARD_MAXTHREADS);

// Slice Array
$seite = $HTTP_GET_VARS['showpage'];
if (empty($seite))
{
    $seite = 1;
}

$START = ($seite * $BITBOARD_MAXTHREADS) - $BITBOARD_MAXTHREADS;

$CONTENTARRAY = array_slice($CONTENTARRAY,$START,$BITBOARD_MAXTHREADS);

// Define PrevPage NextPage

$ENDE=$BITBOARD_MAXTHREADS*$seite;

if ($START != '0') {
    $NEUE_SEITE=$seite-1;
    $SEITEVOR="<a href='$PHP_SELF?DATEIN=$USETOPIC&showpage=$NEUE_SEITE'>$BITBOARD_PREVPAGE</a>";
}
else {
    $SEITEVOR="";
}
if ($ENDE < $StoredThreads) {
    $NEUE_SEITE1=$seite+1;
    $SEITENEXT="<a href='$PHP_SELF?DATEIN=$USETOPIC&showpage=$NEUE_SEITE1'>$BITBOARD_NEXTPAGE</a>";
}
    else {
$SEITENEXT="";
}


// Start Table.
echo $BITBOARD_TABLESTART;

foreach($CONTENTARRAY as $CONTENT)
{
    $CONTENTINFO = explode("#","$CONTENT");
    $USERPROFILE = "./profiles/prf_".strtolower(trim($CONTENTINFO[1])).".php";
    $USERSIGNATURE = "./profiles/sig_".strtolower(trim($CONTENTINFO[1])).".php";

    /*


    <p class=\"UserPostInfo\"></td>";

    */


    // Write user post...
    echo "<tr valign=\"top\">";

    echo "<td class=\"boardtablerow1\" width=\"100\">";
    echo "<strong>$CONTENTINFO[1]</strong>";
    if (file_exists($USERPROFILE)) {
        include $USERPROFILE;
    }
    echo "<br></td>";
    echo "<td class=\"boardtablerow2\">";

    echo $BITBOARD_POSTEDON." ".date($BITBOARD_DATEFORMAT,TIME_CONVERTZONE($CONTENTINFO[3],$BITBOARD_TIMEZONE))." ";
    echo $BITBOARD_SUBJECT.": ".$CONTENTINFO[0]."<hr width=\"100%\" size=\"1\"><br>";
    echo $CONTENTINFO[2];
    if (file_exists($USERSIGNATURE)) {
        include $USERSIGNATURE;
    }
    echo "</td>";
    echo "</tr>";
    echo "<tr><td></td></tr>";

}

echo "</table><br>";
echo "<table align=\"center\" width=\"90%\"><tr class=\"boardtableheader\">";
echo "<td align=\"left\">$BITBOARD_CURRENTPAGE $seite/$AvailPages</td>";
echo "<td align=\"right\">$SEITEVOR $SEITENEXT</td></tr></table>";

?>
