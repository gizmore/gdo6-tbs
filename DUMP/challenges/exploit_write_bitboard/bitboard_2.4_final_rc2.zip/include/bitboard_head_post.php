<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2003 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


echo "

<html>
<head>
<title>'$BITBOARD_FORUMNAME' - powered by BiTBOARD</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
<link href=\"".GETSTYLESHEET()."\" rel=\"stylesheet\" type=\"text/css\">
</head>
<SCRIPT src=\"./modules/fnc_newwindow.js\" type=\"text/javascript\"></SCRIPT>
<body class=\"boardsite\">
<p align=\"center\" class=\"boardheadline\">&quot;$BITBOARD_FORUMNAME&quot;</p>
<p align=\"center\" class=\"boardsite\">$BITBOARD_FORUMDESC</p>
<p align=\"center\" class=\"boardsite\">&nbsp;</p>
";
if (!$HTTP_POST_VARS['cmdSubmit']){
echo "
<table width=\"63%\" height=\"5\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"1\">
  <tr class=\"boardtableheader\">
  <td><a href=\"./include/bitboard_newtopic_postinghelp.php\" onclick=\"NewWindow(this.href,'iexp','440','250','yes');return false\">$BITBOARD_NEEDHELP</a></td>
  </tr>
</table>
";
}
echo "
<br>

";

?>
