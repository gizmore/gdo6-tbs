<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////

?>
<br>
<br>
<br>
<br>
<p class="copyrightnoticetext" align="center">
- BiTBOARD v<?php echo $BITBOARD_VERSION?> Bulletin Board by <a href="http://www.bitshifters.bl.am" target="_blank">the BiTSHiFTERS SDC</a> -<br></font>
</p>

