<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


    if (isset($REPLYTO)){
        $REFER = $PHP_SELF."?REPLYTO=".$REPLYTO;
    }else{
        $REFER = $PHP_SELF;
    }

    if (empty($REMOTE_ADDR) || !isset($REMOTE_ADDR)) {
        $USERSIP = $HTTP_ENV_VARS['REMOTE_ADDR'];
    }else{
        $USERSIP = $REMOTE_ADDR;
    }
    
?>
<table width="63%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="95" class="boardtablerow1"><div align="center"><a href="<?php echo $BITBOARD_MAIN ?>" target="_self"><?= $BITBOARD_STAT_LOGGEDOFF ?><br>
      <?= $BITBOARD_STAT_BACKTOINDEX ?></a></div></td>
  </tr>
</table>

