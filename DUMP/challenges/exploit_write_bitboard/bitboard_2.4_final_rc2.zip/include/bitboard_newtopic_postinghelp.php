<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>BiTBOARD POSTING HELP</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="bitboard_stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body link="#0000CC" vlink="#0000CC" alink="#0000CC">
<p><font size="2" face="Tahoma"><strong>Posting on BiTBOARD Forums</strong></font></p>
<p><font size="2" face="Tahoma">Please ensure you follow the steps provided here 
  to get the most out <br>
  of your post with a BiTBOARD forum.</font></p>
<p><font size="2" face="Tahoma"><em>Index</em></font></p>
<ul>
  <li><strong><font size="2" face="Tahoma"><a href="#bitcodes" target="_self">Bitcodes</a></font></strong> 
    <ul>
      <li><a href="#bitcodes_images"><font size="2" face="Tahoma">Posting Images</font> 
        </a></li>
      <li><font size="2" face="Tahoma"><a href="#bitcodes_hyperlinks">Posting 
        Hyperlinks</a></font></li>
      <li><a href="#bitcodes_email"><font size="2" face="Tahoma">Posting Email</font></a></li>
      <li><a href="#bitcodes_textformatting"><font size="2" face="Tahoma">Text 
        Formatting</font></a></li>
    </ul>
  </li>
  <li><font size="2" face="Tahoma"><strong><a href="#emoticons">Emoticons</a></strong></font></li>
  <li><a href="#html"><font size="2" face="Tahoma"><strong>Using HTML in Posts</strong></font></a></li>
</ul>
<hr size="1">
<p><font size="2" face="Tahoma"><strong><a name="bitcodes"></a>Bitcodes</strong></font></p>
<p><font size="2" face="Tahoma">Since version 1.2 of BiTBOARD it is supporting 
  &quot;BiTCODES&quot;.<br>
  BitCodes are shortcuts to usual HTML functions without actually<br>
  using HTML. You may know these allready from ezBoard or<br>
  any other &quot;bigger&quot; bulletinboard software.</font></p>
<hr size="1">
<p><font size="2" face="Tahoma"><strong><a name="bitcodes_images"></a>Bitcodes 
  -&gt; Posting Images</strong><br>
  <br>
  Posting Images using Bitcodes is pretty easy. <br>
  The scheme is like that:<br>
  <br>
  <font color="#0033FF">[img]</font>http://www.myhost.com/linktomy/image.jpg<font color="#0033FF">[/img]</font></font></p>
<hr size="1">
<p><font size="2" face="Tahoma"><strong><a name="bitcodes_hyperlinks"></a>Bitcodes 
  -&gt; Posting Hyperlinks</strong></font></p>
<p><font size="2" face="Tahoma">Hyperlinks are as easy as image posting. They 
  are a little<br>
  </font><font size="2" face="Tahoma">more complex than the ones you might know 
  from ezBoard,<br>
  but they are far more effective too.<br>
  The scheme:<br>
  <br>
  <font color="#0033FF">[url]</font>http://www.google.com<font color="#0033FF">[linkas]</font>Google<font color="#0033FF">[/url]</font><br>
  <br>
  which will create a Link called &quot;Google&quot; in your Post.<br>
  You can put as well &quot;Check this out!&quot; there!<br>
  Links posted using this feature are always opened<br>
  within a new browser-window.</font></p>
<hr size="1">
<p><font size="2" face="Tahoma"><strong><a name="bitcodes_email" id="bitcodes_email"></a>Bitcodes 
  -&gt; Posting eMail</strong></font></p>
<p><font size="2" face="Tahoma">Posting EMail Adresses is just the same as posting<br>
  Hyperlinks using bitcodes.</font><font size="2" face="Tahoma"><br>
  <br>
  <font color="#0033FF">[mail]name@server.com[/mail]</font><br>
  <br>
  which will create an Emaillink called &quot;Email&quot; in your Post.<br>
  So, to effectively use this feature write like this:</font></p>
<p><font size="2" face="Tahoma">You can [mail]name@server.com[/mail] me too!! 
  <br>
  which creates:<br>
  <br>
  You can <a href="name@server.com">Email</a> me too!!</font></p>
<hr size="1">
<p><font size="2" face="Tahoma"><strong><a name="bitcodes_textformatting" id="bitcodes_textformatting"></a>Bitcodes 
  -&gt; Text Formatting</strong></font></p>
<p><font size="2" face="Tahoma">You can format text to be either bold, italic<br>
  or underlined. The following codes are used:<br>
  <br>
  <font color="#0033FF">[b]bold[/b]</font> <strong>bold</strong><br>
  <font color="#0033FF">[i]italic[/i]</font> <em>italic</em></font><font size="2" face="Tahoma"><br>
  <font color="#0033FF">[u]underline[/u] </font><u>underline</u><br>
  <br>
  You can of course combine these too.</font></p>
<hr size="1">
<p><font size="2" face="Tahoma"><strong><a name="emoticons"></a>Emoticons</strong></font></p>
<p><font size="2" face="Tahoma">Emoticons express your feeling in ASCII, or, <br>
  if the BiTBOARD administartor sets this option, <br>
  your ASCII characters are converted to graphics.<br>
  Here is a list of emoticons used by BiTBOARD:</font></p>
<table width="170" height="186" border="1" cellpadding="0" cellspacing="0">
  <tr bgcolor="#CCCCCC">
    <td width="18" bordercolor="#CCCCCC">&nbsp;</td>
    <td width="59"><p><font color="#0033FF" size="2" face="Tahoma">:[</font></p></td>
    <td width="85"><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_evil.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td><p><font color="#0033FF" size="2" face="Tahoma">:D</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_biggrin.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td><p><font color="#0033FF" size="2" face="Tahoma">8)</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_cool.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td><p><font color="#0033FF" size="2" face="Tahoma">^_^</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_cheesygrin.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td><p><font color="#0033FF" size="2" face="Tahoma">:?</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_question.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td><p><font color="#0033FF" size="2" face="Tahoma">:lol:</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_lol.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td><p><font color="#0033FF" size="2" face="Tahoma">:(</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_sad.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td><p><font color="#0033FF" size="2" face="Tahoma">:)</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_smile.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td><p><font color="#0033FF" size="2" face="Tahoma">:P</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_razz.gif" width="15" height="15"></font></div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td bordercolor="#CCCCCC">&nbsp;</td>
    <td height="18"><p><font color="#0033FF" size="2" face="Tahoma">;)</font></p></td>
    <td><div align="center"><font size="2" face="Tahoma"><img src="../modules/emoticons/icon_wink.gif" width="15" height="15"></font></div></td>
  </tr>
</table>
<br>
<hr size="1">
<p><font size="2" face="Tahoma"><strong><a name="html"></a>Using HTML in Posts</strong></font></p>
<p><font size="2" face="Tahoma">HTML is the Hypertext Markup Language.<br>
  A language that enables authoers to design<br>
  website content.<br>
  If your administrator has this feature enabled,<br>
  you can use this language in your posts.<br>
  <br>
  A List with common HTML functions<br>
  is <a href="http://archive.ncsa.uiuc.edu/General/Internet/WWW/HTMLPrimer.html" target="_blank">here</a>.</font></p>
<hr size="1">
<p><font size="2" face="Tahoma"><br>
  <br>
  (C)BiTSHiFTERS SDC. ALL RIGHTS RESERVED.<br>
  (eof)</font></p>
</body>
</html>
