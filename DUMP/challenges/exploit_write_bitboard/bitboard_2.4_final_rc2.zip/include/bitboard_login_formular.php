<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


?><form name="form1" method="post" action="">
  <table width="63%" border="0" align="center" cellpadding="1" cellspacing="1">
    <tr> 
      <td align="left" valign="top" class="boardtablerow1">
        <?= $BITBOARD_USERNAME ?>
        :</td>
      <td class="boardtablerow1"> <div align="center"> 
          <p align="left"> 
            <input name="txtUserName" type="text" id="txtUserName" size="70" maxlength="50">
          </p>
        </div></td>
    </tr>
    <tr> 
      <td align="left" valign="top" class="boardtablerow1">
        <?= $BITBOARD_PASSWORD ?>
        :</td>
      <td class="boardtablerow1"> <div align="center"> 
          <p align="left"> 
            <input name="txtPassword" type="password" id="txtPassword" size="70" maxlength="60">
          </p>
        </div></td>
    </tr>
    <tr> 
      <td colspan="2" align="center" valign="middle" class="boardtablerow2">&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="2" align="left" valign="top" class="boardtablerow2"> <div align="right"><br>
          <input name="cmdSubmit" type="submit" id="cmdSubmit" value="<?= $BITBOARD_LOGIN ?>">
          <br>
          <br>
        </div></td>
    </tr>
  </table>
</form>
 
