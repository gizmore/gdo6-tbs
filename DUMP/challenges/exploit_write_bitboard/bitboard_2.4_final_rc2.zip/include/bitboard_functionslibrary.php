<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////

function GETTOPICID($FILENAME)
{
    $FILENAME = trim($FILENAME);
    $tmpTopicID = substr($FILENAME,0,strlen($FILENAME)-4);
    $tmpTopicID = substr($tmpTopicID,strrpos($tmpTopicID,"/")+1);
    
    return $tmpTopicID;
}

function GETSUBJECT($FILENAME)
{
    $FILENAME = trim($FILENAME);
    $tmpArray = @file($FILENAME);
    $tmpSubject = explode("#",$tmpArray[0]);
    return $tmpSubject[0];
}

function GETAUTHOR($FILENAME)
{
    global $BITBOARD_DATEFORMAT;
    global $BITBOARD_TIMEZONE;
    
    $FILENAME = trim($FILENAME);
    $tmpArray = file($FILENAME);
    $tmpAuthor = explode("#",$tmpArray[0]);
    if (!isset($tmpAuthor[3]) || empty($tmpAuthor[3])) {
        $tmpAuthor = $tmpAuthor[1]."<br>-";
    }else{
        $tmpAuthor = $tmpAuthor[1]."<br>".date($BITBOARD_DATEFORMAT,TIME_CONVERTZONE($tmpAuthor[3],$BITBOARD_TIMEZONE));
    }
    return $tmpAuthor;
}

function GETLASTREPLY($FILENAME)
{
    global $BITBOARD_DATEFORMAT;
    global $BITBOARD_TIMEZONE;
    
    clearstatcache();
    $FILENAME = trim($FILENAME);
    $tmpArray = file($FILENAME);
    if (sizeof($tmpArray) != "1")
    {
        $tmpLastReply = explode ("#",$tmpArray[sizeof($tmpArray)-1]);
        $tmpLastReplyDate = date($BITBOARD_DATEFORMAT,TIME_CONVERTZONE(filemtime($FILENAME),$BITBOARD_TIMEZONE));

        $LastReply = $tmpLastReply[1]."<br>".$tmpLastReplyDate;
    }else{
        $LastReply = "-";
    }
    return $LastReply;
}

function GETREPLIES($FILENAME)
{
    $FILENAME = trim($FILENAME);
    $tmpArray = file($FILENAME);
    return ((sizeof($tmpArray)-1));
}

function SORTPOSTS($POSTSARRAY)
{
    sort($POSTSARRAY);
    $tmpArray = array();
    $i = sizeof($POSTSARRAY);

    do {
        $i--;
        array_push($tmpArray,$POSTSARRAY[$i]);
    } while ($i>0);
    
    return $tmpArray;
}

function GETSTYLESHEET()
{
    global $BITBOARD_STYLEFILE;
    $tmpStylesheet = @file ($BITBOARD_STYLEFILE);
    return "./styles/".trim($tmpStylesheet[0]);
}

function GETPOSTSAMOUNT()
{
    $directory = "../contents/";
    $dir_handle = opendir($directory);

    while ($file = readdir($dir_handle)) {

        if (is_file($directory.$file)){

            clearstatcache();
            $ftype = strtolower(substr($file,strlen($file)-3));
            $fsize = filesize($directory.$file);

            if ($ftype == "txt") {
                $amount++;
            }
        }
    }
    
    return $amount;
}

function GETPOSTSTOTALSIZE()
{
    $directory = "../contents/";
    $dir_handle = opendir($directory);

    while ($file = readdir($dir_handle)) {

        if (is_file($directory.$file)){

            clearstatcache();
            $ftype = strtolower(substr($file,strlen($file)-3));
            $fsize = filesize($directory.$file);

            if ($ftype == "txt") {
                $amount = $amount + $fsize;
            }
        }
    }

    return $amount;
}

function GETLARGESTTOPIC()
{
    $directory = "../contents/";
    $dir_handle = opendir($directory);

    while ($file = readdir($dir_handle)) {

        if (is_file($directory.$file)){

            clearstatcache();
            $ftype = strtolower(substr($file,strlen($file)-3));
            $fsize = filesize($directory.$file);

            if ($ftype == "txt") {
                if ($fsize > $amount) {
                    $amount = $fsize;
                    $filename = $file;
                }
            }
        }
    }

    return $amount."#".$filename;
}

function GETFIRSTPOST()
{
    $ContentsDirectory = array();

    $directory = "../contents/";
    $dir_handle = opendir($directory);

    while ($file = readdir($dir_handle)) {

        if (is_file($directory.$file)){

            clearstatcache();
            $ftype = strtolower(substr($file,strlen($file)-3));

            if ($ftype == "txt") {

                $creationdate = filemtime(trim($directory.$file));
                array_push($ContentsDirectory,$creationdate."#".$directory.$file);
            }
        }
    }

    $ContentsDirectory = SORTPOSTS($ContentsDirectory);
    $ContentsDirectory = explode("#",$ContentsDirectory[sizeof($ContentsDirectory)-1]);
    return $ContentsDirectory[1];
}

function UNCOOKIE()
{
    setcookie("BITMIN","",time() - 3600);
}

function IS_STICKY($FILENAME)
{
    $FILENAME = trim($FILENAME);
    $tmpArray = @file($FILENAME);
    $tmpSubject = explode("#",$tmpArray[0]);
    if ($tmpSubject[4] == "IsSticky") {
        return TRUE;
    }else{
        return FALSE;
    }
}

function IS_CLOSED($FILENAME)
{
    $FILENAME = trim($FILENAME);
    $tmpArray = @file($FILENAME);
    $tmpSubject = explode("#",$tmpArray[0]);
    if (trim($tmpSubject[5]) == "IsClosed") {
        return TRUE;
    }else{
        return FALSE;
    }
}

function REMOVEEMPTYLINES($ARRAY)
{
    $tmpArray = array();
    $x = 0;
    
    while ($x <= sizeof($ARRAY)) {

        if (strlen(trim($ARRAY[$x])) > 1) {

            array_push($tmpArray,$ARRAY[$x]);

        }
        $x++;
    }
    return $tmpArray;
}

function convBOOL_TO_CHECKBOX($BOOLEANVALUE) {
    if ($BOOLEANVALUE) {
        return "checked";
    }else{
        return "";
    }
}

function convCHECKBOX_TO_BOOL($HTMLCHECKBOX) {
    if ($HTMLCHECKBOX == "checkbox") {
        return "true";
    }else{
        return "false";
    }
}

function USER_UNREGISTER() {

    setcookie("usr[name]",trim($HTTP_POST_VARS['txtUserName']),time()-31536000);
    setcookie("usr[pass]",$submitted_password,time()-31536000);
    setcookie("usr[stat]","activated",time()-31536000);

}

function TIME_CONVERTZONE($iTimestamp,$iHours) {
    /*
        Convert Times of Server
        to User desired time.
    */

    $iHours = $iHours * 3600;

    return $iTimestamp+$iHours;
}

function PASSWORD_GET($sFileName) {
    /*
        Get Hash from PasswordFile
    */
    $sHash = file($sFileName);
    $sHash = substr($sHash[1],2,strlen($sHash[1]));
    return trim($sHash);
}

function PASSWORD_WRITE ($sFileName, $sPasswordHash) {
    /*
        Write Password Hash to specified file.
    */
    $sBreachModule = "include \"../modules/bitboard_module_securitybreach.php\";";
    $fp = fopen($sFileName, "w") or Die("Couldn't open password file.");
    fwrite($fp,"<?php\r\n//$sPasswordHash\r\n");
    fwrite($fp,$sBreachModule);
    fwrite($fp,"\r\n?>\r\n");
    fclose($fp);
}



?>
