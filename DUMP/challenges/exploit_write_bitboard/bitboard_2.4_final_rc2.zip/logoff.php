<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2003 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


// Load all public variables from include.
include "./include/bitboard_configuration.php";

// Load functions library
include "./include/bitboard_functionslibrary.php";

// Unset cookies for log...
USER_UNREGISTER();

// Show general header...
include "./include/bitboard_head_general.php";

// Show Status
include "./include/bitboard_status_loggedoff.php";

// Print Copyrightstamp
include "./include/bitboard_copyrightstamp.php";

?>
