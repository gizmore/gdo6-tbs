<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2003 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


// Load all public variables from include.
include "./include/bitboard_configuration.php";

// Load functions library
include "./include/bitboard_functionslibrary.php";

/*
                 BEGIN SHOW LOGIN
*/


if (!$HTTP_POST_VARS['cmdSubmit']) {

    // Show general Header
    include "./include/bitboard_head_general.php";

    // Show Login Formular
    include "./include/bitboard_login_formular.php";

}else{

    /*
                TRY TO REGISTER USER
    */
    $pwdFile = strtolower(trim($HTTP_POST_VARS['txtUserName'])).".php";
    if (file_exists("./profiles/pwd_".$pwdFile)) {

        // Profile exists... compare passwords
        $submitted_password = crypt(trim($HTTP_POST_VARS['txtPassword']),"BS");
        $stored_password = PASSWORD_GET("./profiles/pwd_".$pwdFile);

        if ($submitted_password == $stored_password) {

            // Set cookies for log...
            setcookie("usr[name]",trim($HTTP_POST_VARS['txtUserName']),time()+31536000);
            setcookie("usr[pass]",$submitted_password,time()+31536000);
            setcookie("usr[stat]","activated",time()+31536000);
            
            // Show general Header
            include "./include/bitboard_head_general.php";
            // Show Okay...
            include "./include/bitboard_status_loggedin.php";

        }else{

            // The Password was wrong...

            // Show general Header
            include "./include/bitboard_head_general.php";
            // Show wrong pass status...
            include "./include/bitboard_status_nopass.php";
            
        }


    }else{

        // Show general Header
        include "./include/bitboard_head_general.php";
        // A Profile doesn't even exist yet...
        include "./include/bitboard_status_noprofile.php";

    }

}

// Print Copyrightstamp
include "./include/bitboard_copyrightstamp.php";

?>
