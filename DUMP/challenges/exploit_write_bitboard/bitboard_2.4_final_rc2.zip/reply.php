<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


// Load all public variables from include.
include "./include/bitboard_configuration.php";

// Load functions library
include "./include/bitboard_functionslibrary.php";

// Load Header.
include "./include/bitboard_head_post.php";

$REPLYTO = trim($HTTP_GET_VARS['REPLYTO']);

if(!isset($REPLYTO)){
    die ($BITBOARD_ERRNOREPLY);
}else{
    $tmpSubjArr = file ("./contents/".trim($REPLYTO).".txt");
    $tmpReSubj = explode("#",$tmpSubjArr[0]);
    $RESUBJECT = "RE: ".$tmpReSubj[0];
}

// Check for post try...
if($HTTP_POST_VARS['cmdSubmit']){

///////////////////////////////////////// SUBMIT HAS BEEN CLICKED!!! ///////////

    // Load BadmouthFilter
    include "./modules/bitboard_module_badmouthfilter.php";

    // Get Variables from Global Scope HTTP Var
    if (isset($HTTP_COOKIE_VARS['usr'])) {

        // User is a registered, logged in user...
        $usr = $HTTP_COOKIE_VARS['usr'];
        $txtUserName = $usr['name'];

        // Protect from "CookieHijacking" on registered users.
        $pwdFile = strtolower(trim($txtUserName)).".php";
        $stored_password = PASSWORD_GET("./profiles/pwd_".$pwdFile);

        if ($usr['pass'] != $stored_password) {
            $ERRORFLAG = " *NOPASS";
        }


    }else{

        // User is not logged in.
        $txtUserName = $HTTP_POST_VARS['txtUserName'];

        // Verify that theres really no profile for this username...
        $pwdFile = strtolower(trim($txtUserName)).".php";
        if (file_exists("./profiles/pwd_".$pwdFile)) {
            $ERRORFLAG = " *NOPASS";
        }


    }

    $txtSubject = $HTTP_POST_VARS['txtSubject'];
    $txtMessage = $HTTP_POST_VARS['txtMessage'];

    // Check if everything is filled.
    if (empty($txtUserName))
    {
        $ERRORFLAG=$BITBOARD_ERRMISSINGFIELD." *NAME";
    }
    if (empty($txtSubject))
    {
        $ERRORFLAG=$BITBOARD_ERRMISSINGFIELD." *SUBJECT";
    }
    if (empty($txtMessage))
    {
        $ERRORFLAG=$BITBOARD_ERRMISSINGFIELD." *MESSAGE";
    }

    // Load Banning Filter...
    include "./modules/bitboard_module_checkbans.php";

    // Check If User has a profile...
    include "./modules/bitboard_module_checkprofiles.php";

    // There was no error. Prepare writing file...
    if (empty($ERRORFLAG))
     {

            include "./include/bitboard_dopost.php";

            // Post Entry to topicfile.
            $fp = fopen("./contents/".$REPLYTO.".txt","a");
            if(!$fp) {
                echo $BITBOARD_ERRCREATETOPIC;
                exit;
            }

            fwrite($fp, $line);
            if(!fclose($fp)) {
                echo $BITBOARD_ERRCREATETOPIC;
                exit;
            }
            
            // "POSTED SUCCESSFULLY"
            include "./include/bitboard_status_postokay.php";
            include "./include/bitboard_copyrightstamp.php";
            
            // Log File if needed.
            if ($BITBOARD_ENABLELOGS){
                // Load Logging Function.
                include "./modules/bitboard_module_logging.php";
            }

            // If wanted, notify about this post by mail.
            if ($BITBOARD_MAILADMINS){
                include "./modules/bitboard_module_emailtheadmins.php";
            }

    } else {

            // "ERROR OCCURED"
            if ($ERRORFLAG ==  " *BANNED") {
                // BANNED USER.
                include "./include/bitboard_status_banned.php";
            }else{
                if ($ERRORFLAG == " *NOPASS") {
                    // NO PASSWORD.
                    include "./include/bitboard_status_nopass.php";
                }else{
                    // SOME OTHER MISTAKE.
                    include "./include/bitboard_status_postmiss.php";
                    include "./include/bitboard_copyrightstamp.php";
                }
            }

    }

}else{

///////////////////////// SUBMIT HAS NOT YET BEEN CLICKED. SHOW FORM! //////////

    include "./include/bitboard_newtopic_formular.php";
    include "./include/bitboard_copyrightstamp.php";

}
?>
</body>
</html>
