<?php
///////////////////////////////////////////////////////////////////////////
//
//                                                   BiTSHiFTERS BiTBOARD
//                              COPYRIGHT 2000 - 2002 The BiTSHiFTERS SDC
//                                                   All Rights Reserved.
//
//  For any copyright or licensing questions, please refer to the
//  End User License Agreement which is included with this Software
//  Package, or head to www.bitshifters.bl.am and read the licenses.
///////////////////////////////////////////////////////////////////////////


// Load all public variables from include.
include "./include/bitboard_configuration.php";

// Load functions library
include "./include/bitboard_functionslibrary.php";

// Check Dependency Variable
if (isset($HTTP_GET_VARS['DATEIN'])) {
    $USETOPIC = $HTTP_GET_VARS['DATEIN'];
}else{
    $USETOPIC = "";
}

// If site is not startet with argument DATEIN...
if (empty($USETOPIC)) {

    /*
                     BEGIN SHOW ALL AVAILABLE TOPICS
    */

    // Show Head for Topic List
    include "./include/bitboard_head_topics.php";
    
    // List All Availabvle Topics
    include "./include/bitboard_walktopics.php";

    // Print Copyrightstamp
    include "./include/bitboard_copyrightstamp.php";

}else{

    /*
                     BEGIN SHOW SELECTED THREAD
    */

    // Show Head for Thread List
    if (IS_CLOSED("./contents/$USETOPIC.txt")) {
        include "./include/bitboard_head_thread_closed.php";
    }else{
        include "./include/bitboard_head_thread.php";
    }

    // List All Available Threads
    if ($BITBOARD_USENEWTHREADWALK) {
        include "./include/bitboard_walkthreads2.2.php";
    }else{
        include "./include/bitboard_walkthreads.php";
    }

    // Print Copyright Stamp
    include "./include/bitboard_copyrightstamp.php";

}

?>
<br>
</body>
</html>
