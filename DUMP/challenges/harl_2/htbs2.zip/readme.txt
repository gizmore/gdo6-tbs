Some might argue that this should go in the Specials section, I did consider it but it is primarily a crackme just that the gui is a little different thats all.

This is an evil little beastie and all in 62 lines of code.
It will tell you the password when you have solved it, good luck.


and....
No!!! i did not forget to put the program in the zip.