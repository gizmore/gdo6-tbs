Filetypes Challenge by Saemon for www.bright-shadows.net
========================================================

Just get the password for each part then put the passes together and extract the final file with the solution.

Don't try to bruteforce the final part - the password is very long.

Good luck!